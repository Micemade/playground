<?php
/**
 * Utility functions for the Mosaic Product Layouts plugin
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */

declare( strict_types=1 );

namespace Micemade\MosaicProductLayouts;

use function get_bloginfo;
use function get_post;
use function parse_blocks;
use function admin_url;
use function esc_html;
use function esc_url;
use function esc_html__;
use function __;
use function printf;
use function apply_filters;
use function array_map;
use function array_filter;
use function array_reduce;
use function array_merge;
use function array_diff;
use function array_diff_key;
use function array_flip;
use function glob;
use function basename;
use function scandir;
use function is_dir;
use function version_compare;
use function preg_match;
use function preg_replace;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Utility class providing helper methods for Mosaic Product Layouts plugin.
 *
 * @package Micemade\MosaicProductLayouts
 */
class Utils {

	/**
	 * Retrieves and filters the Micemade WooCommerce block names.
	 * Converts block names from 'micemade-products-grid' format to 'micemade/products-grid' format.
	 * Applies a filter 'mosaic_product_layouts_names' to the resulting block names array.
	 *
	 * @return array The filtered array of block names.
	 */
	public function get_block_names(): array {
		$mm_blocks_list = $this->get_blocks_list();
		$mm_block_names = array_map(
			static function( string $block ): string {
				return (string) preg_replace( '/-/', '/', $block, 1 );
			},
			$mm_blocks_list
		);

		return apply_filters( 'mosaic_product_layouts_names', $mm_block_names );
	}



	/**
	 * Gets the list of available blocks.
	 *
	 * Retrieves an array containing all registered blocks for the plugin.
	 *
	 * @since 1.0.0
	 * @return array List of available blocks
	 * @throws \RuntimeException If blocks directory is not readable.
	 */
	public function get_blocks_list(): array {

		try {
			// Get the 'build' directory path.
			$blocks_dir_path = MOSAIC_PRODUCT_LAYOUTS_DIR . 'build';

			if ( ! file_exists( $blocks_dir_path ) || ! is_readable( $blocks_dir_path ) ) {
				throw new \RuntimeException( 'Blocks directory is not readable' );
			}

			// Additional security checks.
			if ( ! is_dir( $blocks_dir_path ) ) {
				throw new \RuntimeException( 'Invalid blocks directory path' );
			}

			// Get all directories in the 'build' directory and filter out empty directories.
			$folders = array_filter(
				glob( $blocks_dir_path . '/*' ),
				function( $blocks_dir_path ) {
					// Check if the directory is not empty.
					return is_dir( $blocks_dir_path ) && ! empty( array_diff( scandir( $blocks_dir_path ), array( '..', '.' ) ) );
				}
			);

			return array_filter(
				array_map( 'basename', $folders ),
				static function( string $name ): bool {
					return (bool) preg_match( '/^micemade/', $name );
				}
			);
		} catch ( \RuntimeException $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				wp_debug_log(
					sprintf(
						'MPL Error in parse_block_json: %s',
						$e->getMessage()
					)
				);
			}
			// Return empty array as fallback.
			return array();
		}

	}

	/**
	 * Flattens an array of blocks by removing nested inner blocks and returning a single-level array of blocks.
	 *
	 * This function iterates over the provided blocks array and for each block, it adds a version of the block
	 * that excludes its 'innerBlocks' key to the return array. If a block contains 'innerBlocks', this function
	 * recursively flattens those inner blocks and merges them into the return array.
	 *
	 * @param array $blocks An array of blocks, each block may contain nested 'innerBlocks'.
	 * @return array A flattened array of blocks, where all inner blocks are included at the top level.
	 */
	public function flatten_blocks( array $blocks ): array {

		if ( empty( $blocks ) ) {
			return array();
		}
		return array_reduce(
			$blocks,
			function( array $carry, array $block ): array {
				$current_block = array_diff_key(
					$block,
					array_flip( array( 'innerBlocks' ) )
				);

				array_push( $carry, $current_block );

				if ( isset( $block['innerBlocks'] ) ) {
					return array_merge(
						$carry,
						$this->flatten_blocks( $block['innerBlocks'] )
					);
				}

				return $carry;
			},
			array()
		);
	}

	/**
	 * Compare the current WordPress version with a given version. It's a wrapper around `version-compare`
	 * that additionally takes into account the suffix (like `-RC1`).
	 * For example: version 6.3 is considered lower than 6.3-RC2, so you can do
	 * wp_version_compare( '6.3', '>=' ) and that will return true for 6.3-RC2.
	 *
	 * From: /woocommerce-blocks/src/Utils/Utils.php.
	 *
	 * @param string      $version The version to compare against.
	 * @param string|null $operator Optional. The comparison operator. Defaults to null.
	 * @return bool|int Returns true if the current WordPress version satisfies the comparison, false otherwise.
	 */
	public static function wp_version_compare( string $version, ?string $operator = null ): bool {
		$wp_version = (string) get_bloginfo( 'version' );
		if ( preg_match( '/^([0-9]+\.[0-9]+)/', $wp_version, $matches ) ) {
			$wp_version = (string) (float) $matches[1];
		}

		$sanitized_current = preg_replace( '/[^0-9a-zA-Z\.]+/i', '.', $wp_version );
		$sanitized_version = preg_replace( '/[^0-9a-zA-Z\.]+/i', '.', $version );

		return version_compare(
			(string) $sanitized_current,
			(string) $sanitized_version,
			$operator
		);
	}


	/**
	 * Checks if WooCommerce is installed and active.
	 *
	 * @return bool
	 */
	public function is_woocommerce_active():bool {
		return class_exists( 'WooCommerce' ) || defined( 'WC_PLUGIN_FILE' ) || defined( 'WC_ABSPATH' );
	}

	/**
	 * Admin notice for missing WooCommerce plugin.
	 *
	 * @return void
	 */
	public function admin_notice_no_woocommerce():void {
		$title       = __( 'Mosaic Product Layouts Notice', 'mosaic-product-layouts' );
		$description = __( 'Mosaic Product Layouts is a plugin for creating beautiful layouts with WooCommerce products, using the block editor. To enable the Mosaic Product Layouts plugin, please install and activate the WooCommerce plugin.', 'mosaic-product-layouts' );

		$wc_install_url = admin_url( 'plugin-install.php?s=woocommerce&tab=search&type=term' );
		$wc_page_url    = 'https://wordpress.org/plugins/woocommerce/';

		$wc_install_text = __( 'Install WooCommerce', 'mosaic-product-layouts' );
		$wc_page_text    = __( 'WooCommerce plugin page', 'mosaic-product-layouts' );

		printf(
			'<div class="notice notice-info is-dismissible mosaic-product-layouts-admin-notice"><div class="mosaic-product-layouts-admin-notice-wrapper" style="margin-bottom: 15px;"><h2>%1$s</h2><p>%2$s</p><a target="_self" class="button-primary button" href="%3$s" style="margin-right: 10px;">%4$s</a><a target="_self" class="button-secondary button" href="%5$s">%6$s</a></div></div>',
			esc_html( $title ),
			esc_html( $description ),
			esc_url( $wc_install_url ),
			esc_html( $wc_install_text ),
			esc_url( $wc_page_url ),
			esc_html( $wc_page_text )
		);
	}
}
