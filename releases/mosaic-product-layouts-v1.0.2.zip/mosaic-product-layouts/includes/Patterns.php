<?php
/**
 * Patterns class for the Mosaic Product Layouts plugin.
 *
 * This class is responsible for handling block patterns and synced patterns (reusable blocks)
 * for the Mosaic Product Layouts plugin.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */

declare(strict_types=1);

namespace Micemade\MosaicProductLayouts;

use function parse_blocks;
use function array_merge;
use function array_filter;
use function array_values;
use function array_unique;
use function get_post;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Patterns
 *
 * Handles block patterns and synced patterns (reusable blocks) for the Mosaic Product Layouts plugin.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */
class Patterns {

	/**
	 * The Utils class.
	 *
	 * @var Utils
	 */
	private Utils $utils;

	/**
	 * Initialize the class.
	 *
	 * Instantiates the Utils class dependency.
	 * Supports optional dependency injection for improved testability.
	 *
	 * @param Utils|null $utils Optional. Utils class instance. Default null.
	 * @since 1.0.0
	 */
	public function __construct( ?Utils $utils = null ) {
		$this->utils = $utils ?? new Utils();
	}

	/**
	 * Extracts pattern slugs from template blocks.
	 *
	 * @param array $template_blocks Array of template blocks to process.
	 * @return array Array of pattern slugs.
	 */
	public function extract_pattern_slugs( array $template_blocks ): array {
		return array_values(
			array_filter(
				array_map(
					static function( $block ) {
						return $block['blockName'] === 'core/pattern' && isset( $block['attrs']['slug'] )
							? $block['attrs']['slug']
							: null;
					},
					$template_blocks
				)
			)
		);
	}

	/**
	 * Gets template part slugs from patterns.
	 *
	 * @param array $pattern_slugs Array of pattern slugs.
	 * @return array Array of template part slugs found in patterns.
	 */
	public function get_template_part_slugs_from_patterns( array $pattern_slugs ): array {
		$template_part_slugs = array();

		if ( empty( $pattern_slugs ) ) {
			return $template_part_slugs;
		}

		foreach ( $pattern_slugs as $slug ) {
			if ( empty( $slug ) ) {
				continue;
			}

			$pattern_content = $this->get_pattern_content( $slug );
			if ( ! empty( $pattern_content ) ) {
				$blocks = parse_blocks( $pattern_content );
				$pattern_template_parts = $this->extract_template_part_slugs( $blocks );
				$template_part_slugs = array_merge( $template_part_slugs, $pattern_template_parts );
			}
		}

		return array_unique( $template_part_slugs );
	}

	/**
	 * Gets synced pattern blocks (reusable blocks) from an array of blocks.
	 *
	 * Given an array of blocks, this function iterates over them and for each 'core/block' block with a 'ref' attribute,
	 * it adds the content of the post with that ID to the return array. The content is parsed into blocks and flattened
	 * to a single level using the flatten_blocks function.
	 *
	 * @param array $blocks An array of blocks, where each block may have a 'ref' attribute pointing to a post ID.
	 * @return array A single-level array of blocks, where each block is from the content of a post referenced by a 'core/block' block.
	 */
	public function get_synced_pattern_blocks( array $blocks ): array {
		$synced_pattern_blocks = array();
		foreach ( $blocks as $block ) {
			if ( ! is_array( $block ) ||
				! isset( $block['blockName'] ) ||
				'core/block' !== $block['blockName'] ||
				! isset( $block['attrs']['ref'] ) ) {
				continue;
			}

			$post = get_post( $block['attrs']['ref'] );
			if ( ! $post || empty( $post->post_content ) ) {
				continue;
			}

			$synced_pattern_blocks[] = parse_blocks( $post->post_content );
		}

		if ( empty( $synced_pattern_blocks ) ) {
			return array();
		}

		return $this->utils->flatten_blocks( $synced_pattern_blocks[0] );
	}

	/**
	 * Gets the content of a pattern by its slug.
	 *
	 * @param string $pattern_slug The pattern slug (e.g., 'ollie/template-page-full').
	 * @return string|null The pattern content or null if not found.
	 */
	private function get_pattern_content( string $pattern_slug ): ?string {
		// WordPress stores patterns in the registry
		$pattern_registry = \WP_Block_Patterns_Registry::get_instance();

		if ( ! $pattern_registry->is_registered( $pattern_slug ) ) {
			return null;
		}

		$pattern = $pattern_registry->get_registered( $pattern_slug );

		return isset( $pattern['content'] ) ? $pattern['content'] : null;
	}

	/**
	 * Extracts template part slugs from blocks.
	 *
	 * @param array $blocks Array of blocks to process.
	 * @return array Array of template part slugs.
	 */
	private function extract_template_part_slugs( array $blocks ): array {
		return array_values(
			array_filter(
				array_map(
					static function( $block ) {
						return $block['blockName'] === 'core/template-part' && isset( $block['attrs']['slug'] )
							? $block['attrs']['slug']
							: null;
					},
					$blocks
				)
			)
		);
	}

}// phpcs:ignoreFile
