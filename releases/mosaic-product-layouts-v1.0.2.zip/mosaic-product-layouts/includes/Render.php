<?php
/**
 * Render class for the Mosaic Product Layouts plugin.
 *
 * This class is responsible for rendering HTML markup for the Mosaic Product Layouts plugin.
 * It includes methods for rendering individual products, product grids, and category grids.
 * The frontend rendering is done using React Grid Layout.
 * HTML markup created by this class is used only for SEO purposes and is not visible once the React Grid Layout is loaded.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */

declare(strict_types=1);

namespace Micemade\MosaicProductLayouts;

// WordPress functions.
use function get_block_wrapper_attributes;
use function get_term_by;
use function get_term_link;
use function get_term_meta;
use function wp_get_attachment_image_src;
use function wp_get_attachment_image_srcset;
use function wp_get_attachment_image_sizes;
use function wp_kses_data;
use function wp_kses_post;
use function wp_json_encode;
use function apply_filters;

// WooCommerce functions.
use function wc_get_product;
use function wc_get_products;
use function wc_placeholder_img_src;
use function wc_get_image_size;

// WP Types.
use WP_Term;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Render class for Mosaic Product Layouts
 *
 * @package Micemade\MosaicProductLayouts
 */
class Render {

	/**
	 * Renders a single product.
	 *
	 * @param array $attributes Block attributes.
	 * @return string Rendered block output.
	 */
	public function micemade_product_render( array $attributes ): string {

		// Block wrapper attributes (HTML tag attributes).
		$block_wrapper_atts = get_block_wrapper_attributes( $this->extra_attributes( $attributes ) );

		$product_id = isset( $attributes['querySettings']['id']['value'] ) ? $attributes['querySettings']['id']['value'] : null;
		if ( ! $product_id ) {
			return '';
		}
		$product = wc_get_product( $product_id );
		if ( ! $product || is_wp_error( $product ) ) {
			return '';
		}

		// Layouts to build items.
		if ( ! isset( $attributes['savedLayouts'] ) || empty( $attributes['savedLayouts'] ) ) {
			return '';
		}
		$layouts = $this->decode_layouts( $attributes['savedLayouts'] );
		$items   = $layouts['Desktop'] ?? array();

		// Convert items to array if it's an object.
		if ( is_object( $items ) ) {
			$items = (array) $items;
		}

		usort(
			$items,
			function( $a, $b ) {
				$item_a = str_replace( 'item-', '', $a['i'] );
				$item_b = str_replace( 'item-', '', $b['i'] );
				return $item_a <=> $item_b;
			}
		);

		// Get grid spacing to set the static grid gap.
		$items_margin = $attributes['layoutSettings']['itemsMargin'] ?? null;
		$grid_gap     = $items_margin . 'px ' . $items_margin . 'px';

		// Start output of the block.
		$output = '<section ' . wp_kses_data( $block_wrapper_atts ) . '>'; // Block wrapper start.

		$output .= '<div class="react-grid-layout micemade-wc-grid placeholder" style="gap: ' . $grid_gap . '">';

		if ( ! isset( $attributes['productElementSettings']['elements'] ) ) {
			return '';
		}

		foreach ( $items as $key => $value ) {

			// Retrieve the element based on the item's 'i' value. Returns element settings array.
			$elements = array_filter(
				$attributes['productElementSettings']['elements'],
				function( $element ) use ( $value ) {
					return sanitize_key( $element['i'] ) === sanitize_key( $value['i'] );
				}
			);

			// Get the first matching element (if any).
			$elements = ! empty( $elements ) ? reset( $elements ) : null;

			// Flatten the element settings to only include the desired properties.
			$elm_settings = array();
			if ( $elements ) {
				$elm_settings = array(
					'i'       => $elements['i'],
					'id'      => $elements['id'],
					'name'    => $elements['name'],
					'visible' => $elements['visible'],
					'sort'    => $elements['sort'],
				);
			};
			$elem_name = isset( $elm_settings['id'] ) ? $elm_settings['id'] : null;
			if ( ! $elem_name ) {
				continue;
			}
			$elem_name_style = $elem_name . 'Style';
			$style_sett      = $attributes['productElementSettings'][ $elem_name_style ];
			$z_index         = $attributes['itemZindexes'][ $value['i'] ];

			$valign          = $style_sett['valign'] ?? null;
			$valign          = ( $valign && 'top' === $valign ) ? 'flex-start' : '';
			$align_items     = ( $valign && 'bottom' === $valign ) ? 'flex-end' : 'center';
			$justify_content = $style_sett['align'] ?? null;
			$back_color      = $style_sett['backColor'] ?? null;
			$color           = $style_sett['color'] ?? null;
			$fluid_font      = $style_sett['fluidFont'] ?? null;
			$padding         = $style_sett['padding'] ?? null;
			$border          = $style_sett['border'] ?? null;
			$border_radius   = $style_sett['radius'] ?? null;

			$wrapper_style = 'style="align-items: ' . esc_attr( $align_items ) . ';justify-content: ' . esc_attr( $justify_content ) . ';background: ' . esc_attr( $back_color ) . ';color: ' . esc_attr( $color ) . ';border-width: ' . esc_attr( $border['width'] ?? null ) . ';border-color: ' . esc_attr( $border['color'] ?? null ) . ';border-style: ' . esc_attr( $border['style'] ?? null ) . ';border-radius: ' . esc_attr( $border_radius ) . ';"';

			// Opening and closing tags for reacit-grid-item div.
			$item_open  = '<div class="react-grid-item product-element' . ( $justify_content ? esc_attr( ' align-' . $justify_content ) : ' ' ) . esc_attr( ' ' . sanitize_html_class( $elem_name ) ) . '" style="z-index: ' . $z_index . ';">';
			$item_close = '</div>'; // end react-grid-item.

			// Title.
			if ( 'item-0' === $value['i'] ) {
				$output    .= $item_open;
				$title_aria = __( 'View ', 'mosaic-product-layouts' ) . esc_attr( $product->get_name() );
				$output    .= '<header class="elements-wrapper" ' . wp_kses_data( $wrapper_style ) . '>';
				$output    .= '<h4 class="name" style="text-align: ' . esc_attr( $style_sett['align'] ) . '"><a href="' . esc_url( $product->get_permalink() ) . '" title="' . esc_attr( $title_aria ) . ' aria-label="' . esc_attr( $title_aria ) . '">' . esc_html( $product->get_name() ) . '</a></h4>';
				$output    .= '</header>';
				$output    .= $item_close;
				// Price.
			} elseif ( 'item-1' === $value['i'] ) {
				$output .= $item_open;
				$output .= '<div class="elements-wrapper" ' . wp_kses_data( $wrapper_style ) . '>';
				$output .= wp_kses_post( $product->get_price_html() );
				$output .= '</div>';
				$output .= $item_close;
				// Add to cart.
			} elseif ( 'item-2' === $value['i'] ) {
				$output        .= $item_open;
				$output        .= '<div class="elements-wrapper" ' . wp_kses_data( $wrapper_style ) . '>';
				$output        .= '<div class="add-to-cart-wrapper">';
				$title_aria_add = __( 'Add ', 'mosaic-product-layouts' ) . esc_attr( $product->get_name() ) . __( ' to cart', 'mosaic-product-layouts' );
				$output        .= '<a role="button" class="micemade-add-to-cart" href="' . esc_url( $product->add_to_cart_url() ) . '" aria-label="' . esc_attr( $title_aria ) . '" title="' . esc_attr( $title_aria ) . '">' . esc_html( $product->add_to_cart_text() ) . '</a>';
				$output        .= '</div></div>';
				$output        .= $item_close;
				// Featured image.
			} elseif ( 'item-3' === $value['i'] ) {
				$output .= $item_open;
				$output .= '<figure class="product-featured-image" ' . wp_kses_data( $wrapper_style ) . '>';
				$output .= '<div class="overlay"></div>';
				$output .= '<div class="overlay border"></div>';
				$size    = $attributes['featuredImageSize'] ?? 'full';
				$output .= $product->get_image( $size );
				$output .= '</figure>';
				$output .= $item_close;
				// Short description.
			} elseif ( 'item-4' === $value['i'] ) {
				$output .= $item_open;
				$output .= '<div class="elements-wrapper" ' . wp_kses_data( $wrapper_style ) . '>';
				$output .= '<div class="excerpt">';
				$output .= $product->get_short_description();
				$output .= '</div></div>';
				$output .= $item_close;
			}
		}

		$output .= '</div>'; // end react-grid-layout.
		$output .= '</section>'; // Block wrapper end.

		return wp_kses_post( $output );
	}

	/**
	 * Renders a products grid.
	 *
	 * @param array $attributes Block attributes.
	 * @return string Rendered block output.
	 */
	public function micemade_products_grid_render( array $attributes ): string {

		// Block wrapper attributes (HTML tag attributes).
		$block_wrapper_atts = get_block_wrapper_attributes( $this->extra_attributes( $attributes ) );

		// Layouts to build items.
		if ( ! isset( $attributes['savedLayouts'] ) || empty( $attributes['savedLayouts'] ) ) {
			return '';
		}
		$layouts = $this->decode_layouts( $attributes['savedLayouts'] );
		$items   = $layouts['Desktop'] ?? array();

		// Convert items to array if it's an object.
		if ( is_object( $items ) ) {
			$items = (array) $items;
		}

		// Get grid spacing to set the static grid gap.
		$items_margin = $attributes['gridSettings']['itemsMargin'] ?? null;

		// Get products.
		$wc_items_data = array();
		if ( $attributes['querySettings']['handPicked'] ?? null ) {
			$wc_items_data = $attributes['wcItemsMap'];
		} else {
			$wc_items_data = $this->wc_items_data_products( $attributes, $items );
		}

		// Start output of the block.
		$output  = '<section ' . wp_kses_data( $block_wrapper_atts ) . '>'; // Block wrapper start.
		$output .= '<div class="react-grid-layout micemade-wc-grid placeholder" style="gap: ' . esc_attr( $items_margin ) . 'px">';

		foreach ( $items as $key => $value ) {

			$matched_wc_item_id = '';
			foreach ( $wc_items_data as $wc_item_i => $wc_data ) {
				if ( $wc_item_i === $value['i'] ) {
					$matched_wc_item_id = $wc_data[0];
				}
			}
			// Get product.
			$product = wc_get_product( $matched_wc_item_id );
			if ( ! $product || is_wp_error( $product ) ) {
				continue;
			}

			$output .= '<div class="react-grid-item product">';

			$output .= '<div class="product-wrapper">';
			$output .= '<figure class="product-featured-image">';
			$output .= $product->get_image( $attributes['featuredImageSize'] ?? null, array( 'alt' => esc_attr( $product->get_name() ) ) );
			$output .= '</figure>'; // end product-featured-image.

			$output .= '<div class="product-elements">';
			$output .= '<h4 class="name"><a href="' . esc_url( $product->get_permalink() ) . '" aria-label="View ' . esc_html( $product->get_name() ) . ' product details">' . esc_html( $product->get_name() ) . '</a></h4>';
			$output .= '<div class="price-and-add-to-cart">' . wp_kses_post( $product->get_price_html() ) . '</div>';
			$output .= '<a href="' . esc_url( $product->add_to_cart_url() ) . '" class="micemade-add-to-cart" role="button" aria-label="Add ' . esc_html( $product->get_name() ) . ' to cart">' . esc_html( $product->add_to_cart_text() ) . '</a>';
			$output .= '</div>'; // // // end product-elements

			$output .= '</div>'; // // end product-wrapper

			$output .= '</div>'; // end react-grid-item.
		}

		$output .= '</div>'; // end react-grid-layout.
		$output .= '</section>'; // Block wrapper end.

		return wp_kses_post( $output );

	}

	/**
	 * Renders a categories grid.
	 *
	 * @param array $attributes Block attributes.
	 * @return string Rendered block output.
	 */
	public function micemade_categories_grid_render( array $attributes ): string {

		// Layouts to build items.
		if ( ! isset( $attributes['savedLayouts'] ) || empty( $attributes['savedLayouts'] ) ) {
			return '';
		}
		$layouts = $this->decode_layouts( $attributes['savedLayouts'] );
		$items   = $layouts['Desktop'] ?? array();

		// Convert items to array if it's an object.
		if ( is_object( $items ) ) {
			$items = (array) $items;
		}

		// Categories mapped to grid items.
		$wc_items_data = array();
		if ( $attributes['querySettings']['handPicked'] ?? null ) {
			$wc_items_data = $attributes['wcItemsMap'];
		} else {
			$wc_items_data = $this->wc_items_data_categories( $attributes, $items );
		}
		

		// Get grid spacing to set the static grid gap.
		$items_margin = $attributes['gridSettings']['itemsMargin'] ?? null;

		// Start the output.
		$block_wrapper_atts = get_block_wrapper_attributes( $this->extra_attributes( $attributes ) );
		$output             = '<section ' . wp_kses_data( $block_wrapper_atts ) . '>'; // Block wrapper start.

		$output .= '<div class="react-grid-layout micemade-wc-grid placeholder" style="gap: ' . esc_attr( $items_margin ) . 'px">';

		foreach ( $items as $key => $value ) {

			$matched_wc_item_id = '';

			// Find the matched category ID from $wc_items_data array.
			// The structure of $wc_items_data array is:
			// array( 'item-0' => array( $category_id ), 'item-1' => array( $category_id ) ).
			if ( isset( $wc_items_data[ $value['i'] ] ) ) {
				$matched_wc_item_id = $wc_items_data[ $value['i'] ][0] ?? '';
			}

			if ( empty( $matched_wc_item_id ) ) {
				continue;
			}

			$category = get_term_by( 'id', $matched_wc_item_id, 'product_cat' );

			if ( ! $category || is_wp_error( $category ) ) {
				continue;
			}

			$output .= '<div class="react-grid-item product">';
			$output .= '<div class="product-wrapper">';

			$output .= '<figure class="product-featured-image">';
			$output .= $this->category_thumbnail( $category );
			$output .= '</figure>'; // // end product-featured-image

			$output    .= '<div class="product-elements">';
			$title_aria = __( 'View products in category ', 'mosaic-product-layouts' ) . esc_attr( $category->name );
			$output    .= '<h4 class="name"><a href="' . get_term_link( $category ) . '" title="' . esc_attr( $title_aria ) . '" aria-label="' . esc_attr( $title_aria ) . '">' . esc_html( $category->name ) . ' (' . esc_html( $category->count ) . ')</a></h4>';
			$output    .= '<div class="excerpt">' . esc_html( $category->description ) . '</div>';
			$output    .= '</div>'; // // end product-elements.
			$output    .= '</div>'; // // end product-wrapper.

			$output .= '</div>'; // end react-grid-item.
		}

		$output .= '</div>'; // end react-grid-layout.

		$output .= '</section>'; // Block wrapper end.

		return wp_kses_post( $output );
	}


	/**
	 * Generate extra HTML attributes for the block wrapper.
	 *
	 * @param array $attributes Block attributes saved for the block.
	 *
	 * @return array An associative array of extra block wrapper HTML attributes.
	 */
	private function extra_attributes( array $attributes ):array {
		return array(
			'class'               => 'micemade-wc-block',
			'data-block-id'       => isset( $attributes['id'] ) ? esc_attr( $attributes['id'] ) : null,
			'data-featured-img'   => isset( $attributes['featuredImageSize'] ) ? esc_attr( $attributes['featuredImageSize'] ) : null,
			'data-layouts'        => isset( $attributes['savedLayouts'] ) ? esc_attr( $attributes['savedLayouts'] ) : null,
			'data-wc-items-map'   => wp_json_encode( isset( $attributes['wcItemsMap'] ) ? $attributes['wcItemsMap'] : array() ),
			'data-elements'       => wp_json_encode( isset( $attributes['productElementSettings']['elements'] ) ? $attributes['productElementSettings']['elements'] : array() ),
			'data-query-settings' => wp_json_encode( isset( $attributes['querySettings'] ) ? $attributes['querySettings'] : array() ),
		);
	}

	/**
	 * Maps products to grid items.
	 *
	 * If handpicked is true, returns the $wcItemsMap array as is.
	 * Otherwise, gets products based on query settings and maps them to grid items.
	 *
	 * @param array $attributes Block attributes.
	 * @param array $items      Grid items.
	 *
	 * @return array An associative array, where each key is a grid item ID and value is an array with the product ID and product object.
	 */
	private function wc_items_data_products( array $attributes, array $items ): array {
		// Start arguments for products query.
		$args = array(
			'return'         => 'ids', // wc_get_products() returns an array of product IDs.
			'posts_per_page' => count( $items ),
			'fields'         => 'ids', // Only get IDs.
			'no_found_rows'  => true, // Skip pagination.
			'cache_results'  => true,
		);

		// Categories argument.
		$category_ids = array();
		if ( isset( $attributes['querySettings']['category'] ) ) {
			foreach ( $attributes['querySettings']['category'] as $key => $value ) {
				$category_ids[] = $value['value'];
			}
			$args['product_category_id'] = $category_ids;
		}
		// Get products based on arguments.
		$products = wc_get_products( $args );

		// For non-handpicked items, map products to grid items, into $wc_items_data array.
		return $this->prepare_queried_wc_items_data( $items, $products );
	}

	/**
	 * Maps categories to grid items.
	 *
	 * If handpicked is true, returns the $wcItemsMap array as is.
	 * Otherwise, gets categories based on query settings and maps them to grid items.
	 *
	 * @param array $attributes Block attributes.
	 * @param array $items      Grid items.
	 *
	 * @return array An associative array, where each key is a grid item ID and value is an array with the category ID .
	 */
	public function wc_items_data_categories( array $attributes, array $items ):array {

		$ordering = explode( '/', $attributes['querySettings']['ordering'] );
		$order_by = $ordering[0] ?? 'name';
		$order    = $ordering[1] ?? 'ASC';

		// Start arguments for categories query.
		$args = array(
			'fields'   => 'ids', // get_terms will return array of term IDs.
			'taxonomy' => 'product_cat',
			'number'   => count( $items ),
			'orderby'  => $order_by,
			'order'    => $order,
		);

		$terms = get_terms( $args );

		// For non-handpicked items, map terms (product_cat) to grid items, into $wc_items_data array.
		return $this->prepare_queried_wc_items_data( $items, $terms );
	}

	/**
	 * QUERIED WC items data for products or categories. Not for HANDPICKED items.
	 * Prepares WooCommerce items data by mapping query results (ID's) to grid items.
	 * Structure of $wc_items_data should be identical to $attributes['wcItemsMap']
	 *
	 * @param array $items      Grid items - each item is array, with 'i' key included.
	 * @param array $query_type Query results, either products or categories.
	 *
	 * @return array An associative array, where each key is a grid item ID and value is an array with the query result ID .
	 */
	private function prepare_queried_wc_items_data( array $items, array $query_type ): array {
		if ( empty( $items ) || empty( $query_type ) ) {
			return array();
		}
		// Sort items by their 'i' value.
		$wc_items_data = array();
		foreach ( $items as $key => $value ) {
			// Check if 'i' key exists in $value and $query_type has a value at $key.
			if ( isset( $value['i'] ) && isset( $query_type[ $key ] ) ) {
				$wc_items_data[ $value['i'] ] = array( $query_type[ $key ] );
			} else {
				// If missing key or value, continue to next iteration
				continue;
			}
		}
		return $wc_items_data;
	}

	/**
	 * Gets the thumbnail HTML for a product category.
	 *
	 * @param WP_Term $category The product category term object.
	 * @return string|null The thumbnail HTML markup, or null if no image is found.
	 */
	private function category_thumbnail( WP_Term $category ): string {
		if ( ! $category instanceof WP_Term ) {
			return '';
		}
		$small_thumbnail_size = apply_filters( 'subcategory_archive_thumbnail_size', 'woocommerce_thumbnail' );
		$dimensions           = wc_get_image_size( $small_thumbnail_size );
		$thumbnail_id         = get_term_meta( $category->term_id, 'thumbnail_id', true );

		if ( $thumbnail_id ) {
			$image        = wp_get_attachment_image_src( $thumbnail_id, $small_thumbnail_size );
			$image        = $image[0];
			$image_srcset = function_exists( 'wp_get_attachment_image_srcset' ) ? wp_get_attachment_image_srcset( $thumbnail_id, $small_thumbnail_size ) : false;
			$image_sizes  = function_exists( 'wp_get_attachment_image_sizes' ) ? wp_get_attachment_image_sizes( $thumbnail_id, $small_thumbnail_size ) : false;
		} else {
			$image        = wc_placeholder_img_src();
			$image_srcset = false;
			$image_sizes  = false;
		}

		if ( $image ) {
			// Prevent esc_url from breaking spaces in urls for image embeds.
			// Ref: https://core.trac.wordpress.org/ticket/23605.
			$image = str_replace( ' ', '%20', $image );

			// Add responsive image markup if available.
			if ( $image_srcset && $image_sizes ) {
				return '<img src="' . esc_url( $image ) . '" alt="' . esc_attr( $category->name ) . '" width="' . esc_attr( $dimensions['width'] ) . '" height="' . esc_attr( $dimensions['height'] ) . '" srcset="' . esc_attr( $image_srcset ) . '" sizes="' . esc_attr( $image_sizes ) . '" />';
			} else {
				return '<img src="' . esc_url( $image ) . '" alt="' . esc_attr( $category->name ) . '" width="' . esc_attr( $dimensions['width'] ) . '" height="' . esc_attr( $dimensions['height'] ) . '" />';
			}
		}
	}

	/**
	 * Decodes a JSON string containing layout data into an array.
	 *
	 * @param string $layouts_json JSON string containing layout data.
	 * @return array Decoded layout data as an array, or empty array if invalid.
	 */
	private function decode_layouts( string $layouts_json ): array {
		if ( empty( $layouts_json ) ) {
			return array();
		}

		$layouts = json_decode( $layouts_json, true );
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				wp_debug_log( 'Failed to decode layouts JSON: ' . json_last_error_msg() );
			}
			return array();
		}

		return $layouts;
	}
}// phpcs:ignoreFile