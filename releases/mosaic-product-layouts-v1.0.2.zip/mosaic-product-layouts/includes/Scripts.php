<?php
/**
 * Scripts class for the Mosaic Product Layouts plugin.
 *
 * This class is responsible for enqueuing scripts and styles for the block editor,
 * injecting global JavaScript variables, and managing block attributes.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */

declare( strict_types=1 );

namespace Micemade\MosaicProductLayouts;

use function wp_enqueue_style;
use function wp_register_style;
use function wp_register_script;
use function wp_create_nonce;
use function wp_json_encode;
use function wp_add_inline_script;
use function add_action;
use function filemtime;
use function wc_get_cart_url;
use function sanitize_key;
use function esc_url;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Handles the enqueuing of scripts and styles for the Mosaic Product Layouts plugin.
 *
 * This class manages the inclusion of JavaScript and CSS files, injects global JavaScript variables,
 * and provides utility methods for handling block attributes and WooCommerce integration.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */
class Scripts {

	/**
	 * Array with dependencies and the version, for the block editor scripts.
	 *
	 * @var array
	 */
	private array $asset_file;

	/**
	 * Instance of the Utils class, providing utility methods.
	 *
	 * @var Utils
	 */
	private Utils $utils;

	/**
	 * Constructor for the Scripts class.
	 *
	 * Initializes the asset_file property by including the asset file
	 * containing dependencies and version information for the block editor scripts.
	 * Supports optional dependency injection for improved testability.
	 *
	 * @param Utils|null $utils Optional. Utils class instance. Default null.
	 */
	public function __construct( ?Utils $utils = null ) {
		$this->asset_file = include MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/admin-editor.asset.php';
		$this->utils      = $utils ?? new Utils();
	}
	/**
	 * Enqueue plugin JS and CSS files, and inject global JS object 'mosaicProductLayouts' with default block attributes and WooCommerce status.
	 *
	 * @return void
	 */
	public function enqueue_scripts(): void {
		$default_block_attributes = array(
			'mosaicProductLayoutsDefaultAttrs' => $this->default_block_attributes(),
		);

		$wc_active_js_vars = $this->get_woocommerce_vars();

		// Merge default block attributes JS vars and WC vars.
		$base_inline_js = array_merge( $default_block_attributes, $wc_active_js_vars );

		$this->enqueue_main_script( $base_inline_js );
		$this->enqueue_dashicons();
	}


	/**
	 * Enqueue the main plugin JavaScript file and inject global JavaScript variables.
	 *
	 * This method enqueues the main plugin JavaScript file, which is the bundled
	 * JavaScript file containing the block editor scripts. It also injects global
	 * JavaScript variables, such as the default block attributes and WooCommerce status.
	 *
	 * @param array $inline_js Associative array with global JavaScript variables.
	 */
	private function enqueue_main_script( array $inline_js ): void {
		wp_enqueue_script(
			'mosaic-product-layouts',
			MOSAIC_PRODUCT_LAYOUTS_URL . 'assets/index.js',
			array(),
			(string) filemtime( MOSAIC_PRODUCT_LAYOUTS_DIR . 'assets/index.js' ),
			true
		);

		wp_add_inline_script(
			'mosaic-product-layouts',
			'window.mosaicProductLayouts = ' . wp_json_encode( $inline_js ) . ';',
			'before'
		);
	}

	/**
	 * Enqueue Dashicons CSS on the frontend.
	 *
	 * Since we use Dashicons in the frontend, we need to enqueue the CSS file
	 * on the frontend. We do this by hooking into the 'enqueue_block_assets' action.
	 *
	 * @return void
	 */
	private function enqueue_dashicons(): void {
		add_action(
			'enqueue_block_assets',
			static function(): void {
				wp_enqueue_style( 'dashicons' );
			}
		);
	}


	/**
	 * Get WooCommerce related JavaScript variables.
	 *
	 * Checks if WooCommerce is active, and if so, generates a nonce and cart URL
	 * for use in JavaScript. If WooCommerce is not active, schedules an admin notice
	 * and returns an inactive status.
	 *
	 * @return array Associative array containing WooCommerce status, nonce, and cart URL.
	 */
	private function get_woocommerce_vars(): array {
		if ( ! $this->utils->is_woocommerce_active() ) {
			add_action( 'admin_notices', array( $this->utils, 'admin_notice_no_woocommerce' ) );
			return array( 'wooActive' => false );
		}

		$nonce = wp_create_nonce( 'wc_store_api' );
		return array(
			'wooActive'   => true,
			'nonce'       => sanitize_key( $nonce ),
			'cartUrl'     => esc_url( wc_get_cart_url() ),
			'nonceAction' => 'wc_store_api',
		);
	}

	/**
	 * Add block attributes to inline script.
	 *
	 * Adds block attributes as window object property to the inline script of the block.
	 * The block attributes are available under the window object property
	 * with the name of [block handle + 'Atts' + content or template] (e.g. 'micemadeProductsGridAttsContent').
	 *
	 * @param string $block_name  Block handle.
	 * @param array  $block_attrs Block attributes.
	 * @param string $blocks_source Content or template.
	 */
	public function add_inline_script_attrs( string $block_name, array $block_attrs, string $blocks_source ):void {

		$handle_and_object_name = $this->inline_js_handle_and_object_name( $block_name );
		$handle = $handle_and_object_name[0];
		$object_name = $handle_and_object_name[1];

		wp_add_inline_script(
			$handle. '-view-script',
			/* translators: 1: Object name, 2: Content or template, 3: Block attributes */
			sprintf(
				'window.%1$sAtts%2$s = %3$s;',
				esc_attr( $object_name ), // object name (from block registred name).
				esc_attr( $blocks_source ), // content or template.
				wp_json_encode( $block_attrs ) // block attributes, json encoded.
			),
			'before'
		);
	}

	/**
	 * Creates the handle for the 'wp_inline_script' and the attributes object name.
	 * The attributes object name is created by splitting the block name into parts,
	 * and then capitalizing the first letter of each part.
	 *
	 * @param string $block_name The name of the block.
	 * @return array An array containing the handle and the attributes object name.
	 */
	private function inline_js_handle_and_object_name( string $block_name ): array {
		$handle = str_replace( '/', '-', $block_name );
		$parts  = preg_split( '/[-\/]/', $block_name, 3 );

		if ( false === $parts ) {
			return array( $handle, $block_name );
		}

		$attrs_object_name = $this->build_attrs_object_name( $parts );
		return array( $handle, $attrs_object_name );
	}


	/**
	 * Creates the attributes object name by capitalizing the first letter of each part.
	 *
	 * @param array $parts Block name parts.
	 * @return string Attributes object name.
	 */
	private function build_attrs_object_name( array $parts ): string {
		$attrs_object_name = $parts[0];
		if ( isset( $parts[1] ) ) {
			$attrs_object_name .= ucfirst( $parts[1] );
		}
		if ( isset( $parts[2] ) ) {
			$attrs_object_name .= ucfirst( $parts[2] );
		}
		return $attrs_object_name;
	}

	/**
	 * Retrieves the default attributes from blocks manifest file.
	 *
	 * @return string JSON-encoded string of default block attributes.
	 * @throws \RuntimeException If the manifest file is not found or invalid.
	 */
	public function default_block_attributes(): string {
		$manifest_file = MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/blocks-manifest.php';

		try {
			if ( ! file_exists( $manifest_file ) ) {
				throw new \RuntimeException( 'Manifest file not found' );
			}

			// Manifest dir repeated because $manifest_file could lead to File Inclusion.
			$manifest_data = require MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/blocks-manifest.php';
			$default_attrs = array();

			foreach ( $manifest_data as $block_name => $block_data ) {
				if ( isset( $block_data['attributes'] ) ) {
					$default_attrs[ $block_name ] = $block_data['attributes'];
				}
			}

			$encoded = wp_json_encode( $default_attrs );
			if ( false === $encoded ) {
				throw new \RuntimeException( 'Failed to encode block attributes' );
			}

			return $encoded;
		} catch ( \RuntimeException $e ) {
			// Log the error with context but don't expose sensitive information.
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				wp_debug_log(
					sprintf(
						'MPL Error in default_block_attributes: %s',
						$e->getMessage()
					)
				);
			}
			// Return empty JSON object as fallback.
			return '{}';
		}
	}

	/**
	 * Parses a block.json file and returns its configuration as an associative array.
	 *
	 * This function reads the contents of the block.json file located at the specified file path,
	 * decodes the JSON data, and returns it as an associative array. If the file cannot be read or
	 * the JSON is invalid, a RuntimeException is thrown.
	 *
	 * @param string $file_path The path to the block.json file.
	 * @return array The decoded JSON configuration from the block.json file.
	 * @throws \RuntimeException If the file cannot be read or contains invalid JSON.
	 */
	private function parse_block_json( string $file_path ): array {
		try {
			if ( ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
				throw new \RuntimeException( 'File not accessible' );
			}

			$content = file_get_contents( $file_path );
			if ( false === $content ) {
				throw new \RuntimeException( 'Unable to read file' );
			}

			$config = json_decode( $content, true );
			if ( json_last_error() !== JSON_ERROR_NONE ) {
				throw new \RuntimeException( 'Invalid JSON content' );
			}

			return $config;
		} catch ( \RuntimeException $e ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				wp_debug_log(
					sprintf(
						'MPL Error in parse_block_json: %s',
						$e->getMessage()
					)
				);
			}
			throw new \RuntimeException( 'Failed to parse block configuration' );
		}
	}

	/**
	 * Enqueue the block editor script.
	 *
	 * @return void
	 */
	public function block_editor_assets_file():void {
		wp_enqueue_script(
			'block-editor-script',
			MOSAIC_PRODUCT_LAYOUTS_URL . 'build/admin-editor.js',
			$this->asset_file['dependencies'],
			$this->asset_file['version'],
			false
		);
	}

	/**
	 * Registers and enqueues styles and scripts for the block editor.
	 *
	 * This function registers and enqueues the necessary CSS and JavaScript files
	 * for the block editor. It also modifies the editor settings to include the
	 * enqueued assets. The styles and scripts are versioned using their file
	 * modification times for cache busting.
	 *
	 * @param array $settings An array of existing block editor settings.
	 * @return array Modified block editor settings with added assets.
	 */
	public function block_editor_settings( array $settings ): array {
		$css_path    = 'assets/css/index.css';
		$css_version = (string) filemtime( MOSAIC_PRODUCT_LAYOUTS_DIR . $css_path );

		wp_register_style(
			'mosaic-product-layouts-css',
			MOSAIC_PRODUCT_LAYOUTS_URL . $css_path,
			array(),
			$css_version
		);
		wp_enqueue_style( 'mosaic-product-layouts-css' );

		wp_register_script(
			'mosaic-product-layouts-js',
			MOSAIC_PRODUCT_LAYOUTS_URL . 'build/admin-editor.js',
			$this->asset_file['dependencies'],
			(string) filemtime( MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/admin-editor.js' ),
			true
		);
		wp_enqueue_script( 'mosaic-product-layouts-js' );

		$settings['assets']['scripts']  = 'mosaic-product-layouts-js';
		$settings['assets']['styles'][] = 'mosaic-product-layouts-css';

		return $settings;
	}

}// phpcs:ignoreFile
