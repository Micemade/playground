<?php
/**
 * Templates class for the Mosaic Product Layouts plugin.
 *
 * This class is responsible for extracting and managing template and template part blocks
 * from the current template and its associated template parts.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */

declare(strict_types=1);

namespace Micemade\MosaicProductLayouts;

use function parse_blocks;
use function get_stylesheet;
use function get_block_template;
use function array_merge;
use function array_filter;
use function array_values;
use function sanitize_key;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Templates
 *
 * Handles the extraction and management of template and template part blocks
 * for the Mosaic Product Layouts plugin.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */
class Templates {

	/**
	 * The Utils class.
	 *
	 * @var Utils
	 */
	private Utils $utils;

	/**
	 * The Patterns class.
	 *
	 * @var Patterns
	 */
	private Patterns $patterns;

	/**
	 * Initialize the class.
	 *
	 * Instantiates the Utils and Patterns class dependencies.
	 * Supports optional dependency injection for improved testability.
	 *
	 * @param Utils|null     $utils    Optional. Utils class instance. Default null.
	 * @param Patterns|null  $patterns Optional. Patterns class instance. Default null.
	 * @since 1.0.0
	 */
	public function __construct( ?Utils $utils = null, ?Patterns $patterns = null ) {
		$this->utils = $utils ?? new Utils();
		$this->patterns = $patterns ?? new Patterns( $this->utils );
	}

	/**
	 * Returns all template, template part, patterns, and synced pattern blocks, flattened.
	 * Basically, any blocks not used for the content.
	 *
	 * @return array Array of blocks.
	 */
	public function get_blocks_from_templates() {

		// GET TEMPLATE BLOCKS.
		$template_blocks = $this->get_template_blocks();

		// Get template part slugs from template blocks.
		$template_part_slugs = $this->extract_template_part_slugs( $template_blocks );

		// Get pattern slugs from template blocks and extract template parts from patterns.
		$pattern_slugs = $this->patterns->extract_pattern_slugs( $template_blocks );
		$pattern_template_part_slugs = $this->patterns->get_template_part_slugs_from_patterns( $pattern_slugs );

		// Merge all template part slugs.
		$all_template_part_slugs = array_merge( $template_part_slugs, $pattern_template_part_slugs );

		// Get TEMPLATE PART BLOCKS using template part slugs.
		$template_part_blocks = $this->get_template_part_blocks( $all_template_part_slugs );

		// Merge template and template part blocks.
		$merged_blocks = array_merge( $template_blocks, $template_part_blocks );

		// Flatten blocks.
		$flatten_blocks = $this->utils->flatten_blocks( $merged_blocks );

		// Additionally, check for blocks from SYNCED PATTERNS (reusable blocks).
		// Flattening happens in 'get_synced_pattern_blocks' so merging bellow with other flattened blocks is ok.
		$spb = $this->patterns->get_synced_pattern_blocks( $flatten_blocks );

		// ALL TEMPLATE AND PARTS BLOCKS, FLATTENED.
		$all_template_blocks = array_merge( $flatten_blocks, $spb );

		return $all_template_blocks;
	}

	/**
	 * Returns the blocks from the current template.
	 *
	 * @return array The blocks from the current template.
	 */
	public function get_template_blocks():array {
		// $_wp_current_template_id also available in the global scope.
		global $_wp_current_template_content;

		if ( ! empty( $_wp_current_template_content ) ) {
			return parse_blocks( $_wp_current_template_content );
		}

		return array();
	}

	/**
	 * Extracts template part slugs from template blocks.
	 *
	 * Filters an array of template blocks to extract the slugs from template part blocks.
	 * Returns an array of template part slugs.
	 *
	 * @param array $template_blocks Array of template blocks to process.
	 * @return array Array of template part slugs.
	 */
	private function extract_template_part_slugs( array $template_blocks ): array {
		return array_values(
			array_filter(
				array_map(
					static function( $block ) {
						return $block['blockName'] === 'core/template-part' && isset( $block['attrs']['slug'] )
							? $block['attrs']['slug']
							: null;
					},
					$template_blocks
				)
			)
		);
	}

	/**
	 * Given an array of template part slugs, returns an array of blocks
	 * of the specified block names from all of the template parts.
	 *
	 * @param array $template_part_slugs Array of template part slugs.
	 *
	 * @return array Array of blocks from the template parts.
	 */
	private function get_template_part_blocks( array $template_part_slugs ):array {

		$template_part_blocks = array();

		if ( empty( $template_part_slugs ) ) {
			return $template_part_blocks;
		}

		foreach ( $template_part_slugs as $slug ) {
			if ( empty( $slug ) ) {
				continue;
			}

			$blocks = $this->extract_template_part_blocks( $slug );
			if ( ! empty( $blocks ) ) {
				$template_part_blocks = array_merge(
					$template_part_blocks,
					$blocks
				);
			}
		}
		return $template_part_blocks;
	}

	/**
	 * Extracts and returns all instances of a specified block from a given template part.
	 *
	 * @param string $block_name The name of the block to extract, e.g., 'core/paragraph'.
	 * @param string $template_part_slug The slug of the template part to search within, e.g., 'header'.
	 *
	 * @return array Array of blocks that match the specified block name within the template part.
	 */
	public function extract_template_part_blocks( string $template_part_slug ): array {

		if ( empty( $template_part_slug ) ) {
			return array();
		}

		// Get the template part content.
		$template = get_block_template(
			get_stylesheet() . '//' . sanitize_key( $template_part_slug ), // Sanitize the slug.
			'wp_template_part'
		);

		if ( ! $template ) {
			return array();
		}
		// Parse blocks.
		$blocks = parse_blocks( $template->content );
		// Flatten the blocks array to access inner blocks.
		$flatten_blocks = $this->utils->flatten_blocks( $blocks );

		// Filter the flattened blocks array to get only the blocks with the specified name.
		return array_values(
			array_filter(
				$flatten_blocks,
				static function( $block ): bool {
					return isset( $block['blockName'] );
				}
			)
		);
	}

}// phpcs:ignoreFile
