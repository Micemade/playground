<tr class="lemon-squeezy-updater-license-row <?php echo esc_attr( $this->get_license_status_class() ); ?>">
	<td colspan="5">
		<div class="lemon-squeezy-updater-license-wrap">
			<?php echo wp_kses_post( $this->get_license_message() ); ?>
			<a href="javascript:void(0);"
				class="deactivate"><?php esc_html_e( 'Deactivate license', 'mosaic-product-layouts' ); ?></a>
			<span class="spinner"></span>
		</div>
	</td>
</tr>