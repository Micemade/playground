<?php
/**
 * Attributes class for the Mosaic Product Layouts plugin.
 *
 * This class is responsible for extracting block attributes from post content
 * and templates, and converting them into a format suitable for inline JavaScript.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */

declare( strict_types=1 );

namespace Micemade\MosaicProductLayouts;

use function parse_blocks;
use function array_merge;
use function array_unique;
use function in_array;
use function sanitize_text_field;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Attributes
 *
 * Handles the extraction and processing of block attributes for the Mosaic Product Layouts plugin.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */
class Attributes {

	/**
	 * Instance of the Utils class.
	 *
	 * @var Utils
	 */
	private Utils $utils;

	/**
	 * Instance of the Scripts class.
	 *
	 * @var Scripts
	 */
	private Scripts $scripts;

	/**
	 * Instance of the Patterns class.
	 *
	 * @var Patterns
	 */
	private Patterns $patterns;

	/**
	 * Instance of the Templates class.
	 *
	 * @var Templates
	 */
	private Templates $templates;

	/**
	 * Constructs the Attributes class.
	 *
	 * Initializes the class with optional dependency injection for improved testability.
	 *
	 * @param Utils|null     $utils     Optional. Utils class instance. Default null.
	 * @param Scripts|null   $scripts   Optional. Scripts class instance. Default null.
	 * @param Patterns|null  $patterns  Optional. Patterns class instance. Default null.
	 * @param Templates|null $templates Optional. Templates class instance. Default null.
	 */
	public function __construct( ?Utils $utils = null, ?Scripts $scripts = null, ?Patterns $patterns = null, ?Templates $templates = null ) {
		$this->utils     = $utils ?? new Utils();
		$this->scripts   = $scripts ?? new Scripts();
		$this->patterns  = $patterns ?? new Patterns( $this->utils );
		$this->templates = $templates ?? new Templates();
	}

	/**
	 * Extracts (parses) block attributes from the content of a post and outputs them as a string of JavaScript variables.
	 *
	 * @param string $content The content of a post.
	 *
	 * @return string The content of the post with inline JavaScript variables set.
	 */
	public function extract_attributes_from_content( string $content ):string {
		global $post;

		if ( empty( $post ) ) {
			return $content;
		}

		try {
			$content_blocks = parse_blocks( $post->post_content );
			$flatten_blocks = $this->utils->flatten_blocks( $content_blocks );

			// Add blocks from synced patterns.
			$synced_blocks = $this->patterns->get_synced_pattern_blocks( $flatten_blocks );

			// Merge and deduplicate blocks.
			$all_blocks = array_unique(
				array_merge( $flatten_blocks, $synced_blocks ),
				SORT_REGULAR
			);

			// Filter out blocks not belonging to this plugin.
			$this->prepare_blocks_for_inline_js( $all_blocks, 'Content' );

			return $content;
		} catch ( \Exception $e ) {
			// Log error only if debugging is enabled.
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				wp_debug_log( 'MPL Attributes extraction error: ' . $e->getMessage() );
			}
			return $content;
		}
	}

	/**
	 * Extracts block attributes from all block templates.
	 *
	 * Parses all block templates for blocks and extracts their attributes.
	 * The attributes are then added to the inline JavaScript file.
	 */
	public function extract_attributes_from_templates(): void {
		try {
			$blocks_from_templates = array_unique(
				$this->templates->get_blocks_from_templates(),
				SORT_REGULAR
			);

			$this->prepare_blocks_for_inline_js( $blocks_from_templates, 'Templates' );
		} catch ( \Exception $e ) {
			// Log error only if debugging is enabled.
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				wp_debug_log( 'MPL Template extraction error: ' . $e->getMessage() );
			}
		}
	}

	/**
	 * Adds block attributes to an inline script for Mosaic Product Layouts.
	 *
	 * Iterates over the provided blocks, identifies those that belong to
	 * Mosaic Product Layouts, and collects their attributes. These attributes
	 * are then passed to a JavaScript inline script, making them available
	 * for client-side use.
	 *
	 * @param array  $blocks An array of all blocks to process for attributes.
	 * @param string $blocks_source either content or templates.
	 *
	 * @return void
	 */
	public function prepare_blocks_for_inline_js( array &$blocks, string $blocks_source ):void {

		if ( empty( $blocks ) ) {
			return;
		}

		$mpl_blocks  = $this->utils->get_block_names();
		$block_attrs = array();

		foreach ( $blocks as $block ) {
			if ( ! isset( $block['blockName'] ) || ! isset( $block['attrs'] ) ) {
				continue;
			}

			if ( ! in_array( $block['blockName'], $mpl_blocks, true ) ) {
				continue;
			}

			// Sanitize attributes before adding.
			$sanitized_attrs = $this->sanitize_block_attributes( $block['attrs'] );
			$block_attrs[]   = $sanitized_attrs;

			if ( ! isset( $this->scripts ) ) {
				$this->scripts = new Scripts();
			}

			$this->scripts->add_inline_script_attrs( $block['blockName'], $block_attrs, $blocks_source );
		}
	}


	/**
	 * Sanitizes block attributes.
	 *
	 * Iterates over the provided array of block attributes, sanitizing string values
	 * using `sanitize_text_field()`. Other values are passed through unchanged.
	 *
	 * @param array<string, mixed> $attrs The array of block attributes to sanitize.
	 * @return array<string, mixed> Sanitized array of block attributes.
	 */
	private function sanitize_block_attributes( array $attrs ): array {
		$sanitized = array();
		foreach ( $attrs as $key => $value ) {
			if ( is_string( $value ) ) {
				$sanitized[ $key ] = sanitize_text_field( $value );
			} elseif ( is_numeric( $value ) ) {
				$sanitized[ $key ] = floatval( $value );
			} elseif ( is_bool( $value ) ) {
				$sanitized[ $key ] = (bool) $value;
			} elseif ( is_array( $value ) ) {
				$sanitized[ $key ] = $this->sanitize_block_attributes( $value ); // Recursive sanitization.
			} else {
				// If $value cannot be encoded, false is returned.
				$sanitized[ $key ] = wp_json_encode( $value ) ? $value : null;
			}
		}
		return $sanitized;
	}

}// phpcs:ignoreFile