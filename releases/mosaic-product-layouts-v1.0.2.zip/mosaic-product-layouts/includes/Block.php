<?php
/**
 * Block class for the Mosaic Product Layouts plugin.
 *
 * This class is responsible for registering all blocks, including dynamic and non-dynamic blocks,
 * and managing block metadata collection.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */

declare(strict_types=1);

namespace Micemade\MosaicProductLayouts;

use function register_block_type;
use function wp_register_block_metadata_collection;
use function add_action;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Block
 *
 * This class is responsible for registering and managing blocks.
 *
 * @package Micemade\MosaicProductLayouts
 */
class Block {

	/**
	 * Instance of the Utils class.
	 *
	 * @var Utils
	 */
	private Utils $utils;

	/**
	 * Instance of the Render class.
	 *
	 * @var Render
	 */
	private Render $render_class;

	/**
	 * Initializes the blocks by hooking into the 'init' action to register them.
	 *
	 * This function adds an action to the WordPress 'init' event, which triggers
	 * the registration of blocks through the register_blocks method.
	 */
	public function init_blocks(): void {
		add_action( 'init', array( $this, 'register_mpl_block_types' ) );
		$this->utils        = new Utils();
		$this->render_class = new Render();
	}

	/**
	 * Registers block types with WordPress from a manifest file or registers blocks
	 * using a fallback method if the manifest file is not available.
	 *
	 * This function uses the `wp_register_block_metadata_collection` function if available
	 * to register blocks from the manifest file. If the manifest file is not available,
	 * it registers blocks using the `register_blocks_fallback` method.
	 */
	public function register_mpl_block_types():void {

		$manifest_file = MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/blocks-manifest.php';

		if ( file_exists( $manifest_file ) ) {
			$this->register_blocks_with_manifest();
		} else {
			$this->register_blocks_fallback();
		}

	}


	/**
	 * This function uses the `wp_register_block_metadata_collection` function if available
	 * to register blocks from the manifest file.
	 *
	 * TODO: If the WP6.8+ function 'wp_register_block_types_from_metadata_collection' will add
	 * 'render_callback' to the block registration, replace this method with it.
	 * https://make.wordpress.org/core/2025/03/13/more-efficient-block-type-registration-in-6-8/
	 */
	public function register_blocks_with_manifest():void {

		if ( function_exists( 'wp_register_block_metadata_collection' ) ) {
			wp_register_block_metadata_collection( MOSAIC_PRODUCT_LAYOUTS_DIR . '/build', MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/blocks-manifest.php' );
		}

		// Get block data from the manifest file.
		$manifest_data = require MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/blocks-manifest.php';

		foreach ( array_keys( $manifest_data ) as $block_type ) {
			// Micemade WC Carousel and Inner Block are non-dynamic blocks (no 'render_callback').
			if ( 'micemade/wc-carousel' === $block_type || 'micemade/inner-block' === $block_type ) {
				register_block_type( MOSAIC_PRODUCT_LAYOUTS_DIR . "/build/{$block_type}" );
			} else {
				$name = str_replace( '-', '_', $block_type );
				if ( $this->utils->is_woocommerce_active() ) {
					register_block_type(
						MOSAIC_PRODUCT_LAYOUTS_DIR . "build/{$block_type}",
						array( 'render_callback' => array( $this->render_class, $name . '_render' ) ),
					);
				}
			}
		}
	}

	/**
	 * Fallback method for registering block types.
	 *
	 * This method is used when a manifest file is not available. It retrieves a list of blocks
	 * and registers each block type. Non-dynamic blocks like 'micemade-wc-carousel' and
	 * 'micemade-inner-block' are registered without a render callback. For other blocks, if
	 * WooCommerce is active, it registers the block type with a render callback using the
	 * corresponding render method from the Render class.
	 */
	public function register_blocks_fallback():void {

		$blocks = $this->utils->get_blocks_list();

		foreach ( $blocks as $block ) {
			// Micemade WC Carousel and Inner Block are non-dynamic blocks (no 'render_callback').
			if ( 'micemade-wc-carousel' === $block || 'micemade-inner-block' === $block ) {
				register_block_type( MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/' . trailingslashit( $block ) );
			} else {
				if ( $this->utils->is_woocommerce_active() ) {
					$name = str_replace( '-', '_', $block );
					register_block_type(
						MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/' . trailingslashit( $block ),
						array( 'render_callback' => array( $this->render_class, $name . '_render' ) ),
					);
				}
			}
		}
	}

}// phpcs:ignoreFile
