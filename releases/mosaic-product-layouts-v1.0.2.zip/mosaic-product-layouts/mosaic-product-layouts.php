<?php
/**
 * Plugin Name:       Mosaic Product Layouts
 * Description:       A set of editor blocks to supercharge your WooCommerce online store.
 * Requires at least: 6.7
 * Requires PHP:      7.4
 * Version:           1.0.2
 * Author:            Micemade
 * Author URI:        https://micemade.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mosaic-product-layouts
 * Require Plugins:   woocommerce
 *
 * WC requires at least: 8.2.0
 * WC tested up to: 10.3.4
 *
 * @package mosaic-product-layouts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use ArrayPress\LemonSqueezy\Updater;

// Define plugin version..
if ( ! defined( 'MOSAIC_PRODUCT_LAYOUTS_VERSION' ) ) {
	define( 'MOSAIC_PRODUCT_LAYOUTS_VERSION', '1.0.2' );
}

// Define plugin dir path.
if ( ! defined( 'MOSAIC_PRODUCT_LAYOUTS_DIR' ) ) {
	define( 'MOSAIC_PRODUCT_LAYOUTS_DIR', plugin_dir_path( __FILE__ ) );
}

// Define plugin file path.
if ( ! defined( 'MOSAIC_PRODUCT_LAYOUTS_PLUGIN_FILE' ) ) {
	define( 'MOSAIC_PRODUCT_LAYOUTS_PLUGIN_FILE', __FILE__ );
}

// Define plugin url.
if ( ! defined( 'MOSAIC_PRODUCT_LAYOUTS_URL' ) ) {
	define( 'MOSAIC_PRODUCT_LAYOUTS_URL', plugin_dir_url( __FILE__ ) );
}

// Define plugin basename.
if ( ! defined( 'MOSAIC_PRODUCT_LAYOUTS_BASENAME' ) ) {
	define( 'MOSAIC_PRODUCT_LAYOUTS_BASENAME', plugin_basename( __FILE__ ) );
}

// Lemon Squeezy plugin updater.
$lemon_squeezy_autoload = plugin_dir_path( __FILE__ ) . 'includes/lemon-squeezy-updater/vendor/autoload.php';
if ( file_exists( $lemon_squeezy_autoload ) ) {
	require_once $lemon_squeezy_autoload;
}

// Load main plugin classes.
$plugin_autoload = plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';
if ( file_exists( $plugin_autoload ) ) {
	require_once $plugin_autoload;
	$mosaic_product_layouts_plugin = new Micemade\MosaicProductLayouts\Plugin();
	$mosaic_product_layouts_plugin->init();
} else {
	// Log error or display admin notice.
	add_action(
		'admin_notices',
		function() {
			echo '<div class="notice notice-error"><p>' .
				esc_html__( 'Plugin autoload file is missing. Please reinstall the plugin.', 'mosaic-product-layouts' ) .
				'</p></div>';
		}
	);
}