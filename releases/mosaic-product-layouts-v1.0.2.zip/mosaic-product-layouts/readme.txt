=== Mosaic Product Layouts ===
Contributors:      Micemade
Tags:              woocommerce, products, block, grid, showcase
Requires at least: 6.7
Tested up to:      6.8
Requires PHP:      7.4
Stable tag:        1.0.2
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Create WooCommerce product showcases with image hotspots in the block editor.

== Description ==

Transform your WooCommerce store with creative, flexible, and fully customizable product displays. Our plugin gives you the power to design unique product grids, engaging carousels, and one-of-a-kind single product layouts without writing a single line of code. Choose from predefined layouts, tweak each element, and save your favorite designs for future use—all within the intuitive WordPress editor.

* Easy to Start, Simple to Customize: Quickly select from predefined starter layouts and styles that fit your products perfectly.
* Total Control: Customize every detail—from font size, colors, and images to alignment, spacing, and backgrounds.
* Drag-and-Drop Flexibility: Move and arrange products freely in a grid with drag-and-drop functionality, even overlapping elements if you like.
* Responsive, Adaptive Layouts: Seamlessly adjust layouts for desktop, tablet, and mobile views.
* Save and Reuse Your Designs: Keep your favorite grid and style settings for future layouts, saving time and maintaining a consistent style.
* Carousel Functionality: Add eye-catching carousels to your store by simply nesting products, categories, or single product blocks within a dynamic carousel container.

Whether you’re building a fully custom layout or just need a quick solution, our plugin provides everything you need to make your WooCommerce store look exceptional.
