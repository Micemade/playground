<?php
/**
 * Plugin Name:       Mosaic Product Layouts
 * Description:       A set of editor blocks to supercharge your WooCommerce online store.
 * Requires at least: 6.3
 * Requires PHP:      7.4
 * Version:           1.0.0
 * Author:            Micemade
 * Author URI:        https://micemade.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mosaic-product-layouts
 *
 * @package mosaic-product-layouts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use ArrayPress\LemonSqueezy\Updater;

// Define plugin version..
if ( ! defined( 'MOSAIC_PRODUCT_LAYOUTS_VERSION' ) ) {
	define( 'MOSAIC_PRODUCT_LAYOUTS_VERSION', '1.0.0' );
}

// Define plugin dir path.
if ( ! defined( 'MOSAIC_PRODUCT_LAYOUTS_DIR' ) ) {
	define( 'MOSAIC_PRODUCT_LAYOUTS_DIR', plugin_dir_path( __FILE__ ) );
}

// Define plugin file path.
if ( ! defined( 'MOSAIC_PRODUCT_LAYOUTS_PLUGIN_FILE' ) ) {
	define( 'MOSAIC_PRODUCT_LAYOUTS_PLUGIN_FILE', __FILE__ );
}

// Define plugin url.
if ( ! defined( 'MOSAIC_PRODUCT_LAYOUTS_URL' ) ) {
	define( 'MOSAIC_PRODUCT_LAYOUTS_URL', plugin_dir_url( __FILE__ ) );
}

// Define plugin url.
if ( ! defined( 'MOSAIC_PRODUCT_LAYOUTS_BASENAME' ) ) {
	define( 'MOSAIC_PRODUCT_LAYOUTS_BASENAME', plugin_basename( __FILE__ ) );
}

// Load Lemon Squeezy plugin updater classes.
require_once plugin_dir_path( __FILE__ ) . 'includes/lemon-squeezy-updater/vendor/autoload.php';

// Load main plugin classes.
require_once plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';
$mosaic_product_layouts_plugin = new Micemade\MosaicProductLayouts\Plugin();
$mosaic_product_layouts_plugin->init();
