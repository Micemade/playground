/**
 * Just for test, probably to delete.
 */

alert('Hello from admin-editor.js!');
