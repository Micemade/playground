<?php
namespace Micemade\MosaicProductLayouts;

class Attributes {

	/**
	 * Instance of the Utils class.
	 *
	 * @var Utils
	 */
	public $utils;

	/**
	 * Constructs the Attributes class.
	 *
	 * Initializes the class, instantiating an instance of the Utils class.
	 */
	public function __construct() {
		$this->utils = new Utils();
	}

	/**
	 * Extracts (parses) block attributes from the content of a post and outputs them as a string of JavaScript variables.
	 *
	 * @param string $content The content of a post.
	 *
	 * @return string The content of the post with inline JavaScript variables set.
	 */
	public function extract_attributes_from_content( string $content ):string {
		global $post;

		// Get and PARSE POST CONTENT BLOCKS.
		$content_blocks = ! $post ? array() : parse_blocks( $post->post_content );

		$flatten_blocks = $this->utils->flatten_blocks( $content_blocks );

		// Add blocks from synced patterns (reusable blocks).
		$spb = $this->utils->synced_pattern_blocks( $flatten_blocks );

		// Merge content blocks and synced pattern blocks.
		$flatten_blocks = array_merge( $flatten_blocks, $spb );

		// Avoid duplicates.
		$flatten_blocks = array_unique( $flatten_blocks, SORT_REGULAR );

		// Send parsed blocks to filter mm-wc-blocks attributes to inline JS script.
		$this->block_attributes_to_inline_script( $flatten_blocks );
		return $content;
	}

	/**
	 * Extracts block attributes from all page templates.
	 *
	 * Parses all page templates for blocks and extracts their attributes.
	 * The attributes are then added to the inline JavaScript file.
	 */
	public function extract_attributes_from_templates() {

		// Get and PARSE POST TEMPLATE AND TEMPLATE PART BLOCKS.
		$templates             = new Templates();
		$blocks_from_templates = $templates->get_blocks_from_templates();
		// Avoid duplicates.
		$blocks_from_templates = array_unique( $blocks_from_templates, SORT_REGULAR );

		// Send parsed blocks to filter mm-wc-blocks attributes to inline JS script.
		$this->block_attributes_to_inline_script( $blocks_from_templates );
	}

	/**
	 * Adds block attributes to an inline script for Mosaic Product Layouts.
	 *
	 * Iterates over the provided blocks, identifies those that belong to
	 * Mosaic Product Layouts, and collects their attributes. These attributes
	 * are then passed to a JavaScript inline script, making them available
	 * for client-side use.
	 *
	 * @param array $blocks An array of all blocks to process for attributes.
	 *
	 * @return void
	 */
	public function block_attributes_to_inline_script( array &$blocks ):void {

		$attrs_to_inline_js = new Scripts();
		$micemade_blocks    = $this->utils->get_block_names();

		$block_attrs = array();
		foreach ( $blocks as &$block ) {
			// Find all Mosaic Product Layouts in all blocks.
			if ( in_array( $block['blockName'], $micemade_blocks, true ) ) {

				$block_attrs[] = $block['attrs'];

				$attrs_to_inline_js->add_inline_script_attrs( $block['blockName'], $block_attrs );

			}
		}
	}
}
