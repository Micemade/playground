<?php
namespace Micemade\MosaicProductLayouts;

class Scripts {

	/**
	 * Array with dependencies and the version, for the block editor scripts.
	 *
	 * @var array
	 */
	private $asset_file;

	/**
	 * Instance of the Utils class, providing utility methods.
	 *
	 * @var Utils
	 */
	public $utils;

	/**
	 * Constructor for the Scripts class.
	 *
	 * Initializes the asset_file property by including the asset file
	 * containing dependencies and version information for the block editor scripts.
	 */
	public function __construct() {
		$this->asset_file = include MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/admin-editor.asset.php';
		$this->utils      = new Utils();
	}
	/**
	 * Enqueue plugin JS and CSS files, and inject global JS object 'mosaicProductLayouts' with default block attributes and WooCommerce status.
	 *
	 * @return void
	 */
	public function enqueue_scripts(): void {
		// Default attributes of all Mosaic Product Layouts.
		$default_block_attributes = array(
			'mosaicProductLayoutsDefaultAttrs' => $this->default_block_attributes(),
		);

		// Check if WooCommerce is active.
		if ( $this->utils->is_woocommerce_active() ) {
			// Create nonce value for apiFetch.
			$nonce    = wp_create_nonce( 'wc_store_api' );
			$cart_url = wc_get_cart_url();
			// Javascript variables.
			$wc_active_js_vars = array(
				'wooActive' => true,
				'nonce'     => sanitize_key( $nonce ),
				'cartUrl'   => esc_url( $cart_url ),
			);
		} else {
			$wc_active_js_vars = array(
				'wooActive' => false,
			);
			add_action( 'admin_notices', array( $this->utils, 'admin_notice_no_woocommerce' ) );
		}

		// Merge default block attributes JS vars and WC vars for one global 'mosaicProductLayouts' JS object.
		$base_inline_js = array_merge( $default_block_attributes, $wc_active_js_vars );

		// Enqueue main plugin JS file.
		wp_enqueue_script( 'mosaic-product-layouts', MOSAIC_PRODUCT_LAYOUTS_URL . 'assets/index.js', array(), filemtime( MOSAIC_PRODUCT_LAYOUTS_DIR . 'assets/index.js' ), true );

		// Add JS vars to frontend.
		wp_add_inline_script(
			'mosaic-product-layouts',
			'window.mosaicProductLayouts = ' . wp_json_encode( $base_inline_js ) . ';',
			'before'
		);

		// Fix for Dashicons not loading in blocks editor tablet/mobile preview.
		add_action(
			'enqueue_block_assets',
			function (): void {
				wp_enqueue_style( 'dashicons' );
			}
		);
	}

	/**
	 * Add block attributes to inline script.
	 *
	 * Adds block attributes as window object property to the inline script of the block.
	 * The block attributes are available under the window object property
	 * with the name of block handle + 'Atts'.
	 *
	 * @param string $block_name  Block handle.
	 * @param array  $block_attrs Block attributes.
	 */
	public function add_inline_script_attrs( string $block_name, array $block_attrs ):void {
		$ls = $this->inline_js_handle_object( $block_name );
		wp_add_inline_script(
			$ls[0] . '-view-script',
			'window.' . $ls[1] . 'Atts = ' . wp_json_encode( $block_attrs ) . ';',
			'before'
		);
	}

	/**
	 * Creates the handle for the 'wp_inline_script' and the attributes object name.
	 * The attributes object name is created by splitting the block name into parts,
	 * and then capitalizing the first letter of each part.
	 *
	 * @param string $block_name The name of the block.
	 * @return array An array containing the handle and the attributes object name.
	 */
	public function inline_js_handle_object( string $block_name ):array {
		// Handle for the 'wp_inline_script'.
		$handle = str_replace( '/', '-', $block_name );

		// Split the block name into parts.
		$parts = preg_split( '/[-\/]/', $block_name, 3 );
		// Create the attributes object name from the parts.
		$attrs_object_name = $parts[0];
		if ( isset( $parts[1] ) ) {
			$attrs_object_name .= ucfirst( $parts[1] );
		}
		if ( isset( $parts[2] ) ) {
			$attrs_object_name .= ucfirst( $parts[2] );
		}

		// Return the handle and attributes object name.
		return array( $handle, $attrs_object_name );
	}

	/**
	 * Retrieves the default attributes for all blocks by reading their block.json files.
	 *
	 * This function iterates over a list of blocks, checks for the existence of a block.json
	 * file for each block, and retrieves the attributes specified within the file. If found,
	 * the attributes are added to an array associated with the block name. The function
	 * returns a JSON-encoded string of all default attributes.
	 *
	 * @return string JSON-encoded string of default block attributes.
	 */
	public function default_block_attributes():string {

		$blocks = $this->utils->get_blocks_list();

		$default_attrs = array();
		foreach ( $blocks as $block_name ) {
			// Block.json path.
			$block_dir       = 'build/' . $block_name;
			$block_json_file = MOSAIC_PRODUCT_LAYOUTS_DIR . $block_dir . '/block.json';

			// Check if the file exists.
			if ( file_exists( $block_json_file ) ) {
				// Read the contents of the block.json file.
				$block_json_content = file_get_contents( $block_json_file );
				// Parse the JSON content.
				$block_config = json_decode( $block_json_content, true, 512, JSON_THROW_ON_ERROR );
				// Check if decoding was successful.
				if ( null !== $block_config ) {
					// Check if the "attributes" key exists.
					if ( array_key_exists( 'attributes', $block_config ) ) {
						// Access the value of the "attributes" key.
						$default_attrs[ $block_name ] = $block_config['attributes'];
					}
				}
			} else {
				// Handle file not found error.
				throw new \RuntimeException( "Block.json file not found for block: $block_name" );
			}
		}

		return wp_json_encode( $default_attrs );
	}

	/**
	 * Enqueue the block editor script.
	 *
	 * @return void
	 */
	public function block_editor_assets_file():void {
		wp_enqueue_script(
			'block-editor-script',
			MOSAIC_PRODUCT_LAYOUTS_URL . 'build/admin-editor.js',
			$this->asset_file['dependencies'],
			$this->asset_file['version'],
			false
		);
	}

	/**
	 * Registers and enqueues styles and scripts for the block editor.
	 *
	 * This function registers and enqueues the necessary CSS and JavaScript files
	 * for the block editor. It also modifies the editor settings to include the
	 * enqueued assets. The styles and scripts are versioned using their file
	 * modification times for cache busting.
	 *
	 * @param array $settings An array of existing block editor settings.
	 * @return array Modified block editor settings with added assets.
	 */
	public function block_editor_settings( $settings ) {
		// Styles register and enqueue.
		wp_register_style(
			'mosaic-product-layouts-css',
			MOSAIC_PRODUCT_LAYOUTS_URL . 'assets/css/index.css',
			array(),
			filemtime( MOSAIC_PRODUCT_LAYOUTS_DIR . 'assets/css/index.css' )
		);
		wp_enqueue_style( 'mosaic-product-layouts-css' );

		// Scripts register and enqueue.
		wp_register_script(
			'mosaic-product-layouts-js',
			MOSAIC_PRODUCT_LAYOUTS_URL . 'build/admin-editor.js',
			$this->asset_file['dependencies'],
			filemtime( MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/admin-editor.js' ),
			true
		);
		wp_enqueue_script( 'mosaic-product-layouts-js' );
		// Editor settings.
		$settings['assets']['scripts']  = 'mosaic-product-layouts-js';
		$settings['assets']['styles'][] = 'mosaic-product-layouts-css';
		return $settings;
	}

}
