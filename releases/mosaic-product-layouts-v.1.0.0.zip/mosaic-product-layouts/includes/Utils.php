<?php
namespace Micemade\MosaicProductLayouts;

class Utils {

	/**
	 * Retrieves and filters the Micemade WooCommerce block names.
	 * Converts block names from 'micemade-products-grid' format to 'micemade/products-grid' format.
	 * Applies a filter 'mosaic_product_layouts_names' to the resulting block names array.
	 *
	 * @return array The filtered array of block names.
	 */
	public function get_block_names() {
		$mm_blocks_list = $this->get_blocks_list();
		$mm_block_names = array_map(
			function( $block ) {
				return preg_replace( '/-/', '/', $block, 1 );
			},
			$mm_blocks_list
		);

		return apply_filters( 'mosaic_product_layouts_names', $mm_block_names );
	}

	/**
	 * Returns an array of the block names.
	 *
	 * @return array An array of the block names.
	 */
	public function get_blocks_list() {
		// Get the 'build' directory path.
		$blocks_dir_path = MOSAIC_PRODUCT_LAYOUTS_DIR . 'build';

		// Get all directories in the 'build' directory and filter out empty directories.
		$folders = array_filter(
			glob( $blocks_dir_path . '/*' ),
			function( $blocks_dir_path ) {
				// Check if the directory is not empty.
				return is_dir( $blocks_dir_path ) && ! empty( array_diff( scandir( $blocks_dir_path ), array( '..', '.' ) ) );
			}
		);

		// Get the folder name from each directory path.
		$blocks_list = array_filter(
			array_map(
				function( $blocks_dir_path ) {
					// Get the folder name.
					return basename( $blocks_dir_path );
				},
				$folders
			),
			function( $blocks_dir_name ) {
				// Filter out folder names starting with 'micemade'.
				return preg_match( '/^micemade/', $blocks_dir_name );
			}
		);

		return $blocks_list;
	}

	public function flatten_blocks( array $blocks ):array {

		if ( ! is_array( $blocks ) ) {
			return array();
		}
		return array_reduce(
			$blocks,
			function( $carry, $block ) {
				// Add the current block to the array, excluding its innerBlocks.
				array_push( $carry, array_diff_key( $block, array_flip( array( 'innerBlocks' ) ) ) );

				// If the block has inner blocks, flatten them as well.
				if ( isset( $block['innerBlocks'] ) ) {
					$inner_blocks = $this->flatten_blocks( $block['innerBlocks'] );
					return array_merge( $carry, $inner_blocks );
				}
				// Return the array of blocks.
				return $carry;
			},
			array()
		);
	}

	public function synced_pattern_blocks( array $blocks ):array {
		$synced_pattern_blocks = array();
		foreach ( $blocks as &$block ) {
			if ( in_array( $block['blockName'], array( 'core/block' ), true ) ) {
				$id = isset( $block['attrs']['ref'] ) ? $block['attrs']['ref'] : null;
				if ( $id ) {
					$synced_pattern_post     = get_post( $id );
					$synced_pattern_blocks[] = parse_blocks( $synced_pattern_post->post_content ) ?? array();
				}
			}
		}
		if ( empty( $synced_pattern_blocks ) ) {
			return array();
		}
		$spb = $this->flatten_blocks( $synced_pattern_blocks[0] );
		return $spb;
	}

	/**
	 * Compare the current WordPress version with a given version. It's a wrapper around `version-compare`
	 * that additionally takes into account the suffix (like `-RC1`).
	 * For example: version 6.3 is considered lower than 6.3-RC2, so you can do
	 * wp_version_compare( '6.3', '>=' ) and that will return true for 6.3-RC2.
	 *
	 * From: /woocommerce-blocks/src/Utils/Utils.php.
	 *
	 * @param string      $version The version to compare against.
	 * @param string|null $operator Optional. The comparison operator. Defaults to null.
	 * @return bool|int Returns true if the current WordPress version satisfies the comparison, false otherwise.
	 */
	public static function wp_version_compare( $version, $operator = null ):bool {
		$current_wp_version = get_bloginfo( 'version' );
		if ( preg_match( '/^([0-9]+\.[0-9]+)/', $current_wp_version, $matches ) ) {
			$current_wp_version = (float) $matches[1];
		}

		// Replace non-alphanumeric characters with a dot.
		$current_wp_version = preg_replace( '/[^0-9a-zA-Z\.]+/i', '.', $current_wp_version );
		$version            = preg_replace( '/[^0-9a-zA-Z\.]+/i', '.', $version );

		return version_compare( $current_wp_version, $version, $operator );
	}


	/**
	 * Checks if WooCommerce is installed and active.
	 *
	 * @return bool
	 */
	public function is_woocommerce_active():bool {
		return class_exists( 'WooCommerce' ) || defined( 'WC_PLUGIN_FILE' ) || defined( 'WC_ABSPATH' );
	}

	/**
	 * Admin notice for missing WooCommerce plugin.
	 *
	 * @return void
	 */
	public function admin_notice_no_woocommerce() {
		$title       = __( 'Mosaic Product Layouts Notice', 'mosaic-product-layouts' );
		$description = __( 'Mosaic Product Layouts is a plugin for creating beautiful layouts with WooCommerce products, using the block editor. To enable the Mosaic Product Layouts plugin, please install and activate the WooCommerce plugin.', 'mosaic-product-layouts' );

		$wc_install_url = admin_url( 'plugin-install.php?s=woocommerce&tab=search&type=term' );
		$wc_page_url    = 'https://wordpress.org/plugins/woocommerce/';

		$wc_install_text = __( 'Install WooCommerce', 'mosaic-product-layouts' );
		$wc_page_text    = __( 'WooCommerce plugin page', 'mosaic-product-layouts' );

		printf(
			'<div class="notice notice-info is-dismissible mosaic-product-layouts-admin-notice"><div class="mosaic-product-layouts-admin-notice-wrapper" style="margin-bottom: 15px;"><h2>%1$s</h2><p>%2$s</p><a target="_self" class="button-primary button" href="%3$s" style="margin-right: 10px;">%4$s</a><a target="_self" class="button-secondary button" href="%5$s">%6$s</a></div></div>',
			esc_html( $title ),
			esc_html( $description ),
			esc_url( $wc_install_url ),
			esc_html( $wc_install_text ),
			esc_url( $wc_page_url ),
			esc_html( $wc_page_text )
		);
	}
}
