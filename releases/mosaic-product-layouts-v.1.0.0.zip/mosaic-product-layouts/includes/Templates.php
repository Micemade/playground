<?php
namespace Micemade\MosaicProductLayouts;

class Templates {

	/**
	 * The Utils class.
	 *
	 * @var Utils
	 */
	public $utils;

	/**
	 * Gets the names of the micemade blocks.
	 *
	 * @var array
	 */
	public $micemade_blocks;

	/**
	 * Initialize the class.
	 *
	 * Instantiates the Utils class and sets the class property
	 * $micemade_blocks to the result of the Utils::get_block_names()
	 * method.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->utils           = new Utils();
		$this->micemade_blocks = $this->utils->get_block_names();
	}
	/**
	 * Returns all template and template part blocks, flattened and including synced pattern blocks.
	 *
	 * @return array Array of blocks.
	 */
	public function get_blocks_from_templates() {

		// GET TEMPLATE BLOCKS.
		$template_blocks = $this->get_template_blocks();

		// Get template part slugs from template blocks.
		$template_part_slugs = array();
		foreach ( $template_blocks as &$block ) {
			if ( $block['blockName'] === 'core/template-part' ) {
				$template_part_slugs[] = $block['attrs']['slug'];
			}
		}

		// Get TEMPLATE PART BLOCKS using template part slugs.
		$template_part_blocks = $this->get_template_part_blocks( $template_part_slugs );

		// Merge template and template part blocks.
		$merged_blocks = array_merge( $template_blocks, $template_part_blocks );

		// Flatten blocks.
		$flatten_blocks = $this->utils->flatten_blocks( $merged_blocks );

		// Add blocks from synced patterns (reusable blocks).
		$spb = $this->utils->synced_pattern_blocks( $flatten_blocks );

		// ALL TEMPLATE AND PARTS BLOCKS, FLATTENED.
		$all_template_blocks = array_merge( $flatten_blocks, $spb );

		return $all_template_blocks;
	}

	/**
	 * Returns the blocks from the current template.
	 *
	 * @return array The blocks from the current template.
	 */
	public function get_template_blocks():array {
		global $_wp_current_template_id, $_wp_current_template_content;

		if ( isset( $_wp_current_template_content ) ) {
			$template_blocks = parse_blocks( $_wp_current_template_content );
			return $template_blocks;
		} else {
			return array();
		}
	}

	/**
	 * Given an array of template part slugs, returns an array of blocks
	 * of the specified block names from all of the template parts.
	 *
	 * @param array $template_part_slugs Array of template part slugs.
	 *
	 * @return array Array of blocks from the template parts.
	 */
	public function get_template_part_blocks( array $template_part_slugs ):array {
		$template_part_blocks = array();

		if ( empty( $template_part_slugs ) ) {
			return $template_part_blocks;
		}

		foreach ( $template_part_slugs as $slug ) {
			if ( empty( $slug ) ) {
				continue;
			}

			foreach ( $this->micemade_blocks as $block_name ) {
				if ( empty( $block_name ) ) {
					continue;
				}

				$blocks = $this->extract_template_part_blocks( $block_name, $slug );

				if ( empty( $blocks ) ) {
					continue;
				}

				$template_part_blocks = array_merge(
					$template_part_blocks,
					$blocks
				);
			}
		}
		return $template_part_blocks;
	}

	/**
	 * Extracts and returns all instances of a specified block from a given template part.
	 *
	 * @param string $block_name The name of the block to extract, e.g., 'core/paragraph'.
	 * @param string $template_part_slug The slug of the template part to search within, e.g., 'header'.
	 *
	 * @return array Array of blocks that match the specified block name within the template part.
	 */
	public function extract_template_part_blocks( $block_name, $template_part_slug ) {
		// Get the template part content.
		$template = get_block_template( get_stylesheet() . '//' . $template_part_slug, 'wp_template_part' );

		if ( ! $template ) {
			return array();
		}

		$blocks = parse_blocks( $template->content );

		// Flatten the blocks array to access inner blocks.
		$flatten_blocks = $this->utils->flatten_blocks( $blocks );

		// Filter the flattened blocks array to get only the blocks with the specified name.
		return array_values(
			array_filter(
				$flatten_blocks,
				function ( $block ) use ( $block_name ) {
					// Return false if the block name is not set.
					if ( ! isset( $block['blockName'] ) ) {
						return false;
					}
					// Return true if the block name matches the specified block name.
					return ( $block_name === $block['blockName'] );
				}
			)
		);
	}

}
