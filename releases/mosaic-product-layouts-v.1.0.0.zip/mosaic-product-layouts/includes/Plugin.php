<?php
namespace Micemade\MosaicProductLayouts;

use ArrayPress\LemonSqueezy\Updater;

/**
 * Main plugin class that handles initialization and core functionality.
 *
 * This class serves as the primary controller for the Mosaic Product Layouts plugin.
 * It initializes and manages all core components including blocks, attributes, scripts,
 * plugin settings, and update functionality.
 *
 * @package Micemade\MosaicProductLayouts
 * @since 1.0.0
 */
class Plugin {

	/**
	 * Instance of the Block class.
	 *
	 * @var blocks
	 */

	private $block;
	/**
	 * Instance of the Attributes class.
	 *
	 * @var attributes
	 */
	private $attributes;

	/**
	 * Instance of the Scripts class.
	 *
	 * @var scripts
	 */
	private $scripts;

	/**
	 * Plugin constructor.
	 *
	 * Instantiates the necessary classes for the plugin.
	 */
	public function __construct() {
		$this->block      = new Block();
		$this->attributes = new Attributes();
		$this->scripts    = new Scripts();
	}

	/**
	 * Initializes the plugin.
	 *
	 * Register blocks, extracts attributes from content, extracts attributes from templates,
	 * enqueues scripts and loads the text domain.
	 */
	public function init(): void {

		// Lemon Squeezy Updater.
		add_action( 'init', array( $this, 'update_and_licence' ) );

		// Block attributes extraction from post,page ... content.
		add_filter( 'the_content', array( $this->attributes, 'extract_attributes_from_content' ), 10 );
		// Block attributes extraction from templates, template parts, and synced blocks.
		add_action( 'template_redirect', array( $this->attributes, 'extract_attributes_from_templates' ) );
		add_action( 'render_block_core_template_part_post', array( $this->attributes, 'extract_attributes_from_templates' ) );
		add_action( 'render_block_core_template_part_file', array( $this->attributes, 'extract_attributes_from_templates' ) );

		// Enqueue scripts.
		add_action( 'init', array( $this->scripts, 'enqueue_scripts' ) );

		// Enqueue block editor assets and settings.
		add_action( 'enqueue_block_editor_assets', array( $this->scripts, 'block_editor_assets_file' ) );
		add_filter( 'block_editor_settings_all', array( $this->scripts, 'block_editor_settings' ) );

		// Load text domain.
		add_action(
			'init',
			function() {
				load_plugin_textdomain( 'mosaic-product-layouts', false, dirname( MOSAIC_PRODUCT_LAYOUTS_BASENAME ) . '/languages' );},
			10
		);

		// Register plugin settings.
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'rest_api_init', array( $this, 'register_settings' ) );

		add_action( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 2 );

		$this->block->init_blocks();
	}

	/**
	 * Register plugin settings (for wp_options table).
	 *
	 * Registers three settings: `mosaic_product_layouts_single_setups`,`mosaic_product_layouts_products_setups`,
	 * and `mosaic_product_layouts_categories_setups`.
	 * These settings are registered with the `mosaic_product_layouts` settings group.
	 * The settings are strings, and are shown in the REST API.
	 * The `sanitize_callback` for the settings is `sanitize_text_field`.
	 */
	public function register_settings(): void {
		$group = 'options';
		$args  = array(
			'type'              => 'string',
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
		);

		// Saved layout and style setups for different blocks.
		register_setting( $group, 'mosaic_product_layouts_single_setups', $args );
		register_setting( $group, 'mosaic_product_layouts_products_setups', $args );
		register_setting( $group, 'mosaic_product_layouts_categories_setups', $args );
		// License data.
		register_setting( $group, 'mosaic_product_layouts_license_data', $args );

		$utils  = new Utils();
		$blocks = $utils->get_blocks_list();

	}

	/**
	 * Checks if the plugin's license is activated.
	 *
	 * Uses the Lemon Squeezy Updater class to check if the license is activated.
	 * The Updater class is configured with the plugin file, API URL, version, store ID, product ID, and renewal URL.
	 *
	 * @see \ArrayPress\LemonSqueezy\Updater
	 */
	public function update_and_licence(): void {

		// Initialize the updater with your Lemon Squeezy store details.
		$updater = new Updater(
			MOSAIC_PRODUCT_LAYOUTS_PLUGIN_FILE,
			'https://micemade.com/wp-json/lsq/v1',
			MOSAIC_PRODUCT_LAYOUTS_VERSION, // Optional. Leave empty to use the WordPress plugin version number.
			575, // Optional but recommended. Your Lemon Squeezy Store ID (12345).
			398489, // Optional but recommended. Your Lemon Squeezy Product ID (12345).
			// 'variation_id', // Optional. Your Lemon Squeezy Product Variation ID (12345).
			// 'https://micemade.com/my-plugin-page' // Optional. Expiration Renewal URL.
		);

		if ( ! $updater->is_license_activated() ) {
			// do something if the license is not activated.
		}
	}

	public function plugin_row_meta( $links, $file ) {
		if ( MOSAIC_PRODUCT_LAYOUTS_BASENAME !== $file ) {
			return $links;
		}
		$row_meta = array(
			'support' => '<a href="' . esc_url( 'https://micemade.com/contact/') . '" aria-label="' . esc_attr__( 'Contact us for support', 'mosaic-product-layouts' ) . '" target="_blank" ><span class="dashicons dashicons-sos"></span>' . __( 'Support', 'mosaic-product-layouts' ) . '</a>',
		);

		return array_merge( $links, $row_meta );

	}

}