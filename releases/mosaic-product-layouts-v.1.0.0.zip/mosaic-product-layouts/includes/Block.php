<?php
namespace Micemade\MosaicProductLayouts;

class Block {

	/**
	 * Register all blocks.
	 *
	 * Iterate over the list of blocks found in the build directory and register each one using
	 * `register_block_type`. If the block is a non-dynamic block (no 'render_callback'), register the
	 * block without a render callback. Otherwise, register the block with a render callback defined
	 * in the `Render` class.
	 */
	public function register_blocks() {
		$utils  = new Utils();
		$blocks = $utils->get_blocks_list();

		$render_class = new Render();

		foreach ( $blocks as $block ) {
			$name = str_replace( '-', '_', $block );

			// Micemade WC Carousel and Inner Block are non-dynamic blocks (no 'render_callback').
			if ( 'micemade-wc-carousel' === $block || 'micemade-inner-block' === $block ) {
				register_block_type( MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/' . trailingslashit( $block ) );
			} else {
				if ( $utils->is_woocommerce_active() ) {
					register_block_type(
						MOSAIC_PRODUCT_LAYOUTS_DIR . 'build/' . trailingslashit( $block ),
						array( 'render_callback' => array( $render_class, $name . '_render' ) ),
					);
				}
			}
		}
	}

	/**
	 * Register the block metadata collection.
	 *
	 * https://make.wordpress.org/core/2024/10/17/new-block-type-registration-apis-to-improve-performance-in-wordpress-6-7/
	 *
	 * @since 0.9.0
	 * @see wp_register_block_metadata_collection
	 */
	public function register_metadata_collection(): void {

		$build_dir          = MOSAIC_PRODUCT_LAYOUTS_DIR . 'build';
		$manifest_file_path = $build_dir . '/blocks-manifest.php';

		$utils              = new Utils();
		$correct_wp_version = $utils::wp_version_compare( '6.7' );

		// Early return if the manifest file doesn't exist or the WordPress version is less than 6.7.
		if ( ! file_exists( $manifest_file_path ) || ! $correct_wp_version ) {
			return;
		}

		if ( ! function_exists( 'wp_register_block_metadata_collection' ) ) {
			return;
		}
		wp_register_block_metadata_collection(
			$build_dir,
			$manifest_file_path
		);
	}

	/**
	 * Initializes the blocks by hooking into the 'init' action to register them.
	 *
	 * This function adds an action to the WordPress 'init' event, which triggers
	 * the registration of blocks through the register_blocks method.
	 */
	public function init_blocks() {
		add_action( 'init', array( $this, 'register_blocks' ) );
		add_action( 'init', array( $this, 'register_metadata_collection' ) );
	}

}