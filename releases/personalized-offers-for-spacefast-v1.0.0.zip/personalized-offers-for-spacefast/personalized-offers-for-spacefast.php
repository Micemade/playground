<?php
/**
 * Plugin Name:       Personalized Offers for Spacefast
 * Plugin URI:        https://github.com/Micemade/personalized-offers-for-spacefast
 * Description:       Creates personalized storefront offers for WooCommerce customers using Spacefast.
 * Version:           1.0.0
 * Requires at least: 7.0
 * Requires PHP:      8.3
 * WC requires at least: 8.0
 * WC tested up to:   9.0
 * Author:            Micemade
 * License:           GPL-3.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       personalized-offers-for-spacefast
 * Domain Path:       /languages
 */

declare(strict_types=1);

use Automattic\WooCommerce\Utilities\FeaturesUtil;
use Micemade\PersonalizedOffers\Installer;
use Micemade\PersonalizedOffers\Plugin;

if (!defined('ABSPATH')) {
    exit;
}

define('POFSF_VERSION', '1.0.0');
define('POFSF_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('POFSF_PLUGIN_URL', plugin_dir_url(__FILE__));
define('POFSF_PLUGIN_FILE', __FILE__);

add_action('before_woocommerce_init', static function (): void {
    if (class_exists(FeaturesUtil::class)) {
        FeaturesUtil::declare_compatibility('custom_order_tables', POFSF_PLUGIN_FILE, true);
    }
});

spl_autoload_register(static function (string $class): void {
    $prefix = 'Micemade\\PersonalizedOffers\\';

    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $path = POFSF_PLUGIN_DIR . 'src/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';

    if (is_readable($path)) {
        require_once $path;
    }
});

register_activation_hook(__FILE__, [Installer::class, 'activate']);
register_deactivation_hook(__FILE__, [Installer::class, 'deactivate']);
register_uninstall_hook(__FILE__, [Installer::class, 'uninstall']);

Plugin::boot()->register();
