<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Service\Wishlist\AdapterRegistry;
use WC_Order;
use WC_Product;
use WP_User;

/**
 * Computes a customer's shopping profile from their paid orders: weighted
 * category, brand and attribute preferences (by amount spent and how
 * recently), price band, how recently, often and much they buy, and their
 * wishlist. A registered customer by user ID, a guest by billing email.
 * CustomerProfiles stores the result; this class only computes.
 */
final class ProfileBuilder {
    /** Orders read per customer, newest first. */
    private const MAX_ORDERS = 200;

    /** A purchase counts half as much after this many days. */
    private const HALF_LIFE_DAYS = 180;

    private const TOP_CATEGORIES = 8;
    private const TOP_VALUES = 5;

    public function __construct(
        private readonly AdapterRegistry $wishlists,
        private readonly Logger $log,
    ) {}

    public function buildUserProfile(int $userId): array {
        $profile = self::emptyProfile();
        $profile['user_id'] = $userId;
        $user = $userId > 0 ? get_userdata($userId) : false;

        if (!$user instanceof WP_User) {
            $profile['guest'] = true;

            return $profile;
        }

        $profile['user_email'] = $user->user_email;
        $profile['user_name'] = $user->display_name;
        $profile['user_role'] = $user->roles;
        $profile['is_registered'] = true;
        $profile['wishlist_products'] = $this->wishlists->productsFor($userId);
        $profile['consent_given'] = $this->hasConsent($userId);

        // Their account's orders, and guest orders they placed with its email.
        return $this->withOrders($profile, $this->paidOrders(['customer' => array_filter([$userId, $user->user_email])]));
    }

    /**
     * A guest customer's profile from the orders they placed without an
     * account, by billing email.
     */
    public function buildGuestProfile(string $email): array {
        $email = strtolower(sanitize_email($email));
        $profile = self::emptyProfile();
        $profile['guest'] = true;
        $profile['guest_email'] = $email;
        $profile['user_email'] = $email;

        if ('' === $email) {
            return $profile;
        }

        $orders = $this->paidOrders(['customer_id' => 0, 'billing_email' => $email]);
        $latest = $orders[0] ?? null;

        if ($latest instanceof WC_Order) {
            $profile['user_name'] = trim($latest->get_billing_first_name() . ' ' . $latest->get_billing_last_name());
        }

        return $this->withOrders($profile, $orders);
    }

    public static function emptyProfile(): array {
        return [
            'user_id' => 0,
            'user_email' => '',
            'user_name' => '',
            'user_role' => [],
            'is_registered' => false,
            'guest' => false,
            'guest_email' => null,
            'preferred_categories' => [],
            'brands' => [],
            'attributes' => [],
            'sizes_colors' => [],
            'price_band' => [],
            'price_range' => [],
            'buying_rhythm' => [],
            'activity' => ['order_count' => 0, 'total_spent' => 0.0, 'average_order' => 0.0, 'first_order' => '', 'last_order' => '', 'days_since_last' => null, 'average_gap_days' => null],
            'wishlist_products' => [],
            'past_orders_meta' => [],
            'consent_given' => false,
        ];
    }

    public function markConsent(int $userId): bool {
        return (bool) update_user_meta($userId, 'pofsf_consent_given', 'yes');
    }

    private function hasConsent(int $userId): bool {
        return 'yes' === get_user_meta($userId, 'pofsf_consent_given', true);
    }

    /**
     * Paid orders (processing, completed), newest first.
     *
     * @return list<WC_Order>
     */
    private function paidOrders(array $query): array {
        if (!function_exists('wc_get_orders')) {
            return [];
        }

        try {
            $found = wc_get_orders($query + [
                'status' => function_exists('wc_get_is_paid_statuses') ? wc_get_is_paid_statuses() : ['processing', 'completed'],
                'type' => 'shop_order',
                'limit' => self::MAX_ORDERS,
                'orderby' => 'date',
                'order' => 'DESC',
            ]);
        } catch (\Exception $e) {
            $this->log->error('Error getting orders: ' . $e->getMessage());

            return [];
        }

        return array_values(array_filter((array) $found, static fn ($order): bool => $order instanceof WC_Order));
    }

    /**
     * @param list<WC_Order> $orders
     */
    private function withOrders(array $profile, array $orders): array {
        if ([] === $orders) {
            return $profile;
        }

        $now = time();
        $categories = [];
        $brands = [];
        $attributes = [];
        $unitPrices = [];
        $meta = [];

        foreach ($orders as $order) {
            $created = $order->get_date_created();
            $stamp = $created ? $created->getTimestamp() : $now;
            $decay = 0.5 ** (max(0, $now - $stamp) / DAY_IN_SECONDS / self::HALF_LIFE_DAYS);
            $productIds = [];
            $itemCount = 0;

            foreach ($order->get_items() as $item) {
                if (!$item instanceof \WC_Order_Item_Product) {
                    continue;
                }

                $qty = max(1, (int) $item->get_quantity());
                $amount = (float) $item->get_subtotal();
                $weight = max($amount, 1.0) * $decay;
                $productId = (int) $item->get_product_id();
                $product = $productId > 0 ? wc_get_product($productId) : null;
                $productIds[] = $productId;
                $itemCount += $qty;

                if ($amount > 0) {
                    array_push($unitPrices, ...array_fill(0, min($qty, 20), $amount / $qty));
                }

                if (!$product instanceof WC_Product) {
                    continue;
                }

                foreach ($product->get_category_ids() as $catId) {
                    self::add($categories, (string) (int) $catId, $weight);
                }

                foreach (self::brandIds($productId) as $brandId) {
                    self::add($brands, (string) $brandId, $weight);
                }

                foreach ($this->itemAttributes($item, $product) as $taxonomy => $values) {
                    foreach ($values as $value) {
                        self::add($attributes[$taxonomy], $value, $weight);
                    }
                }
            }

            $meta[] = [
                'order_id' => $order->get_id(),
                'total' => (float) $order->get_total(),
                'date' => $created ? $created->date('Y-m-d') : '',
                'item_count' => $itemCount,
                'product_ids' => array_values(array_unique($productIds)),
            ];
        }

        $profile['past_orders_meta'] = $meta;
        $profile['preferred_categories'] = $this->namedTerms($categories, 'product_cat', self::TOP_CATEGORIES);
        $profile['brands'] = taxonomy_exists('product_brand') ? $this->namedTerms($brands, 'product_brand', self::TOP_VALUES) : [];
        $profile['attributes'] = $this->namedAttributes($attributes);
        $profile['sizes_colors'] = self::sizesColors($profile['attributes']);
        $profile['price_range'] = $this->priceRange($unitPrices);
        $profile['price_band'] = $this->priceBand($meta);
        $profile['activity'] = self::activity($meta, $now);
        $profile['buying_rhythm'] = $this->buyingRhythm($meta);

        return $profile;
    }

    /** @param array<string, array{weight: float, count: int}>|null $bucket */
    private static function add(?array &$bucket, string $key, float $weight): void {
        $bucket ??= [];
        $bucket[$key] ??= ['weight' => 0.0, 'count' => 0];
        $bucket[$key]['weight'] += $weight;
        ++$bucket[$key]['count'];
    }

    /** @return list<int> */
    private static function brandIds(int $productId): array {
        if (!taxonomy_exists('product_brand')) {
            return [];
        }

        $ids = wp_get_post_terms($productId, 'product_brand', ['fields' => 'ids']);

        return is_array($ids) ? array_map('intval', $ids) : [];
    }

    /**
     * Every attribute of what the customer bought: the variation they
     * chose (size, colour) and the product's other attributes (material,
     * fit, style), as taxonomy => term slugs, or name => text for custom
     * attributes.
     *
     * @return array<string, list<string>>
     */
    private function itemAttributes(\WC_Order_Item_Product $item, WC_Product $product): array {
        $found = [];

        foreach ($item->get_meta_data() as $meta) {
            $key = (string) $meta->key;

            if ('' !== $key && '_' !== $key[0] && is_scalar($meta->value) && '' !== (string) $meta->value) {
                $found[self::attributeKey($key)][] = (string) $meta->value;
            }
        }

        foreach ($product->get_attributes() as $attribute) {
            if (!$attribute instanceof \WC_Product_Attribute) {
                continue;
            }

            $key = self::attributeKey($attribute->get_name());

            // The variation's own value says more than every option the product has.
            if ($attribute->get_variation() && isset($found[$key])) {
                continue;
            }

            $values = $attribute->is_taxonomy()
                ? array_map(static fn ($term): string => $term->slug, array_filter($attribute->get_terms() ?: [], static fn ($term): bool => $term instanceof \WP_Term))
                : $attribute->get_options();

            // Only attributes that describe this product, not a long list of options.
            if (!$attribute->get_variation() && count($values) <= 3) {
                $found[$key] = [...($found[$key] ?? []), ...array_map('strval', $values)];
            }
        }

        $out = [];

        foreach (array_filter($found, static fn ($v): bool => is_array($v) && [] !== $v) as $key => $values) {
            $out[$key] = array_values(array_unique(array_map(static fn (string $v): string => self::attributeValue((string) $key, $v), $values)));
        }

        return $out;
    }

    /**
     * One key per attribute: a custom attribute named like a global one
     * ("Size" and pa_size) counts as the global one.
     */
    private static function attributeKey(string $key): string {
        $key = (string) preg_replace('/^attribute_/', '', $key);

        if (str_starts_with($key, 'pa_')) {
            return $key;
        }

        $key = sanitize_title($key);

        return taxonomy_exists('pa_' . $key) ? 'pa_' . $key : $key;
    }

    /**
     * A value as the attribute's term slug when it has one ("Red" → red),
     * so the same value from a custom and a global attribute matches.
     */
    private static function attributeValue(string $key, string $value): string {
        if (!taxonomy_exists($key)) {
            return $value;
        }

        if (get_term_by('slug', $value, $key)) {
            return $value;
        }

        $term = get_term_by('name', $value, $key);

        return $term instanceof \WP_Term ? $term->slug : $value;
    }

    /**
     * @param array<string, array{weight: float, count: int}> $weights
     * @return list<array{id: int, name: string, count: int, weight: float}>
     */
    private function namedTerms(array $weights, string $taxonomy, int $limit): array {
        uasort($weights, static fn (array $a, array $b): int => $b['weight'] <=> $a['weight']);
        $out = [];

        foreach ($weights as $id => $row) {
            $term = get_term((int) $id, $taxonomy);

            if ($term instanceof \WP_Term) {
                $out[] = ['id' => (int) $id, 'name' => html_entity_decode($term->name, ENT_QUOTES), 'count' => $row['count'], 'weight' => round($row['weight'], 2)];
            }

            if (count($out) >= $limit) {
                break;
            }
        }

        return $out;
    }

    /**
     * @param array<string, array<string, array{weight: float, count: int}>> $attributes
     * @return array<string, array{label: string, values: list<array{value: string, name: string, count: int, weight: float}>}>
     */
    private function namedAttributes(array $attributes): array {
        $out = [];

        foreach ($attributes as $key => $values) {
            uasort($values, static fn (array $a, array $b): int => $b['weight'] <=> $a['weight']);
            $rows = [];

            foreach (array_slice($values, 0, self::TOP_VALUES, true) as $value => $row) {
                $term = taxonomy_exists($key) ? get_term_by('slug', (string) $value, $key) : false;
                $rows[] = [
                    'value' => (string) $value,
                    'name' => $term instanceof \WP_Term ? html_entity_decode($term->name, ENT_QUOTES) : (string) $value,
                    'count' => $row['count'],
                    'weight' => round($row['weight'], 2),
                ];
            }

            $out[$key] = ['label' => self::attributeLabel($key), 'values' => $rows];
        }

        return $out;
    }

    public static function attributeLabel(string $key): string {
        $label = taxonomy_exists($key) && function_exists('wc_attribute_label') ? html_entity_decode(wc_attribute_label($key), ENT_QUOTES) : $key;

        // A custom attribute (its name as written is not stored), or a global one without a label: tidy the key.
        return $label !== $key ? $label : mb_convert_case(str_replace(['-', '_'], ' ', (string) preg_replace('/^pa_/', '', $key)), MB_CASE_TITLE);
    }

    /**
     * Sizes and colours in the earlier list shape, which offers created
     * before stored profiles and the data exporter read.
     */
    private static function sizesColors(array $attributes): array {
        $rows = [];

        foreach ($attributes as $key => $attribute) {
            $kind = match (true) {
                str_contains($key, 'size') => 'size',
                str_contains($key, 'colo') => 'color',
                default => null,
            };

            foreach (null !== $kind ? $attribute['values'] : [] as $value) {
                $rows[] = ['attribute' => $kind, 'value' => $value['name']];
            }
        }

        return $rows;
    }

    /**
     * What the customer usually pays for one item, and where that sits in
     * the store's prices: budget, mid or premium.
     *
     * @param list<float> $prices
     */
    private function priceRange(array $prices): array {
        if ([] === $prices) {
            return [];
        }

        sort($prices);
        $at = static fn (float $q): float => round($prices[(int) floor($q * (count($prices) - 1))], 2);
        $median = $at(0.5);
        [$low, $high] = StorePrices::thirds();

        return [
            'min' => round($prices[0], 2),
            'max' => round(end($prices), 2),
            'median' => $median,
            'typical_low' => $at(0.25),
            'typical_high' => $at(0.75),
            'band' => null === $low ? '' : match (true) {
                $median < $low => 'budget',
                $median > $high => 'premium',
                default => 'mid',
            },
        ];
    }

    /**
     * Order totals split in three ranges (the earlier price band, kept for
     * the assistant's offer list).
     */
    private function priceBand(array $meta): array {
        $totals = array_map(static fn (array $o): float => (float) $o['total'], $meta);
        $min = min($totals);
        $max = max($totals);
        $fmt = static fn (float $a, float $b): array => [
            'min' => round($a, 2),
            'max' => round($b, 2),
            'label' => html_entity_decode(wp_strip_all_tags(wc_price($a) . ' – ' . wc_price($b)), ENT_QUOTES),
        ];

        if ($min === $max) {
            return [$fmt($min, $max)];
        }

        $third = ($max - $min) / 3;

        return [$fmt($min, $min + $third), $fmt($min + $third, $min + 2 * $third), $fmt($min + 2 * $third, $max)];
    }

    /**
     * How recently, often and much the customer buys.
     */
    private static function activity(array $meta, int $now): array {
        $dates = array_values(array_filter(array_column($meta, 'date')));
        $total = array_sum(array_column($meta, 'total'));
        $count = count($meta);
        $last = $dates[0] ?? '';
        $first = '' !== $last ? (string) end($dates) : '';
        $span = '' !== $first ? (strtotime($last) - strtotime($first)) / DAY_IN_SECONDS : 0;

        return [
            'order_count' => $count,
            'total_spent' => round($total, 2),
            'average_order' => $count > 0 ? round($total / $count, 2) : 0.0,
            'first_order' => $first,
            'last_order' => $last,
            'days_since_last' => '' !== $last ? max(0, (int) floor(($now - strtotime($last . ' UTC')) / DAY_IN_SECONDS)) : null,
            'average_gap_days' => $count > 1 ? (int) round($span / ($count - 1)) : null,
        ];
    }

    private function buyingRhythm(array $meta): array {
        if (count($meta) < 2) {
            return [];
        }

        $stamps = array_map(static fn (array $o): int => (int) strtotime($o['date']), $meta);
        rsort($stamps);
        $details = [];

        for ($i = 1; $i < count($stamps); $i++) {
            $days = max(1, (int) floor(($stamps[$i - 1] - $stamps[$i]) / DAY_IN_SECONDS));

            $details[] = [
                'frequency' => $this->frequencyLabel($days),
                'days' => $days,
                'from' => gmdate('Y-m-d', $stamps[$i - 1]),
                'to' => gmdate('Y-m-d', $stamps[$i]),
            ];
        }

        $freq = array_count_values(array_column($details, 'frequency'));
        arsort($freq);

        return ['most_common' => (string) key($freq), 'details' => array_slice($details, 0, 20)];
    }

    private function frequencyLabel(int $days): string {
        return match (true) {
            1 === $days => _x('daily', 'buying rhythm frequency', 'personalized-offers-for-spacefast'),
            $days <= 7 => _x('weekly', 'buying rhythm frequency', 'personalized-offers-for-spacefast'),
            $days <= 30 => _x('bi-weekly', 'buying rhythm frequency', 'personalized-offers-for-spacefast'),
            $days <= 90 => _x('monthly', 'buying rhythm frequency', 'personalized-offers-for-spacefast'),
            default => _x('quarterly', 'buying rhythm frequency', 'personalized-offers-for-spacefast'),
        };
    }
}
