<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Repository\BrandSnapshotRepository;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Value\BrandSnapshot;
use Micemade\PersonalizedOffers\Value\OfferCopy;
use Micemade\PersonalizedOffers\Value\OfferDesign;
use WP_Error;
use ZipArchive;

final class ZipExporter {
    public function __construct(
        private readonly OfferRepository $offers,
        private readonly BrandSnapshotRepository $brands,
        private readonly BrandTemplate $brandTemplate,
        private readonly OfferPageRenderer $renderer,
        private readonly TokenService $tokens = new TokenService(),
    ) {}

    /**
     * Builds the offer ZIP for a manual download and marks the offer as sent.
     */
    public function export(int $offerId): string|WP_Error {
        $path = $this->buildZip($offerId);

        if ($path instanceof WP_Error) {
            return $path;
        }

        $offer = $this->offers->find($offerId);
        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $offerData['exported_at'] = current_time('mysql');

        $this->offers->update($offerId, ['status' => OfferStatus::Sent, 'offer_data' => $offerData]);

        return $path;
    }

    /**
     * Writes a self-contained static site to a temporary ZIP: index.html,
     * its stylesheet (assets/offer/offer.css), the cart script and the
     * products' data (offer-cart.js, products.json), and copies of every
     * store image the page uses (assets/media/, assets/brand/), so nothing
     * loads from the store. The caller deletes the file when done.
     */
    public function buildZip(int $offerId): string|WP_Error {
        $offer = $this->exportableOffer($offerId);

        if ($offer instanceof WP_Error) {
            return $offer;
        }

        $brand = $this->brand();
        $design = OfferDesign::fromOffer($offer);
        [$images, $files] = $this->bundledImages($brand);
        $assets = new ExportAssets();

        $offerJson = is_array($offer['offer_data']['offer_json'] ?? null) ? $offer['offer_data']['offer_json'] : [];
        $cart = $this->renderer->cartData($offerJson, $this->offerUrl($offer), $offerId);

        // Copied images first: the page inlines the cart data too.
        foreach ($cart['products'] as &$product) {
            $product['image'] = $assets->add((string) $product['image']);

            foreach ($product['variations'] as &$variation) {
                $variation['image'] = $assets->add((string) $variation['image']);
            }

            unset($variation);
        }

        unset($product);

        $page = $this->pageFor($offer, $brand, $design, $images, false, $cart, true);
        // After the render: the stylesheet includes the block styles that render generated.
        $css = $this->renderer->css($brand, $design);

        $script = POFSF_PLUGIN_DIR . OfferPageRenderer::SCRIPT_FILE;

        $files[OfferPageRenderer::EXPORT_CSS] = ['bytes' => $assets->rewriteCss($css, '../../')];
        $files[OfferPageRenderer::EXPORT_DATA] = ['bytes' => (string) wp_json_encode($cart, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)];
        $files[OfferPageRenderer::EXPORT_SCRIPT] = ['bytes' => is_readable($script) ? (string) file_get_contents($script) : ''];
        $page = $assets->rewriteHtml($page);

        return $this->createZip($page, $files + $assets->files(), $offerId);
    }

    /**
     * Renders the offer page HTML without side effects, for admin previews.
     */
    public function renderHtml(int $offerId): string|WP_Error {
        $offer = $this->exportableOffer($offerId);

        if ($offer instanceof WP_Error) {
            return $offer;
        }

        $brand = $this->brand();

        return $this->pageFor($offer, $brand, OfferDesign::fromOffer($offer), $this->linkedImages($brand), true);
    }

    /**
     * Renders an unsaved offer row (OfferEditor::draft()) for the offer
     * form's live preview. No status check: drafts are never exported.
     */
    public function renderDraft(array $offer): string {
        $brand = $this->brand();

        return $this->pageFor($offer, $brand, OfferDesign::fromOffer($offer), $this->linkedImages($brand), true, null, false, true);
    }

    /**
     * Renders a template with sample copy and real store products, for
     * previewing templates before any offer uses them.
     *
     * @param array{headline?: string, fields?: list<array{type: string, text: string}>} $copy Offer texts to show instead of the samples (EditorCopy).
     */
    public function renderSample(OfferDesign $design, string $content = '', array $copy = []): string {
        $copy = self::withSampleCopy($this->sampleCopy(), $copy);
        $brand = $this->brand();

        $shop = (string) wc_get_page_permalink('shop');

        // The sample products work in the cart; its checkout goes to the shop (a sample has no offer link).
        return $this->renderer->render($copy, $brand, $design, $shop, 0, $this->linkedImages($brand), [
            'cart' => $this->renderer->cartData($copy, $shop, 0),
            'admin_preview' => true,
        ], $content);
    }

    /**
     * Sample offer data for the offer blocks in the template editor.
     *
     * @param array{headline?: string, fields?: list<array{type: string, text: string}>} $copy Offer texts to show instead of the samples (EditorCopy).
     */
    public function sampleVars(OfferDesign $design, array $copy = []): array {
        $copy = self::withSampleCopy($this->sampleCopy(), $copy);
        $brand = $this->brand();

        return $this->renderer->vars($copy, $brand, $design, (string) wc_get_page_permalink('shop'), $this->linkedImages($brand));
    }

    /**
     * The sample offer with the offer texts in $copy (EditorCopy): its
     * headline if set, its fields, sample fields of the types it lacks, and
     * its products if any.
     */
    private static function withSampleCopy(array $sample, array $copy): array {
        if ('' !== trim((string) ($copy['headline'] ?? ''))) {
            $sample['headline'] = (string) $copy['headline'];
        }

        if ('' !== trim((string) ($copy['button_text'] ?? ''))) {
            $sample['button_text'] = (string) $copy['button_text'];
        }

        $sample['fields'] = OfferCopy::withFallback(OfferCopy::sanitizeFields($copy['fields'] ?? [], true), $sample['fields']);

        if (!empty($copy['product_picks']) && is_array($copy['product_picks'])) {
            $sample['product_picks'] = $copy['product_picks'];
        }

        return $sample;
    }

    /**
     * Sample offer JSON: copy and the store's first products.
     */
    private function sampleCopy(): array {
        $picks = [];
        $stories = [
            [
                __('Where the weekend begins', 'personalized-offers-for-spacefast'),
                __('Some pieces earn their place by being the first thing you reach for. This is one of them: easy, honest and made to be lived in.', 'personalized-offers-for-spacefast'),
                __('A favourite with customers who shop like you.', 'personalized-offers-for-spacefast'),
            ],
            [
                __('The quiet companion', 'personalized-offers-for-spacefast'),
                __('It picks up where your last order left off, so the things you already love feel new again.', 'personalized-offers-for-spacefast'),
                __('Pairs well with your recent orders.', 'personalized-offers-for-spacefast'),
            ],
            [
                __('Worth the wait', 'personalized-offers-for-spacefast'),
                __('You had your eye on this one before. It is back, in your size, and it looks even better than you remember.', 'personalized-offers-for-spacefast'),
                __('Back in stock in your size.', 'personalized-offers-for-spacefast'),
            ],
            [
                __('The finishing touch', 'personalized-offers-for-spacefast'),
                __('Small, considered and easy to overlook, until you notice how much it brings everything else together.', 'personalized-offers-for-spacefast'),
                __('Often bought together with your last order.', 'personalized-offers-for-spacefast'),
            ],
        ];

        if (function_exists('wc_get_products')) {
            foreach (wc_get_products(['status' => 'publish', 'limit' => 4, 'stock_status' => 'instock']) as $i => $product) {
                [$title, $story, $reason] = $stories[$i] ?? ['', '', ''];
                $picks[] = ['product_id' => $product->get_id(), 'variation_id' => 0, 'title' => $title, 'story' => $story, 'reason' => $reason];
            }
        }

        return [
            'headline' => __('A few good things for the days you keep for yourself', 'personalized-offers-for-spacefast'),
            'fields' => [
                ['type' => 'overheadline', 'text' => __('The Slow Weekend message', 'personalized-offers-for-spacefast')],
                ['type' => 'greeting', 'text' => __('Hi Sam,', 'personalized-offers-for-spacefast')],
                ['type' => 'subheadline', 'text' => __('Four pieces for unhurried mornings and long walks', 'personalized-offers-for-spacefast')],
                ['type' => 'body', 'text' => __('We looked back at what you have loved so far and imagined the next chapter: unhurried mornings, long walks and the pieces that make them better.', 'personalized-offers-for-spacefast')],
                ['type' => 'additional', 'text' => __('Everything here was chosen with you in mind. Take your time, and make it yours.', 'personalized-offers-for-spacefast')],
            ],
            'product_picks' => $picks,
        ];
    }

    private function exportableOffer(int $offerId): array|WP_Error {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return new WP_Error('offer_not_found', __('Offer not found.', 'personalized-offers-for-spacefast'));
        }

        $status = OfferStatus::tryFrom((string) ($offer['status'] ?? ''));

        if (!$status instanceof OfferStatus || !$status->isExportable()) {
            return new WP_Error('offer_not_ready', __('Offer is not ready for export yet.', 'personalized-offers-for-spacefast'));
        }

        return $offer;
    }

    /**
     * Active brand snapshot, or an empty one (store name only) if none was captured.
     */
    public function brand(): BrandSnapshot {
        $row = $this->brands->findActive();

        return BrandSnapshot::fromArray(is_array($row['data'] ?? null) ? $row['data'] : []);
    }

    /**
     * Logo and site icon referenced by their store URLs, for admin previews.
     *
     * @return array{logo: ?string, icon: ?string}
     */
    private function linkedImages(BrandSnapshot $brand): array {
        $assets = $this->brandTemplate->assets($brand);

        return [
            'logo' => $assets['logo']['url'] ?? null,
            'icon' => $assets['icon']['url'] ?? null,
        ];
    }

    /**
     * Logo and site icon copied into the export, so the published page does
     * not depend on the store's media URLs (which may be local or private).
     *
     * @return array{0: array{logo: ?string, icon: ?string}, 1: array<string, array{path?: string, bytes?: string}>}
     */
    private function bundledImages(BrandSnapshot $brand): array {
        $images = ['logo' => null, 'icon' => null];
        $files = [];

        foreach ($this->brandTemplate->assets($brand) as $key => $asset) {
            if (null === $asset) {
                continue;
            }

            $zipPath = 'assets/brand/' . $key . '.' . $asset['ext'];

            if ('' !== $asset['bytes']) {
                $files[$zipPath] = ['bytes' => $asset['bytes']];
            } elseif ('' !== $asset['path']) {
                $files[$zipPath] = ['path' => $asset['path']];
            } else {
                // No local file (e.g. offloaded media): fall back to the public URL.
                $images[$key] = $asset['url'];
                continue;
            }

            $images[$key] = $zipPath;
        }

        return [$images, $files];
    }

    /**
     * @param bool   $preview For admin previews: the offer link is marked
     *                        so opening it does not count as a use.
     * @param ?array $cart    Cart data (OfferPageRenderer::cartData()); built here when null.
     * @param bool   $export  The page links its stylesheet, script and data files.
     * @param bool   $adminPreview Shown inside an admin modal (OfferPageRenderer::render() admin_preview).
     */
    private function pageFor(array $offer, BrandSnapshot $brand, OfferDesign $design, array $images, bool $preview = false, ?array $cart = null, bool $export = false, bool $adminPreview = false): string {
        $offerJson = $offer['offer_data']['offer_json'] ?? [];
        $offerJson = is_array($offerJson) ? $offerJson : [];
        $offerUrl = $this->offerUrl($offer, $preview);

        return $this->renderer->render(
            $offerJson,
            $brand,
            $design,
            $offerUrl,
            (int) $offer['id'],
            $images,
            [
                'recipient_links' => 'group' === ($offer['type'] ?? ''),
                'export' => $export,
                'admin_preview' => $adminPreview,
                'cart' => $cart ?? $this->renderer->cartData($offerJson, $offerUrl, (int) $offer['id']),
                // Only a public offer is meant to be shared on social networks.
                'social' => 'public' === ($offer['type'] ?? '') ? OfferShare::card($offerJson) : null,
            ],
            (string) ($offer['offer_data']['template_content'] ?? ''),
        );
    }

    /**
     * The offer link the page's buttons lead through (CheckoutHandler).
     */
    private function offerUrl(array $offer, bool $preview = false): string {
        $token = (string) ($offer['token'] ?? '');

        if ('' === $token) {
            return wc_get_checkout_url();
        }

        $args = ['pofsf_offer' => rawurlencode($token)];

        if ($preview) {
            $args['pofsf_preview'] = $this->tokens->previewSignature($token);
        }

        return add_query_arg($args, home_url('/'));
    }

    /**
     * @param array<string, array{path?: string, bytes?: string}> $files Extra files keyed by path in the ZIP.
     */
    private function createZip(string $page, array $files, int $offerId): string|WP_Error {
        if (!class_exists(ZipArchive::class)) {
            return new WP_Error('no_zip', __('ZipArchive is not available on this server.', 'personalized-offers-for-spacefast'));
        }

        $slug = 'offer_' . substr(md5((string) microtime(true) . $offerId), 0, 10);
        $dir = $this->exportDir();

        if (null === $dir) {
            return new WP_Error('zip_error', __('No writable export directory.', 'personalized-offers-for-spacefast'));
        }

        $path = $dir . "offer-{$slug}.zip";
        $zip = new ZipArchive();

        if (true !== $zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
            return new WP_Error('zip_error', __('Failed to create ZIP file.', 'personalized-offers-for-spacefast'));
        }

        foreach ($files as $zipPath => $file) {
            if (isset($file['bytes'])) {
                $zip->addFromString($zipPath, $file['bytes']);
            } elseif (isset($file['path']) && is_readable($file['path'])) {
                $zip->addFile($file['path'], $zipPath);
            }
        }

        $zip->addFromString('index.html', $page);
        $zip->close();

        if (!file_exists($path)) {
            return new WP_Error('zip_error', __('ZIP file could not be written.', 'personalized-offers-for-spacefast'));
        }

        return $path;
    }

    private function exportDir(): ?string {
        $upload = wp_upload_dir();
        $dir = trailingslashit((string) ($upload['basedir'] ?? '')) . 'pofsf_exports/';

        if ('' !== $upload['basedir'] && wp_mkdir_p($dir) && wp_is_writable($dir)) {
            return $dir;
        }

        $fallback = trailingslashit(get_temp_dir()) . 'pofsf_exports/';

        return wp_mkdir_p($fallback) && wp_is_writable($fallback) ? $fallback : null;
    }
}
