<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Enum\OfferType;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\RecipientRepository;
use WC_Order;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Offer links (?pofsf_offer=TOKEN…) are opened by customers, often logged out, from static Spacefast pages on another domain, so they cannot carry a nonce. Each request is authorized by its token (looked up by HMAC hash, with expiry and use limits), and every value read is sanitized.

/**
 * The offer link (?pofsf_offer=TOKEN) leads where the offer page's Action
 * button points (pofsf_to): "cart" fills the cart with the picks, applies
 * the coupon and opens the cart; "shop" opens the shop showing only the
 * picks, and "product" one pick's page (pofsf_pick, 1-based), where the
 * coupon applies once something is added to the cart. Links without
 * pofsf_to (pages published before the Offer action button) fill the cart and
 * open checkout. "Complete purchase" in the offer page's own cart
 * (offer-cart.js) sends what the customer chose (pofsf_cart, see
 * pageCart()) to checkout. The offer is remembered in the customer's session, and
 * the order placed from it counts as a use. A group offer is used through
 * its recipients' own tokens, each with their own uses.
 */
final class CheckoutHandler {
    private const SESSION_KEY = 'pofsf_offer';
    private const ORDER_META = '_pofsf_offer_id';

    public function __construct(
        private readonly OfferRepository $offers,
        private readonly TokenService $tokens,
        private readonly ProfileBuilder $profiles,
        private readonly Logger $log,
        private readonly ProductVariations $variations = new ProductVariations(),
        private readonly RecipientRepository $recipients = new RecipientRepository(),
    ) {}

    public function register(): void {
        // Offer pages refresh prices and stock from the Store API.
        StoreApiCors::register();
        add_action('template_redirect', [$this, 'handleRedirect'], 5);
        add_action('woocommerce_add_to_cart', [$this, 'applyPendingCoupon']);
        add_action('woocommerce_product_query', [$this, 'showPicks']);
        // Classic checkout, and the Checkout block (Store API).
        add_action('woocommerce_checkout_order_created', [$this, 'recordOrder']);
        add_action('woocommerce_store_api_checkout_order_processed', [$this, 'recordOrder']);
    }

    public function handleRedirect(): void {
        if (empty($_GET['pofsf_offer']) || !function_exists('WC') || !WC()->cart) {
            return;
        }

        $token = sanitize_text_field(wp_unslash((string) $_GET['pofsf_offer']));
        $hash = $this->tokens->hash($token);
        $recipient = $this->recipients->findByTokenHash($hash);
        $offer = null !== $recipient ? $this->offers->find($recipient['offer_id']) : $this->offers->findByTokenHash($hash);

        if (null === $offer) {
            $this->fail(__('Invalid or expired offer token.', 'personalized-offers-for-spacefast'));
        }

        // Admin previews and store managers testing the link: fill the cart, change nothing.
        $preview = $this->tokens->isPreview($token, isset($_GET['pofsf_preview']) ? sanitize_key(wp_unslash((string) $_GET['pofsf_preview'])) : '')
            || current_user_can('manage_woocommerce');

        if (!$preview) {
            $this->guard($offer, $recipient);
        }

        if (WC()->session) {
            WC()->session->set_customer_session_cookie(true);
        }

        $target = isset($_GET['pofsf_to']) ? sanitize_key(wp_unslash((string) $_GET['pofsf_to'])) : 'checkout';
        $fill = in_array($target, ['cart', 'checkout'], true);

        if ($fill) {
            // A coupon still waiting from an earlier visit must not apply while the picks go in.
            WC()->session?->set(self::SESSION_KEY, null);
            WC()->cart->empty_cart();

            $chosen = $this->pageCart($offer);

            if (null !== $chosen) {
                // The cart the customer filled on the offer page.
                foreach ($chosen as $item) {
                    $this->addChosen($item);
                }
            } else {
                foreach ($this->resolveItems($offer) as $item) {
                    $this->addItem($item['product_id'], $item['variation_id'], $item['quantity']);
                }
            }
        }

        // A preview keeps the admin's own checkout details.
        if (!$preview) {
            $this->applyAddress($offer, (int) ($recipient['user_id'] ?? $offer['user_id']));
        }

        $coupon = (string) ($offer['coupon_code'] ?? '');
        $picks = $this->pickIds($offer);

        // Browsing first: the coupon waits for the cart to have something in it.
        $pending = '' !== $coupon && !$fill && WC()->cart->is_empty();

        if ('' !== $coupon && !$pending && !WC()->cart->has_discount($coupon)) {
            WC()->cart->apply_coupon($coupon);
        }

        if (WC()->session) {
            WC()->session->set(self::SESSION_KEY, [
                'id' => (int) $offer['id'],
                'recipient' => (int) ($recipient['id'] ?? 0),
                'preview' => $preview,
                'picks' => $picks,
                'coupon' => $pending ? $coupon : '',
            ]);
        }

        if ($preview) {
            wc_add_notice(__('Offer preview: an order placed from this cart does not count as a use of the offer.', 'personalized-offers-for-spacefast'), 'notice');
        }

        wp_safe_redirect($this->destination($target, $picks));
        exit;
    }

    /**
     * Where an offer link leads (see the class description). A product that
     * is not among the picks any more falls back to the shop showing them.
     *
     * @param list<int> $picks
     */
    private function destination(string $target, array $picks): string {
        if ('product' === $target) {
            $pick = isset($_GET['pofsf_pick']) ? absint($_GET['pofsf_pick']) : 1;
            $url = isset($picks[$pick - 1]) ? get_permalink($picks[$pick - 1]) : false;

            if (is_string($url) && '' !== $url) {
                return $url;
            }

            $target = 'shop';
        }

        return match ($target) {
            'cart' => wc_get_cart_url(),
            'shop' => add_query_arg('pofsf_picks', '1', (string) wc_get_page_permalink('shop')),
            default => wc_get_checkout_url(),
        };
    }

    /**
     * The offer's coupon, once the customer who came from a shop or product
     * link adds something to the cart.
     */
    public function applyPendingCoupon(): void {
        $session = function_exists('WC') && WC()->session ? WC()->session : null;
        $data = $session?->get(self::SESSION_KEY);
        $coupon = is_array($data) ? (string) ($data['coupon'] ?? '') : '';

        if ('' === $coupon || !WC()->cart) {
            return;
        }

        $data['coupon'] = '';
        $session->set(self::SESSION_KEY, $data);

        if (!WC()->cart->has_discount($coupon)) {
            WC()->cart->apply_coupon($coupon);
        }
    }

    /**
     * The shop shows only the offer's picks when opened from its shop link.
     */
    public function showPicks(\WP_Query $query): void {
        if (!isset($_GET['pofsf_picks']) || !function_exists('WC') || !WC()->session) {
            return;
        }

        $data = WC()->session->get(self::SESSION_KEY);
        $picks = is_array($data) ? array_values(array_filter(array_map('intval', (array) ($data['picks'] ?? [])))) : [];

        if ([] !== $picks) {
            $query->set('post__in', $picks);
        }
    }

    /**
     * Product IDs of the offer's picks, in the offer's order.
     *
     * @return list<int>
     */
    private function pickIds(array $offer): array {
        return array_values(array_unique(array_filter(array_map(
            static fn (mixed $pick): int => is_array($pick) ? (int) ($pick['product_id'] ?? 0) : 0,
            (array) ($offer['offer_data']['offer_json']['product_picks'] ?? []),
        ))));
    }

    /**
     * Stops a customer's visit when the offer cannot be used (any more).
     * max_uses 0 means the offer has no usage limit; for a group offer it
     * is each recipient's limit.
     */
    private function guard(array $offer, ?array $recipient): void {
        $status = OfferStatus::tryFrom((string) $offer['status']);

        if (!$status instanceof OfferStatus || in_array($status, [OfferStatus::Pending, OfferStatus::Building, OfferStatus::Failed], true)) {
            $this->fail(__('This offer is not available.', 'personalized-offers-for-spacefast'));
        }

        if (OfferStatus::Revoked === $status && !OfferLimits::revokedByLimit($offer)) {
            $this->fail(__('This offer has been withdrawn.', 'personalized-offers-for-spacefast'));
        }

        $group = OfferType::Group->value === ($offer['type'] ?? '');

        if ($group && null === $recipient) {
            $this->fail(__('This offer is for invited customers. Please use the personal link you received.', 'personalized-offers-for-spacefast'));
        }

        if (null !== $recipient && RecipientRepository::REVOKED === $recipient['status']) {
            $this->fail(__('This offer has been withdrawn.', 'personalized-offers-for-spacefast'));
        }

        if (OfferLimits::usedUp($offer) || (null !== $recipient && RecipientRepository::USED === $recipient['status'])) {
            $this->fail(__('This offer has already been used.', 'personalized-offers-for-spacefast'));
        }

        // expires_at is stored in UTC.
        if (current_time('mysql', true) > $offer['expires_at']) {
            $this->offers->update((int) $offer['id'], ['status' => OfferStatus::Expired]);
            JobScheduler::scheduleAccessSync((int) $offer['id']);
            $this->fail(__('This offer has expired.', 'personalized-offers-for-spacefast'));
        }

        if (!$group && OfferLimits::reached($offer)) {
            $this->offers->update((int) $offer['id'], ['status' => OfferStatus::Used]);
            $this->fail(__('This offer has already been used.', 'personalized-offers-for-spacefast'));
        }

        $max = (int) $offer['max_uses'];

        if (null !== $recipient && $max > 0 && $recipient['used_count'] >= $max) {
            $this->recipients->update($recipient['id'], ['status' => RecipientRepository::USED]);
            $this->fail(__('This offer has already been used.', 'personalized-offers-for-spacefast'));
        }

        if (null !== $recipient) {
            $this->profiles->markConsent($recipient['user_id']);
            $this->recipients->update($recipient['id'], ['consent_given' => 1]);
        } elseif ((int) $offer['user_id'] > 0) {
            $this->profiles->markConsent((int) $offer['user_id']);
        }
    }

    /**
     * Counts the order as a use of the offer the customer came from, once
     * per order (payment retries place the same order again). An order
     * without any of the offer's products or its coupon is not from the
     * offer, and the offer stays remembered for a later order.
     */
    public function recordOrder(mixed $order): void {
        $session = function_exists('WC') && WC()->session ? WC()->session : null;
        $data = $session?->get(self::SESSION_KEY);

        if (!$order instanceof WC_Order || !is_array($data) || '' !== (string) $order->get_meta(self::ORDER_META)) {
            return;
        }

        $offer = $this->offers->find((int) ($data['id'] ?? 0));

        if (null === $offer) {
            $session->set(self::SESSION_KEY, null);

            return;
        }

        if (!$this->fromOffer($order, $offer)) {
            return;
        }

        $session->set(self::SESSION_KEY, null);
        $offerId = (int) $offer['id'];
        $order->update_meta_data(self::ORDER_META, $offerId);

        if (!empty($data['preview'])) {
            $order->update_meta_data('_pofsf_offer_preview', 1);
            $order->save();

            return;
        }

        /* translators: %d: offer ID. */
        $order->add_order_note(sprintf(__('Placed from Spacefast offer #%d.', 'personalized-offers-for-spacefast'), $offerId));
        $order->save();

        $recipientId = (int) ($data['recipient'] ?? 0);

        if ($recipientId > 0) {
            $this->recordGroupOrder($order, $offer, $recipientId);

            return;
        }

        if (!$this->offers->incrementUse($offerId)) {
            $this->log->error(sprintf('Order %d came from offer %d after it reached its usage limit; the use was not counted.', $order->get_id(), $offerId));

            return;
        }

        $offer = $this->offers->find($offerId);

        if (null !== $offer && OfferLimits::reached($offer) && in_array($offer['status'], [OfferStatus::Ready->value, OfferStatus::Sent->value], true)) {
            $this->offers->update($offerId, ['status' => OfferStatus::Used]);
        }
    }

    /**
     * A group offer's order: one use of the recipient's own limit, and one
     * more on the offer's running total. The offer is Used once none of its
     * recipients can use it any more.
     */
    private function recordGroupOrder(WC_Order $order, array $offer, int $recipientId): void {
        $offerId = (int) $offer['id'];
        $max = (int) $offer['max_uses'];

        if (!$this->recipients->incrementUse($recipientId, $max)) {
            $this->log->error(sprintf('Order %d came from offer %d after recipient %d reached the usage limit; the use was not counted.', $order->get_id(), $offerId, $recipientId));

            return;
        }

        $this->offers->countUse($offerId);
        $recipient = $this->recipients->find($recipientId);

        if (null !== $recipient && $max > 0 && $recipient['used_count'] >= $max) {
            $this->recipients->update($recipientId, ['status' => RecipientRepository::USED]);

            if (0 === $this->recipients->countActive($offerId) && in_array($offer['status'], [OfferStatus::Ready->value, OfferStatus::Sent->value], true)) {
                $this->offers->update($offerId, ['status' => OfferStatus::Used]);
            }
        }
    }

    private function fromOffer(WC_Order $order, array $offer): bool {
        $coupon = strtolower((string) ($offer['coupon_code'] ?? ''));

        if ('' !== $coupon && in_array($coupon, array_map('strtolower', $order->get_coupon_codes()), true)) {
            return true;
        }

        $picks = array_map(
            static fn ($pick): int => is_array($pick) ? (int) ($pick['product_id'] ?? 0) : 0,
            (array) ($offer['offer_data']['offer_json']['product_picks'] ?? []),
        );

        foreach ($order->get_items() as $item) {
            if ($item instanceof \WC_Order_Item_Product && in_array($item->get_product_id(), $picks, true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * The offer's picks with their chosen variation. An `items` parameter
     * (product_id:quantity,...) may change quantities or leave picks out,
     * but never adds products the offer did not pick.
     *
     * @return list<array{product_id: int, variation_id: int, quantity: int}>
     */
    private function resolveItems(array $offer): array {
        $picks = [];

        foreach ((array) ($offer['offer_data']['offer_json']['product_picks'] ?? []) as $pick) {
            $id = is_array($pick) ? (int) ($pick['product_id'] ?? 0) : 0;

            if ($id > 0) {
                $picks[$id] = [
                    'product_id' => $id,
                    'variation_id' => max(0, (int) ($pick['variation_id'] ?? 0)),
                    'quantity' => max(1, min(99, (int) ($pick['quantity'] ?? 1))),
                ];
            }
        }

        $param = isset($_GET['items']) ? sanitize_text_field(wp_unslash((string) $_GET['items'])) : '';

        if ('' === $param) {
            return array_values($picks);
        }

        $items = [];

        foreach (explode(',', $param) as $pair) {
            [$id, $qty] = array_map('intval', explode(':', $pair, 2)) + [0, 0];

            if (isset($picks[$id]) && $qty > 0) {
                $items[$id] = ['quantity' => min($qty, 99)] + $picks[$id];
            }
        }

        return array_values($items);
    }

    /** Most lines a page cart may send. */
    private const MAX_CART_LINES = 30;

    /**
     * The cart the customer filled on the offer page: pofsf_cart, base64url
     * JSON [[product_id, variation_id, quantity, {attribute_*: value}], ...].
     * Only the offer's picks, their own variations and the values their
     * attributes allow are kept; WooCommerce prices them again at checkout.
     * Null without the parameter.
     *
     * @return list<array{product_id: int, variation_id: int, quantity: int, attributes: array<string, string>}>|null
     */
    private function pageCart(array $offer): ?array {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- A link from the static offer page; the token authorises it.
        $param = isset($_GET['pofsf_cart']) ? sanitize_text_field(wp_unslash((string) $_GET['pofsf_cart'])) : '';

        if ('' === $param) {
            return null;
        }

        // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Transport encoding of the cart lines.
        $lines = json_decode((string) base64_decode(strtr($param, '-_', '+/'), true), true);
        $picks = array_flip($this->pickIds($offer));
        $items = [];

        foreach (array_slice(is_array($lines) ? $lines : [], 0, self::MAX_CART_LINES) as $line) {
            if (!is_array($line)) {
                continue;
            }

            $productId = (int) ($line[0] ?? 0);
            $variationId = max(0, (int) ($line[1] ?? 0));
            $quantity = max(1, min(99, (int) ($line[2] ?? 1)));

            if (!isset($picks[$productId]) || !$this->variations->valid($productId, $variationId)) {
                continue;
            }

            $attributes = $this->chosenAttributes($productId, $variationId, is_array($line[3] ?? null) ? $line[3] : []);

            if (null === $attributes) {
                continue;
            }

            $key = $productId . ':' . $variationId . ':' . md5((string) wp_json_encode($attributes));
            $items[$key] = [
                'product_id' => $productId,
                'variation_id' => $variationId,
                'quantity' => min(99, ($items[$key]['quantity'] ?? 0) + $quantity),
                'attributes' => $attributes,
            ];
        }

        return array_values($items);
    }

    /**
     * The variation's attributes, with the customer's value for each one it
     * leaves open ("any"), when the product offers that value; [] for a
     * simple product; null for a variable product without a variation.
     *
     * @param array<string, mixed> $chosen
     * @return array<string, string>|null
     */
    private function chosenAttributes(int $productId, int $variationId, array $chosen): ?array {
        $product = wc_get_product($productId);

        if (!$product instanceof \WC_Product_Variable) {
            return 0 === $variationId ? [] : null;
        }

        $variation = $variationId > 0 ? wc_get_product($variationId) : null;

        if (!$variation instanceof \WC_Product_Variation) {
            return null;
        }

        $options = [];

        foreach ($product->get_variation_attributes() as $name => $values) {
            $options['attribute_' . sanitize_title((string) $name)] = array_map('strval', (array) $values);
        }

        $attributes = [];

        foreach ($variation->get_variation_attributes() as $key => $value) {
            if ('' === $value) {
                $wanted = (string) ($chosen[$key] ?? '');
                $value = in_array($wanted, $options[$key] ?? [], true) ? $wanted : '';
            }

            if ('' === $value) {
                return null;
            }

            $attributes[$key] = (string) $value;
        }

        return $attributes;
    }

    /**
     * Adds a line of the page cart as the customer chose it; a choice that
     * cannot be bought any more is left out with a notice.
     *
     * @param array{product_id: int, variation_id: int, quantity: int, attributes: array<string, string>} $item
     */
    private function addChosen(array $item): void {
        $product = wc_get_product($item['variation_id'] ?: $item['product_id']);

        if (!$product || !$product->is_purchasable() || !$product->is_in_stock()) {
            wc_add_notice(
                /* translators: %s: product name. */
                sprintf(__('%s is no longer available and was left out of your cart.', 'personalized-offers-for-spacefast'), $product ? $product->get_name() : '#' . $item['product_id']),
                'notice',
            );

            return;
        }

        if (false === WC()->cart->add_to_cart($item['product_id'], $item['quantity'], $item['variation_id'], $item['attributes'])) {
            $this->log->error(sprintf('Offer page cart could not add product %d (variation %d) to the cart.', $item['product_id'], $item['variation_id']));
        }
    }

    private function addItem(int $productId, int $variationId, int $quantity): void {
        $product = wc_get_product($productId);

        if (!$product || is_wp_error($product)) {
            wc_add_notice(
                /* translators: %d: product ID. */
                sprintf(__('Product ID %d not found or unavailable.', 'personalized-offers-for-spacefast'), $productId),
                'notice',
            );

            return;
        }

        $item = $this->variations->cartItem($productId, $variationId);

        if (null === $item) {
            wc_add_notice(
                /* translators: %s: product name. */
                sprintf(__('Product %s is out of stock.', 'personalized-offers-for-spacefast'), $product->get_name()),
                'notice',
            );

            return;
        }

        if (0 === $item['variation_id'] && !$product->is_in_stock()) {
            wc_add_notice(
                /* translators: %s: product name. */
                sprintf(__('Product %s is out of stock.', 'personalized-offers-for-spacefast'), $product->get_name()),
                'notice',
            );

            return;
        }

        if (false === WC()->cart->add_to_cart($productId, $quantity, $item['variation_id'], $item['attributes'])) {
            $this->log->error(sprintf('Offer checkout could not add product %d (variation %d) to the cart.', $productId, $item['variation_id']));
        }
    }

    /**
     * Prefills checkout for the customer the link belongs to (the offer's,
     * or a group recipient's), which also lets their email-restricted coupon apply.
     */
    private function applyAddress(array $offer, int $userId): void {
        if (!WC()->customer) {
            return;
        }

        $this->prefill($offer, $userId);
        // Into the session now (the redirect ends the request), so checkout and the coupon's email check see it.
        WC()->customer->save();
    }

    private function prefill(array $offer, int $userId): void {
        $user = $userId > 0 ? get_userdata($userId) : false;

        if ($user && class_exists('WC_Customer')) {
            try {
                $customer = new \WC_Customer($userId);
            } catch (\Exception) {
                $customer = null;
            }

            if (null !== $customer) {
                $billing = $this->customerAddress($customer, 'billing');
                // Accounts without a billing email still have their login email.
                $billing['email'] = '' !== $billing['email'] ? $billing['email'] : (string) $user->user_email;

                $this->writeAddress('billing', $billing);
                $this->writeAddress('shipping', $this->customerAddress($customer, 'shipping'));

                return;
            }
        }

        $email = (string) ($offer['guest_email'] ?? '');

        if ('' === $email) {
            return;
        }

        $found = function_exists('wc_get_orders')
            ? wc_get_orders(['customer' => [$email], 'limit' => 1, 'orderby' => 'date', 'order' => 'DESC'])
            : [];

        if ([] === $found) {
            WC()->customer->set_billing_email($email);

            return;
        }

        $order = $found[0];

        $this->writeAddress('billing', $this->orderAddress($order, 'billing', $email));
        $this->writeAddress('shipping', $this->orderAddress($order, 'shipping', $email));
    }

    private function customerAddress(object $customer, string $type): array {
        $get = static fn (string $field): string => method_exists($customer, "get_{$type}_{$field}")
            ? (string) $customer->{"get_{$type}_{$field}"}()
            : '';

        return [
            'first_name' => $get('first_name'),
            'last_name' => $get('last_name'),
            'address_1' => $get('address_1'),
            'address_2' => $get('address_2'),
            'city' => $get('city'),
            'state' => $get('state'),
            'postcode' => $get('postcode'),
            'country' => $get('country'),
            'email' => $get('email'),
            'phone' => $get('phone'),
        ];
    }

    private function orderAddress(object $order, string $type, string $fallbackEmail): array {
        $prefix = 'billing' === $type ? 'billing' : 'shipping';
        $get = static fn (string $field): string => method_exists($order, "get_{$prefix}_{$field}")
            ? (string) $order->{"get_{$prefix}_{$field}"}()
            : '';

        $address = [
            'first_name' => $get('first_name'),
            'last_name' => $get('last_name'),
            'address_1' => $get('address_1'),
            'address_2' => $get('address_2'),
            'city' => $get('city'),
            'state' => $get('state'),
            'postcode' => $get('postcode'),
            'country' => $get('country'),
            'email' => $get('email'),
            'phone' => $get('phone'),
        ];

        if ('' === $address['email']) {
            $address['email'] = $fallbackEmail;
        }

        return $address;
    }

    private function writeAddress(string $type, array $address): void {
        if (!WC()->customer) {
            return;
        }

        foreach ($address as $field => $value) {
            $setter = "set_{$type}_{$field}";

            if ('' !== $value && method_exists(WC()->customer, $setter)) {
                WC()->customer->{$setter}($value);
            }
        }
    }

    private function fail(string $message): never {
        if (function_exists('wc_add_notice')) {
            wc_add_notice($message, 'error');
        } else {
            $this->log->error($message);
        }

        wp_safe_redirect(wc_get_page_permalink('shop'));
        exit;
    }
}
