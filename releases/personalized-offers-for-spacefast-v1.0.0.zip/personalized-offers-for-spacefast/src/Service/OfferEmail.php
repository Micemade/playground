<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Enum\OfferType;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\RecipientRepository;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;
use Micemade\PersonalizedOffers\Value\OfferCopy;
use WP_Error;
use WP_User;

/**
 * The email that sends an offer's Spacefast page: WooCommerce's email
 * template around the offer's title, body text and a button to the page,
 * with its own footer text. Its look uses WooCommerce's email design
 * options (WooCommerce > Settings > Emails: logo, header alignment, font,
 * colours), which each offer may change for its own email (`style`; the
 * store's values apply while the email is rendered, nothing else changes).
 * The email is kept per offer (offer_data.email).
 *
 * It goes to a single offer's customer, or to each customer of a group with
 * their personal link. Public offers are shared, not emailed.
 *
 * Placeholders in the subject, title, body and footer: {first_name},
 * {customer_name}, {site_title} (and WooCommerce's own in the footer).
 */
final class OfferEmail {
    public const LIMITS = ['subject' => 150, 'title' => 150, 'body' => 3000, 'button_text' => 60, 'footer' => 500];

    /** WooCommerce's email design options (woocommerce_email_*), as the offer's `style` keys. */
    public const STYLE = [
        'header_image',
        'header_image_width',
        'header_alignment',
        'font_family',
        'base_color',
        'background_color',
        'body_background_color',
        'text_color',
        'footer_text_color',
    ];

    public const ALIGNMENTS = ['left', 'center', 'right'];

    /** WooCommerce's email fonts (EmailFont::$font) when its class is missing. */
    private const FONTS = ['Arial', 'Comic Sans MS', 'Courier New', 'Georgia', 'Helvetica', 'Lucida', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana'];

    public function __construct(
        private readonly OfferRepository $offers,
        private readonly RecipientRepository $recipients = new RecipientRepository(),
    ) {}

    /**
     * The saved design, or one made from the offer: its headline as subject
     * and title, its body text, its button text and the store's email footer.
     */
    public function design(array $offer): array {
        $saved = $offer['offer_data']['email'] ?? null;

        return is_array($saved) && isset($saved['subject']) ? self::sanitize($saved) : $this->defaults($offer);
    }

    public function defaults(array $offer): array {
        $json = is_array($offer['offer_data']['offer_json'] ?? null) ? $offer['offer_data']['offer_json'] : [];
        $headline = sanitize_text_field((string) ($json['headline'] ?? ''));
        $body = implode("\n\n", OfferCopy::textsByType(OfferCopy::fields($json))['body'] ?? []);

        return self::sanitize([
            'subject' => '' !== $headline ? $headline : sprintf(
                /* translators: %s: store name. */
                __('A special offer from %s', 'personalized-offers-for-spacefast'),
                '{site_title}',
            ),
            'title' => $headline,
            'body' => $body,
            'button_text' => sanitize_text_field((string) ($json['button_text'] ?? '')) ?: __('See your offer', 'personalized-offers-for-spacefast'),
            'footer' => html_entity_decode(wp_strip_all_tags((string) get_option('woocommerce_email_footer_text', '{site_title}')), ENT_QUOTES, 'UTF-8'),
        ]);
    }

    public static function sanitize(mixed $design): array {
        $design = is_array($design) ? $design : [];
        $clean = [];

        foreach (self::LIMITS as $key => $limit) {
            $value = (string) ($design[$key] ?? '');
            $value = in_array($key, ['body', 'footer'], true) ? sanitize_textarea_field($value) : sanitize_text_field($value);
            $clean[$key] = mb_substr($value, 0, $limit);
        }

        $clean['style'] = self::sanitizeStyle($design['style'] ?? []);

        return $clean;
    }

    /**
     * The store's email design options, as WooCommerce > Settings > Emails
     * has them (with WooCommerce's defaults for unset ones).
     */
    public static function styleDefaults(): array {
        $colors = class_exists('Automattic\WooCommerce\Internal\Email\EmailColors')
            ? \Automattic\WooCommerce\Internal\Email\EmailColors::get_default_colors(self::improvements())
            : [];

        return [
            'header_image' => (string) get_option('woocommerce_email_header_image', ''),
            'header_image_width' => (string) get_option('woocommerce_email_header_image_width', '120'),
            'header_alignment' => (string) get_option('woocommerce_email_header_alignment', 'left'),
            'font_family' => (string) get_option('woocommerce_email_font_family', 'Helvetica'),
            'base_color' => (string) get_option('woocommerce_email_base_color', $colors['base'] ?? '#720eec'),
            'background_color' => (string) get_option('woocommerce_email_background_color', $colors['bg'] ?? '#f7f7f7'),
            'body_background_color' => (string) get_option('woocommerce_email_body_background_color', $colors['body_bg'] ?? '#ffffff'),
            'text_color' => (string) get_option('woocommerce_email_text_color', $colors['body_text'] ?? '#3c3c3c'),
            'footer_text_color' => (string) get_option('woocommerce_email_footer_text_color', $colors['footer_text'] ?? '#3c3c3c'),
        ];
    }

    /** The offer's style; anything missing or invalid is the store's option. */
    public static function sanitizeStyle(mixed $style): array {
        $style = is_array($style) ? $style : [];
        $defaults = self::styleDefaults();
        $clean = [];

        foreach (self::STYLE as $key) {
            $value = trim((string) ($style[$key] ?? $defaults[$key]));

            $clean[$key] = match ($key) {
                'header_image' => esc_url_raw($value),
                'header_image_width' => (string) max(20, min(600, (int) ($value ?: $defaults[$key]))),
                'header_alignment' => in_array($value, self::ALIGNMENTS, true) ? $value : $defaults[$key],
                'font_family' => in_array($value, self::fonts(), true) ? $value : $defaults[$key],
                default => (string) (sanitize_hex_color($value) ?: $defaults[$key]),
            };
        }

        return $clean;
    }

    /** @return list<string> The font names WooCommerce's emails offer. */
    public static function fonts(): array {
        $class = 'Automattic\WooCommerce\Internal\Email\EmailFont';

        return class_exists($class) && is_array($class::$font) ? array_keys($class::$font) : self::FONTS;
    }

    /**
     * WooCommerce's newer email templates, which use the logo width, header
     * alignment and font options.
     */
    public static function improvements(): bool {
        $class = 'Automattic\WooCommerce\Utilities\FeaturesUtil';

        return class_exists($class) && $class::feature_is_enabled('email_improvements');
    }

    public function saveDesign(int $offerId, array $design): void {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return;
        }

        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $offerData['email'] = self::sanitize($design);
        $this->offers->update($offerId, ['offer_data' => $offerData]);
    }

    /**
     * Why the offer's email cannot be sent now, or null when it can: public
     * offers are shared instead, and the page must be published and up to
     * date so the link shows the current offer. The Send email(s) endpoint
     * and the assistant's send-offer-email ability both check this.
     */
    public static function sendBlocked(array $offer): ?string {
        if (OfferType::Public === OfferEditor::typeOf($offer)) {
            return __('Public offers are shared with their link, not emailed.', 'personalized-offers-for-spacefast');
        }

        if ('' === self::pageUrl($offer)) {
            return __('Publish the offer to Spacefast first: the email links to its page.', 'personalized-offers-for-spacefast');
        }

        if (OfferPublisher::record($offer)['outdated']) {
            return __('The offer has changes that aren’t on its Spacefast page yet. Update the Space, then send.', 'personalized-offers-for-spacefast');
        }

        return null;
    }

    /**
     * The link the email's button leads to: the published page (a public
     * Space, or its private access link). '' when it is not published.
     */
    public static function pageUrl(array $offer): string {
        return OfferPublisher::pageUrl($offer);
    }

    /**
     * Who the email goes to, each with their link: the customer, or the
     * group's customers (those who used the offer up too, to choose from).
     * None for a public offer.
     *
     * @return list<array{id: int, name: string, first_name: string, email: string, link: string, status: string}>
     */
    public function recipients(array $offer): array {
        $pageUrl = self::pageUrl($offer);
        $type = OfferEditor::typeOf($offer);

        if (OfferType::Group === $type) {
            $rows = [];

            foreach ($this->recipients->forOffer((int) $offer['id']) as $recipient) {
                $user = get_userdata((int) $recipient['user_id']);

                if (RecipientRepository::REVOKED === $recipient['status'] || !$user instanceof WP_User) {
                    continue;
                }

                $rows[] = self::person($user, OfferPublisher::recipientUrl($offer, $recipient), (string) $recipient['status']);
            }

            return $rows;
        }

        if (OfferType::Single === $type) {
            $user = (int) $offer['user_id'] > 0 ? get_userdata((int) $offer['user_id']) : false;

            if ($user instanceof WP_User) {
                return [self::person($user, $pageUrl, 'active')];
            }

            $guest = sanitize_email((string) ($offer['guest_email'] ?? ''));

            return '' !== $guest ? [['id' => 0, 'name' => $guest, 'first_name' => '', 'email' => $guest, 'link' => $pageUrl, 'status' => 'active']] : [];
        }

        return [];
    }

    /**
     * The email as HTML, styled inline as WooCommerce sends it.
     *
     * @param array{name?: string, first_name?: string} $person Who it is for (placeholders).
     */
    public function render(array $design, string $link, array $person = []): string {
        if (!function_exists('WC') || !class_exists('WC_Email')) {
            return '';
        }

        $design = self::sanitize($design);
        $mailer = WC()->mailer();
        $footer = self::fill($design['footer'], $person);
        $setFooter = static fn (): string => $footer;
        // The offer's design options stand in for the store's while this email is rendered.
        $options = [];

        foreach ($design['style'] as $key => $value) {
            $options['pre_option_woocommerce_email_' . $key] = static fn (): string => $value;
        }

        // Ahead of WooCommerce's own placeholders ({site_title}, {store_address}, …), which it fills in after.
        add_filter('woocommerce_email_footer_text', $setFooter, 5);

        foreach ($options as $hook => $callback) {
            add_filter($hook, $callback);
        }

        try {
            $html = $mailer->wrap_message(self::fill($design['title'], $person), $this->content($design, $link, $person));
            // The styles are read here (email-styles.php), so the options stay set until after.
            $html = (new \WC_Email())->style_inline($html);
        } finally {
            remove_filter('woocommerce_email_footer_text', $setFooter, 5);

            foreach ($options as $hook => $callback) {
                remove_filter($hook, $callback);
            }
        }

        return $html;
    }

    /**
     * Sends the email to each address and marks the offer sent.
     *
     * @param list<array{email: string, link: string, name?: string, first_name?: string}> $to
     * @return array{sent: int, failed: list<string>}
     */
    public function send(array $offer, array $design, array $to, bool $test = false): array {
        $design = self::sanitize($design);
        $sent = 0;
        $failed = [];

        foreach ($to as $person) {
            $html = $this->render($design, (string) $person['link'], $person);
            $ok = '' !== $html && WC()->mailer()->send((string) $person['email'], self::fill($design['subject'], $person), $html);

            if ($ok) {
                ++$sent;
            } else {
                $failed[] = (string) $person['email'];
            }
        }

        if (!$test && $sent > 0) {
            $this->recordSend((int) $offer['id'], $design, $sent);
        }

        return ['sent' => $sent, 'failed' => $failed];
    }

    /**
     * When the offer's email was last sent, and to how many, for the modal.
     *
     * @return array{at: string, count: int}|null
     */
    public static function lastSend(array $offer): ?array {
        $log = $offer['offer_data']['email_sent'] ?? null;

        return is_array($log) && [] !== $log ? end($log) : null;
    }


    private function recordSend(int $offerId, array $design, int $count): void {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return;
        }

        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $offerData['email'] = $design;
        $log = is_array($offerData['email_sent'] ?? null) ? $offerData['email_sent'] : [];
        $log[] = ['at' => current_time('mysql', true), 'count' => $count];
        $offerData['email_sent'] = array_slice($log, -20);

        $update = ['offer_data' => $offerData];

        if (OfferStatus::Ready->value === (string) $offer['status']) {
            $update['status'] = OfferStatus::Sent;
        }

        $this->offers->update($offerId, $update);
    }

    /** The body: the text in paragraphs, then the button to the page. */
    private function content(array $design, string $link, array $person): string {
        $paragraphs = '';

        foreach (preg_split('/\n\s*\n/', self::fill($design['body'], $person)) ?: [] as $paragraph) {
            if ('' !== trim($paragraph)) {
                $paragraphs .= '<p>' . nl2br(esc_html(trim($paragraph))) . "</p>\n";
            }
        }

        $base = $design['style']['base_color'];
        $text = function_exists('wc_light_or_dark') ? wc_light_or_dark($base, '#1e1e1e', '#ffffff') : '#ffffff';
        $label = '' !== $design['button_text'] ? $design['button_text'] : __('See your offer', 'personalized-offers-for-spacefast');
        $href = '' !== $link ? $link : home_url('/');

        $button = sprintf(
            '<p style="margin: 32px 0; text-align: center;"><a href="%1$s" style="display: inline-block; padding: 14px 28px; background-color: %2$s; color: %3$s; font-weight: bold; text-decoration: none; border-radius: 4px;" target="_blank">%4$s</a></p>',
            esc_url($href),
            esc_attr($base),
            esc_attr($text),
            esc_html(self::fill($label, $person)),
        );

        return $paragraphs . $button;
    }

    private static function fill(string $text, array $person): string {
        $name = (string) ($person['name'] ?? '');
        $first = (string) ($person['first_name'] ?? '') ?: $name;

        return strtr($text, [
            '{first_name}' => $first,
            '{customer_name}' => $name,
            '{site_title}' => wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES),
        ]);
    }

    private static function person(WP_User $user, string $link, string $status): array {
        return [
            'id' => $user->ID,
            'name' => $user->display_name,
            'first_name' => (string) $user->first_name,
            'email' => $user->user_email,
            'link' => $link,
            'status' => $status,
        ];
    }
}
