<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

final class Logger {
    public function log(string $message, string $level = 'info'): void {
        if ('error' !== $level && !Settings::get('debug_logging', false)) {
            return;
        }

        $line = sprintf('[%s] Personalized Offers for Spacefast: %s', current_time('Y-m-d H:i:s'), $message);

        // WooCommerce > Status > Logs. Nothing is logged while WooCommerce is inactive.
        if (function_exists('wc_get_logger')) {
            wc_get_logger()->log($level, $line, ['source' => 'personalized-offers-for-spacefast']);
        }
    }

    public function error(string $message): void {
        $this->log($message, 'error');
    }
}
