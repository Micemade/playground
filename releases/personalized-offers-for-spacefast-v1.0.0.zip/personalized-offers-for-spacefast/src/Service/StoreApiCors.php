<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use WP_REST_Request;
use WP_REST_Server;

/**
 * Lets published offer pages (on Spacefast) read current prices and stock
 * from the store's public Store API product routes (GET
 * /wc/store/v1/products), which the Store API otherwise answers only for
 * the store's own origins. Read-only catalogue data, without cookies; the
 * cart and checkout stay on the store.
 */
final class StoreApiCors {
    /** Hosts offer pages are published on; the pofsf_store_api_origins filter adds more. */
    private const HOST_SUFFIXES = ['.space.fast'];

    public static function register(): void {
        // After the Store API's own CORS headers (priority 10).
        add_filter('rest_pre_serve_request', [self::class, 'sendHeaders'], 11, 4);
    }

    public static function sendHeaders(mixed $served, mixed $result, WP_REST_Request $request, WP_REST_Server $server): mixed {
        $origin = get_http_origin();

        if ('GET' !== $request->get_method() || !str_starts_with($request->get_route(), '/wc/store/v1/products') || !self::allowed((string) $origin)) {
            return $served;
        }

        $server->send_header('Access-Control-Allow-Origin', (string) $origin);
        $server->send_header('Vary', 'Origin');

        return $served;
    }

    private static function allowed(string $origin): bool {
        $parts = wp_parse_url($origin);

        if (!is_array($parts) || 'https' !== ($parts['scheme'] ?? '') || empty($parts['host'])) {
            return false;
        }

        $host = strtolower((string) $parts['host']);

        foreach (self::HOST_SUFFIXES as $suffix) {
            if (str_ends_with($host, $suffix)) {
                return true;
            }
        }

        /**
         * Further origins (e.g. a custom domain of a Space) allowed to read the
         * Store API product routes, as scheme://host.
         *
         * @param list<string> $origins
         */
        return in_array(strtolower(untrailingslashit($origin)), array_map('strtolower', (array) apply_filters('pofsf_store_api_origins', [])), true);
    }
}
