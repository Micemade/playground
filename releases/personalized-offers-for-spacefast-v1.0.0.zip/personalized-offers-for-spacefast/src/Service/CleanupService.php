<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;

final class CleanupService {
    public const HOOK = 'pofsf_daily_cleanup';

    public function __construct(
        private readonly OfferRepository $offers,
        private readonly Logger $log,
    ) {}

    public function register(): void {
        add_action(self::HOOK, [$this, 'run']);
    }

    public function run(): void {
        // Offers' expires_at is UTC.
        $now = current_time('mysql', true);

        $expired = $this->offers->expireOverdue($now);
        $purged = $this->offers->deleteFailedOlderThan($now);

        // Closes the Spacefast Spaces of offers that expired or were revoked
        // (also those missed earlier), and reopens extended ones.
        $synced = 0;

        foreach ($this->offers->withSpace() as $offer) {
            if (OfferPublisher::needsSync($offer)) {
                do_action(JobScheduler::ACCESS_HOOK, (int) $offer['id']);
                ++$synced;
            }
        }

        $this->log->log(sprintf('Daily cleanup: expired %d offers, purged %d failed offers, synced Spacefast access of %d offers.', $expired, $purged, $synced));

        do_action('pofsf_after_daily_cleanup', $expired, $purged);
    }
}
