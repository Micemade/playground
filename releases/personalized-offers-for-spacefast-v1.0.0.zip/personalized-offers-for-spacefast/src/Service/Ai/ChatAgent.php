<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Ai;

use Micemade\PersonalizedOffers\Abilities\CustomerAbilities;
use Micemade\PersonalizedOffers\Abilities\OfferAbilities;
use Micemade\PersonalizedOffers\Abilities\OfferManagementAbilities;
use Micemade\PersonalizedOffers\Abilities\SegmentAbilities;
use Micemade\PersonalizedOffers\Abilities\SharedOfferAbilities;
use Micemade\PersonalizedOffers\Abilities\TemplateAbilities;
use Micemade\PersonalizedOffers\Abilities\SettingsAbilities;
use Micemade\PersonalizedOffers\Abilities\SpacefastAbilities;
use Micemade\PersonalizedOffers\Repository\ChatRepository;
use Micemade\PersonalizedOffers\Service\Logger;
use Throwable;
use WordPress\AiClient\AiClient;
use WordPress\AiClient\Messages\DTO\Message;
use WordPress\AiClient\Messages\DTO\MessagePart;
use WordPress\AiClient\Messages\DTO\UserMessage;
use WP_AI_Client_Ability_Function_Resolver;
use WP_Error;

/**
 * Admin chat assistant: runs the AI Client with the plugin's abilities as
 * tools, executing ability calls until the model answers in plain text.
 *
 * Conversations are stored server-side per user, so the browser only
 * ever sends the new message text and cannot forge tool results.
 */
final class ChatAgent {
    /** Upper bound on model round-trips per user message. */
    private const MAX_TOOL_ROUNDS = 10;

    /**
     * User meta: IDs of offers the assistant created for this manager that
     * the "offer ready" notice has not shown yet. Kept on the server, so
     * the notice still appears after a reload or a timed-out chat reply.
     */
    public const NEW_OFFERS_META = '_pofsf_assistant_new_offers';

    /** Stored messages kept per chat; older turns are dropped. */
    private const MAX_HISTORY = 40;

    /** Exchanges after which a title is derived (retried at the next, then a fallback is used). */
    private const TITLE_AFTER_EXCHANGES = 2;
    private const TITLE_FALLBACK_EXCHANGES = 3;

    /** Preference order: Anthropic first, per project decision. */
    private const PROVIDER_PREFERENCE = ['anthropic', 'openai', 'google'];

    public function __construct(
        private readonly Logger $log,
        private readonly ChatRepository $chats,
    ) {}

    public function isAvailable(): bool {
        return function_exists('wp_ai_client_prompt')
            && class_exists(WP_AI_Client_Ability_Function_Resolver::class)
            && (!function_exists('wp_supports_ai') || wp_supports_ai());
    }

    /**
     * Sends a user message and returns the assistant reply plus the
     * abilities that ran while producing it. An empty or unknown $chatId
     * starts a new chat.
     *
     * @return array{chat: array, reply: string, tools: list<array{ability: string, ok: bool}>}|WP_Error
     */
    public function send(int $userId, string $chatId, string $text): array|WP_Error {
        if (!$this->isAvailable()) {
            return new WP_Error('no_ai', __('AI Client not available. Requires WordPress 7.0+ with Connectors.', 'personalized-offers-for-spacefast'));
        }

        if (null === $this->chats->find($userId, $chatId)) {
            $chatId = ChatRepository::newId();
        }

        $history = $this->load($userId, $chatId);
        $history[] = new UserMessage([new MessagePart($text)]);

        $resolver = new WP_AI_Client_Ability_Function_Resolver(...self::abilityNames());
        $tools = [];

        for ($round = 0; $round < self::MAX_TOOL_ROUNDS; $round++) {
            $result = $this->prompt($history)->generate_text_result();

            if ($result instanceof WP_Error) {
                $this->log->error('Chat generation failed: ' . $result->get_error_message());

                return $result;
            }

            $message = $result->toMessage();
            $history[] = $message;

            if (!$resolver->has_ability_calls($message)) {
                $chat = $this->maybeTitle($userId, $this->save($userId, $chatId, $history), $history);

                return ['chat' => $chat, 'reply' => $this->textOf($message), 'tools' => $tools];
            }

            $responses = $resolver->execute_abilities($message);
            $history[] = $responses;

            foreach ($responses->getParts() as $part) {
                $response = $part->getFunctionResponse();

                if (null === $response) {
                    continue;
                }

                $payload = $response->getResponse();
                $tool = [
                    'ability' => WP_AI_Client_Ability_Function_Resolver::function_name_to_ability_name((string) $response->getName()),
                    'ok' => !(is_array($payload) && isset($payload['error'])),
                ];

                // Offers the assistant created, so the Offers tab can say when they are ready.
                if ($tool['ok'] && is_array($payload) && in_array($tool['ability'], [OfferAbilities::CREATE_OFFERS, SharedOfferAbilities::CREATE_SHARED_OFFER], true)) {
                    $tool['offer_ids'] = array_values(array_filter(array_map('intval', (array) ($payload['offer_ids'] ?? $payload['offer_id'] ?? []))));
                    self::rememberNewOffers($userId, $tool['offer_ids']);
                }

                $tools[] = $tool;
            }
        }

        // Unfinished turns are not saved, so the stored history stays well-formed.
        return new WP_Error('tool_loop', __('The assistant took too many steps without answering. Try a more specific request.', 'personalized-offers-for-spacefast'));
    }

    /**
     * Offers waiting for the "offer ready" notice.
     *
     * @return list<int>
     */
    public static function newOffers(int $userId): array {
        $ids = get_user_meta($userId, self::NEW_OFFERS_META, true);

        return is_array($ids) ? array_values(array_filter(array_map('intval', $ids))) : [];
    }

    /**
     * @param list<int> $offerIds
     */
    public static function rememberNewOffers(int $userId, array $offerIds): void {
        if ([] !== $offerIds) {
            // The 50 newest are enough for one notice.
            update_user_meta($userId, self::NEW_OFFERS_META, array_slice(array_values(array_unique([...self::newOffers($userId), ...$offerIds])), -50));
        }
    }

    /**
     * The notice has shown these offers.
     *
     * @param list<int> $offerIds
     */
    public static function forgetNewOffers(int $userId, array $offerIds): void {
        $left = array_values(array_diff(self::newOffers($userId), $offerIds));

        if ([] === $left) {
            delete_user_meta($userId, self::NEW_OFFERS_META);
        } else {
            update_user_meta($userId, self::NEW_OFFERS_META, $left);
        }
    }

    /**
     * Visible transcript for the UI: user and assistant text only.
     *
     * @return list<array{role: string, text: string}>
     */
    public function transcript(int $userId, string $chatId): array {
        $items = [];

        foreach ($this->load($userId, $chatId) as $message) {
            $text = $this->textOf($message);

            if ('' !== $text) {
                $items[] = ['role' => $message->getRole()->isUser() ? 'user' : 'assistant', 'text' => $text];
            }
        }

        return $items;
    }

    /**
     * @return list<string>
     */
    public static function abilityNames(): array {
        return [...OfferAbilities::names(), ...SharedOfferAbilities::names(), ...OfferManagementAbilities::names(), ...TemplateAbilities::names(), ...SpacefastAbilities::names(), ...SettingsAbilities::names(), ...CustomerAbilities::names(), ...SegmentAbilities::names()];
    }

    /**
     * @return list<array{id: string, title: string, created_at: string, updated_at: string}>
     */
    public function chats(int $userId): array {
        return $this->chats->all($userId);
    }

    public function createChat(int $userId): array {
        return $this->chats->create($userId);
    }

    public function deleteChat(int $userId, string $chatId): bool {
        return $this->chats->delete($userId, $chatId);
    }

    /**
     * @param list<Message> $history
     */
    private function prompt(array $history): \WP_AI_Client_Prompt_Builder {
        $builder = wp_ai_client_prompt($history)
            ->using_system_instruction($this->systemInstruction())
            ->using_abilities(...self::abilityNames())
            ->using_temperature(0.2)
            ->using_max_tokens(1500);

        $provider = $this->preferredProvider();

        return null !== $provider ? $builder->using_provider($provider) : $builder;
    }

    /**
     * Whether any AI provider has credentials, from Connectors settings,
     * a constant or an environment variable.
     */
    public function hasConfiguredProvider(): bool {
        return [] !== $this->configuredProviders();
    }

    private function preferredProvider(): ?string {
        $configured = $this->configuredProviders();

        foreach (self::PROVIDER_PREFERENCE as $id) {
            if (in_array($id, $configured, true)) {
                return $id;
            }
        }

        return $configured[0] ?? null;
    }

    /**
     * @return list<string>
     */
    private function configuredProviders(): array {
        if (!$this->isAvailable()) {
            return [];
        }

        try {
            $registry = AiClient::defaultRegistry();

            return array_values(array_filter(
                $registry->getRegisteredProviderIds(),
                static fn (string $id): bool => $registry->isProviderConfigured($id),
            ));
        } catch (Throwable) {
            return [];
        }
    }

    private function systemInstruction(): string {
        return sprintf(
            'You are the Personalized Offers assistant inside the WooCommerce admin of "%s". '
            . 'You help the store manager create personalized Spacefast offers for customers. '
            . 'Use find-customers to look up customers before creating offers; never guess user IDs. To target customers by what they bought, '
            . 'pass bought with product, category or product-type words (e.g. gym equipment: ["fitness", "gym", "dumbbell", "kettlebell"]). '
            . 'Before calling create-offers, list the exact customers (name and email) and get explicit confirmation, '
            . 'unless the manager has already named them unambiguously and asked you to proceed. '
            . 'There are three kinds of offer; managers rarely use these names, so decide from what they mean. '
            . '(1) One offer for several customers ("an offer for customers who bought X", "for my VIPs", "for these 20 people", a segment): '
            . 'ONE group offer (create-shared-offer, audience group): one page, each customer gets a personal link. This is the default for any '
            . 'request that says "an offer" (singular) for more than one customer. '
            . '(2) One link for anyone (newsletter, social media, website, "everyone", "all visitors"): create-shared-offer, audience public. '
            . '(3) Separate personalized offers, one per customer, with products picked from each customer\'s own order history: create-offers. '
            . 'Use it only when the manager asks for one offer each, personalized or individual offers, or names one customer and no products. '
            . 'When unsure between (1) and (3), ask one short question. '
            . 'For (1) and (2): find the products with find-products (up to 6; use the products the manager names, or choose fitting ones and list them), '
            . 'write a headline and short body that suit everyone (no customer names), confirm customers and products, then create it. '
            . 'Uploading, publishing, putting online or sharing an offer means publish-offer (Spacefast): ask before publishing unless asked to, '
            . 'and publish privately unless the manager asks for a public Space. '
            . 'Use list-offers to report on existing offers and get-offer to read one in full. '
            . 'To change or correct an existing offer (headline, texts, button, products, coupon code or discount, expiry, usage limit, template, '
            . 'a group\'s customers), call get-offer, then update-offer on THAT offer. Never create a new offer to change or correct one, '
            . 'unless the manager asks for a new or extra offer. If no tool can do what the manager asks, say so plainly and do nothing else; '
            . 'never do a different action instead. Every offer has its own WooCommerce coupon that its checkout link applies automatically; '
            . 'if the copy mentions a coupon code it must be the offer\'s coupon code (change one or the other with update-offer). '
            . 'After changing a published offer, offer to publish it again (publish-offer) so its page shows the changes. '
            . 'delete-offer deletes permanently: name the offer (ID and headline) and get explicit confirmation first. '
            . 'send-offer-email emails a published, up-to-date single or group offer; suggest a test send to the manager first, and before a '
            . 'real send state who will get it and get confirmation. Public offers are shared, not emailed: share-offer returns share links '
            . 'per social network that open a ready post; you cannot post yourself, so list the links for the manager to open. '
            . 'Offers from create-offers are built in the background from the customer\'s order history with '
            . 'standard wording (no AI writing), so tell the manager they will be ready shortly and can edit the copy in the Offers tab. '
            . 'You can design offers. A template is a block-editor page layout plus a design. Four read-only built-ins (Classic, Editorial, '
            . 'Personal letter, Spotlight) are starting points: to customise one, call save-template with its id as source_template_id and a '
            . 'changed design. The manager can also edit any custom template visually in the Templates tab. '
            . 'save-template stores a reusable design (base, colors, fonts, layout, copy tone, '
            . 'personal-note guidance, extra CSS; use_brand=false ignores the store brand settings). Pass its template_id to '
            . 'create-offers, together with an optional exact additional_text (e.g. a personal note), or use apply-template to restyle '
            . 'an existing offer. Check list-templates before creating a duplicate. When asked for a style inspired by a website, '
            . 'call inspect-website-style first and build an original palette and font pairing from it (Google Fonts only), '
            . 'without copying logos or trademarks. Make sure text colors contrast with their backgrounds. After saving a template, '
            . 'share its preview_url. If get-offer shows template_deleted, the offer keeps the deleted template\'s design: '
            . 'restore-template brings the template back (new ID, the offers that used it follow it again). '
            . 'delete-template deletes a custom template: call it with dry_run first, name the template and the offers using it '
            . '(they keep their copy), and get explicit confirmation. '
            . 'For Spacefast itself: spacefast-status tells whether it is connected and answering, the plan\'s limits and usage (live Spaces, '
            . 'storage, publishes today, custom domains) and whether live updates (a webhook) are on; when live Spaces are used up, a new '
            . 'offer can\'t be published: suggest deleting leftovers or unpublishing expired offers. The Spaces tab shows all this, links a '
            . 'leftover Space to an offer that has none, and sets an offer\'s own domain. list-spaces lists the team\'s Spaces with the offer '
            . 'each belongs to and marks leftovers; delete-space deletes an offer\'s Space while keeping the offer (offer_id), or a '
            . 'leftover Space (space_id). Deleting a Space breaks its links: name it and get explicit confirmation first. '
            . 'get-settings and update-settings read and change the defaults for new offers, notifications and logging; '
            . 'brand-status shows the locked store brand offer pages use, and lock-brand captures the current one as a new version. '
            . 'Customers have stored shopping profiles: list-customer-profiles lists them by segment (new, loyal, active, at risk, '
            . 'lapsed) or search, guests (no account) included; get-customer-profile shows one (favourite categories, sizes, colours, '
            . 'brands, price band, how recently and often they buy). update-customer-preferences corrects what new offers for a customer '
            . 'use (pin or exclude categories, set sizes or other attributes, a note); confirm the change with the manager first. '
            . 'create-offers takes guest_emails for guest customers. '
            . 'Segments group customers by rules (no AI): list-segments shows the built-in buying patterns and the store\'s own segments '
            . 'with member counts; create-segment saves one from favourite categories, sizes or colours, price band, orders or spending '
            . '(agree on the name and rules first). For an offer to a segment, call segment-customers, propose its suggested_products '
            . 'and copy that suits all of them, then create-shared-offer with audience "group" and the segment (its customers with an '
            . 'account get personal links; guests cannot). Or create-offers with its user_ids for one personalized offer each. '
            . 'Keep replies short and plain text, without Markdown tables. '
            . 'Never reveal offer tokens or customers\' personal links (they stay in the Offers tab); the offer\'s coupon code may be shown to the manager.',
            wp_strip_all_tags(get_bloginfo('name')),
        );
    }

    private function textOf(Message $message): string {
        $texts = [];

        foreach ($message->getParts() as $part) {
            $text = $part->getText();

            if (null !== $text && $part->getChannel()->isContent()) {
                $texts[] = $text;
            }
        }

        return trim(implode("\n\n", $texts));
    }

    /**
     * @return list<Message>
     */
    private function load(int $userId, string $chatId): array {
        $messages = [];

        try {
            foreach ($this->chats->messages($userId, $chatId) as $item) {
                $messages[] = Message::fromArray($item);
            }
        } catch (Throwable $e) {
            $this->log->error('Discarding unreadable chat history: ' . $e->getMessage());

            return [];
        }

        return $messages;
    }

    /**
     * Gives an untitled chat a short title once it has enough content:
     * AI-written after the 2nd exchange, retried after the 3rd, then
     * falling back to the first message.
     *
     * @param list<Message> $history
     */
    private function maybeTitle(int $userId, array $chat, array $history): array {
        if (!empty($chat['titled'])) {
            return $chat;
        }

        $turns = [];

        foreach ($history as $message) {
            $text = $this->textOf($message);

            if ('' !== $text) {
                $turns[] = ($message->getRole()->isUser() ? 'Manager: ' : 'Assistant: ') . mb_substr($text, 0, 500);
            }
        }

        $exchanges = count(array_filter($history, fn (Message $m): bool => $this->isUserText($m)));

        if ($exchanges < self::TITLE_AFTER_EXCHANGES) {
            return $chat;
        }

        $title = $this->generateTitle(implode("\n", array_slice($turns, 0, 8)));

        if ('' === $title && $exchanges >= self::TITLE_FALLBACK_EXCHANGES) {
            $title = (string) preg_replace('/^Manager: /', '', $turns[0] ?? '');
        }

        return '' !== $title ? ($this->chats->setTitle($userId, (string) $chat['id'], $title) ?? $chat) : $chat;
    }

    private function generateTitle(string $conversation): string {
        $builder = wp_ai_client_prompt($conversation)
            ->using_system_instruction(
                'Write a title of 3 to 6 words for this conversation between a store manager and an offers assistant. '
                . 'Name the concrete subject (customer, template, task). Reply with the title only: no quotes, no trailing period.'
            )
            ->using_temperature(0.2)
            ->using_max_tokens(30);

        $provider = $this->preferredProvider();
        $text = (null !== $provider ? $builder->using_provider($provider) : $builder)->generate_text();

        if ($text instanceof WP_Error) {
            $this->log->log('Chat title generation failed: ' . $text->get_error_message());

            return '';
        }

        return trim(strtok(trim((string) $text), "\n") ?: '');
    }

    /**
     * @param list<Message> $history
     */
    private function save(int $userId, string $chatId, array $history): array {
        $history = array_slice($history, -self::MAX_HISTORY);

        // A conversation must open with a plain user turn, not a dangling tool response.
        while ([] !== $history && !$this->isUserText($history[0])) {
            array_shift($history);
        }

        return $this->chats->save(
            $userId,
            $chatId,
            array_map(static fn (Message $m): array => $m->toArray(), $history),
        );
    }

    private function isUserText(Message $message): bool {
        if (!$message->getRole()->isUser()) {
            return false;
        }

        foreach ($message->getParts() as $part) {
            if (null !== $part->getText()) {
                return true;
            }
        }

        return false;
    }
}
