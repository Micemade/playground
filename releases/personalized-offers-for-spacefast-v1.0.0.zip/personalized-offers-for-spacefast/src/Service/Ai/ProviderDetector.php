<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Ai;

final class ProviderDetector {
    /** Preference order: Anthropic first, per project decision. */
    private const PREFERENCE = ['anthropic', 'openai', 'google'];

    public function status(): array {
        $supported = function_exists('wp_supports_ai')
            ? (bool) wp_supports_ai()
            : function_exists('wp_ai_client_prompt');

        if (!$supported) {
            return [
                'supported' => false,
                'providers' => [],
                'active' => null,
                'message' => __('AI Client not available. Requires WordPress 7.0+ with Connectors.', 'personalized-offers-for-spacefast'),
            ];
        }

        $candidates = [
            ['id' => 'anthropic', 'name' => 'Anthropic', 'models' => ['claude-3-5-sonnet-20241022', 'claude-3-5-haiku-20241022']],
            ['id' => 'openai', 'name' => 'OpenAI', 'models' => ['gpt-4o', 'gpt-4o-mini']],
            ['id' => 'google', 'name' => 'Google', 'models' => ['gemini-1.5-pro', 'gemini-1.5-flash']],
        ];

        $providers = array_map(
            fn (array $p): array => $p + ['connected' => $this->isConnected($p['id'])],
            $candidates,
        );

        $active = null;

        foreach (self::PREFERENCE as $preferred) {
            foreach ($providers as $provider) {
                if ($provider['id'] === $preferred && $provider['connected']) {
                    $active = $provider;
                    break 2;
                }
            }
        }

        return [
            'supported' => true,
            'providers' => $providers,
            'active' => $active,
            'message' => $active
                /* translators: %s: AI provider name. */
                ? sprintf(__('Connected: %s', 'personalized-offers-for-spacefast'), $active['name'])
                : __('No AI provider connected. Go to Settings → Connectors to add one.', 'personalized-offers-for-spacefast'),
        ];
    }

    public function preferredModel(): ?string {
        $active = $this->status()['active'];

        return is_array($active) ? ($active['models'][0] ?? null) : null;
    }

    /**
     * Whether the AI Client has this provider registered with credentials.
     */
    public function isProviderAvailable(string $providerId): bool {
        if (!class_exists(\WordPress\AiClient\AiClient::class)) {
            return false;
        }

        try {
            $registry = \WordPress\AiClient\AiClient::defaultRegistry();

            return $registry->hasProvider($providerId) && $registry->isProviderConfigured($providerId);
        } catch (\Throwable) {
            return false;
        }
    }

    private function isConnected(string $providerId): bool {
        $key = get_option("connectors_ai_{$providerId}_api_key");

        if (is_string($key) && '' !== $key) {
            return true;
        }

        $constant = strtoupper($providerId) . '_API_KEY';

        return defined($constant) && (bool) constant($constant);
    }
}
