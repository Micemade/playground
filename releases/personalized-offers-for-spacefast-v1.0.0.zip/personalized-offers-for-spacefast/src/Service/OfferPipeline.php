<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Enum\OfferType;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\RecipientRepository;
use Micemade\PersonalizedOffers\Repository\TemplateRepository;
use Micemade\PersonalizedOffers\Value\OfferCopy;
use Micemade\PersonalizedOffers\Value\OfferDesign;
use Throwable;
use WP_Error;

final class OfferPipeline {
    public function __construct(
        private readonly CustomerProfiles $profiles,
        private readonly ShortlistBuilder $shortlist,
        private readonly OfferComposer $composer,
        private readonly JobScheduler $scheduler,
        private readonly OfferRepository $offers,
        private readonly TemplateRepository $templates,
        private readonly TokenService $tokens,
        private readonly CouponFactory $coupons,
        private readonly Logger $log,
        private readonly RecipientRepository $recipients = new RecipientRepository(),
    ) {}

    /**
     * Records a pending offer per user and queues its background build, so
     * every request is visible in the offers list even if the build fails.
     *
     * @param list<int> $userIds
     * @param array{template_id?: int, additional_text?: string} $options
     *        template_id: design template (0 or missing = the default template, if set).
     *        additional_text: exact Additional text field for every offer in the batch.
     * @param list<string> $guestEmails Guest customers (no account), by the email they ordered with.
     * @return list<int>|WP_Error Offer IDs.
     */
    public function queue(array $userIds, int $initiatorId, array $options = [], array $guestEmails = []): array|WP_Error {
        $userIds = array_values(array_filter(array_map('intval', $userIds)));
        $guestEmails = array_values(array_filter(array_map(static fn ($e): string => strtolower(sanitize_email((string) $e)), $guestEmails)));

        if ([] === $userIds && [] === $guestEmails) {
            return new WP_Error('no_users', __('No users selected.', 'personalized-offers-for-spacefast'));
        }

        $design = $this->designData((int) ($options['template_id'] ?? 0));

        if ($design instanceof WP_Error) {
            return $design;
        }

        $offerData = array_filter([
            'initiator_id' => $initiatorId,
            'additional_text' => mb_substr(sanitize_textarea_field((string) ($options['additional_text'] ?? '')), 0, OfferCopy::LIMITS['additional']),
        ]) + $design;

        $settings = Settings::all();
        $expiryDays = max(1, (int) ($settings['offer_default_expiry'] ?? 30));
        $offerIds = [];

        $customers = [...array_map(static fn (int $id): array => [$id, null], $userIds), ...array_map(static fn (string $e): array => [0, $e], $guestEmails)];

        foreach ($customers as [$userId, $guestEmail]) {
            $token = $this->tokens->generate();

            $offerId = $this->offers->create([
                'token' => $token,
                'token_hash' => $this->tokens->hash($token),
                'user_id' => $userId,
                'guest_email' => $guestEmail,
                'offer_data' => $offerData,
                'status' => OfferStatus::Pending->value,
                'expires_at' => gmdate('Y-m-d H:i:s', strtotime('+' . $expiryDays . ' days')),
                'max_uses' => OfferLimits::defaultMax(),
            ]);

            if ($offerId instanceof WP_Error) {
                return $offerId;
            }

            if (false === $this->scheduler->scheduleOfferBuild($offerId)) {
                $this->fail($offerId, __('The background job could not be queued. Is Action Scheduler (WooCommerce) active?', 'personalized-offers-for-spacefast'));
            }

            $offerIds[] = $offerId;
        }

        return $offerIds;
    }

    /**
     * Action Scheduler callback for the `pofsf_build_offer` hook.
     */
    public function run(int $offerId): void {
        $offer = $this->offers->find($offerId);

        if (null === $offer || OfferStatus::Pending->value !== $offer['status']) {
            return;
        }

        $this->offers->update($offerId, ['status' => OfferStatus::Building]);

        try {
            $this->build($offer);
        } catch (Throwable $e) {
            $this->fail($offerId, $e->getMessage());
        }
    }

    /**
     * Handles jobs queued by earlier versions as `pofsf_build_profile` (user ID, initiator ID).
     */
    public function runLegacy(int $userId, int $initiatorId = 0): void {
        $queued = $this->queue([$userId], $initiatorId);

        if (is_array($queued) && isset($queued[0])) {
            $this->run($queued[0]);
        }
    }

    private function build(array $offer): void {
        $offerId = (int) $offer['id'];
        $userId = (int) $offer['user_id'];
        $offerData = is_array($offer['offer_data']) ? $offer['offer_data'] : [];

        $profile = $userId > 0 ? $this->profiles->forUser($userId) : $this->profiles->forGuest((string) ($offer['guest_email'] ?? ''));
        $items = $this->shortlist->build($profile);

        if ([] === $items) {
            $this->fail($offerId, __('No in-stock products matched this customer, so there was nothing to offer.', 'personalized-offers-for-spacefast'));

            return;
        }

        // No AI: standard copy and the best-matching products; the manager edits it in the Offers tab.
        // personal_note: queued before offers had text fields.
        $offerJson = $this->composer->compose($profile, $items, (string) ($offerData['additional_text'] ?? $offerData['personal_note'] ?? ''));

        if ([] === $offerJson['product_picks']) {
            $this->fail($offerId, __('All matching products have been bought by this customer already, so there was nothing new to offer.', 'personalized-offers-for-spacefast'));

            return;
        }

        $settings = Settings::all();
        $couponCode = $this->issueCoupon($userId, $profile, (string) $offer['expires_at'], max(0, (int) $offer['max_uses']), max(0, (int) $offer['max_uses']), array_filter([(string) ($offer['guest_email'] ?? '')]), null, self::productIds($offerJson));

        $this->offers->update($offerId, [
            'offer_data' => $offerData + ['profile' => $profile, 'shortlist' => $items, 'offer_json' => $offerJson],
            'coupon_code' => $couponCode,
            'consent_given' => !empty($profile['consent_given']) ? 1 : 0,
            'status' => OfferStatus::Ready,
        ]);

        $this->maybeNotify((int) ($offerData['initiator_id'] ?? 0), $userId, $offerId, $settings);
    }

    /**
     * The customer's profile and the in-stock products matched to them, as
     * the background build computes them.
     *
     * @return array{profile: array, items: list<array>}|WP_Error
     */
    public function shortlistFor(int $userId): array|WP_Error {
        if (!get_userdata($userId)) {
            return new WP_Error('pofsf_customer_missing', __('Customer not found.', 'personalized-offers-for-spacefast'));
        }

        $profile = $this->profiles->forUser($userId);

        // May be empty: the offer form can still pick from the whole catalog.
        return ['profile' => $profile, 'items' => $this->shortlist->build($profile)];
    }

    /**
     * shortlistFor() for a guest customer, by the email they ordered with.
     *
     * @return array{profile: array, items: list<array>}|WP_Error
     */
    public function shortlistForGuest(string $email): array|WP_Error {
        $email = sanitize_email($email);

        if ('' === $email || !is_email($email)) {
            return new WP_Error('pofsf_customer_missing', __('Enter a valid email address for the guest customer.', 'personalized-offers-for-spacefast'));
        }

        $profile = $this->profiles->forGuest($email);

        return ['profile' => $profile, 'items' => $this->shortlist->build($profile)];
    }

    /**
     * Creates a ready offer from copy and picks written by hand (Create new
     * offer), skipping the AI build. The caller validates the copy and picks.
     *
     * @param int $userId     The customer; 0 for a group or public offer.
     * @param int $templateId Template to use; 0 means the plain brand look.
     * @param int $maxUses    Usage limit (per recipient for a group offer); 0 means no limit.
     * @param list<string> $emails A group offer's recipients, whom its coupon is restricted to.
     * @param ?array $coupon Coupon settings (CouponFactory::sanitize()); null for the defaults.
     * @param string $guestEmail A single offer's guest customer (no account; $userId 0).
     */
    public function createManual(int $userId, int $initiatorId, int $templateId, array $profile, array $items, array $offerJson, string $expiresAt, int $maxUses, OfferType $type = OfferType::Single, array $emails = [], ?array $coupon = null, string $guestEmail = ''): int|WP_Error {
        $design = $this->designFor($templateId);

        if ($design instanceof WP_Error) {
            return $design;
        }

        $token = $this->tokens->generate();

        return $this->offers->create([
            'token' => $token,
            'token_hash' => $this->tokens->hash($token),
            'user_id' => $userId,
            'guest_email' => OfferType::Single === $type && $userId <= 0 && '' !== $guestEmail ? strtolower($guestEmail) : null,
            'offer_data' => [
                'initiator_id' => $initiatorId,
                'created_manually' => true,
                'profile' => $profile,
                'shortlist' => $items,
                'offer_json' => $offerJson,
            ] + $design,
            'coupon_code' => match ($type) {
                // The customer's own: as many orders as the offer allows.
                OfferType::Single => $this->issueCoupon($userId, $profile, $expiresAt, $maxUses, $maxUses, $userId > 0 ? [] : array_filter([$guestEmail]), $coupon, self::productIds($offerJson)),
                // Shared by the group: each recipient as often as the offer allows them.
                OfferType::Group => $this->issueCoupon(0, [], $expiresAt, 0, $maxUses, $emails, $coupon, self::productIds($offerJson)),
                // Shared by everyone: as many orders as the offer allows, once per customer.
                OfferType::Public => $this->issueCoupon(0, [], $expiresAt, $maxUses, 1, [], $coupon, self::productIds($offerJson)),
            },
            'consent_given' => !empty($profile['consent_given']) ? 1 : 0,
            'status' => OfferStatus::Ready->value,
            'expires_at' => $expiresAt,
            'max_uses' => $maxUses,
            'type' => $type,
        ]);
    }

    /**
     * The coupon for a new offer, with $settings (the offer form's) or the
     * defaults (CouponFactory::defaults()). Returns its code, or '' when it
     * could not be created; a failed coupon does not stop the offer.
     *
     * @param list<string> $emails Restricts the coupon to these customers when there is no $userId.
     * @param list<int> $productIds The offer's products (percentage and fixed product discounts).
     */
    private function issueCoupon(int $userId, array $profile, string $expiresAt, int $usageLimit = 1, int $perUserLimit = 1, array $emails = [], ?array $settings = null, array $productIds = []): string {
        $created = $this->coupons->create($settings ?? CouponFactory::defaults(), $userId > 0 ? $this->customerEmail($userId, $profile) : $emails, (int) strtotime($expiresAt . ' UTC'), $usageLimit, $perUserLimit, $productIds);

        if ($created instanceof WP_Error) {
            $this->log->error('Coupon creation failed: ' . $created->get_error_message());

            return '';
        }

        return $created;
    }

    /**
     * Gives an offer without a coupon (created while coupons were off, or
     * whose coupon was deleted) a new one with $settings, set up for the
     * offer's type. Returns its code.
     */
    public function addCoupon(array $offer, array $settings): string|WP_Error {
        $created = $this->coupons->create($settings, null, (int) strtotime((string) $offer['expires_at'] . ' UTC'), 0, 0, self::productIds((array) ($offer['offer_data']['offer_json'] ?? [])));

        if ($created instanceof WP_Error) {
            return $created;
        }

        $this->offers->update((int) $offer['id'], ['coupon_code' => $created]);
        // Who may use it and how often, as for the offer's type.
        $this->syncCoupon(['coupon_code' => $created] + $offer);

        return $created;
    }

    /**
     * The products of offer JSON's picks.
     *
     * @return list<int>
     */
    public static function productIds(array $offerJson): array {
        return array_values(array_filter(array_map(
            static fn ($pick): int => is_array($pick) ? (int) ($pick['product_id'] ?? 0) : 0,
            (array) ($offerJson['product_picks'] ?? []),
        )));
    }

    /**
     * Deletes an offer: cancels its background job if still queued, removes
     * its coupon and deletes the row. Its Spacefast Space, if
     * any, is handled separately by OfferPublisher::deleteSpace().
     */
    public function delete(int $offerId): true|WP_Error {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return new WP_Error('offer_not_found', __('Offer not found.', 'personalized-offers-for-spacefast'));
        }

        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions(JobScheduler::HOOK, [$offerId], JobScheduler::GROUP);
        }

        $this->deleteCoupon((string) ($offer['coupon_code'] ?? ''));
        $this->recipients->deleteForOffer($offerId);

        if (!$this->offers->delete($offerId)) {
            return new WP_Error('db_delete_error', __('The offer could not be deleted.', 'personalized-offers-for-spacefast'));
        }

        return true;
    }

    /**
     * Keeps a group offer's coupon to its current recipients (after the
     * group changes, or a recipient's data is erased) and to its per-recipient
     * limit.
     */
    public function syncGroupCoupon(array $offer): void {
        $code = (string) ($offer['coupon_code'] ?? '');
        $couponId = '' !== $code && function_exists('wc_get_coupon_id_by_code') ? (int) wc_get_coupon_id_by_code($code) : 0;

        if ($couponId <= 0) {
            return;
        }

        $emails = [];

        foreach ($this->recipients->forOffer((int) $offer['id']) as $recipient) {
            $user = RecipientRepository::REVOKED !== $recipient['status'] ? get_userdata($recipient['user_id']) : false;

            if ($user && '' !== $user->user_email) {
                $emails[] = $user->user_email;
            }
        }

        $coupon = new \WC_Coupon($couponId);
        // An empty list would let anyone use it.
        $coupon->set_email_restrictions([] !== $emails ? $emails : ['nobody@invalid']);
        // Each recipient as often as the offer allows them; no total.
        $coupon->set_usage_limit(0);
        $coupon->set_usage_limit_per_user(max(0, (int) $offer['max_uses']));
        $coupon->save();
    }

    /**
     * Sets an offer's coupon up for the offer's type, as createManual()
     * issues it: a single offer's coupon is for its customer, as many orders
     * as the offer allows; a public offer's is for anyone, as many orders as
     * the offer allows, once per customer; a group offer's follows its
     * recipients. Used when an offer changes type, customer or usage limit.
     */
    public function syncCoupon(array $offer): void {
        $type = OfferType::tryFrom((string) ($offer['type'] ?? '')) ?? OfferType::Single;

        if (OfferType::Group === $type) {
            $this->syncGroupCoupon($offer);

            return;
        }

        $code = (string) ($offer['coupon_code'] ?? '');
        $couponId = '' !== $code && function_exists('wc_get_coupon_id_by_code') ? (int) wc_get_coupon_id_by_code($code) : 0;

        if ($couponId <= 0) {
            return;
        }

        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $email = OfferType::Single === $type
            ? ((int) $offer['user_id'] > 0 ? $this->customerEmail((int) $offer['user_id'], (array) ($offerData['profile'] ?? [])) : (string) ($offer['guest_email'] ?? ''))
            : null;

        $coupon = new \WC_Coupon($couponId);
        $coupon->set_email_restrictions(null !== $email && '' !== $email ? [$email] : []);
        $coupon->set_usage_limit(max(0, (int) $offer['max_uses']));
        $coupon->set_usage_limit_per_user(OfferType::Public === $type ? 1 : max(0, (int) $offer['max_uses']));
        $coupon->save();
    }

    private function deleteCoupon(string $code): void {
        if ('' === $code || !function_exists('wc_get_coupon_id_by_code')) {
            return;
        }

        $couponId = (int) wc_get_coupon_id_by_code($code);

        if ($couponId > 0) {
            wp_delete_post($couponId, true);
        }
    }

    /**
     * Offers follow their template: when a template is saved (block editor,
     * assistant, built-in update), every offer using it takes the new
     * version, so offer previews and downloads show it, and published
     * Spaces are published again in the background (outdated until then).
     *
     * @return int Offers updated.
     */
    public function syncTemplate(int $templateId): int {
        $design = $templateId > 0 ? $this->designData($templateId) : [];

        if ($design instanceof WP_Error || [] === $design) {
            return 0;
        }

        $updated = 0;

        foreach ($this->offers->findByTemplate($templateId) as $offer) {
            // A build in progress writes its own copy of offer_data when it finishes.
            if (OfferStatus::Building->value === (string) $offer['status']) {
                continue;
            }

            $offerData = is_array($offer['offer_data']) ? $offer['offer_data'] : [];
            $changed = self::templateChanged($offerData, $design);

            if (!$changed && ($offerData['template_name'] ?? '') === $design['template_name']) {
                continue;
            }

            $offerData = self::withDesign($offerData, $design);

            // Only the page changes matter for a published Space, not a renamed template.
            $republish = $changed && !empty($offerData['spacefast']['space_id']);

            if ($republish) {
                $offerData['spacefast']['outdated'] = true;
            }

            if (true === $this->offers->update((int) $offer['id'], ['offer_data' => $offerData])) {
                ++$updated;

                // The published page follows too, in the background (a publish takes a while).
                if ($republish) {
                    $this->scheduler->scheduleRepublish((int) $offer['id']);
                }
            }
        }

        return $updated;
    }

    /**
     * Recreates a deleted template from the copy stored in an offer (name,
     * design, block layout) and points every offer that used the deleted
     * template to the new one, so they follow it again. The new template
     * gets a new ID.
     *
     * @return int|WP_Error The new template ID.
     */
    public function restoreTemplate(int $offerId): int|WP_Error {
        $offer = $this->offers->find($offerId);
        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $oldId = (int) ($offerData['template_id'] ?? 0);

        if (null === $offer || $oldId <= 0 || !is_array($offerData['design'] ?? null)) {
            return new WP_Error('pofsf_template_restore', __('This offer has no template to restore.', 'personalized-offers-for-spacefast'));
        }

        if (null !== $this->templates->find($oldId)) {
            return new WP_Error('pofsf_template_exists', __('The offer’s template still exists.', 'personalized-offers-for-spacefast'));
        }

        $name = trim((string) ($offerData['template_name'] ?? ''));
        $newId = $this->templates->save(
            '' !== $name ? $name : __('Restored template', 'personalized-offers-for-spacefast'),
            '',
            OfferDesign::fromArray($offerData['design']),
            0,
            (string) ($offerData['template_content'] ?? ''),
        );

        if ($newId instanceof WP_Error) {
            return $newId;
        }

        foreach ($this->offers->findByTemplate($oldId) as $linked) {
            $linkedData = is_array($linked['offer_data']) ? $linked['offer_data'] : [];
            $linkedData['template_id'] = $newId;
            $this->offers->update((int) $linked['id'], ['offer_data' => $linkedData]);
        }

        // Offers whose copy differs from this one (rare) take the restored version.
        $this->syncTemplate($newId);

        return $newId;
    }

    /**
     * Brings every offer up to date with its template; once, for offers
     * created before offers followed their templates.
     */
    public function syncAllTemplates(): void {
        foreach ($this->templates->all() as $template) {
            $this->syncTemplate((int) $template['id']);
        }
    }

    /**
     * wp_after_insert_post: runs after the block editor's REST save has
     * stored the post and its meta (the design).
     */
    public function onTemplateSaved(int $postId, \WP_Post $post): void {
        if (TemplateRepository::POST_TYPE === $post->post_type && 'publish' === $post->post_status) {
            $this->syncTemplate($postId);
        }
    }

    /**
     * Whether an offer's copy of its template differs from $design (from
     * designFor()) in what the page shows: the block layout or the design.
     */
    public static function templateChanged(array $offerData, array $design): bool {
        // Loose comparison: key order and JSON round-trips do not count as changes.
        return (string) ($design['template_content'] ?? '') !== (string) ($offerData['template_content'] ?? '')
            || (array) ($design['design'] ?? []) != (array) ($offerData['design'] ?? []);
    }

    /**
     * Gives an existing offer a different design (and optionally a new
     * Additional text) without regenerating its copy.
     *
     * @param int $templateId Template to apply; 0 restores the plain brand look.
     * @param ?string $additionalText Replaces the offer's Additional text fields; null keeps them.
     */
    public function restyle(int $offerId, int $templateId, ?string $additionalText = null): true|WP_Error {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return new WP_Error('offer_not_found', __('Offer not found.', 'personalized-offers-for-spacefast'));
        }

        $design = $this->designFor($templateId);

        if ($design instanceof WP_Error) {
            return $design;
        }

        $offerData = self::withDesign(is_array($offer['offer_data']) ? $offer['offer_data'] : [], $design);

        if (null !== $additionalText && is_array($offerData['offer_json'] ?? null)) {
            $json = OfferCopy::normalize($offerData['offer_json']);
            $json['fields'] = OfferCopy::sanitizeFields([
                ...array_filter($json['fields'], static fn (array $field): bool => 'additional' !== $field['type']),
                ['type' => 'additional', 'text' => $additionalText],
            ], true);
            $offerData['offer_json'] = $json;
        }

        // The published page no longer matches; the Offers tab prompts to update the Space.
        if (!empty($offerData['spacefast']['space_id'])) {
            $offerData['spacefast']['outdated'] = true;
        }

        $updated = $this->offers->update($offerId, ['offer_data' => $offerData]);

        return $updated instanceof WP_Error ? $updated : true;
    }

    /**
     * The design keys of offer data for a template chosen in the admin,
     * where 0 means the plain brand look (not the default template).
     *
     * @return array{template_id?: int, template_name?: string, design?: array, template_content?: string}|WP_Error
     */
    public function designFor(int $templateId): array|WP_Error {
        return $templateId > 0 ? $this->designData($templateId) : [];
    }

    /**
     * Offer data with its design keys replaced by $design (from designFor()).
     */
    public static function withDesign(array $offerData, array $design): array {
        unset($offerData['design'], $offerData['template_id'], $offerData['template_name'], $offerData['template_content']);

        return $offerData + $design;
    }

    /**
     * A template's design and block layout for an offer row. The offer
     * stores a copy, kept up to date by syncTemplate() whenever the template
     * is saved, and kept as it was if the template is deleted.
     *
     * @return array{template_id?: int, template_name?: string, design?: array, template_content?: string}|WP_Error
     */
    private function designData(int $templateId): array|WP_Error {
        $templateId = $templateId > 0 ? $templateId : $this->templates->defaultId();

        if (0 === $templateId) {
            return [];
        }

        $template = $this->templates->find($templateId);

        if (null === $template) {
            return new WP_Error('pofsf_template_missing', sprintf(
                /* translators: %d: template ID. */
                __('Template %d not found.', 'personalized-offers-for-spacefast'),
                $templateId,
            ));
        }

        return [
            'template_id' => $template['id'],
            'template_name' => $template['name'],
            'design' => $template['design']->toArray(),
            'template_content' => $template['content'],
        ];
    }

    private function fail(int $offerId, string $reason): void {
        $this->log->error('Offer ' . $offerId . ' failed: ' . $reason);

        $offer = $this->offers->find($offerId);
        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $offerData['error'] = $reason;
        $offerData['failed_at'] = current_time('mysql', true);

        $this->offers->update($offerId, ['status' => OfferStatus::Failed, 'offer_data' => $offerData]);
    }

    private function customerEmail(int $userId, array $profile): ?string {
        $email = $profile['user_email'] ?? '';

        if (is_string($email) && '' !== $email) {
            return $email;
        }

        $user = get_userdata($userId);

        return $user ? (string) $user->user_email : null;
    }

    private function maybeNotify(int $initiatorId, int $userId, int $offerId, array $settings): void {
        if (empty($settings['email_notifications']) || $initiatorId <= 0) {
            return;
        }

        $admin = get_userdata($initiatorId);
        $target = get_userdata($userId);

        if (!$admin || empty($admin->user_email)) {
            return;
        }

        /* translators: %d: offer ID. */
        $subject = sprintf(__('Your Spacefast offer #%d is ready', 'personalized-offers-for-spacefast'), $offerId);

        $body = sprintf(
            /* translators: 1: customer name, 2: offer ID, 3: offers admin URL. */
            __("The personalized offer for %1\$s (offer #%2\$d) finished generating.\n\nPreview it, download the ZIP or publish it to Spacefast from the offers screen:\n%3\$s", 'personalized-offers-for-spacefast'),
            $target ? $target->display_name : '#' . $userId,
            $offerId,
            admin_url('admin.php?page=personalized-offers-for-spacefast'),
        );

        wp_mail((string) $admin->user_email, $subject, $body);
    }
}
