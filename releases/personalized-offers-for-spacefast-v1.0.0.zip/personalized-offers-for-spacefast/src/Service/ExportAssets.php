<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

/**
 * Copies the store's images an exported offer page uses into the export
 * (assets/media/), so the published page does not load anything from the
 * store, which may be local, private or slow. Images under the uploads
 * folder are read from disk; other images on the store's own domain are
 * downloaded. Anything that cannot be copied keeps its URL.
 */
final class ExportAssets {
    public const DIR = 'assets/media/';

    private const EXTENSIONS = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'ico'];

    /** Largest image copied; bigger ones keep their URL. */
    private const MAX_FILE = 8 * MB_IN_BYTES;

    /** All copied images together; once reached, further images keep their URL. */
    private const MAX_TOTAL = 60 * MB_IN_BYTES;

    /** @var array<string, string> URL => path in the export. */
    private array $paths = [];

    /** @var array<string, array{path?: string, bytes?: string}> Path in the export => source. */
    private array $files = [];

    private int $total = 0;

    /**
     * The path in the export for an image URL of the store, or the URL
     * when it is not the store's or cannot be copied.
     */
    public function add(string $url): string {
        $url = html_entity_decode(trim($url), ENT_QUOTES);

        if ('' === $url || isset($this->paths[$url])) {
            return $this->paths[$url] ?? $url;
        }

        $clean = strtok($url, '?#') ?: $url;
        $ext = strtolower(pathinfo((string) wp_parse_url($clean, PHP_URL_PATH), PATHINFO_EXTENSION));

        if (!in_array($ext, self::EXTENSIONS, true) || !$this->isStoreUrl($clean)) {
            return $url;
        }

        $source = $this->source($clean);

        if (null === $source) {
            return $url;
        }

        $size = isset($source['bytes']) ? strlen($source['bytes']) : (int) filesize((string) $source['path']);

        if ($size <= 0 || $size > self::MAX_FILE || $this->total + $size > self::MAX_TOTAL) {
            return $url;
        }

        $name = sanitize_file_name(pathinfo($clean, PATHINFO_FILENAME)) ?: 'image';
        $path = self::DIR . substr(md5($clean), 0, 8) . '-' . substr($name, 0, 60) . '.' . $ext;

        $this->total += $size;
        $this->files[$path] = $source;
        $this->paths[$url] = $path;

        return $path;
    }

    /**
     * The page with its store images copied: img src (srcset and sizes are
     * dropped, the copied src is used at every width), video posters,
     * icons and url() in style attributes and style elements.
     */
    public function rewriteHtml(string $html): string {
        $tags = new \WP_HTML_Tag_Processor($html);
        // set_attribute() escapes URLs and would make a relative path absolute
        // (esc_url adds http://): set placeholders, then put the paths in.
        $placeholders = [];
        $url = function (string $value) use (&$placeholders): string {
            $copied = $this->add($value);

            if ($copied === html_entity_decode(trim($value), ENT_QUOTES) || preg_match('#^[a-z][a-z0-9+.-]*:#i', $copied)) {
                return $value;
            }

            $placeholder = '/__pofsf_asset_' . count($placeholders) . '__';
            $placeholders[$placeholder] = $copied;

            return $placeholder;
        };

        while ($tags->next_tag()) {
            $tag = $tags->get_tag();

            if ('IMG' === $tag || 'SOURCE' === $tag) {
                $src = $tags->get_attribute('src');

                if (is_string($src) && $src !== ($copied = $url($src))) {
                    $tags->set_attribute('src', $copied);
                    $tags->remove_attribute('srcset');
                    $tags->remove_attribute('sizes');
                }
            }

            if ('VIDEO' === $tag && is_string($poster = $tags->get_attribute('poster')) && $poster !== ($copied = $url($poster))) {
                $tags->set_attribute('poster', $copied);
            }

            if ('LINK' === $tag && is_string($rel = $tags->get_attribute('rel')) && str_contains($rel, 'icon') && is_string($href = $tags->get_attribute('href')) && $href !== ($copied = $url($href))) {
                $tags->set_attribute('href', $copied);
            }

            $style = $tags->get_attribute('style');

            if (is_string($style) && str_contains($style, 'url(') && $style !== ($rewritten = $this->rewriteCss($style, ''))) {
                $tags->set_attribute('style', $rewritten);
            }
        }

        $html = strtr($tags->get_updated_html(), $placeholders);

        // <style> elements (e.g. block supports with background images).
        return (string) preg_replace_callback(
            '#(<style\b[^>]*>)(.*?)(</style>)#is',
            fn (array $m): string => $m[1] . $this->rewriteCss($m[2], '') . $m[3],
            $html,
        );
    }

    /**
     * CSS with its store url()s copied. $prefix leads from the stylesheet
     * back to the export root (e.g. "../../" for assets/offer/offer.css).
     */
    public function rewriteCss(string $css, string $prefix): string {
        return (string) preg_replace_callback(
            '#url\(\s*([\'"]?)([^\'")]+)\1\s*\)#i',
            function (array $m) use ($prefix): string {
                $copied = $this->add($m[2]);

                return $copied === html_entity_decode(trim($m[2]), ENT_QUOTES) ? $m[0] : 'url("' . $prefix . $copied . '")';
            },
            $css,
        );
    }

    /**
     * @return array<string, array{path?: string, bytes?: string}> Path in the export => source.
     */
    public function files(): array {
        return $this->files;
    }

    private function isStoreUrl(string $url): bool {
        if (str_starts_with($url, '//')) {
            $url = set_url_scheme($url);
        }

        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));

        return '' !== $host && in_array($host, array_map('strtolower', array_filter([
            (string) wp_parse_url(home_url(), PHP_URL_HOST),
            (string) wp_parse_url(site_url(), PHP_URL_HOST),
            (string) wp_parse_url(content_url(), PHP_URL_HOST),
        ])), true);
    }

    /**
     * The file behind a store URL: from disk when it is under the uploads,
     * content or plugin folders, otherwise downloaded.
     *
     * @return array{path?: string, bytes?: string}|null
     */
    private function source(string $url): ?array {
        $path = (string) wp_parse_url($url, PHP_URL_PATH);
        $uploads = wp_get_upload_dir();
        $roots = [
            (string) wp_parse_url((string) $uploads['baseurl'], PHP_URL_PATH) => (string) $uploads['basedir'],
            (string) wp_parse_url(content_url(), PHP_URL_PATH) => WP_CONTENT_DIR,
            (string) wp_parse_url(includes_url(), PHP_URL_PATH) => ABSPATH . WPINC,
        ];

        foreach ($roots as $urlPath => $dir) {
            $urlPath = untrailingslashit($urlPath);

            if ('' === $urlPath || !str_starts_with($path, $urlPath . '/')) {
                continue;
            }

            $file = realpath(untrailingslashit($dir) . rawurldecode(substr($path, strlen($urlPath))));
            $base = realpath($dir);

            if (false !== $file && false !== $base && str_starts_with($file, $base . DIRECTORY_SEPARATOR) && is_file($file) && is_readable($file)) {
                return ['path' => $file];
            }
        }

        // Offloaded or generated images: download them (the store's own host only).
        $response = wp_safe_remote_get($url, ['timeout' => 10, 'limit_response_size' => self::MAX_FILE + 1]);

        if (is_wp_error($response) || 200 !== (int) wp_remote_retrieve_response_code($response)) {
            return null;
        }

        $type = strtolower((string) wp_remote_retrieve_header($response, 'content-type'));
        $bytes = (string) wp_remote_retrieve_body($response);

        return str_starts_with($type, 'image/') && '' !== $bytes ? ['bytes' => $bytes] : null;
    }
}
