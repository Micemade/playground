<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use WC_Coupon;
use WP_Error;

/**
 * The offer's WooCommerce coupon. The coupon itself holds the offer's
 * coupon settings (code, discount type, amount, free shipping); who may use
 * it and how often follow the offer's type (OfferPipeline::syncCoupon()).
 *
 * Coupon settings: {code: string, discount_type: percent|fixed_cart|fixed_product,
 * amount: string, free_shipping: bool}. Percentage and fixed product
 * discounts apply to the offer's products only; a fixed cart discount to
 * the whole cart.
 */
final class CouponFactory {
    public const TYPES = ['percent', 'fixed_cart', 'fixed_product'];

    /** Longest code (the offers table's coupon_code column). */
    public const MAX_CODE = 50;

    /** A new, unused coupon code. */
    public static function generateCode(): string {
        do {
            $code = 'pofsf_offer_' . strtolower(wp_generate_password(8, false));
        } while (function_exists('wc_get_coupon_id_by_code') && wc_get_coupon_id_by_code($code) > 0);

        return $code;
    }

    /**
     * Settings for a new offer's coupon: a generated code, no discount yet,
     * and free shipping as the plugin settings choose.
     */
    public static function defaults(): array {
        return [
            'code' => self::generateCode(),
            'discount_type' => 'percent',
            'amount' => '0',
            'free_shipping' => !empty(Settings::get('free_shipping_coupon')),
        ];
    }

    /**
     * Coupon settings as posted (offer form), checked: a code no other
     * coupon has, a known discount type and an amount in range.
     *
     * @param string $ownCode The offer's current code, which it may keep.
     */
    public static function sanitize(mixed $input, string $ownCode = ''): array|WP_Error {
        $input = is_array($input) ? $input : [];
        $code = function_exists('wc_format_coupon_code') ? wc_format_coupon_code(sanitize_text_field((string) ($input['code'] ?? ''))) : sanitize_text_field((string) ($input['code'] ?? ''));
        $code = trim((string) $code);

        if ('' === $code) {
            return new WP_Error('coupon_code_empty', __('Enter a coupon code.', 'personalized-offers-for-spacefast'));
        }

        if (mb_strlen($code) > self::MAX_CODE) {
            return new WP_Error('coupon_code_long', sprintf(
                /* translators: %d: most characters in a coupon code. */
                __('The coupon code can have at most %d characters.', 'personalized-offers-for-spacefast'),
                self::MAX_CODE,
            ));
        }

        if (0 !== strcasecmp($code, $ownCode) && function_exists('wc_get_coupon_id_by_code') && wc_get_coupon_id_by_code($code) > 0) {
            return new WP_Error('coupon_code_taken', sprintf(
                /* translators: %s: coupon code. */
                __('The coupon code "%s" is already used by another coupon.', 'personalized-offers-for-spacefast'),
                $code,
            ));
        }

        $type = (string) ($input['discount_type'] ?? 'percent');

        if (!in_array($type, self::TYPES, true)) {
            return new WP_Error('coupon_type_invalid', __('Choose a discount type.', 'personalized-offers-for-spacefast'));
        }

        $amount = str_replace(',', '.', trim((string) ($input['amount'] ?? '0')));
        $amount = '' === $amount ? '0' : $amount;

        if (!is_numeric($amount) || (float) $amount < 0 || ('percent' === $type && (float) $amount > 100)) {
            return new WP_Error('coupon_amount_invalid', 'percent' === $type
                ? __('The percentage discount must be between 0 and 100.', 'personalized-offers-for-spacefast')
                : __('The discount amount must be 0 or more.', 'personalized-offers-for-spacefast'));
        }

        return [
            'code' => $code,
            'discount_type' => $type,
            'amount' => function_exists('wc_format_decimal') ? (string) wc_format_decimal($amount) : $amount,
            'free_shipping' => !empty($input['free_shipping']),
        ];
    }

    /**
     * Creates the coupon.
     *
     * @param array $settings Coupon settings (sanitize()).
     * @param string|list<string>|null $email Customer email(s) the coupon is restricted to; none = anyone.
     * @param int $usageLimit   Orders the coupon may be used on in total; 0 for no limit.
     * @param int $perUserLimit Orders per customer; 0 for no limit.
     * @param list<int> $productIds The offer's products.
     */
    public function create(array $settings, string|array|null $email, int $expiresAt, int $usageLimit = 1, int $perUserLimit = 1, array $productIds = []): string|WP_Error {
        if (!class_exists('WC_Coupon')) {
            return new WP_Error('no_wc', __('WooCommerce coupon API not available.', 'personalized-offers-for-spacefast'));
        }

        try {
            $coupon = new WC_Coupon();
            $coupon->set_code((string) $settings['code']);
            $coupon->set_description(__('Created by Personalized Offers for Spacefast for an offer.', 'personalized-offers-for-spacefast'));
            self::configure($coupon, $settings, $productIds);
            $coupon->set_usage_limit(max(0, $usageLimit));
            $coupon->set_usage_limit_per_user(max(0, $perUserLimit));
            $coupon->set_date_expires($expiresAt);

            $emails = array_values(array_filter((array) $email));

            if ([] !== $emails) {
                $coupon->set_email_restrictions($emails);
            }

            $coupon->save();

            return (string) $settings['code'];
        } catch (\Exception $e) {
            return new WP_Error('coupon_error', $e->getMessage());
        }
    }

    /**
     * The coupon's settings, or null when there is no coupon with this code.
     */
    public function settings(string $code): ?array {
        $coupon = $this->find($code);

        if (null === $coupon) {
            return null;
        }

        $type = $coupon->get_discount_type();

        return [
            'code' => $coupon->get_code(),
            'discount_type' => in_array($type, self::TYPES, true) ? $type : 'fixed_cart',
            'amount' => (string) wc_format_decimal($coupon->get_amount()),
            'free_shipping' => $coupon->get_free_shipping(),
        ];
    }

    /**
     * Applies new settings to the coupon with $code, renaming it when the
     * code changed. Returns the coupon's code.
     *
     * @param list<int> $productIds The offer's products.
     */
    public function update(string $code, array $settings, array $productIds): string|WP_Error {
        $coupon = $this->find($code);

        if (null === $coupon) {
            return new WP_Error('coupon_not_found', __('The offer’s coupon no longer exists.', 'personalized-offers-for-spacefast'));
        }

        $oldCode = $coupon->get_code('edit');

        try {
            $coupon->set_code((string) $settings['code']);
            self::configure($coupon, $settings, $productIds);
            $coupon->save();

            if (0 !== strcasecmp($oldCode, $coupon->get_code('edit'))) {
                self::forgetCode($oldCode);
            }

            return $coupon->get_code();
        } catch (\Exception $e) {
            return new WP_Error('coupon_error', $e->getMessage());
        }
    }

    /**
     * Keeps a percentage or fixed product discount to the offer's products
     * (after its picks change).
     *
     * @param list<int> $productIds
     */
    public function restrictTo(string $code, array $productIds): void {
        $coupon = $this->find($code);

        if (null === $coupon) {
            return;
        }

        $coupon->set_product_ids(self::needsProducts($coupon->get_discount_type()) ? self::ids($productIds) : []);
        $coupon->save();
    }

    public function find(string $code): ?WC_Coupon {
        if ('' === $code || !class_exists('WC_Coupon') || !function_exists('wc_get_coupon_id_by_code')) {
            return null;
        }

        $couponId = (int) wc_get_coupon_id_by_code($code);

        return $couponId > 0 ? new WC_Coupon($couponId) : null;
    }

    /** Discount type, amount, free shipping and product restriction. */
    private static function configure(WC_Coupon $coupon, array $settings, array $productIds): void {
        $type = in_array($settings['discount_type'] ?? '', self::TYPES, true) ? (string) $settings['discount_type'] : 'fixed_cart';

        $coupon->set_discount_type($type);
        $coupon->set_amount((string) ($settings['amount'] ?? '0'));
        $coupon->set_free_shipping(!empty($settings['free_shipping']));
        // Without products a fixed product discount would apply to every product in the cart.
        $coupon->set_product_ids(self::needsProducts($type) ? self::ids($productIds) : []);
    }

    /**
     * WooCommerce caches which coupon a code belongs to and clears it only
     * for the new code on save: drop the old code's entry after a rename,
     * so it stops finding (and applying) the renamed coupon.
     */
    private static function forgetCode(string $code): void {
        $invalidator = 'Automattic\WooCommerce\Internal\Caches\CouponCodeLookupInvalidator';

        try {
            if (class_exists($invalidator) && function_exists('wc_get_container')) {
                wc_get_container()->get($invalidator)->invalidate($code);

                return;
            }
        } catch (\Throwable $e) {
            unset($e);
        }

        // Older WooCommerce.
        if (class_exists('WC_Cache_Helper')) {
            wp_cache_delete(\WC_Cache_Helper::get_cache_prefix('coupons') . 'coupon_id_from_code_' . $code, 'coupons');
        }
    }

    private static function needsProducts(string $type): bool {
        return in_array($type, ['percent', 'fixed_product'], true);
    }

    /** @return list<int> */
    private static function ids(array $productIds): array {
        return array_values(array_unique(array_filter(array_map('intval', $productIds))));
    }
}
