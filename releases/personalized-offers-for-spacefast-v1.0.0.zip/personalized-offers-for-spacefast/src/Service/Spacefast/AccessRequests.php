<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Spacefast;

use Micemade\PersonalizedOffers\Enum\OfferType;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\RecipientRepository;
use Micemade\PersonalizedOffers\Service\Logger;
use Micemade\PersonalizedOffers\Service\OfferEditor;
use WP_Error;
use WP_User;

/**
 * Requests to open a private offer, made on its Space's private page by
 * someone without a working link (an expired session, a forwarded
 * offer), decided here instead of in Spacefast's dashboard. Each request
 * says whether its email is the offer's customer, one of a group offer's
 * customers, or someone else. Approving lets the person in as a viewer
 * of the live page (OfferPublisher::syncAccess() removes them again when
 * the offer closes); Spacefast emails them either way.
 *
 * Spacefast's team-wide list needs more rights than an API key has, so
 * each open private offer's Space is asked; the answers are cached
 * briefly, and forgotten when a webhook reports a new request.
 */
final class AccessRequests {
    private const CACHE = 'pofsf_spacefast_access_requests';
    private const TTL = 2 * MINUTE_IN_SECONDS;
    private const NOTIFIED = 'pofsf_access_request_mail_';
    private const NOTIFY_GAP = 10 * MINUTE_IN_SECONDS;

    /** Fired by Webhooks for `space.access_request_created` on an offer's Space. */
    public const REQUESTED_HOOK = 'pofsf_spacefast_access_requested';

    public const CUSTOMER = 'customer';
    public const RECIPIENT = 'recipient';
    public const REMOVED = 'removed';
    public const OTHER = 'other';

    public function __construct(
        private readonly SpacefastClient $client,
        private readonly OfferRepository $offers,
        private readonly RecipientRepository $recipients,
        private readonly Logger $log,
    ) {}

    public function register(): void {
        add_action(self::REQUESTED_HOOK, [$this, 'notify']);
        add_action('pofsf_spacefast_spaces_changed', [$this, 'forget']);
        add_action('pofsf_spacefast_disconnecting', [$this, 'forget']);
    }

    /**
     * Requests waiting for a decision, newest first, from people who
     * confirmed their email. `error` is the first failure, if any Space
     * could not be asked.
     *
     * @return array{requests: list<array{id: string, offer_id: int, email: string, name: string, message: string, created_at: string, match: string, account: string}>, error: string}
     */
    public function pending(bool $fresh = false): array {
        $cached = $fresh ? false : get_transient(self::CACHE);

        if (is_array($cached) && isset($cached['requests'], $cached['error'])) {
            return $cached;
        }

        $requests = [];
        $error = '';

        foreach ($this->offers->withSpace() as $offer) {
            if (!self::open($offer)) {
                continue;
            }

            $found = $this->client->accessRequests(OfferPublisher::record($offer)['space_id']);

            if ($found instanceof WP_Error) {
                $error = '' !== $error ? $error : $found->get_error_message();
                continue;
            }

            foreach ($found as $request) {
                if ('pending' === $request['status'] && $request['verified']) {
                    $requests[] = $this->present($offer, $request);
                }
            }
        }

        usort($requests, static fn (array $a, array $b): int => strcmp($b['created_at'], $a['created_at']));
        $result = ['requests' => $requests, 'error' => $error];
        set_transient(self::CACHE, $result, self::TTL);

        return $result;
    }

    /**
     * How many requests wait, from the cache only (null when not known),
     * so a page load never waits on Spacefast.
     */
    public function cachedCount(): ?int {
        $cached = get_transient(self::CACHE);

        return is_array($cached) && isset($cached['requests']) ? count($cached['requests']) : null;
    }

    public function forget(): void {
        delete_transient(self::CACHE);
    }

    /**
     * Lets the person in. Not for a closed offer (it opens for nobody), a
     * public one (anyone can open it) or a group offer's removed customer
     * (add them back instead).
     *
     * @return array{email: string}|WP_Error
     */
    public function approve(int $offerId, string $requestId): array|WP_Error {
        $found = $this->request($offerId, $requestId);

        if ($found instanceof WP_Error) {
            return $found;
        }

        [$offer, $request] = $found;

        if (OfferPublisher::closes($offer)) {
            return new WP_Error('pofsf_offer_closed', __('This offer has expired or was revoked, so its page opens for nobody. Decline the request, or reopen the offer first.', 'personalized-offers-for-spacefast'));
        }

        if ('public' === OfferPublisher::record($offer)['access']) {
            return new WP_Error('pofsf_offer_public', __('This offer is public now: anyone with its address can open it, so there is nothing to approve. Decline the request, or send them the address.', 'personalized-offers-for-spacefast'));
        }

        if ('pending' !== $request['status'] || !$request['verified']) {
            return new WP_Error('pofsf_request_unverified', __('This person has not confirmed their email address yet.', 'personalized-offers-for-spacefast'));
        }

        if (self::REMOVED === $this->match($offer, $request['email'])['match']) {
            return new WP_Error('pofsf_request_removed', __('This customer was removed from the offer. Add them back to the offer instead.', 'personalized-offers-for-spacefast'));
        }

        $spaceId = OfferPublisher::record($offer)['space_id'];
        $approved = $this->client->approveAccessRequest($spaceId, $requestId);

        if ($approved instanceof WP_Error) {
            return $approved;
        }

        // Re-read: the offer may have changed while Spacefast answered.
        $offer = $this->offers->find($offerId) ?? $offer;
        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $record = OfferPublisher::record($offer);
        $record['people'][$request['email']] = ['request_id' => $requestId, 'approved_at' => gmdate('c')];
        $offerData['spacefast'] = $record;
        $this->offers->update($offerId, ['offer_data' => $offerData]);
        $this->forget();
        $this->log->log('Offer ' . $offerId . ': access request approved for ' . $request['email'] . '.');

        return ['email' => $request['email']];
    }

    /**
     * @return array{email: string}|WP_Error
     */
    public function deny(int $offerId, string $requestId): array|WP_Error {
        $found = $this->request($offerId, $requestId);

        if ($found instanceof WP_Error) {
            return $found;
        }

        [$offer, $request] = $found;
        $denied = $this->client->denyAccessRequest(OfferPublisher::record($offer)['space_id'], $requestId);

        if ($denied instanceof WP_Error) {
            return $denied;
        }

        $this->forget();
        $this->log->log('Offer ' . $offerId . ': access request declined for ' . $request['email'] . '.');

        return ['email' => $request['email']];
    }

    /**
     * After a webhook reports a request: the cache is forgotten, and the
     * store's admin email told, at most once per offer every 10 minutes
     * (filter `pofsf_access_request_notify` to stop it).
     */
    public function notify(int $offerId): void {
        $this->forget();
        $offer = $this->offers->find($offerId);

        if (null === $offer || get_transient(self::NOTIFIED . $offerId) || !apply_filters('pofsf_access_request_notify', true, $offerId)) {
            return;
        }

        set_transient(self::NOTIFIED . $offerId, 1, self::NOTIFY_GAP);
        $headline = (string) ($offer['offer_data']['offer_json']['headline'] ?? '');
        $site = wp_specialchars_decode((string) get_bloginfo('name'), ENT_QUOTES);

        wp_mail(
            (string) get_option('admin_email'),
            /* translators: 1: site name, 2: offer ID. */
            sprintf(__('[%1$s] Someone asked to open offer #%2$d', 'personalized-offers-for-spacefast'), $site, $offerId),
            sprintf(
                /* translators: 1: offer headline, 2: offer ID, 3: admin URL. */
                __("Someone who can't open the offer \"%1\$s\" (#%2\$d) asked for access on its page.\n\nApprove or decline the request here:\n%3\$s", 'personalized-offers-for-spacefast'),
                '' !== $headline ? $headline : __('(no headline)', 'personalized-offers-for-spacefast'),
                $offerId,
                admin_url('admin.php?page=personalized-offers-for-spacefast&tab=spaces'),
            ),
        );
    }

    /**
     * Whose email it is, for this offer: its customer (single offer), one
     * of its customers (group), a removed customer, or someone else; with
     * the name of the store account using it, if any.
     *
     * @return array{match: string, account: string}
     */
    public function match(array $offer, string $email): array {
        $email = strtolower($email);
        $user = get_user_by('email', $email);
        $account = $user instanceof WP_User ? $user->display_name : '';
        $type = OfferEditor::typeOf($offer);

        if (OfferType::Single === $type) {
            $customer = (int) ($offer['user_id'] ?? 0) > 0 ? get_userdata((int) $offer['user_id']) : false;
            $customerEmail = $customer instanceof WP_User ? $customer->user_email : (string) ($offer['guest_email'] ?? '');

            return ['match' => '' !== $customerEmail && strtolower($customerEmail) === $email ? self::CUSTOMER : self::OTHER, 'account' => $account];
        }

        if (OfferType::Group === $type && $user instanceof WP_User) {
            foreach ($this->recipients->forOffer((int) $offer['id']) as $recipient) {
                if ((int) $recipient['user_id'] === $user->ID) {
                    return ['match' => RecipientRepository::REVOKED === $recipient['status'] ? self::REMOVED : self::RECIPIENT, 'account' => $account];
                }
            }
        }

        return ['match' => self::OTHER, 'account' => $account];
    }

    /**
     * An offer whose page asks for access: private, open, with a Space.
     */
    private static function open(array $offer): bool {
        $record = OfferPublisher::record($offer);

        return '' !== $record['space_id']
            && 'public' !== $record['access']
            && OfferType::Public !== OfferEditor::typeOf($offer)
            && !OfferPublisher::closes($offer);
    }

    /**
     * The offer and one of its Space's undecided requests, asked fresh.
     *
     * @return array{0: array, 1: array}|WP_Error
     */
    private function request(int $offerId, string $requestId): array|WP_Error {
        $offer = $offerId > 0 ? $this->offers->find($offerId) : null;
        $spaceId = null === $offer ? '' : OfferPublisher::record($offer)['space_id'];

        if ('' === $spaceId) {
            return new WP_Error('pofsf_space_missing', __('This offer is not published on Spacefast.', 'personalized-offers-for-spacefast'));
        }

        $requests = $this->client->accessRequests($spaceId);

        if ($requests instanceof WP_Error) {
            return $requests;
        }

        foreach ($requests as $request) {
            if ($requestId === $request['id'] && in_array($request['status'], ['pending', 'verification_pending'], true)) {
                return [$offer, $request];
            }
        }

        $this->forget();

        return new WP_Error('pofsf_request_gone', __('This request was already decided or withdrawn.', 'personalized-offers-for-spacefast'));
    }

    private function present(array $offer, array $request): array {
        return [
            'id' => $request['id'],
            'offer_id' => (int) $offer['id'],
            'email' => $request['email'],
            'name' => $request['name'],
            'message' => mb_substr($request['message'], 0, 280),
            'created_at' => $request['created_at'],
        ] + $this->match($offer, $request['email']);
    }
}
