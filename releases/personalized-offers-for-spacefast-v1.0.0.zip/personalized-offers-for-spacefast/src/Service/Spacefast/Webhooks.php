<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Spacefast;

use Micemade\PersonalizedOffers\Service\JobScheduler;
use Micemade\PersonalizedOffers\Service\Logger;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Live updates from Spacefast: a team webhook posting to a REST route on
 * this site, signed with a secret only this site and Spacefast know. A
 * finished or failed publish is picked up at once instead of on the next
 * check, a Space deleted in Spacefast unpublishes its offer, and a custom
 * domain going live updates the offer's address. Polling stays the
 * fallback: Spacefast can only reach a site on the public internet.
 */
final class Webhooks {
    private const OPTION = 'pofsf_spacefast_webhook';
    private const LOG_OPTION = 'pofsf_spacefast_events';
    private const ROUTE_NAMESPACE = 'pofsf/v1';
    private const ROUTE = '/spacefast-events';

    /** Seconds a signature stays valid: Spacefast leaves the window to us. */
    private const TOLERANCE = 300;

    /** Events kept for the Spaces tab. */
    private const RECENT = 15;

    public const REFRESH_HOOK = 'pofsf_spacefast_refresh_publish';
    public const ADDRESS_HOOK = 'pofsf_spacefast_refresh_address';

    /** What the plugin acts on. */
    public const EVENTS = ['version.ready', 'version.failed', 'space.deleted', 'space.disabled', 'space.access_request_created', 'domain.*'];

    public function __construct(
        private readonly SpacefastClient $client,
        private readonly OfferPublisher $publisher,
        private readonly Logger $log,
    ) {}

    public function register(): void {
        add_action('rest_api_init', [$this, 'registerRoute']);
        add_action('pofsf_spacefast_disconnecting', [$this, 'disable']);
        add_action(self::REFRESH_HOOK, [$this, 'refreshPublish']);
        add_action(self::ADDRESS_HOOK, [$this, 'refreshAddress']);
    }

    public function registerRoute(): void {
        register_rest_route(self::ROUTE_NAMESPACE, self::ROUTE, [
            'methods' => 'POST',
            'callback' => [$this, 'receive'],
            // Spacefast is not a WordPress user: each delivery is checked against its HMAC signature in receive().
            'permission_callback' => '__return_true',
        ]);
    }

    /**
     * Where Spacefast posts events: this site's REST route, or another
     * public HTTPS address that reaches it (a tunnel, a proxy).
     */
    public function url(): string {
        return (string) apply_filters('pofsf_spacefast_webhook_url', rest_url(self::ROUTE_NAMESPACE . self::ROUTE));
    }

    /**
     * Why Spacefast can't reach the site, or '' when it may: it needs a
     * public HTTPS address, not a local one.
     */
    public function unreachableReason(): string {
        $url = $this->url();
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));

        if ('https' !== wp_parse_url($url, PHP_URL_SCHEME)) {
            return __('Spacefast sends events only to HTTPS addresses, and this site uses HTTP.', 'personalized-offers-for-spacefast');
        }

        $local = '' === $host || 'localhost' === $host || !str_contains($host, '.')
            || 1 === preg_match('/\.(local|localhost|test|example|invalid|internal|lan|home|dev\.cc)$/', $host)
            || (false !== filter_var($host, FILTER_VALIDATE_IP) && false === filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE));

        return $local
            ? sprintf(
                /* translators: %s: host name, e.g. shop.local. */
                __('%s is a local address that Spacefast cannot reach from the internet.', 'personalized-offers-for-spacefast'),
                $host,
            )
            : '';
    }

    /**
     * @return array{enabled: bool, id: string, url: string, reachable: bool, needs_key: bool, reason: string, received: int, last_at: string, recent: list<array>}
     */
    public function status(): array {
        $stored = $this->stored();
        $log = $this->eventLog();
        $reason = $this->unreachableReason();

        return [
            'enabled' => '' !== $stored['id'],
            'id' => $stored['id'],
            'url' => '' !== $stored['url'] ? $stored['url'] : $this->url(),
            'reachable' => '' === $reason,
            'needs_key' => 'oauth' === $this->client->status()['auth'],
            'reason' => $reason,
            'received' => (int) $log['received'],
            'last_at' => (string) $log['last_at'],
            'recent' => $log['recent'],
        ];
    }

    /**
     * Spacefast's state of the webhook (active, failing, disabled), or ''.
     */
    public function remoteStatus(): string {
        $id = $this->stored()['id'];

        if ('' === $id) {
            return '';
        }

        $status = $this->client->webhookStatus($id);

        if (null === $status || 'deleted' === $status) {
            // Deleted in Spacefast: forget it here too.
            delete_option(self::OPTION);

            return '';
        }

        return $status instanceof WP_Error ? '' : $status;
    }

    public function enable(): array|WP_Error {
        if (!$this->client->status()['connected']) {
            return new WP_Error('pofsf_spacefast_disconnected', __('Connect a Spacefast account first.', 'personalized-offers-for-spacefast'));
        }

        // Spacefast refuses to create webhooks with a sign-in's token (403), so they need a team API key.
        if ('oauth' === $this->client->status()['auth']) {
            return new WP_Error('pofsf_webhook_needs_key', __('Live updates need a team API key. Disconnect, then connect with an API key to turn them on.', 'personalized-offers-for-spacefast'));
        }

        $reason = $this->unreachableReason();

        if ('' !== $reason) {
            return new WP_Error('pofsf_webhook_unreachable', $reason);
        }

        if ('' !== $this->stored()['id']) {
            return $this->status();
        }

        $created = $this->client->createWebhook($this->url(), self::EVENTS);

        if ($created instanceof WP_Error) {
            return $created;
        }

        update_option(self::OPTION, [
            'id' => $created['id'],
            'secret' => $created['secret'],
            'url' => $this->url(),
            'created_at' => gmdate('c'),
        ], false);

        return $this->status();
    }

    /**
     * Removes the webhook from the team; the plugin goes back to checking.
     */
    public function disable(): true|WP_Error {
        $id = $this->stored()['id'];

        if ('' !== $id && $this->client->status()['connected']) {
            $deleted = $this->client->deleteWebhook($id);

            if ($deleted instanceof WP_Error && 'pofsf_spacefast_disconnecting' !== current_action()) {
                return $deleted;
            }
        }

        delete_option(self::OPTION);

        return true;
    }

    /**
     * A delivery: checked against its signature, then acted on. Answers
     * quickly (Spacefast waits 10 seconds); slower work is queued.
     */
    public function receive(WP_REST_Request $request): WP_REST_Response {
        $secret = $this->stored()['secret'];
        $body = (string) $request->get_body();

        if ('' === $secret || !self::verify($body, (string) $request->get_header('spacefast-signature'), $secret, time())) {
            return new WP_REST_Response(['ok' => false, 'error' => 'invalid_signature'], 401);
        }

        $payload = json_decode($body, true);
        $event = is_array($payload['event'] ?? null) ? $payload['event'] : [];
        $id = (string) ($event['id'] ?? $request->get_header('spacefast-event-id'));

        // Retries and redeliveries can repeat an event.
        if ('' !== $id) {
            $seen = 'pofsf_evt_' . md5($id);

            if (false !== get_transient($seen)) {
                return new WP_REST_Response(['ok' => true, 'duplicate' => true], 200);
            }

            set_transient($seen, 1, 3 * DAY_IN_SECONDS);
        }

        $this->handle($event);

        return new WP_REST_Response(['ok' => true], 200);
    }

    /**
     * Acts on one event.
     *
     * @return int The offer it concerned, 0 if none.
     */
    public function handle(array $event): int {
        $code = (string) ($event['code'] ?? '');
        $spaceId = (string) ($event['spaceId'] ?? $event['details']['spaceId'] ?? '');
        $offer = '' !== $spaceId ? $this->publisher->offerForSpace($spaceId) : null;
        $offerId = null === $offer ? 0 : (int) $offer['id'];

        if (str_starts_with($code, 'space.') || str_starts_with($code, 'version.')) {
            do_action('pofsf_spacefast_spaces_changed');
        }

        if ($offerId > 0) {
            if (in_array($code, ['version.ready', 'version.failed'], true) && 'publishing' === OfferPublisher::record($offer)['status']) {
                $this->queue(self::REFRESH_HOOK, $offerId);
            } elseif ('space.deleted' === $code) {
                $this->publisher->detach($offerId);
                $this->log->log('Offer ' . $offerId . ': its Space was deleted in Spacefast, so the offer is now unpublished.');
            } elseif (str_starts_with($code, 'domain.')) {
                $this->queue(self::ADDRESS_HOOK, $offerId);
            } elseif ('space.access_request_created' === $code) {
                do_action(AccessRequests::REQUESTED_HOOK, $offerId);
            }
        }

        $this->record($code, (string) ($event['message'] ?? ''), $offerId);

        return $offerId;
    }

    public function refreshPublish(int $offerId): void {
        $this->publisher->refresh($offerId);
    }

    public function refreshAddress(int $offerId): void {
        $this->publisher->refreshAddress($offerId);
    }

    /**
     * HMAC-SHA256 over "<t>.<raw body>" with the secret, hex. The header is
     * "t=<unix seconds>, v1=<hex>", with a second v1 during a secret
     * rotation: any match is valid. Stale signatures are refused.
     */
    public static function verify(string $body, string $header, string $secret, int $now): bool {
        $parts = array_map('trim', explode(',', $header));
        $timestamp = '';
        $signatures = [];

        foreach ($parts as $part) {
            if (str_starts_with($part, 't=')) {
                $timestamp = substr($part, 2);
            } elseif (str_starts_with($part, 'v1=')) {
                $signatures[] = substr($part, 3);
            }
        }

        if (!ctype_digit($timestamp) || abs($now - (int) $timestamp) > self::TOLERANCE || [] === $signatures) {
            return false;
        }

        $expected = hash_hmac('sha256', $timestamp . '.' . $body, $secret);

        foreach ($signatures as $signature) {
            if (hash_equals($expected, strtolower($signature))) {
                return true;
            }
        }

        return false;
    }

    private function queue(string $hook, int $offerId): void {
        if (function_exists('as_enqueue_async_action')) {
            as_enqueue_async_action($hook, [$offerId], JobScheduler::GROUP);
        } else {
            do_action($hook, $offerId);
        }
    }

    private function record(string $code, string $message, int $offerId): void {
        $log = $this->eventLog();
        $now = gmdate('c');

        array_unshift($log['recent'], ['code' => $code, 'message' => mb_substr($message, 0, 200), 'offer_id' => $offerId, 'at' => $now]);
        update_option(self::LOG_OPTION, [
            'received' => (int) $log['received'] + 1,
            'last_at' => $now,
            'recent' => array_slice($log['recent'], 0, self::RECENT),
        ], false);
    }

    /**
     * @return array{id: string, secret: string, url: string, created_at: string}
     */
    private function stored(): array {
        $stored = get_option(self::OPTION, []);

        return wp_parse_args(is_array($stored) ? $stored : [], ['id' => '', 'secret' => '', 'url' => '', 'created_at' => '']);
    }

    /**
     * @return array{received: int, last_at: string, recent: list<array>}
     */
    private function eventLog(): array {
        $log = get_option(self::LOG_OPTION, []);
        $log = wp_parse_args(is_array($log) ? $log : [], ['received' => 0, 'last_at' => '', 'recent' => []]);
        $log['recent'] = array_values(array_filter((array) $log['recent'], 'is_array'));

        return $log;
    }
}
