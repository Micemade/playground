<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Spacefast;

use Micemade\PersonalizedOffers\Repository\OfferRepository;
use WP_Error;

/**
 * The Spacefast team's Spaces next to the store's offers: which offer each
 * Space belongs to, leftovers (titled like this store's offer Spaces but
 * belonging to no offer), the team's other Spaces, and offers whose Space
 * is gone. Also the plan's usage. Spacefast's answers are cached briefly.
 */
final class SpaceInventory {
    private const SPACES_CACHE = 'pofsf_spacefast_spaces';
    private const USAGE_CACHE = 'pofsf_spacefast_usage';
    private const TTL = 5 * MINUTE_IN_SECONDS;

    public const OFFER = 'offer';
    public const LEFTOVER = 'leftover';
    public const OTHER = 'other';

    public function __construct(
        private readonly SpacefastClient $client,
        private readonly OfferRepository $offers,
        private readonly OfferPublisher $publisher,
    ) {}

    public function register(): void {
        add_action('pofsf_spacefast_spaces_changed', [$this, 'forget']);
        add_action('pofsf_spacefast_disconnecting', [$this, 'forget']);
    }

    /**
     * The team's Spaces, each with `kind` (offer, leftover, other) and
     * `offer_id` (0 if none).
     *
     * @return list<array{id: string, title: string, live_url: string, status: string, created_at: string, updated_at: string, kind: string, offer_id: int}>|WP_Error
     */
    public function spaces(bool $fresh = false): array|WP_Error {
        $spaces = $fresh ? false : get_transient(self::SPACES_CACHE);

        if (!is_array($spaces)) {
            $spaces = $this->client->listSpaces();

            if ($spaces instanceof WP_Error) {
                return $spaces;
            }

            set_transient(self::SPACES_CACHE, $spaces, self::TTL);
        }

        $owners = $this->owners();

        return array_map(static function (array $space) use ($owners): array {
            $offerId = $owners[$space['id']] ?? 0;
            $space += ['updated_at' => ''];

            return $space + [
                'kind' => $offerId > 0 ? self::OFFER : (self::looksLikeOffer($space['title']) ? self::LEFTOVER : self::OTHER),
                'offer_id' => $offerId,
            ];
        }, $spaces);
    }

    /**
     * Offers that have a Space on record which the team no longer has
     * (deleted in Spacefast's dashboard, say): their links don't work.
     *
     * @param list<array{id: string}> $spaces From spaces().
     * @return list<array{offer_id: int, space_id: string}>
     */
    public function missing(array $spaces): array {
        $ids = array_flip(array_column($spaces, 'id'));
        $missing = [];

        foreach ($this->owners() as $spaceId => $offerId) {
            if (!isset($ids[$spaceId])) {
                $missing[] = ['offer_id' => $offerId, 'space_id' => (string) $spaceId];
            }
        }

        return $missing;
    }

    /**
     * The plan's limits and usage (SpacefastClient::usage()), cached.
     */
    public function usage(bool $fresh = false): array|WP_Error {
        $usage = $fresh ? false : get_transient(self::USAGE_CACHE);

        if (is_array($usage)) {
            return $usage;
        }

        $usage = $this->client->usage();

        if (!$usage instanceof WP_Error) {
            set_transient(self::USAGE_CACHE, $usage, self::TTL);
        }

        return $usage;
    }

    public function forget(): void {
        delete_transient(self::SPACES_CACHE);
        delete_transient(self::USAGE_CACHE);
    }

    /**
     * One of the team's Spaces, with its kind, or null.
     */
    public function find(string $spaceId): array|null|WP_Error {
        $spaces = $this->spaces();

        if ($spaces instanceof WP_Error) {
            return $spaces;
        }

        foreach ($spaces as $space) {
            if ($spaceId === $space['id']) {
                return $space;
            }
        }

        return null;
    }

    /**
     * Deletes a leftover Space. A Space of an offer goes with its offer
     * (or Unpublish), and the team's other Spaces are left alone.
     */
    public function deleteLeftover(string $spaceId): true|WP_Error {
        $owner = $this->owners()[$spaceId] ?? 0;

        // Known without asking Spacefast.
        if ($owner > 0) {
            return new WP_Error('pofsf_space_in_use', sprintf(
                /* translators: %d: offer ID. */
                __('That Space belongs to offer #%d. Unpublish or delete the offer instead.', 'personalized-offers-for-spacefast'),
                $owner,
            ));
        }

        $space = $this->find($spaceId);

        if ($space instanceof WP_Error) {
            return $space;
        }

        if (null === $space) {
            return new WP_Error('pofsf_space_missing', __('No Space with that ID in the connected team.', 'personalized-offers-for-spacefast'));
        }

        if (self::OFFER === $space['kind']) {
            return new WP_Error('pofsf_space_in_use', sprintf(
                /* translators: %d: offer ID. */
                __('That Space belongs to offer #%d. Unpublish or delete the offer instead.', 'personalized-offers-for-spacefast'),
                $space['offer_id'],
            ));
        }

        if (self::LEFTOVER !== $space['kind']) {
            return new WP_Error('pofsf_space_other', __('That Space was not made by this store, so it is left alone here. Manage it in Spacefast.', 'personalized-offers-for-spacefast'));
        }

        $result = $this->client->deleteSpace($spaceId);
        $this->forget();

        return $result;
    }

    /**
     * Gives a leftover Space to an offer that has none, and publishes the
     * offer to it (OfferPublisher::adopt()).
     */
    public function link(string $spaceId, int $offerId): array|WP_Error {
        $space = $this->find($spaceId);

        if ($space instanceof WP_Error) {
            return $space;
        }

        if (null === $space || self::LEFTOVER !== $space['kind']) {
            return new WP_Error('pofsf_space_not_leftover', __('Only a leftover Space can be linked to an offer.', 'personalized-offers-for-spacefast'));
        }

        $result = $this->publisher->adopt($offerId, $spaceId);
        $this->forget();

        return $result;
    }

    /**
     * Which offer each Space belongs to: [space_id => offer_id].
     *
     * @return array<string, int>
     */
    public function owners(): array {
        $owners = [];

        foreach ($this->offers->withSpace() as $offer) {
            $spaceId = OfferPublisher::record($offer)['space_id'];

            if ('' !== $spaceId) {
                $owners[$spaceId] = (int) $offer['id'];
            }
        }

        return $owners;
    }

    /**
     * Titled like this store's offer Spaces ("<Store> offer #N", see
     * OfferPublisher::spaceTitle()). Another site on the same team (a
     * staging copy, say) may share the store name, hence confirmations.
     */
    public static function looksLikeOffer(string $title): bool {
        $prefix = wp_strip_all_tags(get_bloginfo('name'));

        return 1 === preg_match('/^' . preg_quote($prefix, '/') . ' .*#\d+$/u', $title);
    }
}
