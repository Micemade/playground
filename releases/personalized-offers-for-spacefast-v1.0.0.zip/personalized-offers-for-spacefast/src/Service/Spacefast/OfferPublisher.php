<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Spacefast;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Enum\OfferType;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\RecipientRepository;
use Micemade\PersonalizedOffers\Service\OfferEditor;
use Micemade\PersonalizedOffers\Service\Logger;
use Micemade\PersonalizedOffers\Service\ZipExporter;
use WP_Error;

/**
 * Publishes an offer as its own Spacefast Space and records the result in
 * the offer's `offer_data['spacefast']`.
 */
final class OfferPublisher {
    public function __construct(
        private readonly OfferRepository $offers,
        private readonly RecipientRepository $recipients,
        private readonly ZipExporter $zip,
        private readonly SpacefastClient $client,
        private readonly Logger $log,
    ) {}

    /**
     * @param string|null $access `private` (share link) or `public`; null
     *                            keeps the Space's access, or follows the offer type.
     */
    public function publish(int $offerId, ?string $access = null): array|WP_Error {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return new WP_Error('offer_not_found', __('Offer not found.', 'personalized-offers-for-spacefast'));
        }

        $path = $this->zip->buildZip($offerId);

        if ($path instanceof WP_Error) {
            return $path;
        }

        $existing = self::record($offer);
        $spaceId = '' !== $existing['space_id'] ? $existing['space_id'] : null;
        $title = self::spaceTitle($offerId);

        if (null === $spaceId) {
            $spaceId = $this->unfinishedSpace($offer, $existing, $title);

            if ($spaceId instanceof WP_Error) {
                wp_delete_file($path);

                return $spaceId;
            }
        }

        $result = $this->client->publishArchive($path, $spaceId, [
            'title' => $title,
            'access' => 'public' === ($access ?? $existing['access']) ? 'public' : 'private',
        ]);

        wp_delete_file($path);

        if ($result instanceof WP_Error) {
            $this->log->error('Spacefast publish failed for offer ' . $offerId . ': ' . $result->get_error_message());

            return $result;
        }

        $record = $this->store($offer, $existing, $result, $existing['access']);

        return $this->syncAccess($offerId, $access) ?? $record;
    }

    /**
     * The title of an offer's Space: "<store> offer #<ID>".
     */
    public static function spaceTitle(int $offerId): string {
        return mb_substr(sprintf(
            /* translators: 1: store name, 2: offer ID. */
            __('%1$s offer #%2$d', 'personalized-offers-for-spacefast'),
            wp_strip_all_tags(get_bloginfo('name')),
            $offerId,
        ), 0, 255);
    }

    /**
     * Before a first publish: the Space an earlier first publish of this
     * offer created without the plugin hearing back (timeout, closed tab),
     * which then gets a new version instead of a second Space being made.
     * Otherwise notes the attempt (`create_started`), cleared once the
     * Space is stored, so a retry knows to look.
     */
    private function unfinishedSpace(array $offer, array $existing, string $title): string|WP_Error|null {
        if ('' !== $existing['create_started']) {
            // Allows for clock skew between this server and Spacefast.
            $found = $this->client->findSpace($title, gmdate('c', (int) strtotime($existing['create_started']) - 300));

            // Not knowing whether the Space exists, don't risk making a second one.
            if ($found instanceof WP_Error) {
                return $found;
            }

            if (is_array($found) && '' !== $found['id']) {
                $this->log->log('Offer ' . $offer['id'] . ': using Space ' . $found['id'] . ' from an earlier unfinished publish.');

                return $found['id'];
            }
        }

        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $offerData['spacefast'] = ['create_started' => gmdate('c')] + $existing;
        $this->offers->update((int) $offer['id'], ['offer_data' => $offerData]);

        return null;
    }

    /**
     * Brings who can open the offer's Space in line with the offer:
     * - expired or revoked: closed, with no public access and no share links;
     * - public: open to everyone;
     * - private: a share link for the Preview link and the customer, and for
     *   a group offer one per recipient, so removing a recipient revokes
     *   only their link.
     * Links no longer needed are revoked, and visitors signed out so a
     * revoked link stops working at once. $access overrides the public or
     * private choice; without it the stored choice stays, unless the
     * offer's type changed since. Failures are kept in `access_error` and
     * the log. Hooked to JobScheduler::ACCESS_HOOK.
     *
     * @return array|null The updated record, or null without a Space.
     */
    public function syncAccess(int $offerId, ?string $access = null): ?array {
        $offer = $this->offers->find($offerId);
        $record = null !== $offer ? self::record($offer) : null;

        if (null === $record || '' === $record['space_id']) {
            return null;
        }

        $type = OfferEditor::typeOf($offer);
        $access ??= $type->value === $record['type'] && '' !== $record['access']
            ? $record['access']
            : (OfferType::Public === $type ? 'public' : 'private');
        $access = 'public' === $access ? 'public' : 'private';
        $closed = self::closes($offer);
        $spaceId = $record['space_id'];
        $errors = [];

        $result = $this->client->setPublic($spaceId, !$closed && 'public' === $access);

        if ($result instanceof WP_Error) {
            $errors[] = $result->get_error_message();
        }

        // Visitors who opened the page while it was public keep their session otherwise.
        $revoked = true === $result;

        $wanted = [];

        if (!$closed && 'private' === $access) {
            /* translators: %d: offer ID. */
            $wanted['offer'] = sprintf(__('Offer #%d', 'personalized-offers-for-spacefast'), $offerId);

            if (OfferType::Group === $type) {
                foreach ($this->recipients->forOffer($offerId) as $recipient) {
                    if (RecipientRepository::REVOKED !== $recipient['status']) {
                        /* translators: 1: offer ID, 2: recipient (user) ID. */
                        $wanted['r' . $recipient['id']] = sprintf(__('Offer #%1$d, customer #%2$d', 'personalized-offers-for-spacefast'), $offerId, $recipient['user_id']);
                    }
                }
            }
        }

        $links = $record['share_links'];

        foreach (array_diff_key($links, $wanted) as $key => $link) {
            $result = $this->client->revokeShareLink($spaceId, (string) $link['id']);

            if ($result instanceof WP_Error) {
                $errors[] = $result->get_error_message();
            } else {
                unset($links[$key]);
                $revoked = true;
            }
        }

        foreach (array_diff_key($wanted, $links) as $key => $name) {
            $link = $this->client->shareLink($spaceId, $name);

            if ($link instanceof WP_Error) {
                $errors[] = $link->get_error_message();
                break;
            }

            $links[$key] = $link;
        }

        [$record['people'], $removed] = $this->syncPeople($offerId, $spaceId, $type, $closed, $record, $errors);
        $revoked = $revoked || $removed;

        if ($revoked) {
            $result = $this->client->logoutAll($spaceId);

            if ($result instanceof WP_Error) {
                $errors[] = $result->get_error_message();
            }
        }

        $record['share_links'] = $links;
        $record['share_link_id'] = (string) ($links['offer']['id'] ?? '');

        if (isset($links['offer'])) {
            $record['access_url'] = (string) $links['offer']['url'];
            $record['access_expires_at'] = '';
        } elseif (!isset($wanted['offer'])) {
            // Public or closed: no link to hand out.
            $record['access_url'] = '';
            $record['access_expires_at'] = '';
        }

        $record['access'] = $access;
        $record['type'] = $type->value;
        $record['closed'] = $closed;
        $record['access_error'] = implode(' ', array_unique($errors));

        if ([] !== $errors) {
            $this->log->error('Spacefast access change failed for offer ' . $offerId . ': ' . $record['access_error']);
        }

        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $offerData['spacefast'] = $record;
        $this->offers->update($offerId, ['offer_data' => $offerData]);

        return $record;
    }

    /**
     * People let in by approving their access request (AccessRequests)
     * stay while the offer is open. Closing the offer removes them, with
     * anyone let in from Spacefast's dashboard; removing a group offer's
     * recipient removes the person with their email.
     *
     * @param list<string> $errors
     * @return array{0: array<string, array>, 1: bool} The people kept, and whether anyone was removed.
     */
    private function syncPeople(int $offerId, string $spaceId, OfferType $type, bool $closed, array $record, array &$errors): array {
        $people = (array) $record['people'];
        $keep = $closed ? [] : $people;

        if (!$closed && OfferType::Group === $type && [] !== $people) {
            foreach ($this->recipients->forOffer($offerId) as $recipient) {
                $user = RecipientRepository::REVOKED === $recipient['status'] ? get_userdata((int) $recipient['user_id']) : false;

                if (false !== $user) {
                    unset($keep[strtolower((string) $user->user_email)]);
                }
            }
        }

        $gone = array_diff_key($people, $keep);

        // Closing reaches Spacefast once, or again while people remain.
        if ([] === $gone && !($closed && (!$record['closed'] || [] !== $people))) {
            return [$keep, false];
        }

        $grants = $this->client->people($spaceId);

        if ($grants instanceof WP_Error) {
            $errors[] = $grants->get_error_message();

            return [$people, false];
        }

        $removed = false;

        foreach ($closed ? $grants : array_intersect_key($grants, $gone) as $email => $grantId) {
            $result = $this->client->removeAccess($spaceId, $grantId);

            if ($result instanceof WP_Error) {
                $errors[] = $result->get_error_message();
                $keep[$email] = $people[$email] ?? ['approved_at' => ''];
            } else {
                $removed = true;
            }
        }

        return [$closed ? [] : $keep, $removed];
    }

    /** How long view counts are cached, in seconds (Spacefast's analytics can take 20 s or more). */
    private const VIEWS_TTL = 30 * MINUTE_IN_SECONDS;

    /** How long a failed view count is remembered, so a slow Spacefast isn't asked again at once. */
    private const VIEWS_RETRY = 5 * MINUTE_IN_SECONDS;

    /** How long link opens are cached, in seconds. */
    private const OPENS_TTL = 2 * MINUTE_IN_SECONDS;

    /**
     * How the offer's page is used, for the list and the assistant:
     * `views`/`visitors` in the last 30 days (Spacefast keeps no longer;
     * admins' own visits count too; null when not known), and for a group
     * offer `opens` (how often each customer opened their personal link,
     * by user ID, all time), `opened` and `recipients`. With $cachedOnly,
     * views are only read from the cache, so the caller never waits on
     * Spacefast's slow analytics. Null without a Space.
     *
     * @return array{views: ?int, visitors: ?int, window: string, opens: array<int, int>, opened: int, recipients: int}|null
     */
    public function stats(array $offer, bool $cachedOnly = false): ?array {
        $record = self::record($offer);

        if ('' === $record['space_id'] || 'publishing' === $record['status']) {
            return null;
        }

        $views = $this->views((int) $offer['id'], $record['space_id'], $cachedOnly);

        return [
            'views' => $views['views'] ?? null,
            'visitors' => $views['visitors'] ?? null,
            'window' => '30d',
        ] + ($this->linkOpens($offer) ?? ['opens' => [], 'opened' => 0, 'recipients' => 0]);
    }

    /**
     * @return array{views: int, visitors: int}|null
     */
    private function views(int $offerId, string $spaceId, bool $cachedOnly): ?array {
        $key = 'pofsf_views_' . $offerId;
        $cached = get_transient($key);

        if (is_array($cached) && ($cached['space_id'] ?? '') === $spaceId) {
            return $cached['views'];
        }

        if ($cachedOnly) {
            return null;
        }

        $traffic = $this->client->analytics($spaceId);
        $views = $traffic instanceof WP_Error ? null : $traffic;
        set_transient($key, ['space_id' => $spaceId, 'views' => $views], null === $views ? self::VIEWS_RETRY : self::VIEWS_TTL);

        return $views;
    }

    /**
     * For a group offer: how often each customer opened their personal
     * share link (all time), by user ID. Null for other offers, or when
     * Spacefast can't be reached (left out rather than shown as none).
     *
     * @return array{opens: array<int, int>, opened: int, recipients: int}|null
     */
    public function linkOpens(array $offer): ?array {
        $record = self::record($offer);

        if ('' === $record['space_id'] || OfferType::Group !== OfferEditor::typeOf($offer)) {
            return null;
        }

        $key = 'pofsf_opens_' . (int) $offer['id'];
        $links = get_transient($key);

        if (!is_array($links)) {
            $links = $this->client->shareLinkOpens($record['space_id']);

            if ($links instanceof WP_Error) {
                return null;
            }

            set_transient($key, $links, self::OPENS_TTL);
        }

        $result = ['opens' => [], 'opened' => 0, 'recipients' => 0];

        foreach ($this->recipients->forOffer((int) $offer['id']) as $recipient) {
            if (RecipientRepository::REVOKED === $recipient['status']) {
                continue;
            }

            $linkId = (string) ($record['share_links']['r' . $recipient['id']]['id'] ?? '');
            $opens = (int) ($links[$linkId]['opens'] ?? 0);
            $result['opens'][$recipient['user_id']] = $opens;
            $result['opened'] += $opens > 0 ? 1 : 0;
            ++$result['recipients'];
        }

        return $result;
    }

    /**
     * Whether the offer's Space should be closed: the offer expired or was revoked.
     */
    public static function closes(array $offer): bool {
        return in_array((string) ($offer['status'] ?? ''), [OfferStatus::Expired->value, OfferStatus::Revoked->value], true);
    }

    /**
     * Whether the Space is out of line with the offer's status (it expired
     * or was revoked, or came back, since access was last synced).
     */
    public static function needsSync(array $offer): bool {
        $record = self::record($offer);

        return '' !== $record['space_id'] && self::closes($offer) !== $record['closed'];
    }

    /**
     * The link that opens the offer's page: the public page, or its share
     * link. '' while it is not published, or once closed.
     */
    public static function pageUrl(array $offer): string {
        $record = self::record($offer);

        if ('' === $record['space_id'] || 'publishing' === $record['status'] || $record['closed']) {
            return '';
        }

        return 'public' === $record['access'] ? $record['live_url'] : ($record['access_url'] ?: $record['live_url']);
    }

    /**
     * A group recipient's personal link: their own share link (or the
     * public page), with their checkout token in the fragment, which the
     * page reads and which never reaches a server.
     */
    public static function recipientUrl(array $offer, array $recipient): string {
        $pageUrl = self::pageUrl($offer);

        if ('' === $pageUrl || RecipientRepository::REVOKED === $recipient['status']) {
            return '';
        }

        $record = self::record($offer);
        $url = 'public' === $record['access'] ? $pageUrl : (string) ($record['share_links']['r' . $recipient['id']]['url'] ?? $pageUrl);

        return $url . '#r=' . $recipient['token'];
    }

    /**
     * Background job after the offer's template changed: publishes its
     * Space again (same Space, links and access), unless it was already
     * brought up to date or Spacefast is not connected.
     */
    public function republish(int $offerId): void {
        $offer = $this->offers->find($offerId);

        if (null === $offer || '' === self::record($offer)['space_id'] || !self::record($offer)['outdated']) {
            return;
        }

        if (!$this->client->status()['connected']) {
            $this->log->error('Offer ' . $offerId . ' was not republished after its template changed: Spacefast is not connected.');

            return;
        }

        $this->publish($offerId);
    }

    /**
     * Deletes the offer's Spacefast Space, if it has one.
     */
    public function deleteSpace(array $offer): true|WP_Error {
        $spaceId = self::record($offer)['space_id'];

        if ('' === $spaceId) {
            return true;
        }

        $result = $this->client->deleteSpace($spaceId);

        if ($result instanceof WP_Error) {
            $this->log->error('Spacefast Space deletion failed for offer ' . $offer['id'] . ': ' . $result->get_error_message());
        }

        return $result;
    }

    /**
     * Deletes the offer's Space and keeps the offer, unpublished: its links
     * stop working, and publishing it again makes a new Space.
     */
    public function unpublish(int $offerId): true|WP_Error {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return new WP_Error('offer_not_found', __('Offer not found.', 'personalized-offers-for-spacefast'));
        }

        if ('' === self::record($offer)['space_id']) {
            return new WP_Error('pofsf_not_published', __('The offer is not published on Spacefast.', 'personalized-offers-for-spacefast'));
        }

        $deleted = $this->deleteSpace($offer);

        if ($deleted instanceof WP_Error) {
            return $deleted;
        }

        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        unset($offerData['spacefast']);
        $this->offers->update($offerId, ['offer_data' => $offerData]);
        delete_transient('pofsf_views_' . $offerId);
        delete_transient('pofsf_opens_' . $offerId);

        return true;
    }

    /**
     * Gives an offer without a Space an existing one (a leftover): its old
     * share links are revoked, the people let in removed and visitors
     * signed out, so nobody reaches the new offer through them, then the
     * offer is published to it with the access its type needs.
     */
    public function adopt(int $offerId, string $spaceId): array|WP_Error {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return new WP_Error('offer_not_found', __('Offer not found.', 'personalized-offers-for-spacefast'));
        }

        if ('' !== self::record($offer)['space_id']) {
            return new WP_Error('pofsf_has_space', __('This offer already has a Space.', 'personalized-offers-for-spacefast'));
        }

        $revoked = $this->client->revokeAllShareLinks($spaceId);

        if ($revoked instanceof WP_Error) {
            return $revoked;
        }

        $removed = $this->client->removePeople($spaceId);

        if ($removed instanceof WP_Error) {
            return $removed;
        }

        $this->client->logoutAll($spaceId);

        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        // Access '' lets syncAccess() follow the offer type.
        $offerData['spacefast'] = ['space_id' => $spaceId, 'access' => '', 'status' => 'published'];
        $this->offers->update($offerId, ['offer_data' => $offerData]);
        $published = $this->publish($offerId);

        if ($published instanceof WP_Error) {
            // Not this offer's Space after all: it stays a leftover.
            $this->detach($offerId);

            return $published;
        }

        // Named after its new offer once it is its Space; not worth failing over.
        $this->client->renameSpace($spaceId, self::spaceTitle($offerId));
        $this->log->log('Offer ' . $offerId . ': linked to existing Space ' . $spaceId . '.');

        return $published;
    }

    /**
     * Forgets an offer's Space without calling Spacefast, for a Space
     * deleted there: the offer stays, unpublished.
     */
    public function detach(int $offerId): bool {
        $offer = $this->offers->find($offerId);

        if (null === $offer || '' === self::record($offer)['space_id']) {
            return false;
        }

        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        unset($offerData['spacefast']);
        $this->offers->update($offerId, ['offer_data' => $offerData]);
        delete_transient('pofsf_views_' . $offerId);
        delete_transient('pofsf_opens_' . $offerId);

        return true;
    }

    /**
     * Takes the Space's address from Spacefast again, after a custom
     * domain became its main address or stopped being it. Share links
     * keep their own address.
     */
    public function refreshAddress(int $offerId): ?array {
        $offer = $this->offers->find($offerId);
        $record = null === $offer ? null : self::record($offer);

        if (null === $record || '' === $record['space_id']) {
            return null;
        }

        $space = $this->client->space($record['space_id']);

        if ($space instanceof WP_Error || '' === $space['live_url'] || $space['live_url'] === $record['live_url']) {
            return $record;
        }

        $record['live_url'] = $space['live_url'];
        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $offerData['spacefast'] = $record;
        $this->offers->update($offerId, ['offer_data' => $offerData]);

        return $record;
    }

    /**
     * The offer whose Space this is, if any.
     */
    public function offerForSpace(string $spaceId): ?array {
        foreach ($this->offers->withSpace() as $offer) {
            if ($spaceId === self::record($offer)['space_id']) {
                return $offer;
            }
        }

        return null;
    }

    /**
     * Checks a publish that was still running when the admin request ended.
     */
    public function refresh(int $offerId): array|WP_Error {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return new WP_Error('offer_not_found', __('Offer not found.', 'personalized-offers-for-spacefast'));
        }

        $existing = self::record($offer);

        if ('' === $existing['poll_url']) {
            return $existing;
        }

        $result = $this->client->poll(['poll_url' => $existing['poll_url'], 'pending' => true]);

        if ($result instanceof WP_Error) {
            return $result;
        }

        return $this->store($offer, $existing, $result, $existing['access']);
    }

    /**
     * The stored Spacefast record for an offer row, with defaults.
     *
     * @return array{space_id: string, title: string, live_url: string, access_url: string, access_expires_at: string, access: string, version_id: string, version_status: string, status: string, poll_url: string, published_at: string, notes: list<string>, outdated: bool, access_error: string, share_link_id: string, share_links: array<string, array{id: string, url: string}>, type: string, closed: bool, people: array<string, array{request_id?: string, approved_at: string}>}
     */
    public static function record(array $offer): array {
        $stored = $offer['offer_data']['spacefast'] ?? [];

        $record = wp_parse_args(is_array($stored) ? $stored : [], [
            'space_id' => '',
            'title' => '',
            'live_url' => '',
            'access_url' => '',
            'access_expires_at' => '',
            'access' => '',
            'version_id' => '',
            'version_status' => '',
            'status' => '',
            'poll_url' => '',
            'published_at' => '',
            'notes' => [],
            'outdated' => false,
            'access_error' => '',
            'share_link_id' => '',
            // Share links by use: 'offer' (Preview link, the customer), 'r<recipient row ID>'.
            'share_links' => [],
            // The offer type and status access was last synced for.
            'type' => '',
            'closed' => false,
            // People let in by an approved access request: [email => {request_id, approved_at}].
            'people' => [],
            // When a first publish began; cleared once its Space is stored (unfinishedSpace()).
            'create_started' => '',
        ]);

        // Records from before per-recipient links.
        if ([] === $record['share_links'] && '' !== $record['share_link_id']) {
            $record['share_links'] = ['offer' => ['id' => $record['share_link_id'], 'url' => $record['access_url']]];
        }

        return $record;
    }

    private function store(array $offer, array $existing, array $result, string $access): array {
        $space = $result['space'] ?? [];
        $version = $result['version'] ?? [];
        $accessLink = $result['access'] ?? [];

        $record = array_merge($existing, [
            'space_id' => (string) ($space['id'] ?? $existing['space_id']),
            'title' => (string) ($space['title'] ?? $existing['title']),
            'live_url' => (string) ($space['liveUrl'] ?? $existing['live_url']),
            // A bearer URL: kept server-side for admins only. The share link
            // (syncAccess()) replaces the first publish's one-time Open link.
            'access_url' => '' !== $existing['share_link_id'] ? $existing['access_url'] : (string) ($accessLink['url'] ?? $existing['access_url']),
            'access_expires_at' => '' !== $existing['share_link_id'] ? $existing['access_expires_at'] : (string) ($accessLink['expiresAt'] ?? $existing['access_expires_at']),
            'access' => $access,
            'version_id' => (string) ($version['id'] ?? $existing['version_id']),
            'version_status' => (string) ($version['status'] ?? $existing['version_status']),
            'status' => !empty($result['pending']) ? 'publishing' : 'published',
            'poll_url' => (string) ($result['poll_url'] ?? ''),
            'published_at' => current_time('mysql', true),
            'notes' => array_values((array) ($result['diagnostics'] ?? [])),
            'outdated' => false,
            'create_started' => '',
        ]);

        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $offerData['spacefast'] = $record;

        $update = ['offer_data' => $offerData];

        if (OfferStatus::Ready->value === (string) $offer['status']) {
            $update['status'] = OfferStatus::Sent;
        }

        $this->offers->update((int) $offer['id'], $update);

        return $record;
    }
}
