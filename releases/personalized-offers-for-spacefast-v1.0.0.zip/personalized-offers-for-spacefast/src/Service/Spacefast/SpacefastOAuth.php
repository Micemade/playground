<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Spacefast;

use Micemade\PersonalizedOffers\Service\Logger;
use WP_Error;

/**
 * Sign in with Spacefast: OAuth 2.1 authorization code with PKCE, as a
 * public client that the site registers for itself (dynamic client
 * registration). The plugin keeps the refresh token, because a sign-in
 * token can't create a team API key (see SPACEFAST_API.md → Onboarding).
 *
 * Codes and tokens never reach the browser or the log.
 */
final class SpacefastOAuth {
    public const CLIENT_OPTION = 'pofsf_spacefast_oauth_client';
    public const ISSUER = 'https://api.spacefast.com/v1/auth';

    /** Asked for at registration and sign-in; a change means registering again. */
    public const SCOPES = 'openid offline_access teams:read teams:create spaces:read spaces:write spaces:rename spaces:access.write spaces:delete publish:write domains:read domains:write billing:read';

    private const STATE_PREFIX = 'pofsf_oauth_state_';
    private const STATE_TTL = 10 * MINUTE_IN_SECONDS;

    /**
     * The address Spacefast returns to. Always https:// on a site whose
     * address is https://, even when this request came over http://, so it
     * matches the registered one.
     */
    public function redirectUri(): string {
        $https = 'https' === wp_parse_url((string) get_option('siteurl'), PHP_URL_SCHEME) || force_ssl_admin();

        return admin_url('admin-post.php?action=pofsf_spacefast_oauth_callback', $https ? 'https' : 'admin');
    }

    /**
     * Spacefast only returns to https:// addresses (plain http only for
     * loopback hosts).
     */
    public function hasHttps(): bool {
        return 'https' === wp_parse_url($this->redirectUri(), PHP_URL_SCHEME);
    }

    /**
     * Needs https://, and the POFSF_SPACEFAST_API_KEY constant wins over
     * any sign-in.
     */
    public function canSignIn(): bool {
        $allowed = $this->hasHttps()
            && !(defined('POFSF_SPACEFAST_API_KEY') && '' !== (string) constant('POFSF_SPACEFAST_API_KEY'));

        return (bool) apply_filters('pofsf_onboarding_oauth', $allowed);
    }

    /**
     * The site's OAuth client, registered on first use and again when the
     * site's address or the scopes changed. Spacefast can't delete or change
     * a client, so an old one just stays unused.
     *
     * @return array{client_id: string, redirect_uri: string, scope: string}|WP_Error
     */
    public function client(): array|WP_Error {
        $stored = get_option(self::CLIENT_OPTION, []);

        if (is_array($stored) && '' !== (string) ($stored['client_id'] ?? '')
            && $this->redirectUri() === ($stored['redirect_uri'] ?? '') && self::SCOPES === ($stored['scope'] ?? '')) {
            return ['client_id' => (string) $stored['client_id'], 'redirect_uri' => (string) $stored['redirect_uri'], 'scope' => (string) $stored['scope']];
        }

        $name = trim(wp_strip_all_tags((string) get_bloginfo('name')));
        $response = $this->post('/v1/auth/oauth2/register', [
            'client_name' => mb_substr(('' !== $name ? $name . ' – ' : '') . 'Personalized Offers', 0, 120),
            'client_uri' => home_url('/'),
            'redirect_uris' => [$this->redirectUri()],
            'token_endpoint_auth_method' => 'none',
            'grant_types' => ['authorization_code', 'refresh_token'],
            'response_types' => ['code'],
            'scope' => self::SCOPES,
        ], true);

        if ($response instanceof WP_Error) {
            return $response;
        }

        $clientId = (string) ($response['client_id'] ?? '');

        if ('' === $clientId) {
            return new WP_Error('pofsf_spacefast_oauth', __('Spacefast did not register this site for sign-in.', 'personalized-offers-for-spacefast'));
        }

        $client = ['client_id' => $clientId, 'redirect_uri' => $this->redirectUri(), 'scope' => self::SCOPES];
        update_option(self::CLIENT_OPTION, $client + ['registered_at' => gmdate('c')], false);

        return $client;
    }

    /**
     * Where to send the admin to sign in. Keeps the PKCE verifier and a
     * single-use `state`, tied to this user, for 10 minutes.
     */
    public function authorizeUrl(int $userId): string|WP_Error {
        $client = $this->client();

        if ($client instanceof WP_Error) {
            return $client;
        }

        $verifier = self::base64url(random_bytes(48));
        $state = wp_generate_password(40, false);

        set_transient(self::STATE_PREFIX . $state, [
            'verifier' => $verifier,
            'user_id' => $userId,
            'client_id' => $client['client_id'],
        ], self::STATE_TTL);

        return add_query_arg(array_map('rawurlencode', [
            'response_type' => 'code',
            'client_id' => $client['client_id'],
            'redirect_uri' => $client['redirect_uri'],
            'scope' => $client['scope'],
            'state' => $state,
            'code_challenge' => self::base64url(hash('sha256', $verifier, true)),
            'code_challenge_method' => 'S256',
        ]), SpacefastClient::baseUrl() . '/v1/auth/oauth2/authorize');
    }

    /**
     * Forgets a `state` (on a cancelled sign-in); true when it was this user's.
     */
    public function forgetState(string $state, int $userId): bool {
        $saved = '' !== $state ? get_transient(self::STATE_PREFIX . $state) : false;

        if (!is_array($saved)) {
            return false;
        }

        delete_transient(self::STATE_PREFIX . $state);

        return (int) ($saved['user_id'] ?? 0) === $userId;
    }

    /**
     * Swaps the code from the return for tokens, after checking `state`
     * (known, unused, this user's) and `iss`.
     *
     * @return array{access_token: string, refresh_token: string, access_expires: int, client_id: string}|WP_Error
     */
    public function exchange(string $code, string $state, string $iss, int $userId): array|WP_Error {
        $saved = '' !== $state ? get_transient(self::STATE_PREFIX . $state) : false;
        $expired = new WP_Error('pofsf_spacefast_oauth_state', __('This sign-in link expired. Try again.', 'personalized-offers-for-spacefast'));

        if (!is_array($saved)) {
            return $expired;
        }

        // Single use, whatever happens next.
        delete_transient(self::STATE_PREFIX . $state);

        if ((int) ($saved['user_id'] ?? 0) !== $userId || '' === $code) {
            return $expired;
        }

        if (self::ISSUER !== $iss) {
            return new WP_Error('pofsf_spacefast_oauth_issuer', __('The sign-in came back from an unexpected server. Try again.', 'personalized-offers-for-spacefast'));
        }

        $clientId = (string) ($saved['client_id'] ?? '');
        $response = $this->post('/v1/auth/oauth2/token', [
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $this->redirectUri(),
            'client_id' => $clientId,
            'code_verifier' => (string) ($saved['verifier'] ?? ''),
        ]);

        if ($response instanceof WP_Error) {
            $this->forgetClientOn($response);

            return $response;
        }

        $tokens = self::tokens($response, $clientId);

        if ('' === $tokens['refresh_token']) {
            return new WP_Error('pofsf_spacefast_oauth', __('Spacefast did not allow staying signed in. Try again, or use an API key instead.', 'personalized-offers-for-spacefast'));
        }

        return $tokens;
    }

    /**
     * A new access token. Spacefast rotates the refresh token too; when it
     * doesn't send one, the old one stays valid.
     *
     * @return array{access_token: string, refresh_token: string, access_expires: int, client_id: string}|WP_Error
     *         An error with data `code` `invalid_grant` means the sign-in is gone.
     */
    public function refresh(string $refreshToken, string $clientId): array|WP_Error {
        $response = $this->post('/v1/auth/oauth2/token', [
            'grant_type' => 'refresh_token',
            'refresh_token' => $refreshToken,
            'client_id' => $clientId,
        ]);

        if ($response instanceof WP_Error) {
            return $response;
        }

        $tokens = self::tokens($response, $clientId);

        if ('' === $tokens['access_token']) {
            return new WP_Error('pofsf_spacefast_oauth', __('Spacefast did not return a new access token.', 'personalized-offers-for-spacefast'));
        }

        if ('' === $tokens['refresh_token']) {
            $tokens['refresh_token'] = $refreshToken;
        }

        return $tokens;
    }

    /**
     * Revokes a token; best effort, as on Disconnect nothing should stop
     * the site forgetting it.
     */
    public function revoke(string $token, string $hint, string $clientId): void {
        if ('' === $token || '' === $clientId) {
            return;
        }

        $this->post('/v1/auth/oauth2/revoke', [
            'client_id' => $clientId,
            'token' => $token,
            'token_type_hint' => $hint,
        ]);
    }

    /**
     * @return array{access_token: string, refresh_token: string, access_expires: int, client_id: string}
     */
    private static function tokens(array $response, string $clientId): array {
        $expiresIn = (int) ($response['expires_in'] ?? 3600);

        return [
            'access_token' => (string) ($response['access_token'] ?? ''),
            'refresh_token' => (string) ($response['refresh_token'] ?? ''),
            'access_expires' => time() + max(60, $expiresIn),
            'client_id' => $clientId,
        ];
    }

    /**
     * After `invalid_client` the stored client is no use; the next sign-in
     * registers a new one.
     */
    private function forgetClientOn(WP_Error $error): void {
        if ('invalid_client' === ($error->get_error_data()['code'] ?? '')) {
            delete_option(self::CLIENT_OPTION);
        }
    }

    /**
     * A POST to Spacefast's auth server: a form body (JSON for
     * registration), no credential, no redirects followed, and errors
     * logged without the request body.
     */
    private function post(string $path, array $fields, bool $json = false): array|WP_Error {
        $url = SpacefastClient::baseUrl() . $path;
        $response = wp_remote_post($url, [
            'timeout' => 20,
            'redirection' => 0,
            'headers' => [
                'Accept' => 'application/json',
                'x-spacefast-client' => SpacefastClient::CLIENT_HEADER,
            ] + ($json ? ['Content-Type' => 'application/json'] : []),
            'body' => $json ? (string) wp_json_encode($fields) : $fields,
        ]);

        if (is_wp_error($response)) {
            return new WP_Error($response->get_error_code(), sprintf(
                /* translators: 1: API path, 2: error message. */
                __('Spacefast request POST %1$s failed: %2$s', 'personalized-offers-for-spacefast'),
                $path,
                $response->get_error_message(),
            ));
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $decoded = json_decode((string) wp_remote_retrieve_body($response), true);
        $decoded = is_array($decoded) ? $decoded : [];

        if ($status >= 200 && $status < 300) {
            return $decoded;
        }

        // OAuth errors are {error, error_description}; the rest of the API's are problem documents.
        $code = (string) ($decoded['error'] ?? $decoded['code'] ?? '');
        $code = is_string($code) ? sanitize_key($code) : '';
        $detail = $decoded['error_description'] ?? $decoded['detail'] ?? $decoded['title'] ?? '';
        $message = sprintf(
            /* translators: 1: HTTP status code, 2: API path, 3: error message from Spacefast. */
            __('Spacefast API error %1$d on POST %2$s: %3$s', 'personalized-offers-for-spacefast'),
            $status,
            $path,
            is_string($detail) && '' !== $detail ? sanitize_text_field($detail) : ('' !== $code ? $code : __('Unknown error', 'personalized-offers-for-spacefast')),
        );

        (new Logger())->error($message);

        return new WP_Error('pofsf_spacefast_oauth', $message, ['status' => $status, 'code' => $code]);
    }

    private static function base64url(string $bytes): string {
        return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
    }
}
