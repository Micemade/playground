<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Spacefast;

use Micemade\PersonalizedOffers\Service\Logger;
use WP_Error;

/**
 * Minimal Spacefast HTTP API client: connects a team API key and publishes
 * static site archives.
 *
 * The key is stored in a non-autoloaded option, or supplied by the
 * POFSF_SPACEFAST_API_KEY constant, and is never sent to the browser.
 */
final class SpacefastClient {
    private const OPTION = 'pofsf_spacefast_connection';
    private const CLIENT_HEADER = 'personalized-offers-for-spacefast/' . POFSF_VERSION;

    /** Seconds to wait for a publish to settle inside one admin request. */
    private const SETTLE_BUDGET = 40;

    public function apiUrl(): string {
        return untrailingslashit((string) apply_filters('pofsf_spacefast_api_url', 'https://api.spacefast.com'));
    }

    /**
     * @return array{connected: bool, team_id: string, team_name: string, team_slug: string, key_hint: string, from_constant: bool}
     */
    public function status(): array {
        $connection = $this->connection();

        return [
            'connected' => '' !== $this->apiKey() && '' !== $connection['team_id'],
            'team_id' => $connection['team_id'],
            'team_name' => $connection['team_name'],
            'team_slug' => $connection['team_slug'],
            'key_hint' => $this->keyHint(),
            'from_constant' => $this->keyFromConstant(),
        ];
    }

    /**
     * Verifies the API key with the account bootstrap endpoint and stores it
     * with the team it belongs to.
     */
    public function connect(string $apiKey): array|WP_Error {
        $apiKey = trim($apiKey);

        if ('' === $apiKey && !$this->keyFromConstant()) {
            return new WP_Error('pofsf_spacefast_key', __('Enter a Spacefast API key.', 'personalized-offers-for-spacefast'));
        }

        $key = '' !== $apiKey ? $apiKey : (string) constant('POFSF_SPACEFAST_API_KEY');
        $response = $this->request('GET', '/v1/bootstrap', [], $key);

        if ($response instanceof WP_Error) {
            return $response;
        }

        $team = self::teamFromBootstrap(is_array($response['data'] ?? null) ? $response['data'] : []);

        if (null === $team) {
            return new WP_Error('pofsf_spacefast_team', __('This API key has no Spacefast team.', 'personalized-offers-for-spacefast'));
        }

        update_option(self::OPTION, [
            'api_key' => $this->keyFromConstant() ? '' : $key,
            'team_id' => (string) $team['id'],
            'team_name' => (string) ($team['name'] ?? ''),
            'team_slug' => (string) ($team['slug'] ?? ''),
        ], false);

        return $this->status();
    }

    /**
     * Picks the team a key acts for from GET /v1/bootstrap. `resolvedTeam` is
     * a status wrapper ({status: resolved|unresolved|not_requested}), so the
     * team list is the normal source; a team-subject key may only expose
     * itself as `me.subject`.
     *
     * @return array{id: string, name?: string, slug?: string}|null
     */
    private static function teamFromBootstrap(array $data): ?array {
        $candidates = [
            ('resolved' === ($data['resolvedTeam']['status'] ?? '')) ? ($data['resolvedTeam']['value'] ?? null) : null,
            $data['teams'][0] ?? null,
            $data['me']['teams'][0] ?? null,
            ('team' === ($data['me']['subject']['type'] ?? '')) ? ['id' => $data['me']['subject']['id'] ?? ''] : null,
        ];

        foreach ($candidates as $team) {
            if (is_array($team) && is_string($team['id'] ?? null) && '' !== $team['id']) {
                return $team;
            }
        }

        return null;
    }

    public function disconnect(): void {
        // While the key is still stored: lets the webhook be removed from the team.
        do_action('pofsf_spacefast_disconnecting');
        delete_option(self::OPTION);
    }

    /**
     * Whether Spacefast answers with the stored key, and how fast.
     *
     * @return array{ok: bool, ms: int, error: string}
     */
    public function check(): array {
        if (!$this->status()['connected']) {
            return ['ok' => false, 'ms' => 0, 'error' => __('Not connected.', 'personalized-offers-for-spacefast')];
        }

        $start = microtime(true);
        $response = $this->request('GET', '/v1/bootstrap', ['timeout' => 15]);
        $ms = (int) round((microtime(true) - $start) * 1000);

        return $response instanceof WP_Error
            ? ['ok' => false, 'ms' => $ms, 'error' => $response->get_error_message()]
            : ['ok' => true, 'ms' => $ms, 'error' => ''];
    }

    /**
     * The team's plan, its limits and what is used: live Spaces, storage,
     * publishes, custom domains; plus Spacefast's warnings and the storage
     * each Space takes. A limit is null when unlimited.
     *
     * @return array{plan: string, limits: array<string, int|null>, usage: array<string, int>, warnings: list<string>, space_storage: array<string, int>}|WP_Error
     */
    public function usage(): array|WP_Error {
        $team = $this->status()['team_id'];

        if ('' === $team) {
            return new WP_Error('pofsf_spacefast_disconnected', __('Connect a Spacefast account first.', 'personalized-offers-for-spacefast'));
        }

        $policy = $this->request('GET', '/v1/teams/' . rawurlencode($team) . '/plan-policy', ['timeout' => 15]);

        if ($policy instanceof WP_Error) {
            return $policy;
        }

        // Storage and monthly publishes; the plan policy is enough without it.
        $usage = $this->request('GET', '/v1/teams/' . rawurlencode($team) . '/usage', ['timeout' => 15]);
        $counters = $usage instanceof WP_Error ? [] : (array) ($usage['data']['usage'] ?? []);
        $policy = (array) ($policy['data'] ?? []);
        $limits = (array) ($policy['limits'] ?? []);
        $used = (array) ($policy['usage'] ?? []);
        $limit = static fn (mixed $value): ?int => is_numeric($value) ? (int) $value : null;

        $storage = [];

        foreach ($usage instanceof WP_Error ? [] : (array) ($usage['data']['spaceStorage'] ?? []) as $space) {
            if (is_array($space) && isset($space['spaceId'])) {
                $storage[(string) $space['spaceId']] = (int) ($space['storageBytes'] ?? 0);
            }
        }

        $warnings = [];

        foreach ((array) ($policy['warnings'] ?? []) as $warning) {
            $text = is_array($warning) ? ($warning['message'] ?? $warning['code'] ?? '') : $warning;

            if (is_string($text) && '' !== $text) {
                $warnings[] = $text;
            }
        }

        return [
            'plan' => (string) ($policy['plan'] ?? ''),
            'limits' => [
                'live_spaces' => $limit($limits['liveSpaces'] ?? null),
                'storage_bytes' => $limit($counters['storageQuotaBytes'] ?? $limits['storageBytes'] ?? null),
                'publishes_daily' => $limit($limits['buildsDeploysDaily'] ?? null),
                'publishes_monthly' => $limit($limits['buildsDeploysMonthly'] ?? null),
                'custom_domains' => $limit($limits['customDomains'] ?? null),
            ],
            'usage' => [
                'live_spaces' => (int) ($used['liveSpaces'] ?? $counters['liveSpaces'] ?? 0),
                'storage_bytes' => (int) ($counters['storageBytes'] ?? $used['storageBytes'] ?? 0),
                'publishes_today' => (int) ($used['buildsDeploysToday'] ?? $counters['buildsDeploysToday'] ?? 0),
                'publishes_month' => (int) ($counters['buildsDeploysThisMonth'] ?? 0),
                'custom_domains' => (int) ($used['customDomains'] ?? $counters['domains'] ?? 0),
            ],
            'warnings' => $warnings,
            'space_storage' => $storage,
        ];
    }

    /**
     * Registers a webhook for the team: Spacefast POSTs these events to
     * $url, signed with the secret returned here (and only here).
     *
     * @param list<string> $events
     * @return array{id: string, secret: string, status: string}|WP_Error
     */
    public function createWebhook(string $url, array $events): array|WP_Error {
        $team = $this->status()['team_id'];

        if ('' === $team) {
            return new WP_Error('pofsf_spacefast_disconnected', __('Connect a Spacefast account first.', 'personalized-offers-for-spacefast'));
        }

        $response = $this->request('POST', '/v1/webhooks', [
            'headers' => ['Content-Type' => 'application/json', 'Idempotency-Key' => wp_generate_uuid4()],
            'body' => wp_json_encode(['teamId' => $team, 'url' => $url, 'events' => array_values($events)]),
        ]);

        if ($response instanceof WP_Error) {
            return $response;
        }

        $data = (array) ($response['data'] ?? []);

        return '' === (string) ($data['secret'] ?? '')
            ? new WP_Error('pofsf_spacefast_webhook', __('Spacefast did not return the webhook secret.', 'personalized-offers-for-spacefast'))
            : ['id' => (string) ($data['id'] ?? ''), 'secret' => (string) $data['secret'], 'status' => (string) ($data['status'] ?? '')];
    }

    /**
     * A webhook's status: active, failing, disabled; null once deleted.
     */
    public function webhookStatus(string $webhookId): string|null|WP_Error {
        $response = $this->request('GET', '/v1/webhooks/' . rawurlencode($webhookId), ['timeout' => 15]);

        if ($response instanceof WP_Error) {
            return 404 === ($response->get_error_data()['status'] ?? 0) ? null : $response;
        }

        return (string) ($response['data']['status'] ?? '');
    }

    public function deleteWebhook(string $webhookId): true|WP_Error {
        $response = $this->request('DELETE', '/v1/webhooks/' . rawurlencode($webhookId));

        return $response instanceof WP_Error && 404 !== ($response->get_error_data()['status'] ?? 0) ? $response : true;
    }

    /**
     * A Space as Spacefast has it now: its address follows a custom
     * domain made primary.
     *
     * @return array{id: string, title: string, live_url: string, status: string}|WP_Error
     */
    public function space(string $spaceId): array|WP_Error {
        $response = $this->spaceRequest('GET', $spaceId, '');

        if ($response instanceof WP_Error) {
            return $response;
        }

        $data = (array) ($response['data'] ?? []);

        return [
            'id' => (string) ($data['id'] ?? $spaceId),
            'title' => (string) ($data['title'] ?? ''),
            'live_url' => (string) ($data['liveUrl'] ?? ''),
            'status' => (string) ($data['status'] ?? ''),
        ];
    }

    /**
     * Renames a Space (its title, not its address).
     */
    public function renameSpace(string $spaceId, string $title): true|WP_Error {
        $response = $this->spaceRequest('PATCH', $spaceId, '', ['title' => mb_substr($title, 0, 255)]);

        if ($response instanceof WP_Error) {
            return $response;
        }

        do_action('pofsf_spacefast_spaces_changed');

        return true;
    }

    /**
     * A Space's addresses: its space.fast one and custom domains, each with
     * the DNS records still to add.
     *
     * @return list<array>|WP_Error
     */
    public function domains(string $spaceId): array|WP_Error {
        $response = $this->spaceRequest('GET', $spaceId, '/domains');

        return $response instanceof WP_Error
            ? $response
            : array_values(array_map([self::class, 'domain'], array_filter((array) ($response['data'] ?? []), 'is_array')));
    }

    /**
     * Attaches a hostname to a Space, as its main address.
     */
    public function addDomain(string $spaceId, string $hostname): array|WP_Error {
        $response = $this->spaceRequest('POST', $spaceId, '/domains', ['name' => $hostname, 'primary' => true]);

        return $response instanceof WP_Error ? $response : self::domain((array) ($response['data'] ?? []));
    }

    /**
     * Asks Spacefast to check a domain's DNS again.
     */
    public function verifyDomain(string $spaceId, string $domainId): array|WP_Error {
        $response = $this->spaceRequest('POST', $spaceId, '/domains/' . rawurlencode($domainId) . '/verify');

        return $response instanceof WP_Error ? $response : self::domain((array) ($response['data'] ?? []));
    }

    public function removeDomain(string $spaceId, string $domainId): true|WP_Error {
        $response = $this->spaceRequest('DELETE', $spaceId, '/domains/' . rawurlencode($domainId));

        return $response instanceof WP_Error && 404 !== ($response->get_error_data()['status'] ?? 0) ? $response : true;
    }

    /**
     * A domain as the admin needs it: its status, and the DNS records to
     * add (to prove control and route traffic) with any problem found.
     *
     * @return array{id: string, name: string, primary: bool, managed: bool, status: string, records: list<array{type: string, name: string, value: string, purpose: string}>, problems: list<string>}
     */
    private static function domain(array $data): array {
        $records = [];

        foreach ((array) ($data['verification']['requiredRecords'] ?? []) as $record) {
            if (is_array($record) && isset($record['type'], $record['value'])) {
                $records[] = [
                    'type' => (string) $record['type'],
                    'name' => (string) ($record['name'] ?? ''),
                    'value' => (string) $record['value'],
                    'purpose' => (string) ($record['purpose'] ?? ''),
                ];
            }
        }

        $problems = [];

        foreach (array_merge((array) ($data['verification']['diagnostics'] ?? []), (array) ($data['hints'] ?? [])) as $item) {
            $text = is_array($item) ? ($item['message'] ?? $item['summary'] ?? '') : '';

            if (is_string($text) && '' !== $text && 'resolved' !== ($item['status'] ?? '')) {
                $problems[] = $text;
            }
        }

        $managed = !empty($data['managed']);

        return [
            'id' => (string) ($data['id'] ?? ''),
            'name' => (string) ($data['unicodeName'] ?? $data['name'] ?? ''),
            'primary' => !empty($data['primary']),
            'managed' => $managed,
            // not_required (space.fast), pending, verified, failed.
            'status' => $managed ? 'active' : (string) ($data['verification']['status'] ?? 'pending'),
            'records' => $records,
            'problems' => array_values(array_unique($problems)),
        ];
    }

    /**
     * Revokes every share link of a Space, e.g. before it is given to
     * another offer, so old links can't open the new offer.
     */
    public function revokeAllShareLinks(string $spaceId): true|WP_Error {
        $response = $this->spaceRequest('GET', $spaceId, '/share-links?limit=100');

        if ($response instanceof WP_Error) {
            return $response;
        }

        foreach ((array) ($response['data'] ?? []) as $link) {
            if (is_array($link) && isset($link['id']) && false !== ($link['active'] ?? true)) {
                $revoked = $this->revokeShareLink($spaceId, (string) $link['id']);

                if ($revoked instanceof WP_Error) {
                    return $revoked;
                }
            }
        }

        return true;
    }

    /**
     * Publishes a static site ZIP. Creates a new Space unless $spaceId is
     * given, in which case that Space gets a new version.
     *
     * @param array{title?: string, access?: string} $space
     * @return array{space: array, version: array, access: array, pending: bool, poll_url: string, diagnostics: list<string>}|WP_Error
     */
    public function publishArchive(string $zipPath, ?string $spaceId, array $space = []): array|WP_Error {
        $status = $this->status();

        if (!$status['connected']) {
            return new WP_Error('pofsf_spacefast_disconnected', __('Connect a Spacefast account first.', 'personalized-offers-for-spacefast'));
        }

        $bytes = is_readable($zipPath) ? file_get_contents($zipPath) : false;

        if (false === $bytes) {
            return new WP_Error('pofsf_spacefast_archive', __('Offer archive could not be read.', 'personalized-offers-for-spacefast'));
        }

        $payload = null !== $spaceId && '' !== $spaceId
            ? ['spaceId' => $spaceId]
            : array_filter([
                'teamId' => $status['team_id'],
                'space' => isset($space['title']) ? ['title' => mb_substr($space['title'], 0, 255)] : null,
                'access' => in_array($space['access'] ?? '', ['private', 'team', 'public'], true) ? $space['access'] : null,
            ]);

        $boundary = 'pofsf' . wp_generate_password(24, false);
        $body = "--{$boundary}\r\n"
            . "Content-Disposition: form-data; name=\"payload\"\r\n"
            . "Content-Type: application/json\r\n\r\n"
            . wp_json_encode($payload) . "\r\n"
            . "--{$boundary}\r\n"
            . "Content-Disposition: form-data; name=\"archive\"; filename=\"offer.zip\"\r\n"
            . "Content-Type: application/zip\r\n\r\n"
            . $bytes . "\r\n"
            . "--{$boundary}--\r\n";

        $receipt = $this->request('POST', '/v1/publish', [
            'headers' => [
                'Content-Type' => 'multipart/form-data; boundary=' . $boundary,
                'Idempotency-Key' => wp_generate_uuid4(),
            ],
            'body' => $body,
            'timeout' => 90,
        ]);

        if ($receipt instanceof WP_Error) {
            return $receipt;
        }

        if (null === $spaceId || '' === $spaceId) {
            do_action('pofsf_spacefast_spaces_changed');
        }

        return $this->settle($this->merge([], $receipt));
    }

    /**
     * The team's Spaces, newest first as Spacefast lists them, up to $max.
     *
     * @return list<array{id: string, slug: string, title: string, live_url: string, status: string, created_at: string}>|WP_Error
     */
    public function listSpaces(int $max = 1000): array|WP_Error {
        $status = $this->status();

        if (!$status['connected'] || '' === $status['team_id']) {
            return new WP_Error('pofsf_spacefast_disconnected', __('Connect a Spacefast account first.', 'personalized-offers-for-spacefast'));
        }

        $spaces = [];
        $cursor = '';

        do {
            $response = $this->request('GET', add_query_arg(array_filter([
                'limit' => 100,
                'cursor' => $cursor,
            ]), '/v1/teams/' . rawurlencode($status['team_id']) . '/spaces'));

            if ($response instanceof WP_Error) {
                return $response;
            }

            foreach ((array) ($response['data'] ?? []) as $space) {
                if (is_array($space) && isset($space['id'])) {
                    $spaces[] = [
                        'id' => (string) $space['id'],
                        'slug' => (string) ($space['slug'] ?? ''),
                        'title' => (string) ($space['title'] ?? ''),
                        'live_url' => (string) ($space['liveUrl'] ?? ''),
                        'status' => (string) ($space['status'] ?? ''),
                        'created_at' => (string) ($space['createdAt'] ?? ''),
                        'updated_at' => (string) ($space['updatedAt'] ?? ''),
                    ];
                }
            }

            $cursor = (string) ($response['pagination']['nextCursor'] ?? '');
        } while ('' !== $cursor && !empty($response['pagination']['hasMore']) && count($spaces) < $max);

        return array_slice($spaces, 0, $max);
    }

    /**
     * The team's Space with this exact title created at or after $since (an
     * ISO 8601 time), if any: finds the Space a first publish created when
     * its response never arrived, so a retry doesn't create a second one.
     *
     * @return array{id: string}|null|WP_Error
     */
    public function findSpace(string $title, string $since): array|null|WP_Error {
        $spaces = $this->listSpaces();

        if ($spaces instanceof WP_Error) {
            return $spaces;
        }

        $since = (int) strtotime($since);

        foreach ($spaces as $space) {
            if ($title === $space['title'] && (int) strtotime($space['created_at']) >= $since) {
                return ['id' => $space['id']];
            }
        }

        return null;
    }

    /**
     * Deletes a Space: Spacefast stops serving it immediately and keeps its
     * data only for operator cleanup.
     */
    public function deleteSpace(string $spaceId): true|WP_Error {
        if (1 !== preg_match('/^[A-Za-z0-9_-]+$/', $spaceId)) {
            return new WP_Error('pofsf_spacefast_space', __('Invalid Space ID.', 'personalized-offers-for-spacefast'));
        }

        if (!$this->status()['connected']) {
            return new WP_Error('pofsf_spacefast_disconnected', __('Connect a Spacefast account first.', 'personalized-offers-for-spacefast'));
        }

        $response = $this->request('DELETE', '/v1/spaces/' . $spaceId);

        // Already gone counts as deleted.
        if ($response instanceof WP_Error && 404 !== ($response->get_error_data()['status'] ?? 0)) {
            return $response;
        }

        do_action('pofsf_spacefast_spaces_changed');

        return true;
    }

    /**
     * Makes a Space public or private. Public access is a grant with a
     * public audience: added to make it public, its editable grants revoked
     * to make it private. Takes effect without publishing again.
     *
     * @return bool|WP_Error Whether public access was revoked (visitors may
     *                       still hold sessions from it).
     */
    public function setPublic(string $spaceId, bool $public): bool|WP_Error {
        $grants = $this->spaceRequest('GET', $spaceId, '/grants');

        if ($grants instanceof WP_Error) {
            return $grants;
        }

        $publicGrants = array_filter(
            (array) ($grants['data'] ?? []),
            static fn ($item): bool => is_array($item) && 'public' === ($item['grant']['audience']['kind'] ?? '') && 'expired' !== ($item['status'] ?? ''),
        );

        if ($public) {
            if ([] !== $publicGrants) {
                return false;
            }

            $created = $this->spaceRequest('POST', $spaceId, '/grants', [
                'name' => 'Public',
                'audience' => ['kind' => 'public'],
                'resources' => ['include' => ['/**'], 'exclude' => []],
                'capabilities' => ['page.view'],
                'target' => ['kind' => 'live'],
            ]);

            return $created instanceof WP_Error ? $created : false;
        }

        foreach ($publicGrants as $item) {
            if (empty($item['sourceExplanation']['editable'])) {
                return new WP_Error('pofsf_spacefast_public_locked', __('The Space stays public: its public access comes from Spacefast settings, not from this plugin.', 'personalized-offers-for-spacefast'));
            }

            $revoked = $this->spaceRequest('DELETE', $spaceId, '/grants/' . rawurlencode((string) $item['grant']['id']));

            if ($revoked instanceof WP_Error && 404 !== ($revoked->get_error_data()['status'] ?? 0)) {
                return $revoked;
            }
        }

        return [] !== $publicGrants;
    }

    /**
     * A share link that opens a private Space's pages for anyone who has it,
     * in any browser, until it is revoked. (The Open link from a publish
     * works once, in one browser, so it can't be shared.)
     *
     * @return array{id: string, url: string}|WP_Error
     */
    public function shareLink(string $spaceId, string $name): array|WP_Error {
        $response = $this->spaceRequest('POST', $spaceId, '/share-links', [
            'name' => mb_substr($name, 0, 200),
            'resources' => ['include' => ['/**'], 'exclude' => []],
            'capabilities' => ['page.view'],
            'target' => ['kind' => 'live'],
        ]);

        if ($response instanceof WP_Error) {
            return $response;
        }

        $url = (string) ($response['data']['url'] ?? '');

        return '' === $url
            ? new WP_Error('pofsf_spacefast_share_link', __('Spacefast did not return a share link.', 'personalized-offers-for-spacefast'))
            : ['id' => (string) ($response['data']['id'] ?? ''), 'url' => $url];
    }

    /**
     * Revokes a share link; one already gone counts as revoked.
     */
    public function revokeShareLink(string $spaceId, string $linkId): true|WP_Error {
        $result = $this->spaceRequest('DELETE', $spaceId, '/share-links/' . rawurlencode($linkId));

        return $result instanceof WP_Error && 404 !== ($result->get_error_data()['status'] ?? 0) ? $result : true;
    }

    /**
     * Requests to open a Space not yet decided: from people who asked on
     * its private page. Only `pending` ones have a verified email;
     * `verification_pending` ones haven't confirmed theirs yet.
     *
     * @return list<array{id: string, space_id: string, email: string, name: string, message: string, status: string, verified: bool, created_at: string}>|WP_Error
     */
    public function accessRequests(string $spaceId): array|WP_Error {
        $response = $this->spaceRequest('GET', $spaceId, '/access-requests');

        if ($response instanceof WP_Error) {
            return $response;
        }

        $requests = [];

        foreach ((array) ($response['data'] ?? []) as $request) {
            if (is_array($request) && isset($request['id'], $request['email'])) {
                $requests[] = self::accessRequest($request, $spaceId);
            }
        }

        return $requests;
    }

    /**
     * Approves a request: the person is added to the Space's people, as a
     * viewer of the live page whatever they asked for, and Spacefast
     * emails them.
     */
    public function approveAccessRequest(string $spaceId, string $requestId): array|WP_Error {
        $response = $this->spaceRequest('POST', $spaceId, '/access-requests/' . rawurlencode($requestId) . '/approve', ['role' => 'viewer']);

        return $response instanceof WP_Error ? $response : self::accessRequest((array) ($response['data'] ?? []), $spaceId);
    }

    public function denyAccessRequest(string $spaceId, string $requestId): array|WP_Error {
        $response = $this->spaceRequest('POST', $spaceId, '/access-requests/' . rawurlencode($requestId) . '/deny');

        return $response instanceof WP_Error ? $response : self::accessRequest((array) ($response['data'] ?? []), $spaceId);
    }

    /**
     * The people let into a Space one by one (approved requests,
     * invitations), by lowercase email: [email => grant ID].
     *
     * @return array<string, string>|WP_Error
     */
    public function people(string $spaceId): array|WP_Error {
        $response = $this->spaceRequest('GET', $spaceId, '/access?audience=person');

        if ($response instanceof WP_Error) {
            return $response;
        }

        $people = [];

        foreach ((array) ($response['data'] ?? []) as $grant) {
            $email = is_array($grant) ? (string) ($grant['subject']['email'] ?? '') : '';

            if ('' !== $email && isset($grant['id'])) {
                $people[strtolower($email)] = (string) $grant['id'];
            }
        }

        return $people;
    }

    /**
     * Takes one way in away (a person's grant); their sessions end with
     * it. One already gone counts as removed.
     */
    public function removeAccess(string $spaceId, string $grantId): true|WP_Error {
        if (1 !== preg_match('/^grt_[A-Za-z0-9]+$/', $grantId)) {
            return new WP_Error('pofsf_spacefast_grant', __('Invalid access ID.', 'personalized-offers-for-spacefast'));
        }

        $result = $this->spaceRequest('DELETE', $spaceId, '/access/' . $grantId);

        return $result instanceof WP_Error && 404 !== ($result->get_error_data()['status'] ?? 0) ? $result : true;
    }

    /**
     * Removes everyone let into a Space one by one, e.g. before it is
     * given to another offer.
     */
    public function removePeople(string $spaceId): true|WP_Error {
        $people = $this->people($spaceId);

        if ($people instanceof WP_Error) {
            return $people;
        }

        foreach ($people as $grantId) {
            $removed = $this->removeAccess($spaceId, $grantId);

            if ($removed instanceof WP_Error) {
                return $removed;
            }
        }

        return true;
    }

    /**
     * @return array{id: string, space_id: string, email: string, name: string, message: string, status: string, verified: bool, created_at: string}
     */
    private static function accessRequest(array $data, string $spaceId): array {
        return [
            'id' => (string) ($data['id'] ?? ''),
            'space_id' => (string) ($data['spaceId'] ?? $spaceId),
            'email' => strtolower((string) ($data['email'] ?? '')),
            'name' => (string) ($data['displayName'] ?? ''),
            'message' => (string) ($data['message'] ?? ''),
            'status' => (string) ($data['status'] ?? ''),
            'verified' => !empty($data['emailVerified']),
            'created_at' => (string) ($data['createdAt'] ?? ''),
        ];
    }

    /**
     * Ends every visitor session on the Space, so people who opened a
     * revoked link can't keep browsing it; links still valid let them back in.
     */
    public function logoutAll(string $spaceId): true|WP_Error {
        $result = $this->spaceRequest('POST', $spaceId, '/sharing/logout-all');

        return $result instanceof WP_Error ? $result : true;
    }

    /**
     * A Space's traffic over the last 48h, 7d or 30d (the longest Spacefast
     * keeps): page views of its offer page (`/`, not the images and scripts
     * also counted as views) and visitors.
     *
     * @return array{views: int, visitors: int}|WP_Error
     */
    public function analytics(string $spaceId, string $window = '30d'): array|WP_Error {
        // Spacefast's analytics can take 20 s or more.
        $response = $this->spaceRequest('GET', $spaceId, '/analytics?window=' . (in_array($window, ['48h', '7d', '30d'], true) ? $window : '30d'), null, 45);

        if ($response instanceof WP_Error) {
            return $response;
        }

        $views = 0;
        $visitors = 0;

        foreach ((array) ($response['data']['topPaths'] ?? []) as $path) {
            if (is_array($path) && in_array($path['path'] ?? '', ['/', '/index.html'], true)) {
                $views += (int) ($path['views'] ?? 0);
            }
        }

        foreach ((array) ($response['data']['visitorsByDay'] ?? []) as $day) {
            $visitors += is_array($day) ? (int) ($day['visitors'] ?? 0) : 0;
        }

        return ['views' => $views, 'visitors' => $visitors];
    }

    /**
     * How often each of a Space's share links was opened, revoked ones too.
     *
     * @return array<string, array{opens: int, last_opened: string}>|WP_Error By link ID.
     */
    public function shareLinkOpens(string $spaceId): array|WP_Error {
        $response = $this->spaceRequest('GET', $spaceId, '/share-links?limit=100');

        if ($response instanceof WP_Error) {
            return $response;
        }

        $opens = [];

        foreach ((array) ($response['data'] ?? []) as $link) {
            if (is_array($link) && isset($link['id'])) {
                $opens[(string) $link['id']] = [
                    'opens' => (int) ($link['openCount'] ?? 0),
                    'last_opened' => (string) ($link['lastUsedAt'] ?? ''),
                ];
            }
        }

        return $opens;
    }

    private function spaceRequest(string $method, string $spaceId, string $path, ?array $body = null, int $timeout = 30): array|WP_Error {
        if (1 !== preg_match('/^[A-Za-z0-9_-]+$/', $spaceId)) {
            return new WP_Error('pofsf_spacefast_space', __('Invalid Space ID.', 'personalized-offers-for-spacefast'));
        }

        if (!$this->status()['connected']) {
            return new WP_Error('pofsf_spacefast_disconnected', __('Connect a Spacefast account first.', 'personalized-offers-for-spacefast'));
        }

        $headers = 'POST' === $method ? ['Idempotency-Key' => wp_generate_uuid4()] : [];

        return $this->request($method, '/v1/spaces/' . $spaceId . $path, (null === $body ? ['headers' => $headers] : [
            'headers' => $headers + ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($body),
        ]) + ['timeout' => $timeout]);
    }

    /**
     * Follows a pending publish's poll link once more.
     */
    public function poll(array $state): array|WP_Error {
        if ('' === ($state['poll_url'] ?? '')) {
            return $state;
        }

        $response = $this->request('GET', (string) $state['poll_url']);

        if ($response instanceof WP_Error) {
            return $response;
        }

        return $this->settle($this->merge($state, $response), 0);
    }

    /**
     * Follows `next` links until the publish settles or the time budget runs out.
     */
    private function settle(array $state, int $budget = self::SETTLE_BUDGET): array|WP_Error {
        $deadline = time() + $budget;

        while ($state['pending']) {
            if ('' !== $state['error']) {
                return new WP_Error('pofsf_spacefast_publish', $state['error']);
            }

            $next = $state['next'];
            $url = (string) ($next['url'] ?? '');

            if ('finalize' === ($next['action'] ?? '') && '' !== $url) {
                $response = $this->request('POST', $url);
            } elseif ('poll' === ($next['action'] ?? '') && '' !== $url) {
                $wait = max(1, min(10, (int) ($next['retryAfter'] ?? 2)));

                if (time() + $wait > $deadline) {
                    break;
                }

                sleep($wait);
                $response = $this->request('GET', $url);
            } else {
                break;
            }

            if ($response instanceof WP_Error) {
                return $response;
            }

            $state = $this->merge($state, $response);
        }

        if ('' !== $state['error']) {
            return new WP_Error('pofsf_spacefast_publish', $state['error']);
        }

        $state['poll_url'] = $state['pending'] && 'poll' === ($state['next']['action'] ?? '') ? (string) $state['next']['url'] : '';

        return $state;
    }

    /**
     * Folds a receipt, build, operation or version response into the
     * running publish state.
     */
    private function merge(array $state, array $response): array {
        $state += ['space' => [], 'version' => [], 'access' => [], 'next' => [], 'pending' => false, 'poll_url' => '', 'diagnostics' => [], 'error' => ''];
        $data = is_array($response['data'] ?? null) ? $response['data'] : [];

        foreach (['space', 'version', 'access'] as $key) {
            if (is_array($data[$key] ?? null)) {
                $state[$key] = array_merge($state[$key], $data[$key]);
            }
        }

        // A finalize or version response is the version itself.
        if (isset($data['id'], $data['status']) && str_starts_with((string) $data['id'], 'ver_')) {
            $state['version'] = array_merge($state['version'], $data);
        }

        foreach ((array) ($data['diagnostics'] ?? []) as $diagnostic) {
            if (is_array($diagnostic) && isset($diagnostic['message'])) {
                $state['diagnostics'][] = (string) $diagnostic['message'];
            }
        }

        $statuses = array_filter([
            $data['build']['status'] ?? null,
            $data['status'] ?? null,
            $state['version']['status'] ?? null,
        ], 'is_string');

        if (array_intersect($statuses, ['failed', 'canceled', 'cancelled', 'error'])) {
            $state['error'] = (string) ($data['build']['error']['message'] ?? $data['error']['message'] ?? __('Spacefast reported that the publish failed.', 'personalized-offers-for-spacefast'));
        }

        $state['next'] = is_array($data['next'] ?? null) ? $data['next'] : [];
        $action = (string) ($state['next']['action'] ?? '');
        $state['pending'] = '' !== $action
            ? 'done' !== $action
            : !in_array($state['version']['status'] ?? '', ['ready', 'live'], true) && 'succeeded' !== ($data['status'] ?? '');
        $state['diagnostics'] = array_values(array_unique($state['diagnostics']));

        return $state;
    }

    /**
     * Retries a request after a 429 or 503 (or an identical publish still
     * running, `idempotency_conflict_in_progress`) when Spacefast asks for
     * a short wait. Only for requests that are safe to repeat: GET, PUT,
     * DELETE, or a POST with an Idempotency-Key.
     */
    private const RETRIES = 2;

    /** Longest Retry-After waited for within a request, in seconds. */
    private const MAX_RETRY_WAIT = 10;

    private function request(string $method, string $path, array $args = [], ?string $key = null, int $hops = 0, int $tries = 0): array|WP_Error {
        $url = str_starts_with($path, 'https://') ? $path : $this->apiUrl() . '/' . ltrim($path, '/');
        $endpoint = $method . ' ' . (string) wp_parse_url($url, PHP_URL_PATH);

        // Never send the key to another host, even if a response links there.
        if (!str_starts_with($url, $this->apiUrl() . '/')) {
            return new WP_Error('pofsf_spacefast_url', sprintf(
                /* translators: %s: URL returned by Spacefast. */
                __('Unexpected Spacefast API link: %s', 'personalized-offers-for-spacefast'),
                esc_url_raw($url),
            ));
        }

        $key = trim($key ?? $this->apiKey());

        if ('' === $key) {
            return new WP_Error('pofsf_spacefast_key_missing', __('No Spacefast API key is stored. Disconnect and connect again.', 'personalized-offers-for-spacefast'));
        }

        $response = wp_remote_request($url, array_merge([
            'method' => $method,
            'timeout' => 30,
        ], $args, [
            // Redirects are followed below, so the key is re-sent only to the API host.
            'redirection' => 0,
            'headers' => array_merge([
                'Authorization' => 'Bearer ' . $key,
                'Accept' => 'application/json',
                'x-spacefast-client' => self::CLIENT_HEADER,
            ], $args['headers'] ?? []),
        ]));

        if (is_wp_error($response)) {
            return new WP_Error($response->get_error_code(), sprintf(
                /* translators: 1: HTTP method and path, 2: error message. */
                __('Spacefast request %1$s failed: %2$s', 'personalized-offers-for-spacefast'),
                $endpoint,
                $response->get_error_message(),
            ));
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $location = (string) wp_remote_retrieve_header($response, 'location');

        if ($code >= 300 && $code < 400 && '' !== $location && $hops < 3) {
            $next = str_starts_with($location, '/') ? $this->apiUrl() . $location : $location;
            $method = in_array($code, [307, 308], true) ? $method : 'GET';

            return $this->request($method, $next, 'GET' === $method ? array_diff_key($args, ['body' => 1]) : $args, $key, $hops + 1, $tries);
        }

        $decoded = json_decode((string) wp_remote_retrieve_body($response), true);
        $decoded = is_array($decoded) ? $decoded : [];

        $problem = is_string($decoded['code'] ?? null) ? $decoded['code'] : '';
        $retryAfter = $code >= 400 ? self::retryAfter((string) wp_remote_retrieve_header($response, 'retry-after')) : 0;
        $busy = in_array($code, [429, 503], true) || 'idempotency_conflict_in_progress' === $problem;
        $repeatable = in_array($method, ['GET', 'HEAD', 'PUT', 'DELETE'], true) || isset($args['headers']['Idempotency-Key']);

        if ($busy && $repeatable && $tries < self::RETRIES && $retryAfter <= self::MAX_RETRY_WAIT) {
            sleep(max(1, $retryAfter));

            return $this->request($method, $url, $args, $key, $hops, $tries + 1);
        }

        if ($code >= 400) {
            $message = $decoded['detail'] ?? $decoded['error']['message'] ?? $decoded['title'] ?? $decoded['message'] ?? '';
            $message = is_string($message) && '' !== $message ? $message : __('Unknown error', 'personalized-offers-for-spacefast');
            $requestId = (string) ($decoded['requestId'] ?? wp_remote_retrieve_header($response, 'x-request-id'));

            if ($busy && $retryAfter > 0) {
                /* translators: %d: seconds to wait. */
                $message .= ' ' . sprintf(_n('Try again in %d second.', 'Try again in %d seconds.', $retryAfter, 'personalized-offers-for-spacefast'), $retryAfter);
            }

            if (401 === $code) {
                /* translators: %s: masked API key, e.g. "sfa_…NaUf (60 chars)". */
                $message .= ' ' . sprintf(__('(key sent: %s)', 'personalized-offers-for-spacefast'), self::mask($key));
            }

            $error = sprintf(
                /* translators: 1: HTTP status code, 2: HTTP method and path, 3: error message from Spacefast. */
                __('Spacefast API error %1$d on %2$s: %3$s', 'personalized-offers-for-spacefast'),
                $code,
                $endpoint,
                $message,
            ) . ('' !== $requestId ? ' [request ' . sanitize_text_field($requestId) . ']' : '');

            (new Logger())->error($error);

            // `code` is Spacefast's stable problem code (e.g. rate_limited) to branch on.
            return new WP_Error('pofsf_spacefast_http', $error, ['status' => $code, 'code' => $problem, 'retry_after' => $retryAfter]);
        }

        return $decoded;
    }

    /**
     * Seconds from a Retry-After header (seconds or an HTTP date); 0 if absent.
     */
    private static function retryAfter(string $header): int {
        $header = trim($header);

        if ('' === $header) {
            return 0;
        }

        return max(0, ctype_digit($header) ? (int) $header : (int) strtotime($header) - time());
    }

    /**
     * Identifies a key in messages without revealing it.
     */
    private static function mask(string $key): string {
        $prefix = str_contains($key, '_') ? strstr($key, '_', true) . '_' : '';

        return $prefix . '…' . substr($key, -4) . ' (' . strlen($key) . ' chars)';
    }

    /**
     * @return array{api_key: string, team_id: string, team_name: string, team_slug: string}
     */
    private function connection(): array {
        $stored = get_option(self::OPTION, []);

        return wp_parse_args(is_array($stored) ? $stored : [], [
            'api_key' => '',
            'team_id' => '',
            'team_name' => '',
            'team_slug' => '',
        ]);
    }

    private function apiKey(): string {
        return $this->keyFromConstant() ? (string) constant('POFSF_SPACEFAST_API_KEY') : (string) $this->connection()['api_key'];
    }

    private function keyFromConstant(): bool {
        return defined('POFSF_SPACEFAST_API_KEY') && '' !== (string) constant('POFSF_SPACEFAST_API_KEY');
    }

    private function keyHint(): string {
        $key = $this->apiKey();

        return strlen($key) > 8 ? '…' . substr($key, -4) : '';
    }
}
