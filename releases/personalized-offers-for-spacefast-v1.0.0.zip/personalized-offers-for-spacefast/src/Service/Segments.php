<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Repository\CustomerProfileRepository;
use Micemade\PersonalizedOffers\Repository\SegmentRepository;
use WP_Error;

/**
 * Customer segments: rules over the stored profiles, so members follow the
 * profiles as they change (nothing about members is stored). Built-in
 * segments are the buying patterns (CustomerProfiles::segmentOf()); the
 * store saves its own from favourite categories, sizes, colours and other
 * attributes, price band, orders and spending. All rule-based: no AI.
 *
 * A segment's shared preferences (what most of its members like) give the
 * suggested products for a group offer to the segment.
 */
final class Segments {
    public const BANDS = ['budget', 'mid', 'premium'];

    /** Most customers looked at for one segment. */
    private const MAX_SCAN = 20000;

    private const BATCH = 500;

    /** Customers match a category among their top this many favourites. */
    private const TOP_CATEGORIES = 5;

    private const OVERVIEW_TRANSIENT = 'pofsf_segment_overview';

    private const MAX_CATEGORIES = 20;
    private const MAX_ATTRIBUTES = 10;
    private const MAX_VALUES = 20;

    public function __construct(
        private readonly CustomerProfileRepository $profiles,
        private readonly SegmentRepository $segments = new SegmentRepository(),
        private readonly ShortlistBuilder $shortlists = new ShortlistBuilder(),
    ) {}

    public function register(): void {
        // Member counts follow the profiles.
        add_action('pofsf_customer_profile_changed', [$this, 'forgetCounts']);
    }

    public function profiles(): CustomerProfileRepository {
        return $this->profiles;
    }

    public function forgetCounts(): void {
        delete_transient(self::OVERVIEW_TRANSIENT);
    }

    /**
     * The buying-pattern segments every store has.
     *
     * @return array<string, array{name: string, description: string}>
     */
    public static function builtIn(): array {
        return [
            'loyal' => [
                'name' => __('Best customers', 'personalized-offers-for-spacefast'),
                'description' => __('4 or more orders, the last one within 4 months.', 'personalized-offers-for-spacefast'),
            ],
            'active' => [
                'name' => __('Active customers', 'personalized-offers-for-spacefast'),
                'description' => __('Buying regularly, not yet among the best customers.', 'personalized-offers-for-spacefast'),
            ],
            'new' => [
                'name' => __('New customers', 'personalized-offers-for-spacefast'),
                'description' => __('Their first order, within the last 60 days.', 'personalized-offers-for-spacefast'),
            ],
            'at_risk' => [
                'name' => __('At risk', 'personalized-offers-for-spacefast'),
                'description' => __('Well past their usual time between orders.', 'personalized-offers-for-spacefast'),
            ],
            'lapsed' => [
                'name' => __('Lapsed', 'personalized-offers-for-spacefast'),
                'description' => __('No order for over a year.', 'personalized-offers-for-spacefast'),
            ],
        ];
    }

    /**
     * All segments, built-in first, with member counts.
     *
     * @return list<array{id: string, name: string, description: string, built_in: bool, rules: array, members: int, accounts: int}>
     */
    public function all(): array {
        $counts = $this->overview()['counts'];
        $out = [];

        foreach ([...$this->builtInSegments(), ...array_map([$this, 'fromRow'], $this->segments->all())] as $segment) {
            $out[] = $segment + ($counts[$segment['id']] ?? ['members' => 0, 'accounts' => 0]);
        }

        return $out;
    }

    /**
     * Segments worth saving, from what many customers share: favourite
     * categories, attribute values and price bands not saved yet.
     *
     * @return list<array{name: string, description: string, rules: array, members: int}>
     */
    public function suggestions(): array {
        return $this->overview()['suggestions'];
    }

    /**
     * A segment by ID: a built-in key ('loyal') or a saved segment's number.
     */
    public function find(string $id): ?array {
        $builtIn = self::builtIn();

        if (isset($builtIn[$id])) {
            return $this->builtInSegments()[array_search($id, array_keys($builtIn), true)];
        }

        $row = ctype_digit($id) ? $this->segments->find((int) $id) : null;

        return null !== $row ? $this->fromRow($row) : null;
    }

    /**
     * Saves a segment (a new one without $id).
     *
     * @param array{name?: string, description?: string, rules?: array} $input
     */
    public function save(array $input, int $id = 0, int $byUserId = 0): array|WP_Error {
        if ($id > 0 && null === $this->segments->find($id)) {
            return new WP_Error('segment_not_found', __('Segment not found.', 'personalized-offers-for-spacefast'));
        }

        $name = mb_substr(trim(sanitize_text_field((string) ($input['name'] ?? ''))), 0, 100);

        if ('' === $name) {
            return new WP_Error('segment_name_empty', __('Give the segment a name.', 'personalized-offers-for-spacefast'));
        }

        $rules = self::sanitizeRules((array) ($input['rules'] ?? []));

        if ([] === $rules) {
            return new WP_Error('segment_no_rules', __('Add at least one rule: who belongs in this segment?', 'personalized-offers-for-spacefast'));
        }

        $data = [
            'name' => $name,
            'description' => mb_substr(trim(sanitize_textarea_field((string) ($input['description'] ?? ''))), 0, 500),
            'rules' => $rules,
        ];

        if ($id > 0) {
            $this->segments->update($id, $data);
        } else {
            $id = $this->segments->create($data + ['created_by' => $byUserId]);

            if ($id <= 0) {
                return new WP_Error('segment_not_saved', __('The segment could not be saved.', 'personalized-offers-for-spacefast'));
            }
        }

        $this->forgetCounts();

        return (array) $this->find((string) $id);
    }

    public function delete(string $id): bool|WP_Error {
        if (!ctype_digit($id) || null === $this->segments->find((int) $id)) {
            return new WP_Error('segment_not_found', isset(self::builtIn()[$id])
                ? __('Built-in segments cannot be deleted.', 'personalized-offers-for-spacefast')
                : __('Segment not found.', 'personalized-offers-for-spacefast'));
        }

        $this->segments->delete((int) $id);
        $this->forgetCounts();

        return true;
    }

    /**
     * Rules as stored: only known keys and existing categories and
     * attribute values; empty rules left out.
     */
    public static function sanitizeRules(array $rules): array {
        $out = [];

        $buying = array_values(array_intersect(array_map('strval', (array) ($rules['buying'] ?? [])), array_keys(CustomerProfiles::segments())));

        if ([] !== $buying) {
            $out['buying'] = $buying;
        }

        $categories = [];

        foreach (array_slice(array_values(array_unique(array_map('intval', (array) ($rules['categories'] ?? [])))), 0, self::MAX_CATEGORIES) as $categoryId) {
            if ($categoryId > 0 && get_term($categoryId, 'product_cat') instanceof \WP_Term) {
                $categories[] = $categoryId;
            }
        }

        if ([] !== $categories) {
            $out['categories'] = $categories;
        }

        $attributes = [];

        foreach (array_slice((array) ($rules['attributes'] ?? []), 0, self::MAX_ATTRIBUTES, true) as $taxonomy => $values) {
            $taxonomy = sanitize_key((string) $taxonomy);
            $values = array_slice(array_values(array_unique(array_filter(array_map(static fn ($v): string => sanitize_title((string) $v), (array) $values)))), 0, self::MAX_VALUES);

            if (str_starts_with($taxonomy, 'pa_') && taxonomy_exists($taxonomy) && [] !== $values) {
                $attributes[$taxonomy] = $values;
            }
        }

        if ([] !== $attributes) {
            $out['attributes'] = $attributes;
        }

        $bands = array_values(array_intersect(self::BANDS, array_map('strval', (array) ($rules['price_bands'] ?? []))));

        if ([] !== $bands) {
            $out['price_bands'] = $bands;
        }

        foreach (['min_orders' => 1000, 'ordered_within_days' => 3650, 'not_ordered_for_days' => 3650] as $key => $max) {
            $value = min($max, max(0, (int) ($rules[$key] ?? 0)));

            if ($value > 0) {
                $out[$key] = $value;
            }
        }

        $spent = round(max(0.0, (float) ($rules['min_spent'] ?? 0)), 2);

        if ($spent > 0) {
            $out['min_spent'] = $spent;
        }

        if (!empty($rules['accounts_only'])) {
            $out['accounts_only'] = true;
        }

        return $out;
    }

    /**
     * The rules in words, for lists and the assistant.
     *
     * @return list<string>
     */
    public static function describe(array $rules): array {
        $out = [];
        $labels = CustomerProfiles::segments();

        if (!empty($rules['buying'])) {
            /* translators: %s: buying patterns, e.g. "Loyal or Active". */
            $out[] = sprintf(__('Buying pattern: %s', 'personalized-offers-for-spacefast'), implode(' / ', array_map(static fn (string $k): string => $labels[$k] ?? $k, $rules['buying'])));
        }

        if (!empty($rules['categories'])) {
            $names = array_map(static fn (int $id): string => html_entity_decode((string) get_term_field('name', $id, 'product_cat'), ENT_QUOTES), $rules['categories']);
            /* translators: %s: category names. */
            $out[] = sprintf(__('Likes %s', 'personalized-offers-for-spacefast'), implode(' / ', $names));
        }

        foreach ((array) ($rules['attributes'] ?? []) as $taxonomy => $values) {
            $names = array_map(static function (string $slug) use ($taxonomy): string {
                $term = get_term_by('slug', $slug, (string) $taxonomy);

                if ($term instanceof \WP_Term) {
                    return html_entity_decode($term->name, ENT_QUOTES);
                }

                // A value written on products by hand, not a term: short ones are sizes (XL), others words.
                return mb_strlen($slug) <= 3 ? mb_strtoupper($slug) : mb_convert_case(str_replace('-', ' ', $slug), MB_CASE_TITLE);
            }, $values);
            $out[] = ProfileBuilder::attributeLabel((string) $taxonomy) . ': ' . implode(' / ', $names);
        }

        if (!empty($rules['price_bands'])) {
            $bands = ['budget' => __('Budget', 'personalized-offers-for-spacefast'), 'mid' => __('Mid-range', 'personalized-offers-for-spacefast'), 'premium' => __('Premium', 'personalized-offers-for-spacefast')];
            /* translators: %s: price bands. */
            $out[] = sprintf(__('Price band: %s', 'personalized-offers-for-spacefast'), implode(' / ', array_map(static fn (string $b): string => $bands[$b], $rules['price_bands'])));
        }

        if (!empty($rules['min_orders'])) {
            /* translators: %d: number of orders. */
            $out[] = sprintf(_n('At least %d order', 'At least %d orders', (int) $rules['min_orders'], 'personalized-offers-for-spacefast'), (int) $rules['min_orders']);
        }

        if (!empty($rules['min_spent'])) {
            /* translators: %s: amount. */
            $out[] = sprintf(__('Spent at least %s', 'personalized-offers-for-spacefast'), html_entity_decode(wp_strip_all_tags(wc_price((float) $rules['min_spent'])), ENT_QUOTES));
        }

        if (!empty($rules['ordered_within_days'])) {
            /* translators: %d: days. */
            $out[] = sprintf(_n('Ordered in the last %d day', 'Ordered in the last %d days', (int) $rules['ordered_within_days'], 'personalized-offers-for-spacefast'), (int) $rules['ordered_within_days']);
        }

        if (!empty($rules['not_ordered_for_days'])) {
            /* translators: %d: days. */
            $out[] = sprintf(_n('No order for %d day', 'No order for %d days', (int) $rules['not_ordered_for_days'], 'personalized-offers-for-spacefast'), (int) $rules['not_ordered_for_days']);
        }

        if (!empty($rules['accounts_only'])) {
            $out[] = __('Customers with an account', 'personalized-offers-for-spacefast');
        }

        return $out;
    }

    /**
     * The members of a segment (or of unsaved rules), most spent first,
     * with what they share.
     *
     * @return array{total: int, accounts: int, keys: list<string>, recipients: list<array{id: int, name: string, email: string}>, shared: array}
     */
    public function members(array $rules, int $maxRecipients = OfferEditor::MAX_RECIPIENTS): array {
        $matches = [];
        $context = $this->context($rules);

        $this->scan(self::columnFilters($rules), function (array $row, array $profile) use ($rules, $context, &$matches): void {
            if (self::matches($row, $profile, $rules, $context)) {
                $matches[] = ['row' => $row] + self::traits($profile);
            }
        });

        usort($matches, static fn (array $a, array $b): int => [(float) $b['row']['total_spent'], $a['row']['id']] <=> [(float) $a['row']['total_spent'], $b['row']['id']]);

        $recipients = [];

        foreach ($matches as $match) {
            if ((int) $match['row']['user_id'] > 0 && '' !== (string) $match['row']['email'] && count($recipients) < $maxRecipients) {
                $recipients[] = ['id' => (int) $match['row']['user_id'], 'name' => (string) ($match['row']['name'] ?: $match['row']['email']), 'email' => (string) $match['row']['email']];
            }
        }

        return [
            'total' => count($matches),
            'accounts' => count(array_filter($matches, static fn (array $m): bool => (int) $m['row']['user_id'] > 0)),
            'keys' => array_map(static fn (array $m): string => (string) $m['row']['customer_key'], $matches),
            'recipients' => $recipients,
            'shared' => self::shared($matches),
        ];
    }

    /**
     * Products for a group offer to the segment: from the categories and
     * attribute values its rules name, then what most members share; best
     * sellers first.
     *
     * @return list<int>
     */
    public function suggestedProducts(array $rules, ?array $shared = null): array {
        $shared ??= $this->members($rules)['shared'];
        $categories = [];

        foreach ((array) ($rules['categories'] ?? []) as $id) {
            $categories[(int) $id] = ['id' => (int) $id, 'weight' => PHP_INT_MAX];
        }

        foreach (array_slice((array) $shared['categories'], 0, 4) as $category) {
            $categories[(int) $category['id']] ??= ['id' => (int) $category['id'], 'weight' => (int) $category['members']];
        }

        $preferred = [];

        foreach ((array) ($rules['attributes'] ?? []) as $taxonomy => $slugs) {
            foreach ($slugs as $slug) {
                $term = get_term_by('slug', $slug, (string) $taxonomy);
                $preferred[(string) $taxonomy][] = $term instanceof \WP_Term ? html_entity_decode($term->name, ENT_QUOTES) : $slug;
            }
        }

        foreach ((array) $shared['attributes'] as $attribute) {
            if (!isset($preferred[$attribute['key']])) {
                $preferred[$attribute['key']] = array_column(array_slice($attribute['values'], 0, 2), 'name');
            }
        }

        $items = $this->shortlists->build([
            'is_registered' => true,
            'preferred_categories' => array_values($categories),
            'preferred_attributes' => $preferred,
        ]);

        return array_slice(array_map(static fn (array $item): int => (int) $item['product_id'], $items), 0, 30);
    }

    /**
     * Member counts of every segment and suggestions, from one pass over
     * the profiles; kept until a profile or segment changes.
     *
     * @return array{counts: array<string, array{members: int, accounts: int}>, suggestions: list<array>}
     */
    private function overview(): array {
        $cached = get_transient(self::OVERVIEW_TRANSIENT);

        if (is_array($cached) && isset($cached['counts'], $cached['suggestions'])) {
            return $cached;
        }

        $saved = array_map([$this, 'fromRow'], $this->segments->all());
        $contexts = [];

        foreach ($saved as $segment) {
            $contexts[$segment['id']] = $this->context($segment['rules']);
        }

        $counts = [];
        $tally = ['categories' => [], 'attributes' => [], 'bands' => []];
        $cutoffs = [];

        foreach ($saved as $segment) {
            $cutoffs[$segment['id']] = self::columnFilters($segment['rules']);
        }

        $this->scan([], function (array $row, array $profile) use ($saved, $contexts, $cutoffs, &$counts, &$tally): void {
            $account = (int) $row['user_id'] > 0 ? 1 : 0;
            $segment = (string) $row['segment'];

            if (isset(self::builtIn()[$segment])) {
                $counts[$segment]['members'] = ($counts[$segment]['members'] ?? 0) + 1;
                $counts[$segment]['accounts'] = ($counts[$segment]['accounts'] ?? 0) + $account;
            }

            foreach ($saved as $custom) {
                if (self::passesColumns($row, $cutoffs[$custom['id']]) && self::matches($row, $profile, $custom['rules'], $contexts[$custom['id']])) {
                    $counts[$custom['id']]['members'] = ($counts[$custom['id']]['members'] ?? 0) + 1;
                    $counts[$custom['id']]['accounts'] = ($counts[$custom['id']]['accounts'] ?? 0) + $account;
                }
            }

            if ((int) $row['order_count'] > 0) {
                $traits = self::traits($profile);

                foreach ($traits['categories'] as $id => $name) {
                    $tally['categories'][$id] = ['name' => $name, 'n' => ($tally['categories'][$id]['n'] ?? 0) + 1];
                }

                foreach ($traits['attributes'] as $key => $values) {
                    foreach ($values as $slug => $name) {
                        if (str_starts_with((string) $key, 'pa_')) {
                            $tally['attributes'][$key . '|' . $slug] = ['key' => $key, 'slug' => $slug, 'name' => $name, 'n' => ($tally['attributes'][$key . '|' . $slug]['n'] ?? 0) + 1];
                        }
                    }
                }

                if ('' !== $traits['band']) {
                    $tally['bands'][$traits['band']] = ($tally['bands'][$traits['band']] ?? 0) + 1;
                }
            }
        });

        $overview = ['counts' => $counts, 'suggestions' => $this->suggestFrom($tally, array_column($saved, 'rules'))];
        set_transient(self::OVERVIEW_TRANSIENT, $overview, HOUR_IN_SECONDS);

        return $overview;
    }

    /**
     * @param list<array> $savedRules Rules already saved, not suggested again.
     */
    private function suggestFrom(array $tally, array $savedRules): array {
        $byCount = static fn (array $a, array $b): int => $b['n'] <=> $a['n'];
        $out = [];

        uasort($tally['categories'], $byCount);

        foreach (array_slice($tally['categories'], 0, 3, true) as $id => $category) {
            if ($category['n'] >= 2) {
                $out[] = [
                    /* translators: %s: category name. */
                    'name' => sprintf(__('Likes %s', 'personalized-offers-for-spacefast'), $category['name']),
                    'rules' => ['categories' => [(int) $id]],
                    'members' => $category['n'],
                ];
            }
        }

        usort($tally['attributes'], $byCount);

        foreach (array_slice($tally['attributes'], 0, 3) as $value) {
            if ($value['n'] >= 2) {
                $out[] = [
                    'name' => ProfileBuilder::attributeLabel((string) $value['key']) . ': ' . $value['name'],
                    'rules' => ['attributes' => [$value['key'] => [$value['slug']]]],
                    'members' => $value['n'],
                ];
            }
        }

        foreach (['premium' => __('Premium shoppers', 'personalized-offers-for-spacefast'), 'budget' => __('Bargain hunters', 'personalized-offers-for-spacefast')] as $band => $name) {
            if (($tally['bands'][$band] ?? 0) >= 2) {
                $out[] = ['name' => $name, 'rules' => ['price_bands' => [$band]], 'members' => $tally['bands'][$band]];
            }
        }

        $out = array_values(array_filter($out, static fn (array $s): bool => !in_array($s['rules'], $savedRules, false)));

        return array_map(static fn (array $s): array => $s + ['description' => implode(' · ', self::describe($s['rules']))], array_slice($out, 0, 6));
    }

    /**
     * Calls $visit with each profile row that passes the column filters
     * and its effective profile, in batches.
     */
    private function scan(array $filters, callable $visit): void {
        $afterId = 0;
        $seen = 0;

        do {
            $rows = $this->profiles->batch($filters, $afterId, self::BATCH);

            foreach ($rows as $row) {
                $visit($row, CustomerProfiles::effective($row));
                $afterId = (int) $row['id'];
            }

            $seen += count($rows);
        } while (count($rows) === self::BATCH && $seen < self::MAX_SCAN);
    }

    /**
     * The rules the profiles table can check itself.
     */
    private static function columnFilters(array $rules): array {
        return array_filter([
            'segments' => (array) ($rules['buying'] ?? []),
            'min_orders' => (int) ($rules['min_orders'] ?? 0),
            'min_spent' => (float) ($rules['min_spent'] ?? 0),
            'ordered_since' => !empty($rules['ordered_within_days']) ? wp_date('Y-m-d', time() - (int) $rules['ordered_within_days'] * DAY_IN_SECONDS) : '',
            'not_ordered_since' => !empty($rules['not_ordered_for_days']) ? wp_date('Y-m-d', time() - (int) $rules['not_ordered_for_days'] * DAY_IN_SECONDS) : '',
            'accounts_only' => !empty($rules['accounts_only']),
        ]);
    }

    /**
     * The same checks as columnFilters(), on a row already read.
     */
    private static function passesColumns(array $row, array $filters): bool {
        $last = (string) ($row['last_order_at'] ?? '');

        return match (true) {
            [] !== (array) ($filters['segments'] ?? []) && !in_array((string) $row['segment'], $filters['segments'], true) => false,
            (int) $row['order_count'] < (int) ($filters['min_orders'] ?? 0) => false,
            (float) $row['total_spent'] < (float) ($filters['min_spent'] ?? 0) => false,
            isset($filters['ordered_since']) && ('' === $last || $last < $filters['ordered_since']) => false,
            isset($filters['not_ordered_since']) && '' !== $last && $last >= $filters['not_ordered_since'] => false,
            !empty($filters['accounts_only']) && (int) $row['user_id'] <= 0 => false,
            default => true,
        };
    }

    /**
     * What matching needs, worked out once per segment: each rule
     * category with its subcategories.
     */
    private function context(array $rules): array {
        $categories = [];

        foreach ((array) ($rules['categories'] ?? []) as $id) {
            $children = get_term_children((int) $id, 'product_cat');
            $categories = [...$categories, (int) $id, ...(is_array($children) ? array_map('intval', $children) : [])];
        }

        return ['categories' => array_flip($categories)];
    }

    /**
     * Whether a profile meets the rules the table cannot check: favourite
     * categories, attribute values and price band. Within a rule any value
     * matches; every rule must.
     */
    private static function matches(array $row, array $profile, array $rules, array $context): bool {
        $traits = null;

        if (!empty($rules['categories'])) {
            $traits = self::traits($profile);

            if ([] === array_intersect_key($traits['categories'], $context['categories'])) {
                return false;
            }
        }

        foreach ((array) ($rules['attributes'] ?? []) as $taxonomy => $slugs) {
            $traits ??= self::traits($profile);
            $own = $traits['attributes'][$taxonomy] ?? $traits['attributes'][preg_replace('/^pa_/', '', (string) $taxonomy)] ?? [];

            if ([] === array_intersect(array_keys($own), $slugs)) {
                return false;
            }
        }

        if (!empty($rules['price_bands'])) {
            $traits ??= self::traits($profile);

            if (!in_array($traits['band'], $rules['price_bands'], true)) {
                return false;
            }
        }

        return true;
    }

    /**
     * What segments look at in an effective profile: the top favourite
     * categories, preferred attribute values (set ones, else the two most
     * bought) and price band.
     *
     * @return array{categories: array<int, string>, attributes: array<string, array<string, string>>, band: string, typical: float, buying: string}
     */
    private static function traits(array $profile): array {
        $categories = [];

        foreach (array_slice((array) ($profile['preferred_categories'] ?? []), 0, self::TOP_CATEGORIES) as $category) {
            $categories[(int) $category['id']] = (string) $category['name'];
        }

        $attributes = [];

        foreach ((array) ($profile['attributes'] ?? []) as $key => $attribute) {
            $values = (array) ($attribute['values'] ?? []);

            foreach (isset($attribute['set_by']) ? $values : array_slice($values, 0, 2) as $value) {
                $attributes[(string) $key][sanitize_title((string) ($value['value'] ?? $value['name'] ?? ''))] = (string) ($value['name'] ?? '');
            }
        }

        return [
            'categories' => $categories,
            'attributes' => $attributes,
            'band' => (string) ($profile['price_range']['band'] ?? ''),
            'typical' => (float) ($profile['price_range']['median'] ?? 0),
            'buying' => (string) ($profile['segment'] ?? ''),
        ];
    }

    /**
     * What a segment's members have in common.
     *
     * @param list<array{row: array, categories: array, attributes: array, band: string, typical: float, buying: string}> $matches
     */
    private static function shared(array $matches): array {
        $categories = [];
        $attributes = [];
        $bands = array_fill_keys(self::BANDS, 0);
        $buying = [];
        $typical = [];
        $spent = 0.0;
        $orders = 0;

        foreach ($matches as $match) {
            foreach ($match['categories'] as $id => $name) {
                $categories[$id] = ['id' => $id, 'name' => $name, 'members' => ($categories[$id]['members'] ?? 0) + 1];
            }

            foreach ($match['attributes'] as $key => $values) {
                foreach ($values as $slug => $name) {
                    $attributes[$key][$slug] = ['slug' => $slug, 'name' => $name, 'members' => ($attributes[$key][$slug]['members'] ?? 0) + 1];
                }
            }

            if (isset($bands[$match['band']])) {
                ++$bands[$match['band']];
            }

            if ('' !== $match['buying']) {
                $buying[$match['buying']] = ($buying[$match['buying']] ?? 0) + 1;
            }

            if ($match['typical'] > 0) {
                $typical[] = $match['typical'];
            }

            $spent += (float) $match['row']['total_spent'];
            $orders += (int) $match['row']['order_count'];
        }

        $byMembers = static fn (array $a, array $b): int => $b['members'] <=> $a['members'];
        usort($categories, $byMembers);

        // Attributes with a value at least two members (or a fifth of them) share.
        $sharedAttributes = [];
        $enough = max(2, (int) ceil(count($matches) / 5));

        foreach ($attributes as $key => $values) {
            usort($values, $byMembers);

            if ($values[0]['members'] >= min($enough, max(1, count($matches)))) {
                $sharedAttributes[] = ['key' => (string) $key, 'label' => ProfileBuilder::attributeLabel((string) $key), 'values' => array_slice($values, 0, 3)];
            }
        }

        usort($sharedAttributes, static fn (array $a, array $b): int => $b['values'][0]['members'] <=> $a['values'][0]['members']);
        sort($typical);
        arsort($buying);

        return [
            'categories' => array_slice($categories, 0, 6),
            'attributes' => array_slice($sharedAttributes, 0, 4),
            'bands' => $bands,
            'buying' => $buying,
            'typical_price' => [] !== $typical ? $typical[intdiv(count($typical), 2)] : 0.0,
            'total_spent' => $spent,
            'average_orders' => [] !== $matches ? round($orders / count($matches), 1) : 0.0,
        ];
    }

    private function builtInSegments(): array {
        $out = [];

        foreach (self::builtIn() as $key => $segment) {
            $out[] = ['id' => $key, 'built_in' => true, 'rules' => ['buying' => [$key]]] + $segment;
        }

        return $out;
    }

    private function fromRow(array $row): array {
        return [
            'id' => (string) $row['id'],
            'name' => (string) $row['name'],
            'description' => (string) $row['description'],
            'built_in' => false,
            'rules' => self::sanitizeRules((array) $row['rules']),
        ];
    }
}
