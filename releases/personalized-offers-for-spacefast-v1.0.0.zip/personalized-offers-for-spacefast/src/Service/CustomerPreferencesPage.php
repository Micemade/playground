<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

/**
 * My Account → My preferences (when the store turns it on): the customer
 * agrees to personalized offers and says what they like (categories,
 * sizes, colours and other attributes), and may allow their product
 * searches to be remembered. Saved in their stored profile.
 */
final class CustomerPreferencesPage {
    public const ENDPOINT = 'pofsf-preferences';

    private const NONCE = 'pofsf_save_preferences';
    private const FLUSH_OPTION = 'pofsf_flush_rewrite';

    /** Attributes with more values than this are left out of the form. */
    private const MAX_VALUES = 40;

    public function __construct(
        private readonly CustomerProfiles $profiles,
    ) {}

    public function register(): void {
        // A changed setting adds or removes the endpoint's rewrite rule on the next request.
        add_action('update_option_' . Settings::OPTION, static fn () => update_option(self::FLUSH_OPTION, 1, false));
        add_action('init', [$this, 'maybeFlush'], 99);

        if (!Settings::get('preferences_page')) {
            return;
        }

        add_filter('woocommerce_get_query_vars', [$this, 'queryVars']);
        add_filter('woocommerce_account_menu_items', [$this, 'menuItem']);
        add_filter('woocommerce_endpoint_' . self::ENDPOINT . '_title', [$this, 'title']);
        add_action('woocommerce_account_' . self::ENDPOINT . '_endpoint', [$this, 'render']);
        add_action('template_redirect', [$this, 'save']);

        if (Settings::get('record_searches')) {
            add_action('pre_get_posts', [$this, 'recordSearch']);
        }
    }

    public function maybeFlush(): void {
        if (get_option(self::FLUSH_OPTION)) {
            delete_option(self::FLUSH_OPTION);
            flush_rewrite_rules(false);
        }
    }

    public function queryVars(array $vars): array {
        $vars[self::ENDPOINT] = self::ENDPOINT;

        return $vars;
    }

    public function menuItem(array $items): array {
        $logout = isset($items['customer-logout']) ? ['customer-logout' => $items['customer-logout']] : [];
        unset($items['customer-logout']);

        return $items + [self::ENDPOINT => __('My preferences', 'personalized-offers-for-spacefast')] + $logout;
    }

    public function title(): string {
        return __('My preferences', 'personalized-offers-for-spacefast');
    }

    public function render(): void {
        $userId = get_current_user_id();
        $input = $this->profiles->customerInput($userId);
        $stated = (array) ($input['stated'] ?? []);
        $chosenCategories = array_map('intval', (array) ($stated['categories'] ?? []));
        $chosenAttributes = (array) ($stated['attributes'] ?? []);

        echo '<form method="post" class="pofsf-preferences woocommerce-EditAccountForm">';
        wp_nonce_field(self::NONCE, 'pofsf_preferences_nonce');
        echo '<p>' . esc_html__('Tell us what you like and we’ll put together offers that suit you. You can change this or withdraw your consent at any time.', 'personalized-offers-for-spacefast') . '</p>';

        printf(
            '<p class="form-row"><label class="woocommerce-form__label woocommerce-form__label-for-checkbox"><input type="checkbox" class="woocommerce-form__input-checkbox" name="pofsf_consent" value="1" %s> <span>%s</span></label></p>',
            checked(!empty($input['consent']), true, false),
            esc_html__('Yes, use my preferences and purchases to personalize offers for me.', 'personalized-offers-for-spacefast'),
        );

        $categories = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => true, 'parent' => 0, 'number' => 30, 'exclude' => [(int) get_option('default_product_cat')]]);

        if (is_array($categories) && [] !== $categories) {
            $this->group(
                __('Favourite categories', 'personalized-offers-for-spacefast'),
                'pofsf_categories[]',
                array_map(static fn (\WP_Term $t): array => [(string) $t->term_id, html_entity_decode($t->name, ENT_QUOTES)], $categories),
                array_map('strval', $chosenCategories),
            );
        }

        foreach (function_exists('wc_get_attribute_taxonomies') ? wc_get_attribute_taxonomies() : [] as $attribute) {
            $taxonomy = wc_attribute_taxonomy_name($attribute->attribute_name);
            $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => true, 'number' => self::MAX_VALUES + 1]);

            if (!is_array($terms) || [] === $terms || count($terms) > self::MAX_VALUES) {
                continue;
            }

            $this->group(
                (string) $attribute->attribute_label,
                'pofsf_attributes[' . $taxonomy . '][]',
                array_map(static fn (\WP_Term $t): array => [$t->slug, html_entity_decode($t->name, ENT_QUOTES)], $terms),
                array_map('strval', (array) ($chosenAttributes[$taxonomy] ?? [])),
            );
        }

        if (Settings::get('record_searches')) {
            printf(
                '<p class="form-row"><label class="woocommerce-form__label woocommerce-form__label-for-checkbox"><input type="checkbox" class="woocommerce-form__input-checkbox" name="pofsf_record_searches" value="1" %s> <span>%s</span></label></p>',
                checked(!empty($input['record_searches']), true, false),
                esc_html__('Remember what I search for in the shop, to suggest products I’m looking for.', 'personalized-offers-for-spacefast'),
            );
        }

        printf(
            '<p><button type="submit" class="woocommerce-Button button" name="pofsf_save_preferences" value="1">%s</button></p></form>',
            esc_html__('Save preferences', 'personalized-offers-for-spacefast'),
        );
    }

    /**
     * @param list<array{0: string, 1: string}> $options Value and label.
     * @param list<string> $checked
     */
    private function group(string $legend, string $name, array $options, array $checked): void {
        echo '<fieldset class="pofsf-preferences__group"><legend>' . esc_html($legend) . '</legend><p>';

        foreach ($options as [$value, $label]) {
            printf(
                '<label style="display:inline-block;margin:0 1em .4em 0"><input type="checkbox" name="%s" value="%s" %s> %s</label>',
                esc_attr($name),
                esc_attr($value),
                checked(in_array($value, $checked, true), true, false),
                esc_html($label),
            );
        }

        echo '</p></fieldset>';
    }

    public function save(): void {
        if (!isset($_POST['pofsf_save_preferences']) || !is_user_logged_in()) {
            return;
        }

        if (!wp_verify_nonce(sanitize_text_field(wp_unslash((string) ($_POST['pofsf_preferences_nonce'] ?? ''))), self::NONCE)) {
            wc_add_notice(__('Your session expired. Please try again.', 'personalized-offers-for-spacefast'), 'error');

            return;
        }

        $attributes = [];

        foreach ((array) wp_unslash($_POST['pofsf_attributes'] ?? []) as $taxonomy => $values) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized per value below and by CustomerProfiles::saveCustomerInput().
            $attributes[sanitize_key((string) $taxonomy)] = array_map('sanitize_title', (array) $values);
        }

        $consent = !empty($_POST['pofsf_consent']);
        $this->profiles->saveCustomerInput(get_current_user_id(), [
            'consent' => $consent,
            'record_searches' => !empty($_POST['pofsf_record_searches']),
            'categories' => array_map('intval', (array) wp_unslash($_POST['pofsf_categories'] ?? [])),
            'attributes' => $attributes,
        ]);

        wc_add_notice($consent
            ? __('Your preferences are saved.', 'personalized-offers-for-spacefast')
            : __('Saved. Without your consent we don’t keep your stated preferences or searches.', 'personalized-offers-for-spacefast'));
        wp_safe_redirect(wc_get_account_endpoint_url(self::ENDPOINT));
        exit;
    }

    /**
     * Remembers a shop search (product search, first page) for a customer
     * who allowed it.
     */
    public function recordSearch(\WP_Query $query): void {
        if (is_admin() || !$query->is_main_query() || !$query->is_search() || !is_user_logged_in() || (int) $query->get('paged') > 1) {
            return;
        }

        $postType = $query->get('post_type');

        if ('product' === $postType || (is_array($postType) && in_array('product', $postType, true))) {
            $this->profiles->recordSearch(get_current_user_id(), (string) $query->get('s'));
        }
    }
}
