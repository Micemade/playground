<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

final class TokenService {
    private const KEY_OPTION = 'pofsf_token_hmac_key';

    public function generate(): string {
        return bin2hex(random_bytes(16));
    }

    public function hash(string $token): string {
        return hash_hmac('sha256', $token, $this->key());
    }

    public function matches(string $token, string $hash): bool {
        return hash_equals($hash, $this->hash($token));
    }

    /**
     * Signature that marks an offer's checkout link as an admin preview, so
     * opening it does not count as a use. Only the server can make one.
     */
    public function previewSignature(string $token): string {
        return hash_hmac('sha256', 'preview:' . $token, $this->key());
    }

    public function isPreview(string $token, string $signature): bool {
        return '' !== $signature && hash_equals($this->previewSignature($token), $signature);
    }

    private function key(): string {
        $key = get_option(self::KEY_OPTION);

        if (!is_string($key) || '' === $key) {
            $key = bin2hex(random_bytes(32));
            update_option(self::KEY_OPTION, $key);
        }

        return $key;
    }
}
