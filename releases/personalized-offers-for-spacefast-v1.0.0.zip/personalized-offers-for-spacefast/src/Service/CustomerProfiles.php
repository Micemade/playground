<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Repository\CustomerProfileRepository;
use WP_Error;

/**
 * Stored customer profiles: built by ProfileBuilder, kept current when an
 * order is paid and by a nightly background job, corrected by the store
 * manager, and completed by what customers tell the store themselves
 * (My preferences, searches; with their consent). Offers are built from
 * the effective profile: the computed one with corrections and stated
 * preferences applied.
 */
final class CustomerProfiles {
    public const GROUP = 'pofsf-profiles';
    public const REFRESH_HOOK = 'pofsf_refresh_profile';
    public const NIGHTLY_HOOK = 'pofsf_refresh_profiles';
    public const BACKFILL_HOOK = 'pofsf_backfill_profiles';
    public const STALE_HOOK = 'pofsf_refresh_stale_profiles';

    private const BACKFILLED_OPTION = 'pofsf_profiles_backfilled';
    private const LAST_RUN_OPTION = 'pofsf_profiles_last_run';

    /** Profiles rebuilt per background run; more continue in another run. */
    private const BATCH = 50;

    /** A profile is rebuilt by the nightly job when older than this (recency changes). */
    private const MAX_AGE_DAYS = 7;

    private const MAX_SEARCHES = 30;

    public function __construct(
        private readonly ProfileBuilder $builder,
        private readonly CustomerProfileRepository $repository,
        private readonly Logger $log,
    ) {}

    public function register(): void {
        add_action('woocommerce_order_status_processing', [$this, 'onOrderPaid']);
        add_action('woocommerce_order_status_completed', [$this, 'onOrderPaid']);
        add_action(self::REFRESH_HOOK, [$this, 'refresh']);
        add_action(self::NIGHTLY_HOOK, [$this, 'runNightly']);
        add_action(self::BACKFILL_HOOK, [$this, 'backfill']);
        add_action(self::STALE_HOOK, [$this, 'refreshStale']);
        add_action('action_scheduler_init', [$this, 'scheduleNightly']);
        add_action('deleted_user', [$this, 'onUserDeleted']);
        add_action('profile_update', [$this, 'onUserUpdated']);
    }

    /** Segment keys and labels (rule-based, from how recently and often the customer buys). */
    public static function segments(): array {
        return [
            'new' => __('New', 'personalized-offers-for-spacefast'),
            'loyal' => __('Loyal', 'personalized-offers-for-spacefast'),
            'active' => __('Active', 'personalized-offers-for-spacefast'),
            'at_risk' => __('At risk', 'personalized-offers-for-spacefast'),
            'lapsed' => __('Lapsed', 'personalized-offers-for-spacefast'),
            'none' => __('No orders yet', 'personalized-offers-for-spacefast'),
        ];
    }

    public static function userKey(int $userId): string {
        return 'user:' . $userId;
    }

    public static function guestKey(string $email): string {
        return 'guest:' . strtolower(sanitize_email($email));
    }

    /**
     * The key of a customer given as a user ID or, for a guest, an email
     * (an email of an account means that account).
     */
    public static function keyFor(int $userId, string $email = ''): string {
        if ($userId > 0) {
            return self::userKey($userId);
        }

        $user = '' !== $email ? get_user_by('email', $email) : false;

        return $user ? self::userKey($user->ID) : self::guestKey($email);
    }

    /**
     * The customer of an order: its account, or the account with its
     * billing email, or the guest. '' without an email.
     */
    public static function keyForOrder(\WC_Order $order): string {
        $email = (string) $order->get_billing_email();

        return $order->get_customer_id() > 0 || '' !== $email ? self::keyFor($order->get_customer_id(), $email) : '';
    }

    /**
     * A registered customer's effective profile; built and stored first
     * when there is none yet (or $rebuild).
     */
    public function forUser(int $userId, bool $rebuild = false): array {
        return $this->effective($this->row(self::userKey($userId), $rebuild) ?? []);
    }

    /**
     * A guest customer's effective profile, by the email they ordered with.
     */
    public function forGuest(string $email, bool $rebuild = false): array {
        return $this->effective($this->row(self::guestKey($email), $rebuild) ?? []);
    }

    /**
     * The stored row of $key, built first when missing (or $rebuild). Null
     * for a key that names no customer.
     */
    public function row(string $key, bool $rebuild = false): ?array {
        $row = $rebuild ? null : $this->repository->find($key);

        return $row ?? $this->refresh($key);
    }

    /**
     * Rebuilds and stores the computed profile of $key; keeps the
     * corrections and what the customer stated. Action Scheduler callback.
     */
    public function refresh(string $key): ?array {
        [$kind, $id] = array_pad(explode(':', $key, 2), 2, '');

        if ('user' === $kind) {
            if (!get_userdata((int) $id)) {
                $this->repository->delete($key);

                return null;
            }

            $profile = $this->builder->buildUserProfile((int) $id);
        } elseif ('guest' === $kind && is_email($id)) {
            $profile = $this->builder->buildGuestProfile($id);
        } else {
            return null;
        }

        $activity = (array) ($profile['activity'] ?? []);
        $profile['segment'] = self::segmentOf($activity);

        $this->repository->save($key, [
            'user_id' => (int) $profile['user_id'],
            'email' => strtolower((string) $profile['user_email']),
            'name' => mb_substr((string) $profile['user_name'], 0, 255),
            'profile' => $profile,
            'order_count' => (int) ($activity['order_count'] ?? 0),
            'total_spent' => (float) ($activity['total_spent'] ?? 0),
            'last_order_at' => '' !== (string) ($activity['last_order'] ?? '') ? $activity['last_order'] : null,
            'segment' => $profile['segment'],
            'built_at' => current_time('mysql', true),
        ]);

        return $this->repository->find($key);
    }

    /**
     * Rule-based segment from the customer's activity (ProfileBuilder).
     */
    public static function segmentOf(array $activity): string {
        $count = (int) ($activity['order_count'] ?? 0);
        $days = $activity['days_since_last'] ?? null;
        $gap = (int) ($activity['average_gap_days'] ?? 0);

        if ($count <= 0 || null === $days) {
            return 'none';
        }

        return match (true) {
            $days > 365 => 'lapsed',
            1 === $count && $days <= 60 => 'new',
            // Overdue: well past their usual gap between orders, or months without one.
            $count > 1 && $days > max(90, 2 * $gap) => 'at_risk',
            1 === $count && $days > 120 => 'at_risk',
            $count >= 4 && $days <= 120 => 'loyal',
            default => 'active',
        };
    }

    /**
     * The profile offers use: computed preferences with the manager's
     * corrections and, with consent, the customer's stated preferences
     * applied. Pinned categories come first, excluded ones are dropped;
     * an attribute set by the manager or the customer replaces the
     * computed values.
     */
    public static function effective(array $row): array {
        $profile = ((array) ($row['profile'] ?? [])) + ProfileBuilder::emptyProfile();
        $corrections = (array) ($row['corrections'] ?? []);
        $input = (array) ($row['customer_input'] ?? []);
        $stated = !empty($input['consent']) ? (array) ($input['stated'] ?? []) : [];

        $excluded = array_map('intval', (array) ($corrections['categories_excluded'] ?? []));
        $pinned = array_values(array_diff(array_unique(array_map('intval', [
            ...(array) ($corrections['categories_pinned'] ?? []),
            ...(array) ($stated['categories'] ?? []),
        ])), $excluded));
        $categories = [];

        foreach ($pinned as $id) {
            $term = get_term($id, 'product_cat');

            if ($term instanceof \WP_Term) {
                $categories[] = ['id' => $id, 'name' => html_entity_decode($term->name, ENT_QUOTES), 'count' => 0, 'weight' => 0, 'pinned' => true];
            }
        }

        foreach ((array) $profile['preferred_categories'] as $category) {
            $id = (int) ($category['id'] ?? 0);

            if (!in_array($id, $excluded, true) && !in_array($id, $pinned, true)) {
                $categories[] = $category;
            }
        }

        $attributes = (array) $profile['attributes'];

        foreach (['customer' => (array) ($stated['attributes'] ?? []), 'manager' => (array) ($corrections['attributes'] ?? [])] as $by => $set) {
            foreach ($set as $key => $values) {
                $values = array_values(array_filter(array_map('strval', (array) $values)));

                if ([] === $values) {
                    continue;
                }

                $attributes[$key] = [
                    'label' => ProfileBuilder::attributeLabel((string) $key),
                    'values' => array_map(static function (string $value) use ($key, $by): array {
                        $term = taxonomy_exists((string) $key) ? get_term_by('slug', $value, (string) $key) : false;

                        return ['value' => $value, 'name' => $term instanceof \WP_Term ? html_entity_decode($term->name, ENT_QUOTES) : $value, 'count' => 0, 'weight' => 0, 'set_by' => $by];
                    }, $values),
                    'set_by' => $by,
                ];
            }
        }

        $profile['preferred_categories'] = $categories;
        $profile['excluded_categories'] = $excluded;
        $profile['attributes'] = $attributes;
        $profile['preferred_attributes'] = self::preferredAttributes($attributes);
        $profile['manager_note'] = (string) ($corrections['note'] ?? '');
        $profile['searches'] = !empty($input['consent']) ? array_values((array) ($input['searches'] ?? [])) : [];
        $profile['segment'] = (string) ($row['segment'] ?? ($profile['segment'] ?? 'none'));
        $profile['built_at'] = (string) ($row['built_at'] ?? '');

        return $profile;
    }

    /**
     * What products are ranked by: values set by the manager or customer,
     * else the two most bought, per attribute.
     *
     * @return array<string, list<string>> Attribute => value names.
     */
    private static function preferredAttributes(array $attributes): array {
        $out = [];

        foreach ($attributes as $key => $attribute) {
            $values = (array) ($attribute['values'] ?? []);
            $values = isset($attribute['set_by']) ? $values : array_slice($values, 0, 2);
            $out[(string) $key] = array_values(array_unique(array_map(static fn (array $v): string => (string) $v['name'], $values)));
        }

        return array_filter($out);
    }

    /**
     * Saves the manager's corrections. Keys left out stay as they are;
     * `reset` removes all corrections.
     *
     * @param array{categories_pinned?: list<int>, categories_excluded?: list<int>, attributes?: array<string, list<string>>, note?: string, reset?: bool} $changes
     */
    public function correct(string $key, array $changes, int $byUserId = 0): array|WP_Error {
        $row = $this->row($key);

        if (null === $row) {
            return new WP_Error('pofsf_customer_missing', __('Customer not found.', 'personalized-offers-for-spacefast'));
        }

        $corrections = !empty($changes['reset']) ? [] : (array) $row['corrections'];

        foreach (['categories_pinned', 'categories_excluded'] as $field) {
            if (array_key_exists($field, $changes)) {
                $ids = array_values(array_unique(array_filter(array_map('intval', (array) $changes[$field]))));
                $ids = array_values(array_filter($ids, static fn (int $id): bool => get_term($id, 'product_cat') instanceof \WP_Term));
                $corrections[$field] = array_slice($ids, 0, 20);
            }
        }

        if (array_key_exists('attributes', $changes)) {
            $attributes = [];

            foreach ((array) $changes['attributes'] as $attribute => $values) {
                $attribute = sanitize_key((string) $attribute);
                $values = array_slice(array_values(array_unique(array_filter(array_map(
                    static fn ($v): string => sanitize_text_field((string) $v),
                    (array) $values,
                )))), 0, 10);

                if ('' !== $attribute && [] !== $values) {
                    $attributes[$attribute] = $values;
                }
            }

            $corrections['attributes'] = $attributes;
        }

        if (array_key_exists('note', $changes)) {
            $corrections['note'] = mb_substr(sanitize_textarea_field((string) $changes['note']), 0, 1000);
        }

        $corrections = array_filter($corrections, static fn ($v): bool => [] !== $v && '' !== $v);

        if ([] !== $corrections) {
            $corrections['updated_by'] = $byUserId;
            $corrections['updated_at'] = current_time('mysql', true);
        }

        $this->repository->save($key, ['corrections' => $corrections]);

        return $this->effective((array) $this->repository->find($key));
    }

    /**
     * What a registered customer told the store about themselves (My
     * preferences). Without consent, stated preferences and searches are
     * removed.
     *
     * @param array{consent: bool, record_searches?: bool, categories?: list<int>, attributes?: array<string, list<string>>} $input
     */
    public function saveCustomerInput(int $userId, array $input): void {
        $key = self::userKey($userId);
        $row = $this->row($key);

        if (null === $row) {
            return;
        }

        if (empty($input['consent'])) {
            $this->repository->save($key, ['customer_input' => ['consent' => false]]);

            return;
        }

        $current = (array) $row['customer_input'];
        $attributes = [];

        foreach ((array) ($input['attributes'] ?? []) as $taxonomy => $values) {
            $values = array_values(array_filter(array_map('sanitize_title', (array) $values)));

            if (taxonomy_exists((string) $taxonomy) && [] !== $values) {
                $attributes[(string) $taxonomy] = array_slice($values, 0, 10);
            }
        }

        $this->repository->save($key, ['customer_input' => [
            'consent' => true,
            'consent_at' => !empty($current['consent']) ? ($current['consent_at'] ?? current_time('mysql', true)) : current_time('mysql', true),
            'record_searches' => !empty($input['record_searches']),
            'stated' => [
                'categories' => array_slice(array_values(array_filter(array_map('intval', (array) ($input['categories'] ?? [])))), 0, 20),
                'attributes' => $attributes,
            ],
            'searches' => !empty($input['record_searches']) ? (array) ($current['searches'] ?? []) : [],
        ]]);
    }

    /**
     * Remembers a product search of a customer who allowed it.
     */
    public function recordSearch(int $userId, string $term): void {
        $term = mb_strtolower(mb_substr(trim(sanitize_text_field($term)), 0, 100));
        $row = '' !== $term ? $this->repository->find(self::userKey($userId)) : null;
        $input = (array) ($row['customer_input'] ?? []);

        if (empty($input['consent']) || empty($input['record_searches'])) {
            return;
        }

        $searches = [];

        foreach ((array) ($input['searches'] ?? []) as $search) {
            $searches[(string) ($search['term'] ?? '')] = $search;
        }

        $searches[$term] = ['term' => $term, 'count' => (int) ($searches[$term]['count'] ?? 0) + 1, 'last' => current_time('mysql', true)];
        uasort($searches, static fn (array $a, array $b): int => strcmp((string) $b['last'], (string) $a['last']));
        $input['searches'] = array_values(array_slice($searches, 0, self::MAX_SEARCHES));

        $this->repository->save(self::userKey($userId), ['customer_input' => $input]);
    }

    /**
     * The customer's stated preferences and consent, for My preferences.
     */
    public function customerInput(int $userId): array {
        return (array) ($this->repository->find(self::userKey($userId))['customer_input'] ?? []);
    }

    public function onOrderPaid(int $orderId): void {
        $order = function_exists('wc_get_order') ? wc_get_order($orderId) : null;

        if (!$order instanceof \WC_Order) {
            return;
        }

        $key = self::keyForOrder($order);

        if ('' !== $key) {
            $this->schedule($key);
        }
    }

    /**
     * Queues a rebuild of $key, once at a time.
     */
    public function schedule(string $key): void {
        if (!function_exists('as_enqueue_async_action')) {
            $this->refresh($key);

            return;
        }

        if (!as_has_scheduled_action(self::REFRESH_HOOK, [$key], self::GROUP)) {
            as_enqueue_async_action(self::REFRESH_HOOK, [$key], self::GROUP);
        }
    }

    public function scheduleNightly(): void {
        if (function_exists('as_has_scheduled_action') && !as_has_scheduled_action(self::NIGHTLY_HOOK, null, self::GROUP)) {
            // Soon after install, then at night (site time).
            $first = (new \DateTimeImmutable('tomorrow 03:00', wp_timezone()))->getTimestamp();
            as_schedule_recurring_action(get_option(self::BACKFILLED_OPTION) ? $first : time() + 120, DAY_IN_SECONDS, self::NIGHTLY_HOOK, [], self::GROUP);
        }
    }

    /**
     * Nightly: the first time, profiles for everyone who ever ordered;
     * then customers whose orders changed since the last run, and profiles
     * older than a week (how recently they bought changes every day).
     */
    public function runNightly(): void {
        if (!get_option(self::BACKFILLED_OPTION)) {
            $this->startBackfill();
        }

        $since = (string) get_option(self::LAST_RUN_OPTION, '');
        update_option(self::LAST_RUN_OPTION, current_time('mysql', true), false);

        if ('' !== $since && function_exists('wc_get_orders')) {
            $orders = wc_get_orders(['date_modified' => '>' . strtotime($since . ' UTC'), 'limit' => 500, 'type' => 'shop_order', 'return' => 'objects']);

            foreach ((array) $orders as $order) {
                $key = self::keyForOrder($order);

                if ('' !== $key) {
                    $this->schedule($key);
                }
            }
        }

        $this->refreshStale();
    }

    /**
     * Rebuilds a batch of outdated profiles; another run follows while
     * there are more.
     */
    public function refreshStale(): void {
        $before = gmdate('Y-m-d H:i:s', time() - self::MAX_AGE_DAYS * DAY_IN_SECONDS);
        $keys = $this->repository->staleKeys($before, self::BATCH);

        foreach ($keys as $key) {
            $this->refresh($key);
        }

        if (count($keys) === self::BATCH && function_exists('as_schedule_single_action')) {
            as_schedule_single_action(time() + 60, self::STALE_HOOK, [], self::GROUP);
        }
    }

    /**
     * Builds profiles for everyone who has a paid order, in the background
     * (Customers tab, first nightly run).
     */
    public function startBackfill(): void {
        delete_option(self::BACKFILLED_OPTION);

        if (function_exists('as_enqueue_async_action') && !as_has_scheduled_action(self::BACKFILL_HOOK, null, self::GROUP)) {
            as_enqueue_async_action(self::BACKFILL_HOOK, [1], self::GROUP);
        } elseif (!function_exists('as_enqueue_async_action')) {
            $this->backfill(1);
        }
    }

    public function backfillRunning(): bool {
        return !get_option(self::BACKFILLED_OPTION) && function_exists('as_has_scheduled_action') && as_has_scheduled_action(self::BACKFILL_HOOK, null, self::GROUP);
    }

    /**
     * One page of paid orders, oldest first: profiles for their customers
     * that don't have one yet. Queues the next page.
     */
    public function backfill(int $page = 1): void {
        $orders = function_exists('wc_get_orders') ? wc_get_orders([
            'status' => function_exists('wc_get_is_paid_statuses') ? wc_get_is_paid_statuses() : ['processing', 'completed'],
            'type' => 'shop_order',
            'limit' => self::BATCH * 2,
            'page' => max(1, $page),
            'orderby' => 'ID',
            'order' => 'ASC',
        ]) : [];

        $keys = [];

        foreach ((array) $orders as $order) {
            $key = self::keyForOrder($order);

            if ('' !== $key) {
                $keys[$key] = true;
            }
        }

        foreach (array_keys($keys) as $key) {
            if (null === $this->repository->find($key)) {
                $this->refresh($key);
            }
        }

        if (count((array) $orders) === self::BATCH * 2 && function_exists('as_enqueue_async_action')) {
            as_enqueue_async_action(self::BACKFILL_HOOK, [$page + 1], self::GROUP);

            return;
        }

        update_option(self::BACKFILLED_OPTION, current_time('mysql', true), false);
        $this->log->log('Customer profiles built for every customer with orders.');
    }

    public function onUserDeleted(int $userId): void {
        $this->repository->delete(self::userKey($userId));
    }

    /** A changed name or email shows in the list right away. */
    public function onUserUpdated(int $userId): void {
        $user = get_userdata($userId);

        if ($user && null !== $this->repository->find(self::userKey($userId))) {
            $this->repository->save(self::userKey($userId), ['email' => strtolower($user->user_email), 'name' => $user->display_name]);
        }
    }

    /**
     * Removes a customer's stored profile (personal data erasure).
     */
    public function erase(string $email): bool {
        $removed = false;
        $user = get_user_by('email', $email);

        if ($user) {
            $removed = $this->repository->delete(self::userKey($user->ID)) || $removed;
        }

        return $this->repository->delete(self::guestKey($email)) || $removed;
    }

    public function repository(): CustomerProfileRepository {
        return $this->repository;
    }
}
