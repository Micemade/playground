<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\RecipientRepository;

final class PrivacyEraser {
    public function __construct(
        private readonly OfferRepository $offers,
        private readonly OfferPipeline $pipeline,
        private readonly CustomerProfiles $profiles,
        private readonly RecipientRepository $recipients = new RecipientRepository(),
    ) {}

    public function register(): void {
        add_filter('wp_privacy_personal_data_erasers', [$this, 'registerEraser']);
    }

    public function registerEraser(array $erasers): array {
        $erasers['pofsf_offers'] = [
            'eraser_friendly_name' => __('Spacefast personalized offers', 'personalized-offers-for-spacefast'),
            'callback' => [$this, 'erase'],
        ];

        return $erasers;
    }

    public function erase(string $email, int $page = 1): array {
        $email = sanitize_email($email);

        if ('' === $email) {
            return $this->result(false, [__('No email provided.', 'personalized-offers-for-spacefast')]);
        }

        $messages = [];
        $removed = false;

        // Only the account with this email. (get_users() has no `email` argument: it ignored it and returned every user.)
        $user = get_user_by('email', $email);

        foreach ($user ? [$user->ID] : [] as $userId) {
            $userId = (int) $userId;

            delete_user_meta($userId, 'pofsf_consent_given');

            foreach ($this->offers->findByUser($userId) as $offer) {
                $this->revoke($offer);
                $removed = true;
            }

            // Group offers: drop the customer's personal link and their email from the shared coupon.
            foreach ($this->recipients->forUser($userId) as $recipient) {
                $this->recipients->delete($recipient['id']);
                $offer = $this->offers->find($recipient['offer_id']);

                if (null !== $offer) {
                    $this->pipeline->syncGroupCoupon($offer);
                    // Revokes their personal Spacefast link.
                    do_action(JobScheduler::ACCESS_HOOK, (int) $offer['id']);
                }

                $removed = true;
            }

            if ($removed) {
                /* translators: %d: WordPress user ID. */
                $messages[] = sprintf(__('Erased offers for registered user %d.', 'personalized-offers-for-spacefast'), $userId);
            }
        }

        foreach ($this->offers->findByGuestEmail($email) as $offer) {
            $this->revoke($offer);
            $removed = true;
        }

        if ($removed) {
            $messages[] = __('Erased offers for guest customer.', 'personalized-offers-for-spacefast');
        }

        if ($this->profiles->erase($email)) {
            $removed = true;
            $messages[] = __('Erased the stored shopping profile.', 'personalized-offers-for-spacefast');
        }

        $messages[] = __('Note: the customer\'s published Spacefast pages are closed and their links revoked while Spacefast is connected; the pages themselves are deleted with their offers.', 'personalized-offers-for-spacefast');

        return $this->result($removed, $messages);
    }

    private function result(bool $removed, array $messages): array {
        return [
            'items_removed' => $removed,
            'items_retained' => false,
            'messages' => $messages,
            'done' => true,
        ];
    }

    /**
     * Revoked for the erasure, so changing the offer's usage limit never brings it back.
     */
    private function revoke(array $offer): void {
        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $offerData['revoked_reason'] = 'erasure';

        $this->offers->update((int) $offer['id'], ['status' => OfferStatus::Revoked, 'offer_data' => $offerData]);
        // Closes its Spacefast Space, if any.
        do_action(JobScheduler::ACCESS_HOOK, (int) $offer['id']);
    }
}
