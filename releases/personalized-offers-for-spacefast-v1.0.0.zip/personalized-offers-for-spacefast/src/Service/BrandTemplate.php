<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Value\BrandSnapshot;
use WP_Error;

final class BrandTemplate {
    public function capture(): BrandSnapshot|WP_Error {
        return BrandSnapshot::fromArray([
            'logo' => $this->captureLogo(),
            'identity' => $this->captureIdentity(),
            'colors' => $this->captureColors(),
            'fonts' => $this->captureFonts(),
            'email_branding' => $this->captureEmailBranding(),
            'woocommerce_branding' => $this->captureWooCommerceBranding(),
            'captured_at' => current_time('mysql'),
            'captured_by' => get_current_user_id(),
        ]);
    }

    public function generateCss(BrandSnapshot $brand): string {
        $c = $brand->colors;
        $f = $brand->fonts;

        return ":root {\n"
            . "  --pofsf-primary: {$c['primary']};\n"
            . "  --pofsf-secondary: {$c['secondary']};\n"
            . "  --pofsf-background: {$c['background']};\n"
            . "  --pofsf-surface: {$c['surface']};\n"
            . "  --pofsf-text: {$c['text']};\n"
            . "  --pofsf-text-muted: {$c['text_muted']};\n"
            . "  --pofsf-border: {$c['border']};\n"
            . "  --pofsf-accent: {$c['accent']};\n"
            . "  --pofsf-font-heading: {$f['heading']};\n"
            . "  --pofsf-font-body: {$f['body']};\n"
            . "}\n";
    }

    /**
     * Brand images for an offer page: the logo and the site icon, resolved
     * live from the site with the snapshot's choices first. Each asset has
     * a public URL (for previews) and, when available, the local file (so
     * exports can bundle it and not depend on the store being reachable).
     *
     * @return array{logo: ?array, icon: ?array}
     */
    public function assets(BrandSnapshot $brand): array {
        $logo = null;

        foreach ([(int) ($brand->logo['attachment_id'] ?? 0), $this->siteLogoId()] as $id) {
            $logo ??= $this->attachmentAsset($id, 'medium_large');
        }

        // Snapshots can hold an inline SVG logo without a usable attachment.
        if (null === $logo && '' !== (string) ($brand->logo['svg'] ?? '')) {
            $svg = (string) $brand->logo['svg'];
            $logo = ['url' => 'data:image/svg+xml;base64,' . base64_encode($svg), 'path' => '', 'bytes' => $svg, 'ext' => 'svg', 'width' => 0, 'height' => 0];
        }

        $icon = null;

        foreach ([(int) ($brand->logo['site_icon_id'] ?? 0), (int) get_option('site_icon', 0)] as $id) {
            $icon ??= $this->attachmentAsset($id, [512, 512]);
        }

        return ['logo' => $logo, 'icon' => $icon];
    }

    /**
     * Site logo: classic themes use the custom_logo theme mod, block themes the site_logo option.
     */
    private function siteLogoId(): int {
        return (int) get_theme_mod('custom_logo', 0) ?: (int) get_option('site_logo', 0);
    }

    /**
     * @param string|int[] $size Preferred image size; falls back to the original.
     * @return array{url: string, path: string, bytes: string, ext: string, width: int, height: int}|null
     */
    private function attachmentAsset(int $id, string|array $size): ?array {
        if ($id <= 0 || !wp_attachment_is_image($id)) {
            return null;
        }

        $original = get_attached_file($id);
        $original = is_string($original) && is_readable($original) ? $original : '';

        if ('image/svg+xml' === get_post_mime_type($id)) {
            $svg = $this->readLogoSvg($id);

            return '' === $svg ? null : [
                'url' => (string) wp_get_attachment_url($id),
                'path' => '',
                'bytes' => $svg,
                'ext' => 'svg',
                'width' => 0,
                'height' => 0,
            ];
        }

        $src = wp_get_attachment_image_src($id, $size);

        if (!is_array($src) || empty($src[0])) {
            return null;
        }

        $path = $original;
        $resized = '' !== $original ? image_get_intermediate_size($id, $size) : false;

        if (is_array($resized) && !empty($resized['file'])) {
            $candidate = trailingslashit(dirname($original)) . $resized['file'];
            $path = is_readable($candidate) ? $candidate : $original;
        }

        $ext = strtolower(pathinfo('' !== $path ? $path : (string) $src[0], PATHINFO_EXTENSION));

        return [
            'url' => (string) $src[0],
            'path' => $path,
            'bytes' => '',
            'ext' => in_array($ext, ['png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'ico'], true) ? $ext : 'png',
            'width' => (int) ($src[1] ?? 0),
            'height' => (int) ($src[2] ?? 0),
        ];
    }

    private function captureLogo(): array {
        $logoId = $this->siteLogoId();
        $iconId = (int) get_option('site_icon', 0);

        return [
            'attachment_id' => $logoId,
            'site_icon_id' => $iconId,
            'url' => $logoId ? (string) wp_get_attachment_image_url($logoId, 'full') : '',
            'svg' => $this->readLogoSvg($logoId),
            'icon_url' => $iconId ? (string) get_site_icon_url(512) : '',
            'width' => $logoId ? (int) get_post_meta($logoId, '_wp_attachment_image_width', true) : 0,
            'height' => $logoId ? (int) get_post_meta($logoId, '_wp_attachment_image_height', true) : 0,
        ];
    }

    private function readLogoSvg(int $logoId): string {
        if ($logoId <= 0 || 'image/svg+xml' !== get_post_mime_type($logoId)) {
            return '';
        }

        $path = get_attached_file($logoId);
        if (!is_string($path) || !is_readable($path)) {
            return '';
        }

        $svg = file_get_contents($path);

        return is_string($svg) ? $this->sanitizeSvg($svg) : '';
    }

    private function sanitizeSvg(string $svg): string {
        $svg = (string) preg_replace('/<script\b[^>]*>.*?<\/script>/is', '', $svg);
        $svg = (string) preg_replace('/on\w+\s*=\s*["\'][^"\']*["\']/i', '', $svg);
        $svg = (string) preg_replace('/javascript:/i', '', $svg);
        $svg = (string) preg_replace('/xlink:href\s*=\s*["\'][^"\']*["\']/i', '', $svg);

        if (!preg_match('/viewBox\s*=/i', $svg)
            && preg_match('/<svg[^>]*width\s*=\s*["\']([^"\']+)["\'][^>]*height\s*=\s*["\']([^"\']+)["\']/i', $svg, $m)
        ) {
            $svg = (string) preg_replace('/<svg/i', '<svg viewBox="0 0 ' . $m[1] . ' ' . $m[2] . '"', $svg, 1);
        }

        return $svg;
    }

    private function captureIdentity(): array {
        return [
            'name' => (string) get_option('blogname'),
            'tagline' => (string) get_option('blogdescription'),
            'address' => (string) get_option('woocommerce_store_address'),
            'address_2' => (string) get_option('woocommerce_store_address_2'),
            'city' => (string) get_option('woocommerce_store_city'),
            'state' => (string) get_option('woocommerce_store_state'),
            'postcode' => (string) get_option('woocommerce_store_postcode'),
            'country' => (string) get_option('woocommerce_default_country'),
        ];
    }

    private function captureColors(): array {
        $colors = [
            'primary' => '',
            'secondary' => '',
            'background' => '',
            'surface' => '',
            'text' => '',
            'text_muted' => '',
            'border' => '',
            'accent' => '',
        ];

        if (function_exists('wp_get_global_styles')) {
            $global = wp_get_global_styles();
            $palette = $global['settings']['color']['palette'] ?? [];

            foreach ($palette as $color) {
                $slug = $color['slug'] ?? '';
                $value = $color['color'] ?? '';

                match ($slug) {
                    'primary', 'accent' => $colors['primary'] = $value,
                    'secondary' => $colors['secondary'] = $value,
                    'background', 'base' => $colors['background'] = $value,
                    'foreground', 'text' => $colors['text'] = $value,
                    'muted' => $colors['text_muted'] = $value,
                    'border' => $colors['border'] = $value,
                    default => null,
                };
            }

            if ('' === $colors['primary'] && isset($palette[0]['color'])) {
                $colors['primary'] = $palette[0]['color'];
            }
        }

        $colors['primary'] = '' !== $colors['primary'] ? $colors['primary'] : (string) get_option('woocommerce_email_base_color');
        $colors['background'] = '' !== $colors['background'] ? $colors['background'] : (string) get_option('woocommerce_email_background_color');
        $colors['text'] = '' !== $colors['text'] ? $colors['text'] : (string) get_option('woocommerce_email_text_color');

        return array_merge([
            'primary' => '#0066cc',
            'secondary' => '#6c757d',
            'background' => '#ffffff',
            'surface' => '#f8f9fa',
            'text' => '#212529',
            'text_muted' => '#6c757d',
            'border' => '#dee2e6',
            'accent' => '#0066cc',
        ], array_filter($colors, static fn (mixed $v): bool => '' !== $v));
    }

    private function captureFonts(): array {
        $fonts = ['heading' => '', 'body' => ''];

        if (function_exists('wp_get_global_styles')) {
            $global = wp_get_global_styles();
            $families = $global['settings']['typography']['fontFamilies'] ?? [];

            foreach ($families as $font) {
                $slug = (string) ($font['slug'] ?? '');
                $family = (string) ($font['fontFamily'] ?? '');

                if (str_contains($slug, 'heading') || str_contains($slug, 'title')) {
                    $fonts['heading'] = $family;
                } elseif (str_contains($slug, 'body') || str_contains($slug, 'text') || '' === $fonts['body']) {
                    $fonts['body'] = $family;
                }
            }

            $root = $global['styles']['typography']['fontFamily'] ?? '';
            if ('' !== $root && '' === $fonts['body']) {
                $fonts['body'] = $root;
            }
        }

        if ('' === $fonts['body']) {
            $fonts['body'] = (string) get_option('woocommerce_email_font_family');
        }

        if ('' === $fonts['heading']) {
            $fonts['heading'] = $fonts['body'];
        }

        $fallback = 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';

        return array_merge(
            ['heading' => $fallback, 'body' => $fallback],
            array_filter($fonts, static fn (mixed $v): bool => '' !== $v),
        );
    }

    private function captureEmailBranding(): array {
        return [
            'header_image' => get_option('woocommerce_email_header_image'),
            'base_color' => get_option('woocommerce_email_base_color'),
            'background_color' => get_option('woocommerce_email_background_color'),
            'body_background' => get_option('woocommerce_email_body_background_color'),
            'text_color' => get_option('woocommerce_email_text_color'),
            'font_family' => get_option('woocommerce_email_font_family'),
            'footer_text' => get_option('woocommerce_email_footer_text'),
        ];
    }

    private function captureWooCommerceBranding(): array {
        $stored = get_option('woo_storefront_settings');

        if (!is_array($stored) || !isset($stored['branding']) || !is_array($stored['branding'])) {
            return [];
        }

        return [
            'logo' => $stored['branding']['logo'] ?? '',
            'colors' => $stored['branding']['colors'] ?? [],
            'typography' => $stored['branding']['typography'] ?? [],
        ];
    }
}
