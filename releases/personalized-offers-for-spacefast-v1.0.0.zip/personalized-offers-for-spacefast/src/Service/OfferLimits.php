<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Enum\OfferStatus;

/**
 * An offer's usage limit: max_uses 0 means no limit. A use is an order
 * placed from the offer; an offer that reaches its limit becomes Used, and
 * raising or removing the limit brings it back. Offers revoked for other
 * reasons (a privacy erasure) stay revoked.
 */
final class OfferLimits {
    /** revoked_reason of offers that earlier versions revoked on reaching their limit. */
    public const REASON = 'max_uses';
    public const MAX = 65535; // The max_uses column is a SMALLINT UNSIGNED.

    public static function reached(array $offer): bool {
        $max = (int) ($offer['max_uses'] ?? 1);

        return $max > 0 && (int) ($offer['used_count'] ?? 0) >= $max;
    }

    /**
     * Used up its limit: Used, or revoked for it by an earlier version.
     */
    public static function usedUp(array $offer): bool {
        return OfferStatus::Used->value === (string) ($offer['status'] ?? '') || self::revokedByLimit($offer);
    }

    /**
     * Revoked because the limit was reached (earlier versions). Offers
     * revoked before reasons were recorded count when they had used up
     * their limit.
     */
    public static function revokedByLimit(array $offer): bool {
        if (OfferStatus::Revoked->value !== (string) ($offer['status'] ?? '')) {
            return false;
        }

        $reason = $offer['offer_data']['revoked_reason'] ?? null;

        return null === $reason ? self::reached($offer) : self::REASON === $reason;
    }

    /** The settings' default limit for a new offer. */
    public static function defaultMax(): int {
        return max(1, min(self::MAX, (int) Settings::get('offer_max_uses', 1)));
    }
}
