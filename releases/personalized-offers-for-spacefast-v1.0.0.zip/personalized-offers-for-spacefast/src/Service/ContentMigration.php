<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Blocks\OfferBlocks;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\TemplateRepository;
use Closure;
use Micemade\PersonalizedOffers\Value\OfferCopy;
use Micemade\PersonalizedOffers\Value\OfferDesign;

/**
 * Once per version: offers and templates move to the current copy and blocks.
 *
 * 1. The fixed copy fields (theme, greeting, body copy, personal note,
 *    closing) and their blocks became text fields and the Offer text block.
 * 2. One text field per type (OfferCopy::sanitizeFields() joins repeated
 *    ones), so the Offer text block lost its "Which" (index) setting; the
 *    Checkout button became the Action button and the Offer terms block went.
 * 3. The Action button became the Offer action button.
 * 4. The design lost its corner radius, banner color and header branding:
 *    a radius other than the default and a gradient banner become extra
 *    CSS, the header branding becomes the Offer branding block's settings.
 * 5. The Offer products block lost its section heading, "skip the first"
 *    and "show at most" settings and its webshop styles: a heading becomes
 *    a paragraph above the block, a block that continued an earlier one's
 *    list (skipping its products) goes, the former styles become the
 *    editorial ones (OfferBlocks::legacyProductsGrid()).
 *
 * The result looks as before, so published pages are not marked outdated:
 * offers are migrated first, so their copy of each template already
 * matches the template when it is saved (OfferPipeline::syncTemplate()).
 * Built-in templates are replaced by their new versions separately
 * (TemplateRepository::ensureBuiltins()).
 */
final class ContentMigration {
    public const OPTION = 'pofsf_offer_fields_version';
    private const VERSION = 5;
    private const BATCH = 200;

    /** The corner radius designs had by default, now the --pofsf-radius default in offer.css. */
    private const DEFAULT_RADIUS = 8;

    /** Whether the store has a logo (not just a site icon), for the former "auto" header branding. */
    private ?bool $hasLogo = null;

    /**
     * @param Closure(): bool $storeHasLogo
     */
    public function __construct(
        private readonly OfferRepository $offers,
        private readonly Closure $storeHasLogo,
    ) {}

    public function maybeRun(): void {
        if ((int) get_option(self::OPTION, 0) >= self::VERSION) {
            return;
        }

        // First, so a failure part-way does not run it again and again.
        update_option(self::OPTION, self::VERSION, false);
        $this->migrateOffers();
        $this->migrateTemplates();
    }

    /**
     * Block markup with the current blocks: replaced blocks upgraded
     * (OfferBlocks::legacyBlock()), Offer terms blocks left out, and Offer
     * text blocks without an index. A block that showed a second or later
     * text of its type goes, as that text is now part of the first; so does
     * a closing line next to a personal note, which became one Additional text.
     */
    public static function markup(string $content): string {
        if (!preg_match('#<!-- wp:pofsf/(theme|greeting|body-copy|personal-note|closing|checkout-button|action-button|offer-terms)[ /]|"index":#', $content)) {
            return $content;
        }

        $blocks = parse_blocks($content);
        $dropClosing = in_array('pofsf/personal-note', self::names($blocks), true);

        return serialize_blocks(array_values(array_filter(self::upgrade($blocks, $dropClosing))));
    }

    private function migrateOffers(): void {
        for ($offset = 0; ; $offset += self::BATCH) {
            $rows = $this->offers->list(['limit' => self::BATCH, 'offset' => $offset, 'orderby' => 'created_at', 'order' => 'ASC']);

            foreach ($rows as $offer) {
                $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
                $migrated = $offerData;

                if (is_array($offerData['offer_json'] ?? null)) {
                    $migrated['offer_json'] = OfferCopy::normalize($offerData['offer_json']);
                }

                $branding = [];

                if (is_array($offerData['design'] ?? null)) {
                    [$design, $branding] = $this->design($offerData['design']);
                    $migrated['design'] = $design;
                }

                if (isset($offerData['template_content'])) {
                    $migrated['template_content'] = self::products(self::withBranding(self::markup((string) $offerData['template_content']), $branding));
                }

                if (isset($offerData['personal_note'])) {
                    $migrated['additional_text'] = $offerData['personal_note'];
                    unset($migrated['personal_note']);
                }

                if ($migrated !== $offerData) {
                    $this->offers->update((int) $offer['id'], ['offer_data' => $migrated]);
                }
            }

            if (count($rows) < self::BATCH) {
                break;
            }
        }
    }

    private function migrateTemplates(): void {
        foreach (get_posts(['post_type' => TemplateRepository::POST_TYPE, 'post_status' => 'any', 'numberposts' => -1]) as $post) {
            $stored = get_post_meta($post->ID, TemplateRepository::META_DESIGN, true);
            $branding = [];

            if (is_array($stored)) {
                [$design, $branding] = $this->design($stored);

                // Before the content, so saving it finds the offers' copies already matching.
                if ($design != $stored) {
                    update_post_meta($post->ID, TemplateRepository::META_DESIGN, $design);
                }
            }

            $content = self::products(self::withBranding(self::markup($post->post_content), $branding));

            if ($content !== $post->post_content) {
                wp_update_post(wp_slash(['ID' => $post->ID, 'post_content' => $content]));
            }
        }
    }

    /**
     * A design without the corner radius, banner color and header branding
     * (step 4), and the Offer branding block settings that replace its
     * header branding. Designs saved without them are only normalized.
     *
     * @return array{0: array, 1: array<string, bool>} The design (OfferDesign::toArray()) and the branding block attributes.
     */
    public function design(array $design): array {
        $css = trim((string) ($design['custom_css'] ?? ''));
        $radius = isset($design['radius']) ? max(0, min(32, (int) $design['radius'])) : self::DEFAULT_RADIUS;

        if (self::DEFAULT_RADIUS !== $radius) {
            // First, so a radius the CSS already sets still wins.
            $css = ':root { --pofsf-radius: ' . $radius . 'px; }' . ('' !== $css ? "\n" . $css : '');
        }

        if ('gradient' === ($design['hero'] ?? '')) {
            // Banners without their own background, as the setting colored them.
            $css .= ('' !== $css ? "\n" : '') . '.wp-block-group.is-style-pofsf-banner:where(:not(.has-background)) { background: linear-gradient(120deg, var(--pofsf-primary), var(--pofsf-accent)); }';
        }

        // The block shows the logo (or site icon) and the store name by default.
        $branding = match ((string) ($design['logo'] ?? '')) {
            // The logo alone; stores without one showed the site icon with the store name.
            'auto' => $this->hasLogo() ? ['showTitle' => false] : [],
            'logo' => ['showTitle' => false],
            'none' => ['showLogo' => false],
            default => [],
        };

        $design['custom_css'] = $css;

        return [OfferDesign::fromArray($design)->toArray(), $branding];
    }

    /**
     * Gives the Offer branding blocks in $content the settings $branding,
     * unless a block has its own.
     *
     * @param array<string, bool> $branding
     */
    public static function withBranding(string $content, array $branding): string {
        if ([] === $branding || !str_contains($content, '<!-- wp:pofsf/branding')) {
            return $content;
        }

        return serialize_blocks(self::brandingBlocks(parse_blocks($content), $branding));
    }

    private static function brandingBlocks(array $blocks, array $branding): array {
        foreach ($blocks as &$block) {
            if ('pofsf/branding' === ($block['blockName'] ?? '')) {
                $block['attrs'] = (array) ($block['attrs'] ?? []) + $branding;
            }

            if (!empty($block['innerBlocks'])) {
                $block['innerBlocks'] = self::brandingBlocks($block['innerBlocks'], $branding);
            }
        }

        return $blocks;
    }

    /**
     * Offer products blocks with their current settings (step 5).
     */
    public static function products(string $content): string {
        if (!str_contains($content, '<!-- wp:pofsf/products')) {
            return $content;
        }

        $seen = false;

        return serialize_blocks(self::productsBlocks(parse_blocks($content), $seen));
    }

    /**
     * @return list<array> The blocks; a products block may become two (its
     *         heading as a paragraph, then the block) or none.
     */
    private static function productsBlocks(array $blocks, bool &$seen): array {
        $result = [];

        foreach ($blocks as $block) {
            if ('pofsf/products' === ($block['blockName'] ?? '')) {
                $attrs = (array) ($block['attrs'] ?? []);

                // It showed the rest of an earlier products block's list: that block now shows them all.
                if ($seen && (int) ($attrs['offset'] ?? 0) > 0) {
                    continue;
                }

                $seen = true;
                $heading = trim((string) ($attrs['heading'] ?? ''));

                if ('' !== $heading) {
                    $html = '<p class="pofsf-eyebrow">' . esc_html($heading) . '</p>';
                    $result[] = ['blockName' => 'core/paragraph', 'attrs' => ['className' => 'pofsf-eyebrow'], 'innerBlocks' => [], 'innerHTML' => $html, 'innerContent' => [$html]];
                }

                $result[] = OfferBlocks::legacyProductsGrid($block, true);
                continue;
            }

            if (!empty($block['innerBlocks'])) {
                $replacements = [];

                // In order, so $seen follows the page from top to bottom.
                foreach ($block['innerBlocks'] as $inner) {
                    $replacements[] = self::productsBlocks([$inner], $seen);
                }

                $innerContent = [];
                $i = 0;

                foreach ((array) $block['innerContent'] as $chunk) {
                    if (null !== $chunk) {
                        $innerContent[] = $chunk;
                        continue;
                    }

                    foreach ($replacements[$i++] ?? [] as $n => $unused) {
                        if ($n > 0) {
                            $innerContent[] = "\n\n";
                        }

                        $innerContent[] = null;
                    }
                }

                $block['innerBlocks'] = array_merge(...$replacements);
                $block['innerContent'] = $innerContent;
            }

            $result[] = $block;
        }

        return $result;
    }

    private function hasLogo(): bool {
        return $this->hasLogo ??= (bool) ($this->storeHasLogo)();
    }

    /**
     * @return list<string>
     */
    private static function names(array $blocks): array {
        $names = [];

        foreach ($blocks as $block) {
            $names[] = (string) ($block['blockName'] ?? '');
            array_push($names, ...self::names($block['innerBlocks'] ?? []));
        }

        return $names;
    }

    /**
     * The blocks, upgraded, without the ones that go. A removed inner
     * block also leaves its parent's innerContent (where a null marks each
     * inner block).
     */
    private static function upgrade(array $blocks, bool $dropClosing): array {
        $kept = [];

        foreach ($blocks as $block) {
            $name = (string) ($block['blockName'] ?? '');
            $index = (int) ($block['attrs']['index'] ?? 0);

            if ('pofsf/offer-terms' === $name || ($dropClosing && 'pofsf/closing' === $name) || ('pofsf/offer-text' === $name && $index > 1)) {
                $kept[] = null;
                continue;
            }

            if (!empty($block['innerBlocks'])) {
                $inner = self::upgrade($block['innerBlocks'], $dropClosing);
                $block['innerContent'] = self::withoutRemoved((array) ($block['innerContent'] ?? []), $inner);
                $block['innerBlocks'] = array_values(array_filter($inner));
            }

            $block = OfferBlocks::legacyBlock($block);
            unset($block['attrs']['index']);
            $kept[] = $block;
        }

        return $kept;
    }

    /**
     * @param list<?array> $inner The inner blocks, null where one was removed.
     */
    private static function withoutRemoved(array $innerContent, array $inner): array {
        $content = [];
        $i = 0;

        foreach ($innerContent as $chunk) {
            if (null === $chunk && null === ($inner[$i++] ?? null)) {
                continue;
            }

            $content[] = $chunk;
        }

        return $content;
    }
}
