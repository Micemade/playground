<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Value\OfferCopy;

/**
 * Offer texts and products for the template editor opened from the Edit
 * offer form, so the blocks show the offer's own (possibly unsaved) texts
 * and picks instead of the samples. The form stores them under a random key, which travels in
 * the editor URL (pofsf_copy) and its block previews; only the user who
 * stored them can read them, for a couple of hours.
 */
final class EditorCopy {
    public const PARAM = 'pofsf_copy';
    private const TRANSIENT = 'pofsf_editor_copy_';
    private const TTL = 2 * HOUR_IN_SECONDS;

    /**
     * Keeps the headline, the fields with text and the product picks of
     * $input; returns their key.
     */
    public static function store(array $input): string {
        $copy = ['fields' => OfferCopy::sanitizeFields($input['fields'] ?? [], true)];
        $picks = self::picks(is_array($input['picks'] ?? null) ? $input['picks'] : []);

        if ([] !== $picks) {
            $copy['product_picks'] = $picks;
        }
        $headline = mb_substr(trim(sanitize_text_field((string) ($input['headline'] ?? ''))), 0, OfferCopy::LIMITS['headline']);

        if ('' !== $headline) {
            $copy['headline'] = $headline;
        }

        $buttonText = mb_substr(trim(sanitize_text_field((string) ($input['button_text'] ?? ''))), 0, OfferCopy::LIMITS['button_text']);

        if ('' !== $buttonText) {
            $copy['button_text'] = $buttonText;
        }

        $key = strtolower(wp_generate_password(20, false));
        set_transient(self::TRANSIENT . $key, ['user' => get_current_user_id(), 'copy' => $copy], self::TTL);

        return $key;
    }

    /**
     * Picks of published products, at most OfferCopy::MAX_PICKS.
     *
     * @return list<array{product_id: int, variation_id: int, title: string, story: string, reason: string}>
     */
    private static function picks(array $input): array {
        $picks = [];

        foreach ($input as $pick) {
            $productId = is_array($pick) ? (int) ($pick['product_id'] ?? 0) : 0;

            if ($productId <= 0 || isset($picks[$productId]) || 'product' !== get_post_type($productId) || 'publish' !== get_post_status($productId)) {
                continue;
            }

            $picks[$productId] = [
                'product_id' => $productId,
                'variation_id' => max(0, (int) ($pick['variation_id'] ?? 0)),
                'title' => mb_substr(trim(sanitize_text_field((string) ($pick['title'] ?? ''))), 0, OfferCopy::LIMITS['title']),
                'story' => mb_substr(trim(sanitize_textarea_field((string) ($pick['story'] ?? ''))), 0, OfferCopy::LIMITS['story']),
                'reason' => mb_substr(trim(sanitize_text_field((string) ($pick['reason'] ?? ''))), 0, OfferCopy::LIMITS['reason']),
            ];
        }

        return array_slice(array_values($picks), 0, OfferCopy::MAX_PICKS);
    }

    /**
     * The texts stored under $key for the current user; empty if none.
     *
     * @return array{headline?: string, button_text?: string, fields?: list<array{type: string, text: string}>, product_picks?: list<array>}
     */
    public static function load(string $key): array {
        $key = sanitize_key($key);
        $stored = '' !== $key ? get_transient(self::TRANSIENT . $key) : false;

        return is_array($stored) && (int) ($stored['user'] ?? 0) === get_current_user_id() && is_array($stored['copy'] ?? null)
            ? $stored['copy']
            : [];
    }

    /**
     * The key in the current request (editor page, block preview, template preview).
     */
    public static function requestKey(): string {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only lookup of the user's own stored texts.
        return isset($_GET[self::PARAM]) ? sanitize_key(wp_unslash((string) $_GET[self::PARAM])) : '';
    }

    /**
     * @return array{headline?: string, button_text?: string, fields?: list<array{type: string, text: string}>, product_picks?: list<array>}
     */
    public static function fromRequest(): array {
        return self::load(self::requestKey());
    }
}
