<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

final class ShortlistBuilder {
    private const LIMIT = 50;

    public function build(array $profile): array {
        if (!function_exists('wc_get_product')) {
            return [];
        }

        // Guests with orders have preferences too; without any, their wishlist.
        $items = !empty($profile['is_registered']) || [] !== (array) ($profile['preferred_categories'] ?? [])
            ? $this->fromCatalog($profile)
            : $this->fromWishlist($profile);

        return array_slice($items, 0, self::LIMIT);
    }

    /**
     * In-stock products from the customer's favourite categories, best
     * sellers first; the store's best sellers when they have no orders yet.
     */
    private function fromCatalog(array $profile): array {
        $slugs = [];

        foreach ($profile['preferred_categories'] ?? [] as $cat) {
            $term = get_term((int) ($cat['id'] ?? 0), 'product_cat');

            if ($term && !is_wp_error($term)) {
                $slugs[] = $term->slug;
            }
        }

        if (!function_exists('wc_get_products')) {
            return [];
        }

        $query = [
            'status' => 'publish',
            'stock_status' => 'instock',
            'limit' => self::LIMIT,
            'orderby' => 'meta_value_num',
            'meta_key' => 'total_sales', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Best sellers, as WooCommerce sorts by popularity; the result is limited.
            'order' => 'DESC',
        ];

        $products = [] !== $slugs ? wc_get_products($query + ['category' => $slugs]) : [];

        if ([] === $products) {
            $products = wc_get_products($query);
        }

        $products = $this->withoutExcluded($products, array_map('intval', (array) ($profile['excluded_categories'] ?? [])));

        return array_map([$this, 'summarize'], $this->byAttributes($products, (array) ($profile['preferred_attributes'] ?? [])));
    }

    /**
     * Drops products in categories the manager excluded (or their subcategories).
     *
     * @param list<\WC_Product> $products
     * @param list<int> $excluded
     * @return list<\WC_Product>
     */
    private function withoutExcluded(array $products, array $excluded): array {
        if ([] === $excluded) {
            return $products;
        }

        return array_values(array_filter($products, static function (object $product) use ($excluded): bool {
            $own = array_map('intval', $product->get_category_ids());
            $all = array_merge($own, ...array_map(static fn (int $id): array => array_map('intval', get_ancestors($id, 'product_cat', 'taxonomy')), $own));

            return [] === array_intersect($excluded, $all);
        }));
    }

    /**
     * Products offered in the customer's sizes, colours and other preferred
     * attribute values first; the order stays best sellers within a group.
     *
     * @param list<\WC_Product> $products
     * @param array<string, list<string>> $preferred Attribute => value names.
     * @return list<\WC_Product>
     */
    private function byAttributes(array $products, array $preferred): array {
        if ([] === $preferred) {
            return $products;
        }

        $scored = [];

        foreach (array_values($products) as $position => $product) {
            $score = 0;

            foreach ($preferred as $attribute => $names) {
                // A global attribute (pa_size), or a custom one with the same name (Size).
                $text = (string) $product->get_attribute((string) $attribute) ?: (string) $product->get_attribute((string) preg_replace('/^pa_/', '', (string) $attribute));
                $offered = array_map('trim', preg_split('/[,|]/', mb_strtolower($text)) ?: []);
                $score += [] !== array_intersect($offered, array_map('mb_strtolower', $names)) ? 1 : 0;
            }

            $scored[] = [$score, $position, $product];
        }

        usort($scored, static fn (array $a, array $b): int => [$b[0], $a[1]] <=> [$a[0], $b[1]]);

        return array_column($scored, 2);
    }

    private function fromWishlist(array $profile): array {
        $out = [];

        foreach (array_slice($profile['wishlist_products'] ?? [], 0, 10) as $entry) {
            $id = is_array($entry) ? (int) ($entry['product_id'] ?? 0) : (int) $entry;
            $product = $id > 0 ? wc_get_product($id) : false;

            if ($product && !is_wp_error($product) && $product->is_in_stock()) {
                $out[] = $this->summarize($product);
            }
        }

        if ([] !== $out) {
            return $out;
        }

        $fallback = function_exists('wc_get_products')
            ? wc_get_products(['status' => 'publish', 'limit' => 5, 'orderby' => 'rand'])
            : [];

        foreach ($fallback as $product) {
            if ($product->is_in_stock()) {
                $out[] = $this->summarize($product);
            }
        }

        return $out;
    }

    private function summarize(object $product): array {
        $imageId = method_exists($product, 'get_image_id') ? $product->get_image_id() : 0;

        return [
            'product_id' => $product->get_id(),
            'name' => $product->get_name(),
            'price' => $product->get_price(),
            'image' => $imageId ? wp_get_attachment_image_url($imageId, 'thumbnail') : '',
            'sku' => method_exists($product, 'get_sku') ? $product->get_sku() : '',
        ];
    }
}
