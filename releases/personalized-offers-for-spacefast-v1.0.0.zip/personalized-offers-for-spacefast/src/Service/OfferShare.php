<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Value\OfferCopy;

/**
 * How a public offer's page looks when shared: the link card social
 * networks build from its Open Graph tags (OfferPageRenderer adds them to
 * public offer pages), and the text the Social share modal starts from.
 */
final class OfferShare {
    /** Longest description in the card; networks cut longer ones. */
    private const DESCRIPTION = 200;

    /**
     * @return array{title: string, description: string, image: string, site_name: string}
     */
    public static function card(array $offerJson): array {
        $texts = OfferCopy::textsByType(OfferCopy::fields($offerJson));
        $description = '';

        foreach (['body', 'subheadline', 'overheadline', 'additional'] as $type) {
            if ([] !== ($texts[$type] ?? [])) {
                $description = (string) $texts[$type][0];
                break;
            }
        }

        $description = trim((string) preg_replace('/\s+/', ' ', $description));

        if (mb_strlen($description) > self::DESCRIPTION) {
            $description = rtrim(mb_substr($description, 0, self::DESCRIPTION - 1)) . '…';
        }

        return [
            'title' => sanitize_text_field((string) ($offerJson['headline'] ?? '')) ?: __('Picked just for you', 'personalized-offers-for-spacefast'),
            'description' => $description,
            'image' => self::image(is_array($offerJson['product_picks'] ?? null) ? $offerJson['product_picks'] : []),
            'site_name' => wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES),
        ];
    }

    /** The first pick's image, large enough for a link card (absolute URL). */
    private static function image(array $picks): string {
        if (!function_exists('wc_get_product')) {
            return '';
        }

        foreach ($picks as $pick) {
            $product = is_array($pick) ? wc_get_product((int) ($pick['product_id'] ?? 0)) : null;
            $imageId = $product ? (int) $product->get_image_id() : 0;

            if ($imageId > 0) {
                return (string) wp_get_attachment_image_url($imageId, 'large');
            }
        }

        return '';
    }
}
