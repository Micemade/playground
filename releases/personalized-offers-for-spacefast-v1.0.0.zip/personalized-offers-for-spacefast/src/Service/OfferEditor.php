<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Enum\OfferType;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\RecipientRepository;
use Micemade\PersonalizedOffers\Repository\TemplateRepository;
use Micemade\PersonalizedOffers\Value\OfferCopy;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;
use WP_Error;

/**
 * Manual edits to a generated offer (copy, product picks, expiry and
 * template), offers written by hand (Create new offer), and unsaved drafts
 * for the live preview. The form searches the whole catalog (WC Store API),
 * so picks may be any published product that can go in a cart; the
 * customer's shortlist, or the store's bestsellers for a public offer, is
 * offered as suggestions.
 */
final class OfferEditor {
    /** Most customers in one group offer. */
    public const MAX_RECIPIENTS = 100;

    public function __construct(
        private readonly OfferRepository $offers,
        private readonly OfferPipeline $pipeline,
        private readonly TemplateRepository $templates,
        private readonly ProductVariations $variations = new ProductVariations(),
        private readonly RecipientRepository $recipients = new RecipientRepository(),
        private readonly TokenService $tokens = new TokenService(),
        private readonly CouponFactory $coupons = new CouponFactory(),
    ) {}

    /**
     * Everything the edit form needs.
     */
    public function editable(int $offerId): array|WP_Error {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return new WP_Error('offer_not_found', __('Offer not found.', 'personalized-offers-for-spacefast'));
        }

        $json = is_array($offer['offer_data']['offer_json'] ?? null) ? $offer['offer_data']['offer_json'] : [];
        $picks = [];

        foreach ((array) ($json['product_picks'] ?? []) as $pick) {
            if (is_array($pick)) {
                $picks[(int) ($pick['product_id'] ?? 0)] = $pick;
            }
        }

        $copy = ['headline' => (string) ($json['headline'] ?? ''), 'button_text' => (string) ($json['button_text'] ?? ''), 'fields' => OfferCopy::fields($json)];

        $type = self::typeOf($offer);
        $user = OfferType::Single === $type && (int) $offer['user_id'] > 0 ? get_userdata((int) $offer['user_id']) : false;
        $guest = OfferType::Single === $type && !$user ? (string) ($offer['guest_email'] ?? '') : '';

        return $copy + [
            'type' => $type->value,
            // The type, customer and group can all be changed while editing.
            'customer' => $user
                ? ['id' => $user->ID, 'name' => $user->display_name, 'email' => $user->user_email]
                : ('' !== $guest ? self::guestCustomer($guest, (array) ($offer['offer_data']['profile'] ?? [])) : null),
            'max_recipients' => self::MAX_RECIPIENTS,
            'expires_on' => '' !== (string) ($offer['expires_at'] ?? '') ? get_date_from_gmt((string) $offer['expires_at'], 'Y-m-d') : '',
            'template_id' => (int) ($offer['offer_data']['template_id'] ?? 0),
            'template_outdated' => $this->templateOutdated($offer),
            'usage_limit' => (int) $offer['max_uses'] > 0,
            'max_uses' => (int) $offer['max_uses'] > 0 ? (int) $offer['max_uses'] : OfferLimits::defaultMax(),
            'used_count' => (int) $offer['used_count'],
            // The coupon's own settings; an offer without one gets the defaults, created on save.
            'coupon' => $this->coupons->settings((string) ($offer['coupon_code'] ?? '')) ?? CouponFactory::defaults(),
            'coupon_missing' => null === $this->coupons->find((string) ($offer['coupon_code'] ?? '')),
            'picks' => $this->pickRows($picks),
            'suggested' => match ($type) {
                OfferType::Single => $this->suggested((array) ($offer['offer_data']['shortlist'] ?? [])),
                OfferType::Group => $this->groupSuggestions(array_column($this->recipients->forOffer($offerId), 'user_id')),
                OfferType::Public => $this->bestsellers(),
            },
            'limits' => self::limits(),
            'field_types' => OfferCopy::typeLabels(),
        ] + (OfferType::Group === $type ? $this->recipientRows($offer) : ['recipients' => [], 'page_url' => '']);
    }

    /**
     * Whether the offer's copy of its template differs from the template as
     * saved now. Offers follow their template (OfferPipeline::syncTemplate()),
     * so this is rare, e.g. an offer that was being built during the save.
     */
    private function templateOutdated(array $offer): bool {
        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $templateId = (int) ($offerData['template_id'] ?? 0);
        $design = $templateId > 0 ? $this->pipeline->designFor($templateId) : [];

        return !$design instanceof WP_Error && [] !== $design && OfferPipeline::templateChanged($offerData, $design);
    }

    /**
     * A group offer's recipients for the form, each with the personal link
     * to send them once the page is published to Spacefast.
     *
     * @return array{recipients: list<array{id: int, name: string, email: string, status: string, used_count: int, link: string}>, page_url: string}
     */
    private function recipientRows(array $offer): array {
        $pageUrl = OfferPublisher::pageUrl($offer);
        $rows = [];

        foreach ($this->recipients->forOffer((int) $offer['id']) as $recipient) {
            if (RecipientRepository::REVOKED === $recipient['status']) {
                continue;
            }

            $user = get_userdata($recipient['user_id']);
            $rows[] = [
                'id' => $recipient['user_id'],
                'name' => $user ? $user->display_name : '#' . $recipient['user_id'],
                'email' => $user ? $user->user_email : '',
                'status' => $recipient['status'],
                'used_count' => $recipient['used_count'],
                'link' => OfferPublisher::recipientUrl($offer, $recipient),
            ];
        }

        return ['recipients' => $rows, 'page_url' => $pageUrl];
    }

    /**
     * The edit form for a new offer: empty copy, the default expiry and
     * template, no picks, and as suggestions the customer's shortlist, the
     * products a group's customers have in common, or for a public offer the
     * store's bestsellers.
     *
     * @param list<int> $recipientIds A group offer's customers so far.
     */
    public function blank(int $userId, OfferType $type = OfferType::Single, array $recipientIds = [], string $guestEmail = ''): array|WP_Error {
        [$userId, $guestEmail] = self::customerOf($userId, $guestEmail);
        $shortlist = $this->shortlist($type, $userId, $guestEmail);

        if ($shortlist instanceof WP_Error) {
            return $shortlist;
        }

        $user = $type->isPersonal() && $userId > 0 ? get_userdata($userId) : false;
        $days = max(1, (int) Settings::get('offer_default_expiry', 30));

        return [
            'headline' => '',
            'button_text' => '',
            'fields' => [],
            'expires_on' => wp_date('Y-m-d', strtotime('+' . $days . ' days')),
            'template_id' => $this->templates->defaultId(),
            'usage_limit' => true,
            'max_uses' => OfferLimits::defaultMax(),
            'type' => $type->value,
            'used_count' => 0,
            'coupon' => CouponFactory::defaults(),
            'picks' => [],
            'suggested' => match ($type) {
                OfferType::Single => $this->suggested($shortlist['items']),
                OfferType::Group => $this->groupSuggestions($recipientIds),
                OfferType::Public => $this->bestsellers(),
            },
            'limits' => self::limits(),
            'field_types' => OfferCopy::typeLabels(),
            'customer' => $user
                ? ['id' => $userId, 'name' => $user->display_name, 'email' => $user->user_email]
                : (OfferType::Single === $type && '' !== $guestEmail ? self::guestCustomer($guestEmail, $shortlist['profile']) : null),
            'recipients' => [],
            'max_recipients' => self::MAX_RECIPIENTS,
        ];
    }

    /**
     * Creates a ready offer from the Create new offer form.
     *
     * @param array{headline?: string, fields?: list<array{type: string, text: string}>,
     *              picks?: list<array{product_id: int, title?: string, story?: string, reason?: string}>, expires_on?: string, template_id?: int} $input
     */
    public function create(int $userId, int $initiatorId, array $input, OfferType $type = OfferType::Single, string $guestEmail = ''): int|WP_Error {
        [$userId, $guestEmail] = $type->isPersonal() ? self::customerOf($userId, $guestEmail) : [0, ''];
        $shortlist = $this->shortlist($type, $userId, $guestEmail);

        if ($shortlist instanceof WP_Error) {
            return $shortlist;
        }

        $json = $this->copy($input + ['headline' => '', 'fields' => []], [], true);

        if ($json instanceof WP_Error) {
            return $json;
        }

        $picks = $this->picks((array) ($input['picks'] ?? []), []);

        if ($picks instanceof WP_Error) {
            return $picks;
        }

        $expiresAt = $this->expiry((string) ($input['expires_on'] ?? ''));

        if ($expiresAt instanceof WP_Error) {
            return $expiresAt;
        }

        $maxUses = $this->maxUses($input['max_uses'] ?? OfferLimits::defaultMax());

        if ($maxUses instanceof WP_Error) {
            return $maxUses;
        }

        if (OfferType::Group === $type) {
            $recipientIds = $this->recipientIds((array) ($input['recipients'] ?? []));

            if ($recipientIds instanceof WP_Error) {
                return $recipientIds;
            }
        }

        $coupon = array_key_exists('coupon', $input) ? CouponFactory::sanitize($input['coupon']) : null;

        if ($coupon instanceof WP_Error) {
            return $coupon;
        }

        $offerId = $this->pipeline->createManual(
            $userId,
            $initiatorId,
            max(0, (int) ($input['template_id'] ?? 0)),
            $shortlist['profile'],
            $shortlist['items'],
            $json + ['product_picks' => $picks],
            $expiresAt,
            $maxUses,
            $type,
            isset($recipientIds) ? array_map(static fn (int $id): string => (string) get_userdata($id)->user_email, $recipientIds) : [],
            $coupon,
            $guestEmail,
        );

        if (isset($recipientIds) && is_int($offerId)) {
            $this->syncRecipients($offerId, $recipientIds);
            $this->tagSegment($offerId, $input['segment'] ?? null);
        }

        return $offerId;
    }

    /**
     * Notes on a group offer the segment it was made for.
     *
     * @param mixed $segment {id, name} from the caller, which checked it.
     */
    private function tagSegment(int $offerId, mixed $segment): void {
        $offer = is_array($segment) && '' !== (string) ($segment['id'] ?? '') ? $this->offers->find($offerId) : null;

        if (null !== $offer) {
            $this->offers->update($offerId, ['offer_data' => ['segment' => [
                'id' => (string) $segment['id'],
                'name' => sanitize_text_field((string) ($segment['name'] ?? '')),
            ]] + (array) $offer['offer_data']]);
        }
    }

    /**
     * An unsaved offer row for the form's live preview: the saved offer (or
     * a new one) with the form's copy, picks, expiry and template. Lenient,
     * since the form may be half filled in; nothing is stored.
     */
    public function draft(int $offerId, array $input): array|WP_Error {
        $offer = $offerId > 0 ? $this->offers->find($offerId) : ['id' => 0, 'token' => '', 'coupon_code' => '', 'offer_data' => []];

        if (null === $offer) {
            return new WP_Error('offer_not_found', __('Offer not found.', 'personalized-offers-for-spacefast'));
        }

        // The type chosen in the form, which may not be saved yet.
        $type = OfferType::tryFrom((string) ($input['type'] ?? ''));

        if (null !== $type) {
            $offer['type'] = $type->value;
        }

        $offerData = is_array($offer['offer_data']) ? $offer['offer_data'] : [];
        $templateId = max(0, (int) ($input['template_id'] ?? 0));

        // A saved offer's copy of its template is current (syncTemplate()); it is
        // read again when a different template is chosen or the form asks for it.
        if ($offerId <= 0 || $templateId !== (int) ($offerData['template_id'] ?? 0) || !empty($input['refresh_template'])) {
            $design = $this->pipeline->designFor($templateId);
            $offerData = OfferPipeline::withDesign($offerData, $design instanceof WP_Error ? [] : $design);
        }

        $json = $this->copy($input, is_array($offerData['offer_json'] ?? null) ? $offerData['offer_json'] : [], false);
        $json['product_picks'] = [];

        foreach (array_slice((array) ($input['picks'] ?? []), 0, OfferCopy::MAX_PICKS) as $pick) {
            $json['product_picks'][] = [
                'product_id' => (int) ($pick['product_id'] ?? 0),
                'variation_id' => max(0, (int) ($pick['variation_id'] ?? 0)),
                'title' => sanitize_text_field((string) ($pick['title'] ?? '')),
                'story' => sanitize_textarea_field((string) ($pick['story'] ?? '')),
                'reason' => sanitize_text_field((string) ($pick['reason'] ?? '')),
            ];
        }

        $offerData['offer_json'] = $json;
        $offer['offer_data'] = $offerData;

        $expiresAt = $this->expiry((string) ($input['expires_on'] ?? ''));
        $offer['expires_at'] = $expiresAt instanceof WP_Error ? ($offer['expires_at'] ?? '') : $expiresAt;

        return $offer;
    }

    /**
     * Applies an edit. Only the keys present in $input change.
     *
     * `type` changes who the offer is for. A single offer needs a customer
     * (`customer_id`, or its current one) and a group offer its recipients;
     * leaving a group revokes the recipients' links; the coupon is set up
     * again for the new type, and a published page is marked outdated.
     *
     * @param array{headline?: string, fields?: list<array{type: string, text: string}>,
     *              picks?: list<array{product_id: int, title?: string, story?: string, reason?: string}>, expires_on?: string, template_id?: int} $input
     */
    public function update(int $offerId, array $input): true|WP_Error {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return new WP_Error('offer_not_found', __('Offer not found.', 'personalized-offers-for-spacefast'));
        }

        if (OfferStatus::Building->value === $offer['status']) {
            return new WP_Error('offer_busy', __('This offer is still being generated. Try again in a moment.', 'personalized-offers-for-spacefast'));
        }

        $oldType = self::typeOf($offer);
        $type = array_key_exists('type', $input) ? OfferType::tryFrom((string) $input['type']) : $oldType;

        if (null === $type) {
            return new WP_Error('offer_type_invalid', __('Choose who the offer is for.', 'personalized-offers-for-spacefast'));
        }

        $retyped = $type !== $oldType;

        // A single offer's customer, when it changes (or the offer becomes single).
        $customer = null;

        if (OfferType::Single === $type && ($retyped || array_key_exists('customer_id', $input) || array_key_exists('customer_email', $input))) {
            $changesCustomer = array_key_exists('customer_id', $input) || array_key_exists('customer_email', $input);
            [$customerId, $guestEmail] = $changesCustomer
                ? self::customerOf((int) ($input['customer_id'] ?? 0), (string) ($input['customer_email'] ?? ''))
                : [(int) $offer['user_id'], (string) ($offer['guest_email'] ?? '')];
            $user = $customerId > 0 ? get_userdata($customerId) : false;

            if ((!$user || '' === $user->user_email) && '' === $guestEmail) {
                return new WP_Error('offer_customer_invalid', __('Choose a customer with an email address for this offer.', 'personalized-offers-for-spacefast'));
            }

            if ($retyped || $customerId !== (int) $offer['user_id'] || $guestEmail !== (string) ($offer['guest_email'] ?? '')) {
                $customer = $this->shortlist(OfferType::Single, $customerId, $guestEmail);

                if ($customer instanceof WP_Error) {
                    return $customer;
                }

                $customer['id'] = $customerId;
                $customer['guest_email'] = $guestEmail;
            }
        }

        if (OfferType::Group === $type && $retyped && !array_key_exists('recipients', $input)) {
            return new WP_Error('offer_no_recipients', __('Add at least one customer to the group.', 'personalized-offers-for-spacefast'));
        }

        if (OfferType::Group === $type && array_key_exists('recipients', $input)) {
            $recipientIds = $this->recipientIds((array) $input['recipients']);

            if ($recipientIds instanceof WP_Error) {
                return $recipientIds;
            }
        }

        // The coupon's settings; its code may stay its own.
        if (array_key_exists('coupon', $input)) {
            $existing = $this->coupons->find((string) ($offer['coupon_code'] ?? ''));
            $coupon = CouponFactory::sanitize($input['coupon'], null !== $existing ? $existing->get_code() : '');

            if ($coupon instanceof WP_Error) {
                return $coupon;
            }
        }

        // Template first: restyle() rewrites the design keys of offer_data.
        if (isset($input['template_id'])) {
            $restyled = $this->pipeline->restyle($offerId, max(0, (int) $input['template_id']));

            if ($restyled instanceof WP_Error) {
                return $restyled;
            }

            $offer = (array) $this->offers->find($offerId);
        }

        $offerData = is_array($offer['offer_data']) ? $offer['offer_data'] : [];
        $json = is_array($offerData['offer_json'] ?? null) ? $offerData['offer_json'] : [];
        $copyChanged = [] !== array_intersect(['headline', 'button_text', 'fields'], array_keys($input));
        $json = $this->copy($input, $json, true);

        if ($json instanceof WP_Error) {
            return $json;
        }

        if (array_key_exists('picks', $input)) {
            $picks = $this->picks((array) $input['picks'], (array) ($json['product_picks'] ?? []));

            if ($picks instanceof WP_Error) {
                return $picks;
            }

            $json['product_picks'] = $picks;
            $copyChanged = true;
        }

        $update = [];

        if ($retyped) {
            $update['type'] = $type;
        }

        if (null !== $customer) {
            $update['user_id'] = $customer['id'];
            $update['guest_email'] = '' !== $customer['guest_email'] ? $customer['guest_email'] : null;
            $update['consent_given'] = !empty($customer['profile']['consent_given']) ? 1 : 0;
            $offerData['profile'] = $customer['profile'];
            $offerData['shortlist'] = $customer['items'];
        } elseif ($retyped && !$type->isPersonal()) {
            $update['user_id'] = 0;
            $update['guest_email'] = null;
            $update['consent_given'] = 0;
            $offerData['profile'] = [];
            $offerData['shortlist'] = [];
        }

        if ($copyChanged) {
            if ([] === $json) {
                return new WP_Error('offer_not_generated', __('This offer has no generated content to edit yet.', 'personalized-offers-for-spacefast'));
            }

            $offerData['offer_json'] = $json;
            $offerData['edited_at'] = current_time('mysql', true);
        }

        if (array_key_exists('expires_on', $input)) {
            $expiresAt = $this->expiry((string) $input['expires_on']);

            if ($expiresAt instanceof WP_Error) {
                return $expiresAt;
            }

            $update['expires_at'] = $expiresAt;
            $this->updateCouponExpiry((string) ($offer['coupon_code'] ?? ''), $expiresAt);

            if (OfferStatus::Expired->value === $offer['status'] && strtotime($expiresAt . ' UTC') > time()) {
                $update['status'] = $this->activeStatus($offerData);
            }
        }

        if (array_key_exists('max_uses', $input)) {
            $maxUses = $this->maxUses($input['max_uses']);

            if ($maxUses instanceof WP_Error) {
                return $maxUses;
            }

            $update['max_uses'] = $maxUses;
        }

        // The usage limit, or what counts against it, changed.
        if (isset($update['max_uses']) || $retyped) {
            $maxUses = (int) ($update['max_uses'] ?? $offer['max_uses']);

            // A group offer's limit is per recipient; settleGroup() applies it below.
            $reached = OfferType::Group !== $type && OfferLimits::reached(['max_uses' => $maxUses] + $offer);

            // Raising or removing the limit brings back an offer that had used it up.
            if (OfferType::Group !== $type && OfferLimits::usedUp($offer) && !$reached) {
                $expiresAt = (string) ($update['expires_at'] ?? $offer['expires_at']);
                $update['status'] = strtotime($expiresAt . ' UTC') > time() ? $this->activeStatus($offerData) : OfferStatus::Expired;
                unset($offerData['revoked_reason']);
            } elseif ($reached && in_array(($update['status'] ?? OfferStatus::tryFrom((string) $offer['status'])), [OfferStatus::Ready, OfferStatus::Sent], true)) {
                // Lowered to the number of orders already placed.
                $update['status'] = OfferStatus::Used;
            }
        }

        // A published page no longer matches; the Offers tab prompts to update the Space.
        if (!empty($offerData['spacefast']['space_id']) && ($copyChanged || isset($input['template_id']) || $retyped)) {
            $offerData['spacefast']['outdated'] = true;
        }

        $update['offer_data'] = $offerData;
        $result = $this->offers->update($offerId, $update);

        if ($result instanceof WP_Error) {
            return $result;
        }

        // No longer a group: the recipients' personal links stop working.
        if ($retyped && OfferType::Group === $oldType) {
            $this->syncRecipients($offerId, []);
        }

        if (OfferType::Group === $type && (isset($recipientIds) || isset($update['max_uses']) || $retyped)) {
            if (isset($recipientIds)) {
                $this->syncRecipients($offerId, $recipientIds);
            }

            $this->settleGroup($offerId);
        }

        $current = (array) $this->offers->find($offerId);

        if ($retyped || isset($recipientIds) || OfferPublisher::needsSync($current)) {
            /**
             * The offer's type, recipients or status changed: its Spacefast
             * Space (if any) follows (OfferPublisher::syncAccess()).
             */
            do_action(JobScheduler::ACCESS_HOOK, $offerId);
        }

        $couponCode = (string) ($offer['coupon_code'] ?? '');

        if (isset($coupon)) {
            $productIds = OfferPipeline::productIds((array) ($offerData['offer_json'] ?? []));
            $saved = null !== $this->coupons->find($couponCode)
                ? $this->coupons->update($couponCode, $coupon, $productIds)
                : $this->pipeline->addCoupon((array) $this->offers->find($offerId), $coupon);

            if ($saved instanceof WP_Error) {
                return $saved;
            }

            if ($saved !== $couponCode) {
                $this->offers->update($offerId, ['coupon_code' => $saved]);
                $couponCode = $saved;
            }
        } elseif (array_key_exists('picks', $input)) {
            // Percentage and fixed product discounts follow the offer's products.
            $this->coupons->restrictTo($couponCode, OfferPipeline::productIds((array) ($offerData['offer_json'] ?? [])));
        }

        if ($retyped || null !== $customer || isset($update['max_uses']) || (OfferType::Group === $type && isset($recipientIds))) {
            $this->pipeline->syncCoupon((array) $this->offers->find($offerId));
        }

        return true;
    }

    /**
     * The chosen customers of a group offer: existing accounts with an email
     * address, 1 to MAX_RECIPIENTS of them.
     *
     * @return list<int>|WP_Error
     */
    private function recipientIds(array $ids): array|WP_Error {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));

        if ([] === $ids) {
            return new WP_Error('offer_no_recipients', __('Add at least one customer to the group.', 'personalized-offers-for-spacefast'));
        }

        if (count($ids) > self::MAX_RECIPIENTS) {
            return new WP_Error('offer_too_many_recipients', sprintf(
                /* translators: %d: most customers in a group offer. */
                __('A group offer can have at most %d customers.', 'personalized-offers-for-spacefast'),
                self::MAX_RECIPIENTS,
            ));
        }

        foreach ($ids as $id) {
            $user = get_userdata($id);

            if (!$user || '' === $user->user_email) {
                return new WP_Error('offer_recipient_invalid', sprintf(
                    /* translators: %d: user ID. */
                    __('Customer #%d does not exist or has no email address.', 'personalized-offers-for-spacefast'),
                    $id,
                ));
            }
        }

        return $ids;
    }

    /**
     * Makes the group exactly $userIds: new customers get a personal token;
     * removed ones lose their link (kept as revoked if they had used it, so
     * their orders stay accounted for).
     *
     * @param list<int> $userIds
     */
    private function syncRecipients(int $offerId, array $userIds): void {
        $current = [];

        foreach ($this->recipients->forOffer($offerId) as $recipient) {
            $current[$recipient['user_id']] = $recipient;
        }

        foreach ($userIds as $userId) {
            if (!isset($current[$userId])) {
                $token = $this->tokens->generate();
                $this->recipients->create($offerId, $userId, $token, $this->tokens->hash($token));
            } elseif (RecipientRepository::REVOKED === $current[$userId]['status']) {
                // Back in the group; settleGroup() decides active or used.
                $this->recipients->update($current[$userId]['id'], ['status' => RecipientRepository::ACTIVE]);
            }
        }

        foreach (array_diff_key($current, array_flip($userIds)) as $recipient) {
            if ($recipient['used_count'] > 0) {
                $this->recipients->update($recipient['id'], ['status' => RecipientRepository::REVOKED]);
            } else {
                $this->recipients->delete($recipient['id']);
            }
        }
    }

    /**
     * Applies a group offer's per-recipient limit: recipients who reached it
     * are used, the others active; the offer is Used once nobody can use it
     * any more, and comes back when someone can.
     */
    private function settleGroup(int $offerId): void {
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return;
        }

        $max = (int) $offer['max_uses'];
        $active = 0;

        foreach ($this->recipients->forOffer($offerId) as $recipient) {
            if (RecipientRepository::REVOKED === $recipient['status']) {
                continue;
            }

            $status = $max > 0 && $recipient['used_count'] >= $max ? RecipientRepository::USED : RecipientRepository::ACTIVE;
            $active += RecipientRepository::ACTIVE === $status ? 1 : 0;

            if ($status !== $recipient['status']) {
                $this->recipients->update($recipient['id'], ['status' => $status]);
            }
        }

        $status = OfferStatus::tryFrom((string) $offer['status']);
        $offerData = is_array($offer['offer_data']) ? $offer['offer_data'] : [];

        if (0 === $active && in_array($status, [OfferStatus::Ready, OfferStatus::Sent], true)) {
            $this->offers->update($offerId, ['status' => OfferStatus::Used]);
        } elseif ($active > 0 && OfferStatus::Used === $status) {
            $this->offers->update($offerId, ['status' => strtotime($offer['expires_at'] . ' UTC') > time() ? $this->activeStatus($offerData) : OfferStatus::Expired]);
        }
    }

    /**
     * Suggestions for a group offer: products on several of its customers'
     * shortlists first (from the first ten customers, to keep it quick),
     * then the store's bestsellers.
     *
     * @param list<int> $userIds
     * @return list<int>
     */
    private function groupSuggestions(array $userIds): array {
        $votes = [];

        foreach (array_slice(array_values(array_unique(array_map('intval', $userIds))), 0, 10) as $userId) {
            $shortlist = $userId > 0 ? $this->pipeline->shortlistFor($userId) : null;

            foreach (is_array($shortlist) ? $this->suggested($shortlist['items']) : [] as $productId) {
                $votes[$productId] = ($votes[$productId] ?? 0) + 1;
            }
        }

        arsort($votes);

        return array_slice(array_values(array_unique([...array_keys($votes), ...$this->bestsellers()])), 0, 30);
    }

    /**
     * $json (in the current shape, see OfferCopy::normalize()) with the
     * headline and fields present in $input, sanitized and cut to their
     * limits. Strict mode (saving) rejects an empty headline and leaves out
     * fields without text; the draft preview keeps them.
     */
    private function copy(array $input, array $json, bool $strict): array|WP_Error {
        $json = OfferCopy::normalize($json);

        if (array_key_exists('headline', $input)) {
            $headline = mb_substr(trim(sanitize_text_field((string) $input['headline'])), 0, OfferCopy::LIMITS['headline']);

            if ($strict && '' === $headline) {
                return new WP_Error('offer_field_empty', __('The headline cannot be empty.', 'personalized-offers-for-spacefast'));
            }

            $json['headline'] = $headline;
        }

        if (array_key_exists('button_text', $input)) {
            // Optional: empty leaves the block's own text (or the default).
            $json['button_text'] = mb_substr(trim(sanitize_text_field((string) $input['button_text'])), 0, OfferCopy::LIMITS['button_text']);
        }

        if (array_key_exists('fields', $input)) {
            $json['fields'] = OfferCopy::sanitizeFields($input['fields'], $strict);
        }

        return $json;
    }

    /**
     * Character limits for the form, with the most picks.
     */
    private static function limits(): array {
        return OfferCopy::LIMITS + ['max_picks' => OfferCopy::MAX_PICKS];
    }

    /**
     * The picked products as the form lists them, in pick order.
     *
     * @param array<int, array> $picks Current picks keyed by product ID.
     */
    private function pickRows(array $picks): array {
        $rows = [];

        foreach ($picks as $productId => $pick) {
            $product = function_exists('wc_get_product') ? wc_get_product((int) $productId) : null;
            $imageId = $product ? (int) $product->get_image_id() : 0;

            $rows[] = [
                'product_id' => (int) $productId,
                'name' => $product ? $product->get_name() : '#' . $productId,
                'price' => $product ? html_entity_decode(wp_strip_all_tags($product->get_price_html()), ENT_QUOTES) : '',
                'image' => $imageId ? (string) wp_get_attachment_image_url($imageId, 'woocommerce_gallery_thumbnail') : '',
                'in_stock' => $product ? $product->is_in_stock() : false,
                'variation_id' => (int) ($pick['variation_id'] ?? 0),
                'variations' => $this->variations->options((int) $productId),
                'title' => (string) ($pick['title'] ?? ''),
                'story' => (string) ($pick['story'] ?? ''),
                'reason' => (string) ($pick['reason'] ?? ''),
            ];
        }

        return $rows;
    }

    /**
     * Product IDs the shortlist suggests for the customer, best first.
     *
     * @return list<int>
     */
    private function suggested(array $shortlist): array {
        return array_values(array_filter(array_map(static fn (mixed $item): int => (int) ($item['product_id'] ?? 0), $shortlist)));
    }

    /**
     * @return list<array{product_id: int, variation_id: int, title: string, story: string, reason: string}>|WP_Error
     */
    private function picks(array $input, array $current): array|WP_Error {
        // Picks saved before the form sent variations keep theirs.
        $variations = [];

        foreach ($current as $pick) {
            if (is_array($pick)) {
                $variations[(int) ($pick['product_id'] ?? 0)] = (int) ($pick['variation_id'] ?? 0);
            }
        }

        $picks = [];

        foreach ($input as $pick) {
            $productId = (int) ($pick['product_id'] ?? 0);

            if (!$this->pickable($productId)) {
                return new WP_Error('offer_pick_invalid', sprintf(
                    /* translators: %d: product ID. */
                    __('Product #%d cannot be offered: it is not published or cannot be added to a cart.', 'personalized-offers-for-spacefast'),
                    $productId,
                ));
            }

            $variationId = array_key_exists('variation_id', $pick) ? max(0, (int) $pick['variation_id']) : ($variations[$productId] ?? 0);

            if (!$this->variations->valid($productId, $variationId)) {
                return new WP_Error('offer_variation_invalid', sprintf(
                    /* translators: %d: product ID. */
                    __('The chosen variation does not belong to product #%d.', 'personalized-offers-for-spacefast'),
                    $productId,
                ));
            }

            $picks[$productId] = [
                'product_id' => $productId,
                'variation_id' => $variationId,
                'title' => mb_substr(trim(sanitize_text_field((string) ($pick['title'] ?? ''))), 0, OfferCopy::LIMITS['title']),
                'story' => mb_substr(trim(sanitize_textarea_field((string) ($pick['story'] ?? ''))), 0, OfferCopy::LIMITS['story']),
                'reason' => mb_substr(trim(sanitize_text_field((string) ($pick['reason'] ?? ''))), 0, OfferCopy::LIMITS['reason']),
            ];
        }

        if ([] === $picks) {
            return new WP_Error('offer_picks_empty', __('Pick at least one product.', 'personalized-offers-for-spacefast'));
        }

        if (count($picks) > OfferCopy::MAX_PICKS) {
            return new WP_Error('offer_picks_many', sprintf(
                /* translators: %d: maximum number of products. */
                __('Pick at most %d products.', 'personalized-offers-for-spacefast'),
                OfferCopy::MAX_PICKS,
            ));
        }

        return array_values($picks);
    }

    /**
     * Status of a usable offer: Sent once it was published or downloaded.
     */
    private function activeStatus(array $offerData): OfferStatus {
        return !empty($offerData['spacefast']['space_id']) || !empty($offerData['exported_at']) ? OfferStatus::Sent : OfferStatus::Ready;
    }

    /**
     * The form's usage limit: 0 for no limit, otherwise 1 to OfferLimits::MAX.
     */
    private function maxUses(mixed $value): int|WP_Error {
        $maxUses = is_numeric($value) ? (int) $value : -1;

        if ($maxUses < 0 || $maxUses > OfferLimits::MAX) {
            return new WP_Error('offer_max_uses_invalid', sprintf(
                /* translators: %d: highest allowed number of uses. */
                __('Max uses per offer must be between 1 and %d.', 'personalized-offers-for-spacefast'),
                OfferLimits::MAX,
            ));
        }

        return $maxUses;
    }

    /**
     * A published product the checkout hand-off can add to a cart. Grouped
     * and external products cannot be bought through the offer.
     */
    private function pickable(int $productId): bool {
        $product = $productId > 0 && function_exists('wc_get_product') ? wc_get_product($productId) : null;

        return $product instanceof \WC_Product
            && 'publish' === $product->get_status()
            && !in_array($product->get_type(), ['grouped', 'external'], true)
            && $product->is_purchasable();
    }

    /**
     * Offers expire at the end of the chosen day, in the site's time zone; stored in UTC.
     */
    private function expiry(string $date): string|WP_Error {
        $local = \DateTimeImmutable::createFromFormat('!Y-m-d', $date, wp_timezone());

        if (false === $local || $local->format('Y-m-d') !== $date) {
            return new WP_Error('offer_expiry_invalid', __('Enter a valid expiry date.', 'personalized-offers-for-spacefast'));
        }

        $end = $local->setTime(23, 59, 59);

        if ($end->getTimestamp() < time()) {
            return new WP_Error('offer_expiry_past', __('The expiry date must be today or later.', 'personalized-offers-for-spacefast'));
        }

        return $end->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s');
    }

    private function updateCouponExpiry(string $code, string $expiresAt): void {
        $this->updateCoupon($code, static fn (\WC_Coupon $coupon) => $coupon->set_date_expires((int) strtotime($expiresAt . ' UTC')));
    }

    /**
     * @param callable(\WC_Coupon): mixed $change
     */
    private function updateCoupon(string $code, callable $change): void {
        if ('' === $code || !class_exists('WC_Coupon') || !function_exists('wc_get_coupon_id_by_code')) {
            return;
        }

        $couponId = (int) wc_get_coupon_id_by_code($code);

        if ($couponId > 0) {
            $coupon = new \WC_Coupon($couponId);
            $change($coupon);
            $coupon->save();
        }
    }

    /**
     * [user ID, guest email] of a customer given either way: an email of an
     * account means that account; a guest email is normalized.
     *
     * @return array{0: int, 1: string}
     */
    private static function customerOf(int $userId, string $email): array {
        if ($userId > 0) {
            return [$userId, ''];
        }

        $email = strtolower(sanitize_email($email));
        $user = '' !== $email ? get_user_by('email', $email) : false;

        return $user ? [(int) $user->ID, ''] : [0, $email];
    }

    /**
     * The customer's profile and shortlist for a type; none for group and public offers.
     *
     * @return array{profile: array, items: list<array>}|WP_Error
     */
    private function shortlist(OfferType $type, int $userId, string $guestEmail): array|WP_Error {
        if (!$type->isPersonal()) {
            return ['profile' => [], 'items' => []];
        }

        return $userId > 0 || '' === $guestEmail ? $this->pipeline->shortlistFor($userId) : $this->pipeline->shortlistForGuest($guestEmail);
    }

    /**
     * A guest customer as the form shows a customer.
     *
     * @return array{id: int, name: string, email: string, guest: bool}
     */
    public static function guestCustomer(string $email, array $profile = []): array {
        $name = trim((string) ($profile['user_name'] ?? ''));

        return ['id' => 0, 'name' => '' !== $name ? $name : $email, 'email' => $email, 'guest' => true];
    }

    public static function typeOf(array $offer): OfferType {
        return OfferType::tryFrom((string) ($offer['type'] ?? '')) ?? OfferType::Single;
    }

    /**
     * Suggestions for a public offer: the store's best-selling products
     * that can go in a cart.
     *
     * @return list<int>
     */
    private function bestsellers(): array {
        if (!function_exists('wc_get_products')) {
            return [];
        }

        return array_map('intval', wc_get_products([
            'status' => 'publish',
            'stock_status' => 'instock',
            'type' => ['simple', 'variable'],
            'limit' => 30,
            'orderby' => 'meta_value_num',
            'meta_key' => 'total_sales', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Best sellers, as WooCommerce sorts by popularity; the result is limited.
            'order' => 'DESC',
            'return' => 'ids',
        ]));
    }
}
