<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Value\OfferCopy;
use WC_Product;

/**
 * Builds an offer without AI: products from the customer's shortlist that
 * they have not bought yet, favouring their most-bought categories, and
 * standard wording with their first name. The store manager edits the copy
 * in the Offers tab; the Assistant is the plugin's only use of AI.
 */
final class OfferComposer {
    /** Enough for a small edit; the form allows up to OfferCopy::MAX_PICKS. */
    private const PICKS = 4;

    /**
     * @param array $shortlist Candidates from ShortlistBuilder.
     * @param string $additionalText Exact Additional text for the offer, if the manager gave one.
     * @return array Offer JSON: headline, fields (OfferCopy) and product_picks.
     */
    public function compose(array $profile, array $shortlist, string $additionalText = ''): array {
        $categories = array_values(array_filter(array_map(
            static fn (mixed $cat): int => is_array($cat) ? (int) ($cat['id'] ?? 0) : 0,
            (array) ($profile['preferred_categories'] ?? []),
        )));
        // Term names are stored escaped ("Hoodies &amp; Sweatshirts").
        $categoryNames = array_map(
            static fn (string $name): string => html_entity_decode($name, ENT_QUOTES),
            array_column((array) ($profile['preferred_categories'] ?? []), 'name', 'id'),
        );
        $picks = [];

        foreach ($this->rank($shortlist, $categories, $this->boughtIds($profile)) as [$product, $category]) {
            $picks[] = [
                'product_id' => $product->get_id(),
                'variation_id' => 0,
                'title' => mb_substr($product->get_name(), 0, OfferCopy::LIMITS['title']),
                'story' => mb_substr(trim(wp_strip_all_tags($product->get_short_description() ?: $product->get_description())), 0, OfferCopy::LIMITS['story']),
                'reason' => isset($categoryNames[$category])
                    ? mb_substr(sprintf(
                        /* translators: %s: product category name. */
                        __('From %s, one of your favourite categories.', 'personalized-offers-for-spacefast'),
                        $categoryNames[$category],
                    ), 0, OfferCopy::LIMITS['reason'])
                    : '',
            ];
        }

        $name = trim(strtok((string) ($profile['user_name'] ?? ''), ' ') ?: '');
        $top = (string) ($categoryNames[$categories[0] ?? 0] ?? '');

        $headline = __('A few things we think you’ll love', 'personalized-offers-for-spacefast');
        $fields = [
            ['type' => 'overheadline', 'text' => __('Picked for you', 'personalized-offers-for-spacefast')],
            ['type' => 'greeting', 'text' => '' !== $name
                /* translators: %s: customer's first name. */
                ? sprintf(__('Hi %s,', 'personalized-offers-for-spacefast'), $name)
                : __('Hello,', 'personalized-offers-for-spacefast')],
            ['type' => 'body', 'text' => '' !== $top
                /* translators: %s: the customer's most-bought product category. */
                ? sprintf(__('We put together a small selection with you in mind, starting from what you enjoy most in %s.', 'personalized-offers-for-spacefast'), $top)
                : __('We put together a small selection with you in mind.', 'personalized-offers-for-spacefast')],
            // One field per type, as in the offer form: the manager's text, or a thank-you.
            ['type' => 'additional', 'text' => '' !== trim($additionalText) ? $additionalText : __('Thank you for shopping with us.', 'personalized-offers-for-spacefast')],
        ];

        $copy = [
            'headline' => mb_substr($headline, 0, OfferCopy::LIMITS['headline']),
            'fields' => OfferCopy::sanitizeFields($fields, true),
        ];

        return $copy + ['product_picks' => $picks];
    }

    /**
     * Shortlisted products that can go in a cart, not bought before, those
     * in the customer's favourite categories first (in order of preference).
     *
     * @param list<int> $categories Preferred category IDs, most-bought first.
     * @param list<int> $bought
     * @return list<array{0: WC_Product, 1: int}> Product and the preferred category it matched (0 for none).
     */
    private function rank(array $shortlist, array $categories, array $bought): array {
        $ranked = [];

        foreach ($shortlist as $position => $item) {
            $product = wc_get_product((int) ($item['product_id'] ?? 0));

            if (!$product instanceof WC_Product || in_array($product->get_id(), $bought, true) || !$product->is_purchasable() || in_array($product->get_type(), ['grouped', 'external'], true)) {
                continue;
            }

            // A product in a subcategory belongs to its parents too (a polo in T-shirts is Clothing).
            $own = array_map('intval', $product->get_category_ids());
            $all = array_merge($own, ...array_map(static fn (int $id): array => array_map('intval', get_ancestors($id, 'product_cat', 'taxonomy')), $own));
            $matches = array_values(array_intersect($categories, $all));
            $category = $matches[0] ?? 0;
            $rank = 0 !== $category ? (int) array_search($category, $categories, true) : count($categories);
            $ranked[] = [$rank, $position, $product, $category];
        }

        usort($ranked, static fn (array $a, array $b): int => [$a[0], $a[1]] <=> [$b[0], $b[1]]);

        return array_map(static fn (array $row): array => [$row[2], $row[3]], array_slice($ranked, 0, self::PICKS));
    }

    /**
     * @return list<int>
     */
    private function boughtIds(array $profile): array {
        $ids = [];

        foreach ((array) ($profile['past_orders_meta'] ?? []) as $order) {
            array_push($ids, ...array_map('intval', (array) ($order['product_ids'] ?? [])));
        }

        return array_values(array_unique($ids));
    }
}
