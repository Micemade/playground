<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use WP_Error;

/**
 * Reads a public website's visual vocabulary (colors, fonts, web font
 * stylesheets) so the assistant can design templates "inspired by" it.
 *
 * Uses wp_safe_remote_get(), which refuses private and local addresses.
 */
final class StyleInspector {
    private const MAX_BYTES = 1_500_000;
    private const MAX_STYLESHEETS = 4;

    public function inspect(string $url): array|WP_Error {
        $url = esc_url_raw(trim($url), ['https', 'http']);

        if ('' === $url || !wp_http_validate_url($url)) {
            return new WP_Error('pofsf_style_url', __('Enter a public website address.', 'personalized-offers-for-spacefast'));
        }

        $html = $this->fetch($url);

        if ($html instanceof WP_Error) {
            return $html;
        }

        $css = '';

        if (preg_match_all('#<style[^>]*>(.*?)</style>#is', $html, $styles)) {
            $css .= implode("\n", $styles[1]);
        }

        $fontLinks = [];
        $sheets = 0;

        if (preg_match_all('#<link\b[^>]*>#i', $html, $links)) {
            foreach ($links[0] as $tag) {
                if (!preg_match('#rel=["\']?[^"\'>]*stylesheet#i', $tag) || !preg_match('#href=["\']([^"\']+)["\']#i', $tag, $href)) {
                    continue;
                }

                $sheetUrl = $this->absolute(html_entity_decode($href[1]), $url);
                $host = (string) wp_parse_url($sheetUrl, PHP_URL_HOST);

                if (in_array($host, ['fonts.googleapis.com', 'fonts.bunny.net'], true)) {
                    $fontLinks[] = $sheetUrl;
                    continue;
                }

                if ($sheets < self::MAX_STYLESHEETS) {
                    $sheet = $this->fetch($sheetUrl);
                    $sheets++;

                    if (is_string($sheet)) {
                        $css .= "\n" . $sheet;
                    }
                }
            }
        }

        preg_match('#<title[^>]*>(.*?)</title>#is', $html, $title);
        preg_match('#<meta[^>]+name=["\']theme-color["\'][^>]+content=["\']([^"\']+)#i', $html, $themeColor);

        return [
            'url' => $url,
            'title' => isset($title[1]) ? trim(wp_strip_all_tags(html_entity_decode($title[1]))) : '',
            'theme_color' => $themeColor[1] ?? '',
            'colors' => $this->colors($css . "\n" . $html),
            'color_variables' => $this->colorVariables($css),
            'fonts' => $this->fonts($css),
            'web_font_stylesheets' => array_values(array_unique($fontLinks)),
            'stylesheets_read' => $sheets,
            'note' => 'Colors are ordered by how often they appear. Self-hosted brand fonts cannot be loaded on Spacefast pages; pick a similar Google Font instead.',
        ];
    }

    private function fetch(string $url): string|WP_Error {
        $response = wp_safe_remote_get($url, [
            'timeout' => 15,
            'redirection' => 3,
            'limit_response_size' => self::MAX_BYTES,
            'user-agent' => 'Mozilla/5.0 (compatible; Personalized-Offers-for-Spacefast/' . POFSF_VERSION . '; +' . home_url('/') . ')',
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);

        if ($code >= 400) {
            return new WP_Error('pofsf_style_http', sprintf(
                /* translators: %d: HTTP status code. */
                __('The website responded with HTTP %d.', 'personalized-offers-for-spacefast'),
                $code,
            ));
        }

        return (string) wp_remote_retrieve_body($response);
    }

    /**
     * @return list<array{color: string, count: int}>
     */
    private function colors(string $text): array {
        preg_match_all('/#(?:[0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b/', $text, $hex);
        preg_match_all('/rgba?\(\s*(\d{1,3})[\s,]+(\d{1,3})[\s,]+(\d{1,3})/i', $text, $rgb, PREG_SET_ORDER);

        $counts = [];

        foreach ($hex[0] as $color) {
            $color = strtolower($color);

            if (4 === strlen($color)) {
                $color = '#' . $color[1] . $color[1] . $color[2] . $color[2] . $color[3] . $color[3];
            }

            $counts[$color] = ($counts[$color] ?? 0) + 1;
        }

        foreach ($rgb as $match) {
            $color = sprintf('#%02x%02x%02x', min(255, (int) $match[1]), min(255, (int) $match[2]), min(255, (int) $match[3]));
            $counts[$color] = ($counts[$color] ?? 0) + 1;
        }

        arsort($counts);

        return array_map(
            static fn (string $color, int $count): array => ['color' => $color, 'count' => $count],
            array_keys(array_slice($counts, 0, 16, true)),
            array_slice($counts, 0, 16, true),
        );
    }

    /**
     * Named color custom properties often reveal the brand palette directly.
     *
     * @return array<string, string>
     */
    private function colorVariables(string $css): array {
        preg_match_all('/(--[\w-]*(?:color|colour|brand|primary|secondary|accent|background|bg|text)[\w-]*)\s*:\s*(#[0-9a-fA-F]{3,8}|rgba?\([^)]*\))/i', $css, $vars, PREG_SET_ORDER);

        $out = [];

        foreach ($vars as $var) {
            $out[$var[1]] ??= $var[2];

            if (count($out) >= 30) {
                break;
            }
        }

        return $out;
    }

    /**
     * @return list<array{family: string, count: int}>
     */
    private function fonts(string $css): array {
        preg_match_all('/font-family\s*:\s*([^;}{]+)/i', $css, $families);

        $counts = [];

        foreach ($families[1] as $stack) {
            $stack = trim(preg_replace('/\s*!important/i', '', $stack));

            if ('' === $stack || str_starts_with($stack, 'var(') || in_array(strtolower($stack), ['inherit', 'initial', 'unset'], true)) {
                continue;
            }

            $counts[$stack] = ($counts[$stack] ?? 0) + 1;
        }

        arsort($counts);

        return array_map(
            static fn (string $family, int $count): array => ['family' => $family, 'count' => $count],
            array_keys(array_slice($counts, 0, 8, true)),
            array_slice($counts, 0, 8, true),
        );
    }

    private function absolute(string $href, string $base): string {
        if (str_starts_with($href, '//')) {
            return 'https:' . $href;
        }

        if (preg_match('#^https?://#i', $href)) {
            return $href;
        }

        $parts = wp_parse_url($base);
        $origin = ($parts['scheme'] ?? 'https') . '://' . ($parts['host'] ?? '');

        if (str_starts_with($href, '/')) {
            return $origin . $href;
        }

        $path = isset($parts['path']) ? preg_replace('#/[^/]*$#', '/', $parts['path']) : '/';

        return $origin . $path . $href;
    }
}
