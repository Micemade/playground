<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use WC_Product;
use WC_Product_Variable;
use WC_Product_Variation;

/**
 * Variations of offer picks. The offer form lets the admin choose one;
 * the checkout hand-off adds that variation, or a sensible one when the
 * pick has none (older and AI-built offers) or it has sold out.
 */
final class ProductVariations {
    /**
     * Choices for the offer form. Empty for products without variations.
     *
     * @return list<array{id: int, label: string, in_stock: bool}>
     */
    public function options(int $productId): array {
        $product = $this->variable($productId);

        if (null === $product) {
            return [];
        }

        $options = [];

        foreach ($product->get_children() as $childId) {
            $variation = wc_get_product($childId);

            if (!$variation instanceof WC_Product_Variation || 'publish' !== $variation->get_status()) {
                continue;
            }

            $options[] = [
                'id' => $variation->get_id(),
                'label' => html_entity_decode(wp_strip_all_tags($variation->get_attribute_summary()), ENT_QUOTES) ?: '#' . $variation->get_id(),
                'in_stock' => $variation->is_in_stock(),
            ];
        }

        return $options;
    }

    /**
     * The variation to suggest: the product's default attributes if they
     * match an available variation, otherwise the first available one.
     */
    public function preferred(int $productId): int {
        $product = $this->variable($productId);

        if (null === $product) {
            return 0;
        }

        $defaults = $product->get_default_attributes();

        if ([] !== $defaults) {
            $attributes = [];

            foreach ($defaults as $name => $value) {
                $attributes['attribute_' . $name] = $value;
            }

            $match = (int) (new \WC_Product_Data_Store_CPT())->find_matching_product_variation($product, $attributes);

            if ($match > 0 && $this->available($product, $match)) {
                return $match;
            }
        }

        foreach ($product->get_children() as $childId) {
            if ($this->available($product, (int) $childId)) {
                return (int) $childId;
            }
        }

        return 0;
    }

    /**
     * Whether $variationId can be saved on a pick of $productId: 0 for a
     * product without variations, or one of its variations.
     */
    public function valid(int $productId, int $variationId): bool {
        $product = $this->variable($productId);

        if (null === $product) {
            return 0 === $variationId;
        }

        return 0 === $variationId || in_array($variationId, array_map('intval', $product->get_children()), true);
    }

    /**
     * What to add to the cart for a pick: the chosen variation while it can
     * be bought, otherwise the preferred one. Attributes a variation leaves
     * open ("any") are filled from the product's defaults or first option.
     *
     * @return array{product_id: int, variation_id: int, attributes: array<string, string>}|null Null when nothing can be bought.
     */
    public function cartItem(int $productId, int $variationId): ?array {
        $product = $this->variable($productId);

        if (null === $product) {
            return ['product_id' => $productId, 'variation_id' => 0, 'attributes' => []];
        }

        if (!$this->available($product, $variationId)) {
            $variationId = $this->preferred($productId);
        }

        $variation = $variationId > 0 ? wc_get_product($variationId) : null;

        if (!$variation instanceof WC_Product_Variation) {
            return null;
        }

        $attributes = [];
        $defaults = $product->get_default_attributes();
        $options = $product->get_variation_attributes();

        foreach ($variation->get_variation_attributes() as $key => $value) {
            if ('' === $value) {
                $name = substr($key, strlen('attribute_'));
                $value = (string) ($defaults[$name] ?? (array_values((array) ($options[$name] ?? []))[0] ?? ''));
            }

            $attributes[$key] = $value;
        }

        return ['product_id' => $productId, 'variation_id' => $variationId, 'attributes' => $attributes];
    }

    private function variable(int $productId): ?WC_Product_Variable {
        $product = $productId > 0 && function_exists('wc_get_product') ? wc_get_product($productId) : null;

        return $product instanceof WC_Product_Variable ? $product : null;
    }

    private function available(WC_Product $product, int $variationId): bool {
        if ($variationId <= 0 || !in_array($variationId, array_map('intval', $product->get_children()), true)) {
            return false;
        }

        $variation = wc_get_product($variationId);

        return $variation instanceof WC_Product_Variation
            && 'publish' === $variation->get_status()
            && $variation->is_purchasable()
            && $variation->is_in_stock();
    }
}
