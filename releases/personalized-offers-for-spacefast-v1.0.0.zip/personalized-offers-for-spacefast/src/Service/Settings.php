<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

final class Settings {
    public const OPTION = 'pofsf_settings';

    /** Removed settings, dropped from stored values. */
    private const RETIRED = ['guest_customers_enabled', 'guest_default_expiry', 'show_management_screen'];

    public static function defaults(): array {
        return [
            'brand_snapshot_version' => 0,
            'offer_default_expiry' => 30,
            'offer_max_uses' => 1,
            'free_shipping_coupon' => true,
            'email_notifications' => false,
            'debug_logging' => false,
            // Off until the store decides to ask customers (and says so in its privacy policy).
            'preferences_page' => false,
            'record_searches' => false,
        ];
    }

    public static function all(): array {
        $stored = get_option(self::OPTION, []);

        return array_diff_key(wp_parse_args(is_array($stored) ? $stored : [], self::defaults()), array_flip(self::RETIRED));
    }

    public static function get(string $key, mixed $default = null): mixed {
        $all = self::all();

        return $all[$key] ?? $default;
    }

    /**
     * The editable settings from a submitted form or the offers screen's
     * Settings tab: unchecked boxes are missing (or false), numbers are
     * clamped. Both screens save through this so they stay in sync.
     */
    public static function sanitize(array $posted): array {
        $defaults = self::defaults();
        $flag = static fn (string $key): bool => !empty($posted[$key]) && 'false' !== $posted[$key];
        // A blank or non-numeric field means the default, not the minimum.
        $number = static fn (string $key, int $max): int => is_numeric($posted[$key] ?? null)
            ? max(1, min($max, (int) $posted[$key]))
            : $defaults[$key];

        return [
            'offer_default_expiry' => $number('offer_default_expiry', 365),
            'offer_max_uses' => $number('offer_max_uses', 1000000),
            'free_shipping_coupon' => $flag('free_shipping_coupon'),
            'email_notifications' => $flag('email_notifications'),
            'debug_logging' => $flag('debug_logging'),
            'preferences_page' => $flag('preferences_page'),
            'record_searches' => $flag('record_searches'),
        ];
    }

    /** The editable settings only, as sanitize() returns them. */
    public static function editable(): array {
        return array_intersect_key(self::all(), self::sanitize([]));
    }

    public static function update(array $new): bool {
        return update_option(self::OPTION, array_merge(self::all(), $new));
    }
}
