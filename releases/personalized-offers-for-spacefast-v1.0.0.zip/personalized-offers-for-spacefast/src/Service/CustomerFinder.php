<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use WP_Term;
use WP_User;
use WP_User_Query;

/**
 * Customer accounts an offer can be made for, newest first. Used by the
 * find-customers ability and the Create new offer form.
 */
final class CustomerFinder {
    /** Orders scanned when filtering by purchase, newest first. */
    private const MAX_ORDERS = 2000;

    /** Order statuses that count as a purchase. */
    private const PAID_STATUSES = ['wc-completed', 'wc-processing', 'wc-on-hold'];

    /**
     * @return list<WP_User>
     */
    public function find(string $search = '', int $limit = 10): array {
        return $this->query($search, max(1, min(50, $limit)));
    }

    /**
     * Customers who bought a product matching any of the keywords: the
     * product name, or a product category or tag (with its subcategories).
     *
     * @param list<string> $keywords
     * @return array{customers: list<WP_User>, categories: list<string>, products: list<string>, product_count: int, purchases: array<int, list<string>>}
     */
    public function findByPurchase(array $keywords, string $search = '', int $limit = 10): array {
        $keywords = array_values(array_filter(array_map(static fn ($k): string => trim((string) $k), $keywords), static fn (string $k): bool => '' !== $k));
        $empty = ['customers' => [], 'categories' => [], 'products' => [], 'product_count' => 0, 'purchases' => []];

        if ([] === $keywords) {
            return $empty;
        }

        [$productIds, $categories] = $this->productsMatching($keywords);

        if ([] === $productIds) {
            return ['categories' => $categories] + $empty;
        }

        $purchases = $this->buyers($productIds);
        $userIds = array_keys($purchases);
        $customers = [] === $userIds ? [] : $this->query($search, max(1, min(50, $limit)), $userIds);

        $names = array_map(static fn (int $id): string => html_entity_decode(get_the_title($id), ENT_QUOTES), array_slice($productIds, 0, 15));

        return [
            'customers' => $customers,
            'categories' => $categories,
            'products' => $names,
            'product_count' => count($productIds),
            'purchases' => $purchases,
        ];
    }

    /**
     * @param list<int> $include
     * @return list<WP_User>
     */
    private function query(string $search, int $limit, array $include = []): array {
        $args = [
            'number' => $limit,
            'orderby' => 'registered',
            'order' => 'DESC',
            'role__in' => ['customer', 'subscriber'],
        ];

        if ([] !== $include) {
            $args['include'] = $include;
        }

        $search = trim($search);

        if ('' !== $search) {
            $args['search'] = '*' . $search . '*';
            $args['search_columns'] = ['user_login', 'user_email', 'user_nicename', 'display_name'];
        }

        return array_values((new WP_User_Query($args))->get_results());
    }

    /**
     * Product IDs whose name, category or tag matches a keyword, and the
     * names of the matching categories and tags.
     *
     * @param list<string> $keywords
     * @return array{0: list<int>, 1: list<string>}
     */
    public function productsMatching(array $keywords): array {
        $ids = [];
        $termNames = [];
        $termIds = [];

        foreach ($keywords as $keyword) {
            $terms = get_terms(['taxonomy' => ['product_cat', 'product_tag'], 'name__like' => $keyword, 'hide_empty' => false]);

            foreach (is_array($terms) ? $terms : [] as $term) {
                if (!$term instanceof WP_Term) {
                    continue;
                }

                $termNames[] = html_entity_decode($term->name, ENT_QUOTES);
                $termIds[$term->taxonomy][] = $term->term_id;
            }

            $ids = array_merge($ids, get_posts([
                'post_type' => 'product',
                'post_status' => 'publish',
                'numberposts' => 200,
                'fields' => 'ids',
                's' => $keyword,
                'search_columns' => ['post_title'],
            ]));
        }

        foreach ($termIds as $taxonomy => $termsOfTaxonomy) {
            $ids = array_merge($ids, get_posts([
                'post_type' => 'product',
                'post_status' => 'publish',
                'numberposts' => 500,
                'fields' => 'ids',
                'tax_query' => [[ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Products in the matched categories or attributes, at most 500 IDs.
                    'taxonomy' => $taxonomy,
                    'terms' => array_unique($termsOfTaxonomy),
                    'include_children' => true,
                ]],
            ]));
        }

        return [array_values(array_unique(array_map('intval', $ids))), array_values(array_unique($termNames))];
    }

    /**
     * Registered customers who ordered any of the products (paid orders),
     * with up to three of the matching product names they bought.
     *
     * @param list<int> $productIds
     * @return array<int, list<string>>
     */
    private function buyers(array $productIds): array {
        global $wpdb;

        $placeholders = implode(',', array_fill(0, count($productIds), '%d'));

        // Line items reference the parent product, also for variations.
        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- One query over order line items (WooCommerce has no API to find orders by product); $placeholders is one %d per product ID, filled by the spread $productIds.
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT i.order_id, m.meta_value AS product_id
            FROM {$wpdb->prefix}woocommerce_order_items i
            INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta m ON m.order_item_id = i.order_item_id AND m.meta_key = '_product_id'
            WHERE i.order_item_type = 'line_item' AND m.meta_value IN ({$placeholders})
            ORDER BY i.order_id DESC
            LIMIT %d",
            ...[...$productIds, self::MAX_ORDERS]
        ), ARRAY_A);
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

        $byOrder = [];

        foreach ((array) $rows as $row) {
            $byOrder[(int) $row['order_id']][] = (int) $row['product_id'];
        }

        $buyers = [];

        foreach ($byOrder as $orderId => $products) {
            $order = wc_get_order($orderId);

            if (!$order || !in_array('wc-' . $order->get_status(), self::PAID_STATUSES, true) || $order->get_customer_id() <= 0) {
                continue;
            }

            $userId = $order->get_customer_id();

            foreach ($products as $productId) {
                $name = html_entity_decode(get_the_title($productId), ENT_QUOTES);

                if (count($buyers[$userId] ?? []) < 3 && !in_array($name, $buyers[$userId] ?? [], true)) {
                    $buyers[$userId][] = $name;
                }
            }

            $buyers[$userId] ??= [];
        }

        return $buyers;
    }
}
