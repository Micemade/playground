<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

/**
 * The store's price thirds (from in-stock published products), so a
 * customer's typical price can be called budget, mid or premium.
 */
final class StorePrices {
    private const TRANSIENT = 'pofsf_store_price_thirds';

    /**
     * @return array{0: ?float, 1: ?float} Upper bound of the cheapest third and lower bound of the dearest; nulls without products.
     */
    public static function thirds(): array {
        $cached = get_transient(self::TRANSIENT);

        if (is_array($cached) && 2 === count($cached)) {
            return $cached;
        }

        global $wpdb;

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- WooCommerce's product lookup table has no API for this; cached for a day.
        $prices = $wpdb->get_col(
            "SELECT l.min_price FROM {$wpdb->prefix}wc_product_meta_lookup l
            INNER JOIN {$wpdb->posts} p ON p.ID = l.product_id
            WHERE p.post_type = 'product' AND p.post_status = 'publish' AND l.stock_status = 'instock' AND l.min_price > 0
            ORDER BY l.min_price"
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

        $prices = array_map('floatval', (array) $prices);
        $thirds = count($prices) >= 3
            ? [$prices[(int) floor((count($prices) - 1) / 3)], $prices[(int) floor(2 * (count($prices) - 1) / 3)]]
            : [null, null];

        set_transient(self::TRANSIENT, $thirds, DAY_IN_SECONDS);

        return $thirds;
    }
}
