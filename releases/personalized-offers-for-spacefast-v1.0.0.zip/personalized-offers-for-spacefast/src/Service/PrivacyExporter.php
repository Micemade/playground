<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\RecipientRepository;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;

/**
 * WordPress personal data exporter (Tools → Export Personal Data): the
 * customer's offers (made for them, or a group offer they are in), the
 * shopping profile each offer was built from, their stored profile
 * (with what they stated and searched for), and their consent.
 */
final class PrivacyExporter {
    public function __construct(
        private readonly OfferRepository $offers,
        private readonly CustomerProfiles $profiles,
        private readonly RecipientRepository $recipients = new RecipientRepository(),
    ) {}

    public function register(): void {
        add_filter('wp_privacy_personal_data_exporters', [$this, 'registerExporter']);
    }

    public function registerExporter(array $exporters): array {
        $exporters['pofsf_offers'] = [
            'exporter_friendly_name' => __('Spacefast personalized offers', 'personalized-offers-for-spacefast'),
            'callback' => [$this, 'export'],
        ];

        return $exporters;
    }

    /**
     * @return array{data: list<array{group_id: string, group_label: string, item_id: string, data: list<array{name: string, value: string}>}>, done: bool}
     */
    public function export(string $email, int $page = 1): array {
        $email = sanitize_email($email);
        $user = '' !== $email ? get_user_by('email', $email) : false;
        $items = [];
        $group = ['group_id' => 'pofsf-offers', 'group_label' => __('Personalized offers', 'personalized-offers-for-spacefast')];

        $offers = '' !== $email ? $this->offers->findByGuestEmail($email) : [];

        if ($user) {
            $offers = array_merge($offers, $this->offers->findByUser((int) $user->ID));

            if (get_user_meta((int) $user->ID, 'pofsf_consent_given', true)) {
                $items[] = $group + [
                    'item_id' => 'pofsf-consent',
                    'data' => [['name' => __('Consent to personalized offers', 'personalized-offers-for-spacefast'), 'value' => __('Given', 'personalized-offers-for-spacefast')]],
                ];
            }
        }

        $keys = array_filter([$user ? CustomerProfiles::userKey((int) $user->ID) : '', '' !== $email ? CustomerProfiles::guestKey($email) : '']);

        foreach ($keys as $key) {
            $row = $this->profiles->repository()->find($key);

            if (null !== $row) {
                $items[] = [
                    'group_id' => 'pofsf-profile',
                    'group_label' => __('Shopping profile', 'personalized-offers-for-spacefast'),
                    'item_id' => 'pofsf-profile-' . $row['id'],
                    'data' => $this->profileData($row),
                ];
            }
        }

        foreach ($offers as $offer) {
            $items[] = $group + ['item_id' => 'pofsf-offer-' . $offer['id'], 'data' => $this->offerData($offer, OfferPublisher::pageUrl($offer))];
        }

        // Group offers the customer is a recipient of: their own link and uses.
        foreach ($user ? $this->recipients->forUser((int) $user->ID) : [] as $recipient) {
            $offer = $this->offers->find((int) $recipient['offer_id']);

            if (null === $offer) {
                continue;
            }

            $data = $this->offerData($offer, OfferPublisher::recipientUrl($offer, $recipient), false);
            $data[] = ['name' => __('Your status in the group', 'personalized-offers-for-spacefast'), 'value' => (string) $recipient['status']];
            $data[] = ['name' => __('Orders with this offer', 'personalized-offers-for-spacefast'), 'value' => (string) $recipient['used_count']];
            $items[] = $group + ['item_id' => 'pofsf-recipient-' . $recipient['id'], 'data' => $data];
        }

        return ['data' => $items, 'done' => true];
    }

    /**
     * A stored profile as name/value pairs.
     *
     * @return list<array{name: string, value: string}>
     */
    private function profileData(array $row): array {
        $profile = $this->profiles->effective($row);
        $input = (array) $row['customer_input'];
        $names = static fn (array $list, string $key = 'name'): string => implode(', ', array_map('strval', array_column($list, $key)));
        $data = [
            [__('Favourite categories', 'personalized-offers-for-spacefast'), $names((array) $profile['preferred_categories'])],
            [__('Brands', 'personalized-offers-for-spacefast'), $names((array) $profile['brands'])],
        ];

        foreach ((array) $profile['attributes'] as $attribute) {
            $data[] = [(string) $attribute['label'], $names((array) $attribute['values'])];
        }

        $activity = (array) $profile['activity'];
        $data[] = [__('Orders', 'personalized-offers-for-spacefast'), (string) ($activity['order_count'] ?? 0)];
        $data[] = [__('Last order', 'personalized-offers-for-spacefast'), (string) ($activity['last_order'] ?? '')];
        $data[] = [__('Typical price per item', 'personalized-offers-for-spacefast'), (string) ($profile['price_range']['median'] ?? '')];
        $data[] = [__('Segment', 'personalized-offers-for-spacefast'), (string) (CustomerProfiles::segments()[$profile['segment']] ?? '')];
        $data[] = [__('Consent given on My preferences', 'personalized-offers-for-spacefast'), !empty($input['consent']) ? (string) ($input['consent_at'] ?? __('Yes', 'personalized-offers-for-spacefast')) : __('No', 'personalized-offers-for-spacefast')];
        $data[] = [__('Searches', 'personalized-offers-for-spacefast'), $names((array) $profile['searches'], 'term')];
        $data[] = [__('Store note', 'personalized-offers-for-spacefast'), (string) $profile['manager_note']];

        return array_map(
            static fn (array $pair): array => ['name' => $pair[0], 'value' => $pair[1]],
            array_values(array_filter($data, static fn (array $pair): bool => '' !== $pair[1])),
        );
    }

    /**
     * @return list<array{name: string, value: string}>
     */
    private function offerData(array $offer, string $link, bool $withProfile = true): array {
        $offerData = is_array($offer['offer_data'] ?? null) ? $offer['offer_data'] : [];
        $profile = is_array($offerData['profile'] ?? null) ? $offerData['profile'] : [];
        $rows = [
            __('Offer', 'personalized-offers-for-spacefast') => '#' . $offer['id'],
            __('Headline', 'personalized-offers-for-spacefast') => (string) ($offerData['offer_json']['headline'] ?? ''),
            __('Status', 'personalized-offers-for-spacefast') => (string) $offer['status'],
            __('Created', 'personalized-offers-for-spacefast') => (string) $offer['created_at'],
            __('Expires (UTC)', 'personalized-offers-for-spacefast') => (string) $offer['expires_at'],
            __('Coupon', 'personalized-offers-for-spacefast') => (string) $offer['coupon_code'],
            __('Offer page link', 'personalized-offers-for-spacefast') => $link,
        ];

        if ($withProfile) {
            // The shopping profile the offer was built from.
            $rows[__('Preferred categories', 'personalized-offers-for-spacefast')] = implode(', ', array_map(
                static fn (mixed $cat): string => is_array($cat) ? html_entity_decode((string) ($cat['name'] ?? ''), ENT_QUOTES) : '',
                (array) ($profile['preferred_categories'] ?? []),
            ));
            $rows[__('Sizes and colours', 'personalized-offers-for-spacefast')] = implode(', ', array_unique(array_map(
                static fn (mixed $attr): string => is_array($attr) ? (string) ($attr['attribute'] ?? '') . ': ' . (string) ($attr['value'] ?? '') : '',
                (array) ($profile['sizes_colors'] ?? []),
            )));
            $rows[__('Wishlist products', 'personalized-offers-for-spacefast')] = (string) count((array) ($profile['wishlist_products'] ?? []));
        }

        $data = [];

        foreach ($rows as $name => $value) {
            if ('' !== $value) {
                $data[] = ['name' => $name, 'value' => $value];
            }
        }

        return $data;
    }
}
