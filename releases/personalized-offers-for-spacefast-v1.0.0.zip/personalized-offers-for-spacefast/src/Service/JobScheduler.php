<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

final class JobScheduler {
    public const HOOK = 'pofsf_build_offer';

    /** Hook used before offers were recorded at queue time; kept for already-queued jobs. */
    public const LEGACY_HOOK = 'pofsf_build_profile';

    public const GROUP = 'pofsf-offers';

    /** Publishes an offer's Spacefast Space again after its template changed. */
    public const REPUBLISH_HOOK = 'pofsf_republish_offer';

    /** Brings who can open an offer's Space in line with the offer (OfferPublisher::syncAccess()). */
    public const ACCESS_HOOK = 'pofsf_sync_offer_access';

    /**
     * Queues an access sync, for requests that shouldn't wait on Spacefast
     * (checkout). Without Action Scheduler the daily cleanup catches up.
     */
    public static function scheduleAccessSync(int $offerId): void {
        if ($offerId > 0 && function_exists('as_enqueue_async_action')
            && !(function_exists('as_has_scheduled_action') && as_has_scheduled_action(self::ACCESS_HOOK, [$offerId], self::GROUP))) {
            as_enqueue_async_action(self::ACCESS_HOOK, [$offerId], self::GROUP);
        }
    }

    public function scheduleOfferBuild(int $offerId): int|false {
        if ($offerId <= 0 || !function_exists('as_enqueue_async_action')) {
            return false;
        }

        $actionId = as_enqueue_async_action(self::HOOK, [$offerId], self::GROUP);

        return $actionId > 0 ? $actionId : false;
    }

    /**
     * Queues a background publish of the offer's Space; one per offer at a
     * time, so several template saves in a row publish once.
     */
    public function scheduleRepublish(int $offerId): bool {
        if ($offerId <= 0 || !function_exists('as_enqueue_async_action')) {
            return false;
        }

        if (function_exists('as_has_scheduled_action') && as_has_scheduled_action(self::REPUBLISH_HOOK, [$offerId], self::GROUP)) {
            return true;
        }

        return as_enqueue_async_action(self::REPUBLISH_HOOK, [$offerId], self::GROUP) > 0;
    }
}
