<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Automattic\WooCommerce\StoreApi\RoutesController;
use Automattic\WooCommerce\StoreApi\StoreApi;
use WC_Product;
use WC_Product_Variable;
use WP_REST_Request;

/**
 * Product data for the offer page's cart (assets/offer/offer-cart.js):
 * the offer's picks as the WooCommerce Store API describes them (prices in
 * minor units, stock, purchase limits, images), with each variable pick's
 * variations and the attribute keys and values WooCommerce adds them to the
 * cart with. Read through internal Store API requests, so nothing leaves
 * the server and the store does not have to be reachable from outside.
 *
 * The published page keeps this as products.json; the page may refresh
 * prices and stock from the public Store API (GET /products) when the
 * store is reachable. Checkout always recalculates them.
 */
final class StoreProducts {
    private const NAMESPACE = '/wc/store/v1';

    /** Variations read per Store API page; a pick's variations are read in full. */
    private const PER_PAGE = 100;

    /**
     * @param list<array{product_id?: int, variation_id?: int}> $picks The offer's product picks.
     * @return array{currency: array, products: list<array>}
     */
    public function forPicks(array $picks): array {
        $products = [];
        $currency = [];

        foreach (array_values($picks) as $index => $pick) {
            $productId = is_array($pick) ? (int) ($pick['product_id'] ?? 0) : 0;
            $product = $productId > 0 ? wc_get_product($productId) : null;

            if (!$product instanceof WC_Product) {
                continue;
            }

            $data = $this->get('/products/' . $productId);

            if (null === $data) {
                continue;
            }

            $currency = $currency ?: self::currency($data['prices'] ?? []);
            $item = [
                'pick' => $index + 1,
                'id' => $productId,
                'name' => html_entity_decode((string) ($data['name'] ?? $product->get_name()), ENT_QUOTES),
                'type' => (string) ($data['type'] ?? $product->get_type()),
                'permalink' => (string) ($data['permalink'] ?? ''),
                'prices' => self::prices($data['prices'] ?? []),
                'image' => self::image($data['images'][0]['id'] ?? 0),
                'in_stock' => !empty($data['is_in_stock']),
                'purchasable' => !empty($data['is_purchasable']),
                'sold_individually' => !empty($data['sold_individually']),
                'limits' => self::limits($data['add_to_cart'] ?? []),
                'attributes' => [],
                'variations' => [],
                'selected' => 0,
            ];

            if ($product instanceof WC_Product_Variable) {
                $item['attributes'] = self::attributes($product);
                $item['variations'] = $this->variations($productId);
                $chosen = (int) ($pick['variation_id'] ?? 0);
                $item['selected'] = in_array($chosen, array_column($item['variations'], 'id'), true) ? $chosen : 0;
                $item['defaults'] = self::defaults($product);
            }

            $products[] = $item;
        }

        return ['currency' => $currency, 'products' => $products];
    }

    /**
     * The product's variations as the Store API lists them (type=variation),
     * with WooCommerce's own attribute keys and values ('' = any value).
     *
     * @return list<array>
     */
    private function variations(int $productId): array {
        $variations = [];

        for ($page = 1; $page <= 10; $page++) {
            $rows = $this->get('/products', ['type' => 'variation', 'parent' => [$productId], 'per_page' => self::PER_PAGE, 'page' => $page]);

            foreach ((array) $rows as $row) {
                $variation = wc_get_product((int) ($row['id'] ?? 0));

                if (!$variation instanceof \WC_Product_Variation || $variation->get_parent_id() !== $productId) {
                    continue;
                }

                $variations[] = [
                    'id' => $variation->get_id(),
                    'attributes' => array_map('strval', $variation->get_variation_attributes()),
                    'prices' => self::prices($row['prices'] ?? []),
                    'image' => self::image($row['images'][0]['id'] ?? 0),
                    'in_stock' => !empty($row['is_in_stock']),
                    'purchasable' => !empty($row['is_purchasable']),
                    'limits' => self::limits($row['add_to_cart'] ?? []),
                    'stock' => wp_strip_all_tags((string) ($row['stock_availability']['text'] ?? '')),
                ];
            }

            if (count((array) $rows) < self::PER_PAGE) {
                break;
            }
        }

        return $variations;
    }

    /**
     * Attributes used for variations: the cart key (attribute_*), the
     * label and the options, with the term name for taxonomy attributes.
     *
     * @return list<array{key: string, label: string, options: list<array{value: string, label: string}>}>
     */
    private static function attributes(WC_Product_Variable $product): array {
        $attributes = [];

        foreach ($product->get_variation_attributes() as $name => $values) {
            $options = [];
            $taxonomy = taxonomy_exists((string) $name);

            foreach ((array) $values as $value) {
                $value = (string) $value;
                $term = $taxonomy ? get_term_by('slug', $value, (string) $name) : null;

                $options[] = [
                    'value' => $value,
                    'label' => html_entity_decode($term instanceof \WP_Term ? $term->name : $value, ENT_QUOTES),
                ];
            }

            $attributes[] = [
                'key' => 'attribute_' . sanitize_title((string) $name),
                'label' => html_entity_decode(wc_attribute_label((string) $name, $product), ENT_QUOTES),
                'options' => $options,
            ];
        }

        return $attributes;
    }

    /**
     * @return array<string, string> attribute_* key => default value.
     */
    private static function defaults(WC_Product_Variable $product): array {
        $defaults = [];

        foreach ($product->get_default_attributes() as $name => $value) {
            $defaults['attribute_' . sanitize_title((string) $name)] = (string) $value;
        }

        return $defaults;
    }

    /** Store API prices: amounts in the currency's minor unit, as strings. */
    private static function prices(mixed $prices): array {
        $prices = is_array($prices) ? $prices : [];

        return [
            'price' => (string) ($prices['price'] ?? '0'),
            'regular_price' => (string) ($prices['regular_price'] ?? ''),
            'sale_price' => (string) ($prices['sale_price'] ?? ''),
        ];
    }

    /** Formatting of the Store API currency (CurrencySchema). */
    private static function currency(mixed $prices): array {
        $prices = is_array($prices) ? $prices : [];

        return [
            'code' => (string) ($prices['currency_code'] ?? get_woocommerce_currency()),
            'minor_unit' => (int) ($prices['currency_minor_unit'] ?? wc_get_price_decimals()),
            'decimal_separator' => (string) ($prices['currency_decimal_separator'] ?? wc_get_price_decimal_separator()),
            'thousand_separator' => (string) ($prices['currency_thousand_separator'] ?? wc_get_price_thousand_separator()),
            'prefix' => html_entity_decode((string) ($prices['currency_prefix'] ?? ''), ENT_QUOTES),
            'suffix' => html_entity_decode((string) ($prices['currency_suffix'] ?? ''), ENT_QUOTES),
        ];
    }

    /** Store API add_to_cart limits. */
    private static function limits(mixed $limits): array {
        $limits = is_array($limits) ? $limits : [];

        return [
            'minimum' => max(1, (int) ($limits['minimum'] ?? 1)),
            'maximum' => max(1, min(99, (int) ($limits['maximum'] ?? 99))),
            'multiple_of' => max(1, (int) ($limits['multiple_of'] ?? 1)),
        ];
    }

    /** The image in the single product size (absolute URL; the export bundles it). */
    private static function image(mixed $id): string {
        $id = (int) $id;

        if ($id > 0) {
            return (string) wp_get_attachment_image_url($id, 'woocommerce_single');
        }

        return function_exists('wc_placeholder_img_src') ? (string) wc_placeholder_img_src('woocommerce_single') : '';
    }

    /**
     * WooCommerce starts the Store API only outside the admin, so in admin
     * requests (the offer previews, Publish and Update Space run through
     * admin-ajax) its routes are missing: register them once.
     */
    private static function ensureRoutes(): void {
        static $done = false;

        $server = rest_get_server();

        if ($done || isset($server->get_routes('wc/store/v1')['/wc/store/v1/products'])) {
            $done = true;

            return;
        }

        $done = true;
        if (!class_exists(StoreApi::class) || !class_exists(RoutesController::class)) {
            return;
        }

        try {
            StoreApi::container()->get(RoutesController::class)->register_all_routes();
        } catch (\Throwable $e) {
            // Without the routes the page has no cart data; its buttons keep their links to the store.
            unset($e);
        }
    }

    /**
     * An internal Store API GET; its data as arrays, or null on an error.
     */
    private function get(string $route, array $params = []): ?array {
        self::ensureRoutes();
        $request = new WP_REST_Request('GET', self::NAMESPACE . $route);
        $request->set_query_params($params);
        $response = rest_do_request($request);

        if ($response->is_error() || $response->get_status() >= 400) {
            return null;
        }

        $data = json_decode((string) wp_json_encode($response->get_data()), true);

        return is_array($data) ? $data : null;
    }
}
