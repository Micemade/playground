<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Wishlist;

final class AdapterRegistry {
    /** @var list<WishlistAdapter> */
    private readonly array $adapters;

    public function __construct(?array $adapters = null) {
        $this->adapters = $adapters ?? [new CoreAdapter(), new YithAdapter(), new TiAdapter()];
    }

    /**
     * @return list<array{product_id:int,name?:string}>
     */
    public function productsFor(int $userId): array {
        $merged = [];

        foreach ($this->adapters as $adapter) {
            if (!$adapter->isAvailable()) {
                continue;
            }

            foreach ($adapter->productsFor($userId) as $product) {
                $id = (int) ($product['product_id'] ?? 0);

                if ($id > 0 && !isset($merged[$id])) {
                    $merged[$id] = $product;
                }
            }
        }

        return array_values($merged);
    }
}
