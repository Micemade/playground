<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Wishlist;

interface WishlistAdapter {
    public function isAvailable(): bool;

    /**
     * @return list<array{product_id:int,name?:string}>
     */
    public function productsFor(int $userId): array;
}
