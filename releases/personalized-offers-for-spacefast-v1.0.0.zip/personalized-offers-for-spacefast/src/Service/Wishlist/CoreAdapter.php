<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Wishlist;

final class CoreAdapter implements WishlistAdapter {
    public function isAvailable(): bool {
        return function_exists('wc_get_shopper_lists');
    }

    public function productsFor(int $userId): array {
        $lists = wc_get_shopper_lists($userId);

        if (!$lists || empty($lists->products) || !is_array($lists->products)) {
            $fallback = get_user_meta($userId, '_wc_shopper_list', true);

            return is_array($fallback) ? $this->normalize($fallback) : [];
        }

        return $this->normalize($lists->products);
    }

    private function normalize(array $items): array {
        $out = [];

        foreach ($items as $item) {
            $id = is_array($item) ? (int) ($item['product_id'] ?? $item['id'] ?? 0) : (int) $item;

            if ($id > 0) {
                $out[] = ['product_id' => $id];
            }
        }

        return $out;
    }
}
