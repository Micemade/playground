<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Wishlist;

final class YithAdapter implements WishlistAdapter {
    public function isAvailable(): bool {
        return class_exists('YITH_WCWL');
    }

    public function productsFor(int $userId): array {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The wishlist plugin's own table, which it offers no API to read.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT product_id FROM {$wpdb->prefix}yith_wcwl_wishlist_items WHERE user_id = %d AND status = 'active'",
                $userId,
            ),
            ARRAY_A,
        );

        if (!is_array($rows)) {
            return [];
        }

        $out = [];

        foreach ($rows as $row) {
            $id = (int) ($row['product_id'] ?? 0);

            if ($id <= 0 || !function_exists('wc_get_product')) {
                continue;
            }

            $product = wc_get_product($id);

            if ($product && !is_wp_error($product)) {
                $out[] = ['product_id' => $id, 'name' => $product->get_name()];
            }
        }

        return $out;
    }
}
