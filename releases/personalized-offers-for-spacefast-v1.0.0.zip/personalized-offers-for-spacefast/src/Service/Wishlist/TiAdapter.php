<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service\Wishlist;

final class TiAdapter implements WishlistAdapter {
    public function isAvailable(): bool {
        return class_exists('TI_Wishlist');
    }

    public function productsFor(int $userId): array {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The wishlist plugin's own table, which it offers no API to read.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT product_id, product_name FROM {$wpdb->prefix}ti_wishlist WHERE user_id = %d",
                $userId,
            ),
            ARRAY_A,
        );

        if (!is_array($rows)) {
            return [];
        }

        $out = [];

        foreach ($rows as $row) {
            $id = (int) ($row['product_id'] ?? 0);

            if ($id > 0) {
                $out[] = ['product_id' => $id, 'name' => (string) ($row['product_name'] ?? '')];
            }
        }

        return $out;
    }
}
