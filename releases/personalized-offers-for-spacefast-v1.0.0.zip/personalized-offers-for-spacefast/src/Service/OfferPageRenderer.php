<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Service;

use Micemade\PersonalizedOffers\Blocks\OfferBlocks;
use Micemade\PersonalizedOffers\Repository\TemplateRepository;
use Micemade\PersonalizedOffers\Value\BrandSnapshot;
use Micemade\PersonalizedOffers\Value\OfferCopy;
use Micemade\PersonalizedOffers\Value\OfferDesign;

/**
 * Renders the static offer page (index.html) from an offer template: block
 * markup made of core blocks and the dynamic pofsf/* offer blocks (see
 * OfferBlocks), styled by the template design through CSS variables.
 *
 * The page is self-contained: the CSS that WordPress would normally enqueue
 * for these blocks is inlined, because the page is published as static HTML.
 */
final class OfferPageRenderer {
    /** The offer page's stylesheet, script and product data in an export (paths from index.html). */
    public const EXPORT_CSS = 'assets/offer/offer.css';
    public const EXPORT_SCRIPT = 'assets/offer/offer-cart.js';
    public const EXPORT_DATA = 'assets/offer/products.json';

    /** The cart script's source in the plugin. */
    public const SCRIPT_FILE = 'assets/offer/offer-cart.js';

    public function __construct(
        private readonly StoreProducts $store = new StoreProducts(),
    ) {}

    /**
     * @param array $offerJson headline, fields (OfferCopy) and product_picks.
     * @param array{logo?: ?string, icon?: ?string} $images Image src for the logo and site icon:
     *        absolute URLs for previews, relative paths for bundled exports.
     * @param string $offerUrl The offer link (CheckoutHandler) the Offer action buttons lead through.
     * @param array{recipient_links?: bool, export?: bool, cart?: ?array, admin_preview?: bool} $context
     *        recipient_links: a group offer page, whose offer links take the recipient's token from the page URL.
     *        export: the page links its stylesheet, script and product data as files (EXPORT_*)
     *        instead of inlining them; the exporter writes those files.
     *        cart: the cart data (cartData()) for the products' cart buttons.
     *        admin_preview: a preview shown inside an admin modal: links open in a new tab, the
     *        Offer action button and the cart's checkout do nothing, and hovered blocks are
     *        outlined with their name.
     *        social: a public offer's link card (OfferShare::card()), added as Open Graph tags.
     * @param string $content Template block markup.
     */
    public function render(array $offerJson, BrandSnapshot $brand, OfferDesign $design, string $offerUrl, int $offerId = 0, array $images = [], array $context = [], string $content = ''): string {
        $vars = $this->vars($offerJson, $brand, $design, $offerUrl, $images);
        $vars['cart'] = is_array($context['cart'] ?? null);
        $adminPreview = !empty($context['admin_preview']);
        $vars['inert'] = $adminPreview;
        $iconSrc = (string) ($images['icon'] ?? '');
        $export = !empty($context['export']);

        if ($adminPreview) {
            add_filter('render_block', [self::class, 'labelBlock'], 10, 2);
        }

        try {
            $body = OfferBlocks::renderWith($vars, '' !== trim($content) ? $content : TemplateRepository::starterContent($design->base));
        } finally {
            remove_filter('render_block', [self::class, 'labelBlock'], 10);
        }

        $fontLinks = '';

        foreach ($design->fontUrls() as $url) {
            // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Standalone static page published to Spacefast, not rendered by WordPress, so there is no enqueue.
            $fontLinks .= sprintf("<link rel=\"stylesheet\" href=\"%s\" />\n", esc_url($url));
        }

        $bodyClasses = sprintf('pofsf-offer-page pofsf-base-%s', $design->base);

        return "<!DOCTYPE html>\n<html lang=\"" . esc_attr(str_replace('_', '-', get_locale())) . "\">\n<head>\n"
            . "<meta charset=\"UTF-8\" />\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n"
            . "<meta name=\"robots\" content=\"noindex, nofollow\" />\n"
            // Previews in the admin: the store's pages open in a new tab, not inside the preview.
            . ($adminPreview ? "<base target=\"_blank\" />\n" : '')
            . '<title>' . esc_html($vars['headline']) . "</title>\n"
            . (is_array($context['social'] ?? null) ? self::socialTags($context['social']) : '')
            . ('' !== $iconSrc ? sprintf("<link rel=\"icon\" href=\"%1\$s\" />\n<link rel=\"apple-touch-icon\" href=\"%1\$s\" />\n", esc_attr($iconSrc)) : '')
            . ([] !== $design->fontUrls() ? "<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin />\n" : '')
            . $fontLinks
            // In an export the stylesheet is its own file, written after this render (its block styles come from it).
            // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedStylesheet -- Standalone static page.
            . ($export ? '<link rel="stylesheet" href="' . self::EXPORT_CSS . "\" />\n" : '<style>' . $this->css($brand, $design) . "</style>\n")
            . "</head>\n"
            . '<body class="' . esc_attr($bodyClasses) . "\">\n"
            // The root container lays the top-level blocks out as the block editor does.
            . '<div class="' . esc_attr($this->rootLayout()['class']) . '">' . $body . '</div>'
            . ($offerId > 0 ? "\n<!-- pofsf-offer-id:" . $offerId . " -->\n" : "\n")
            . (!empty($context['recipient_links']) ? $this->recipientScript() : '')
            . ($vars['cart'] ? $this->cartScript($context['cart'], $export) : '')
            . ($adminPreview ? $this->previewTools() : '')
            . "</body>\n</html>\n";
    }

    /**
     * Open Graph and X card tags, so a shared link shows the offer's title,
     * text and image.
     *
     * @param array{title?: string, description?: string, image?: string, site_name?: string} $card
     */
    private static function socialTags(array $card): string {
        $tags = [
            ['property', 'og:type', 'website'],
            ['property', 'og:title', (string) ($card['title'] ?? '')],
            ['property', 'og:description', (string) ($card['description'] ?? '')],
            ['property', 'og:site_name', (string) ($card['site_name'] ?? '')],
            ['property', 'og:image', (string) ($card['image'] ?? '')],
            ['name', 'twitter:card', '' !== (string) ($card['image'] ?? '') ? 'summary_large_image' : 'summary'],
            ['name', 'description', (string) ($card['description'] ?? '')],
        ];
        $html = '';

        foreach ($tags as [$attribute, $name, $value]) {
            if ('' !== $value) {
                $html .= sprintf("<meta %s=\"%s\" content=\"%s\" />\n", $attribute, $name, 'og:image' === $name ? esc_url($value) : esc_attr($value));
            }
        }

        return $html;
    }

    /**
     * Admin previews: each block's outer element gets its name
     * (data-pofsf-block) for the hover outline (previewTools()): the name
     * given in the editor's List View, else the block type's title.
     */
    public static function labelBlock(string $html, array $block): string {
        $name = (string) ($block['blockName'] ?? '');

        if ('' === $name || '' === trim($html)) {
            return $html;
        }

        $attrs = (array) ($block['attrs'] ?? []);
        $type = \WP_Block_Type_Registry::get_instance()->get_registered($name);
        $label = trim((string) ($attrs['metadata']['name'] ?? ''));

        if ('' === $label && 'pofsf/offer' === ($attrs['metadata']['bindings']['content']['source'] ?? '')) {
            $label = __('Offer headline', 'personalized-offers-for-spacefast');
        }

        // As the editor names its variations: "Offer text: Greeting".
        if ('' === $label && 'pofsf/offer-text' === $name) {
            $field = (string) ($attrs['field'] ?? 'body');
            $label = sprintf(
                /* translators: %s: offer field type, e.g. "Greeting". */
                __('Offer text: %s', 'personalized-offers-for-spacefast'),
                OfferCopy::typeLabels()[$field] ?? $field,
            );
        }

        if ('' === $label) {
            $label = $type && '' !== (string) $type->title ? (string) $type->title : $name;
        }

        $tags = new \WP_HTML_Tag_Processor($html);

        if (!$tags->next_tag() || null !== $tags->get_attribute('data-pofsf-block')) {
            return $html;
        }

        $tags->set_attribute('data-pofsf-block', $label);

        return $tags->get_updated_html();
    }

    /**
     * Admin previews: a thin outline and a name label on the hovered block,
     * and checkout turned off (the Offer action button renders inert; the
     * cart's "Complete purchase" and the products' fallback links to the
     * store do nothing), so the preview never loads the store's cart.
     */
    private function previewTools(): string {
        $css = '.pofsf-hover{position:absolute;z-index:2147483000;pointer-events:none;display:none;outline:1px solid #3858e9;outline-offset:-1px}'
            . '.pofsf-hover.is-shown{display:block}'
            . '.pofsf-hover__label{position:absolute;left:-1px;bottom:100%;padding:1px 6px;border-radius:2px 2px 0 0;background:#3858e9;color:#fff;'
            . 'font:500 11px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;letter-spacing:normal;text-transform:none;white-space:nowrap}'
            . '.pofsf-hover.is-inside .pofsf-hover__label{bottom:auto;top:0;left:0;border-radius:0 0 2px 0}'
            . '.pofsf-offer-action__button[aria-disabled="true"],.pofsf-cart__complete{cursor:not-allowed}';

        $js = "(function(){var box=document.createElement('div'),label=document.createElement('span'),current=null;"
            . "box.className='pofsf-hover';box.setAttribute('aria-hidden','true');label.className='pofsf-hover__label';box.appendChild(label);document.body.appendChild(box);"
            . "function hide(){current=null;box.classList.remove('is-shown');}"
            . "function show(block){if(block===current)return;current=block;var r=block.getBoundingClientRect();"
            . "if(!r.width&&!r.height){hide();return;}"
            . "box.style.left=(r.left+window.scrollX)+'px';box.style.top=(r.top+window.scrollY)+'px';box.style.width=r.width+'px';box.style.height=r.height+'px';"
            . "label.textContent=block.getAttribute('data-pofsf-block');box.classList.toggle('is-inside',r.top+window.scrollY<22);box.classList.add('is-shown');}"
            . "document.addEventListener('mouseover',function(e){var b=e.target.closest&&e.target.closest('[data-pofsf-block]');if(b){show(b);}else{hide();}});"
            . "document.documentElement.addEventListener('mouseleave',hide);window.addEventListener('resize',hide);"
            . "window.addEventListener('scroll',function(){if(current){var b=current;current=null;show(b);}},{passive:true});"
            // Checkout is off: the action button (inert already), the cart's Complete purchase and the products' store links.
            . "document.addEventListener('submit',function(e){if(e.target.matches&&e.target.matches('form[data-pofsf-checkout]')){e.preventDefault();e.stopImmediatePropagation();}},true);"
            . "document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href*=\"pofsf_to=\"],a.pofsf-cart__complete');"
            . "if(!a)return;e.preventDefault();if(a.classList.contains('pofsf-cart__complete')){e.stopImmediatePropagation();}},true);"
            . "})();";

        return '<style>' . $css . "</style>
<script>" . $js . "</script>
";
    }

    /**
     * Group offers publish one page for all their customers. Each customer's
     * link ends in #r=TOKEN; this puts that token into the page's offer
     * links and the Offer action button's form. The fragment never reaches a server, so the page stays static
     * and holds nothing personal.
     */
    private function recipientScript(): string {
        return "<script>(function(){var m=/(?:^#|&)r=([0-9a-f]{32})(?:&|$)/.exec(location.hash);if(!m)return;"
            . "document.querySelectorAll('a[href*=\"pofsf_offer=\"]').forEach(function(a){a.href=a.href.replace(/([?&]pofsf_offer=)[^&#]*/,'$1'+m[1]);});"
            . "document.querySelectorAll('input[name=\"pofsf_offer\"]').forEach(function(i){i.value=m[1];});})();</script>\n";
    }

    /**
     * The cart script and its data. The data is inlined, so the cart does
     * not depend on another request; an export also keeps it as
     * products.json and the script as a file next to the page, previews
     * load the script from the plugin.
     */
    private function cartScript(array $data, bool $export): string {
        if (!$export) {
            // Previews are rendered fresh, and their sandbox could not reach the store anyway.
            $data['storeApi'] = '';
        }

        $json = '<script type="application/json" id="pofsf-offer-data">' . wp_json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";

        if ($export) {
            // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Standalone static page.
            return $json . '<script src="' . self::EXPORT_SCRIPT . '" data-pofsf-data="' . self::EXPORT_DATA . "\" defer></script>\n";
        }

        // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Standalone page, not rendered by WordPress' script loader.
        return $json . '<script src="' . esc_url(POFSF_PLUGIN_URL . self::SCRIPT_FILE . '?ver=' . POFSF_VERSION) . "\" defer></script>\n";
    }

    /**
     * Data for the cart script (assets/offer/offer-cart.js): the picks with
     * their prices, stock, limits and variations from the Store API
     * (StoreProducts), the checkout link and the texts to show.
     *
     * @param string $offerUrl The offer link; "Complete purchase" leads through it to checkout.
     */
    public function cartData(array $offerJson, string $offerUrl, int $offerId): array {
        $products = $this->store->forPicks(is_array($offerJson['product_picks'] ?? null) ? $offerJson['product_picks'] : []);

        return [
            'version' => 1,
            'offer' => $offerId,
            'generated' => gmdate('c'),
            'checkout' => add_query_arg('pofsf_to', 'checkout', $offerUrl),
            // The page refreshes prices and stock from here when the store is reachable.
            'storeApi' => rest_url('wc/store/v1/'),
            'currency' => $products['currency'],
            'products' => $products['products'],
            'i18n' => [
                'addToCart' => __('Add to cart', 'personalized-offers-for-spacefast'),
                'selectOptions' => __('Select options', 'personalized-offers-for-spacefast'),
                'outOfStock' => __('Out of stock', 'personalized-offers-for-spacefast'),
                'unavailable' => __('This combination is not available.', 'personalized-offers-for-spacefast'),
                'chooseAn' => __('Choose an option', 'personalized-offers-for-spacefast'),
                'quantity' => __('Quantity', 'personalized-offers-for-spacefast'),
                'added' => __('Added to your cart', 'personalized-offers-for-spacefast'),
                'cart' => __('Your cart', 'personalized-offers-for-spacefast'),
                'openCart' => __('Open your cart', 'personalized-offers-for-spacefast'),
                'close' => __('Close', 'personalized-offers-for-spacefast'),
                'empty' => __('Your cart is empty.', 'personalized-offers-for-spacefast'),
                'remove' => __('Remove', 'personalized-offers-for-spacefast'),
                'decrease' => __('Decrease quantity', 'personalized-offers-for-spacefast'),
                'increase' => __('Increase quantity', 'personalized-offers-for-spacefast'),
                'subtotal' => __('Subtotal', 'personalized-offers-for-spacefast'),
                'note' => __('Your offer discount, shipping and taxes are applied at checkout, where prices and stock are confirmed.', 'personalized-offers-for-spacefast'),
                'complete' => __('Complete purchase', 'personalized-offers-for-spacefast'),
                'cancel' => __('Cancel', 'personalized-offers-for-spacefast'),
            ],
        ];
    }

    /**
     * Data the offer blocks render, with raw values (blocks escape them).
     */
    public function vars(array $offerJson, BrandSnapshot $brand, OfferDesign $design, string $offerUrl, array $images = []): array {
        $storeName = $brand->storeName();

        return [
            'headline' => sanitize_text_field((string) ($offerJson['headline'] ?? '')) ?: __('Picked just for you', 'personalized-offers-for-spacefast'),
            // The offer's text fields by type, for the Offer text block.
            'texts' => OfferCopy::textsByType(OfferCopy::fields($offerJson)),
            'products' => $this->products(is_array($offerJson['product_picks'] ?? null) ? $offerJson['product_picks'] : []),
            // The Offer branding block chooses what to show.
            'branding' => [
                'logo' => (string) ($images['logo'] ?? ''),
                'icon' => (string) ($images['icon'] ?? ''),
                'name' => $storeName,
                'url' => home_url('/'),
            ],
            'store_name' => $storeName,
            'offer_url' => $offerUrl,
            'cta_label' => __('Claim your offer', 'personalized-offers-for-spacefast'),
            // The offer's own text for the Offer action button; the block's text is the fallback.
            'button_text' => sanitize_text_field((string) ($offerJson['button_text'] ?? '')),
        ];
    }

    /**
     * All CSS for a rendered page. Call after rendering, so the per-block
     * styles WordPress generated for that render are included.
     */
    /**
     * The page root as the block editor lays out a block theme's content:
     * constrained to the theme's content width (Wide and Full alignments
     * reach the wide width and the screen edge), with the theme's root
     * padding and block gap. A theme without a content width gets a plain
     * flow root, as its editor has. The sizes become the CSS variables
     * offer.css lays the page out with.
     *
     * @return array{class: string, css: string}
     */
    private function rootLayout(): array {
        $settings = function_exists('wp_get_global_settings') ? wp_get_global_settings() : [];
        $styles = function_exists('wp_get_global_styles') ? wp_get_global_styles() : [];
        $contentSize = self::cssValue($settings['layout']['contentSize'] ?? '');
        $wideSize = self::cssValue($settings['layout']['wideSize'] ?? '');
        $rootPadding = !empty($settings['useRootPaddingAwareAlignments']);
        $vars = [
            '--wp--style--global--content-size' => $contentSize,
            '--wp--style--global--wide-size' => '' !== $wideSize ? $wideSize : $contentSize,
            '--wp--style--block-gap' => self::cssValue($styles['spacing']['blockGap'] ?? ''),
        ];

        if ($rootPadding) {
            foreach (['left', 'right'] as $side) {
                $vars['--wp--style--root--padding-' . $side] = self::cssValue($styles['spacing']['padding'][$side] ?? '');
            }
        }

        $declarations = '';

        foreach (array_filter($vars, static fn (string $value): bool => '' !== $value) as $name => $value) {
            $declarations .= $name . ':' . $value . ';';
        }

        return [
            'class' => 'pofsf-offer-page__root ' . ('' !== $contentSize ? 'is-layout-constrained' . ($rootPadding ? ' has-global-padding' : '') : 'is-layout-flow'),
            'css' => '' !== $declarations ? '/* Theme layout */ body.pofsf-offer-page{' . $declarations . '}' : '',
        ];
    }

    /**
     * A theme.json style value as CSS: `var:preset|spacing|50` becomes
     * var(--wp--preset--spacing--50); anything that could end the
     * declaration is dropped.
     */
    private static function cssValue(mixed $value): string {
        if (!is_string($value) && !is_int($value) && !is_float($value)) {
            return '';
        }

        $value = trim((string) $value);

        if (str_starts_with($value, 'var:')) {
            $value = 'var(--wp--' . str_replace('|', '--', substr($value, 4)) . ')';
        }

        return 1 === preg_match('/^[\w\s().,%+*\/-]+$/', $value) ? $value : '';
    }

    public function css(BrandSnapshot $brand, OfferDesign $design): string {
        $parts = [OfferBlocks::tokensCss($design, $brand)];

        $library = ABSPATH . WPINC . '/css/dist/block-library/style.min.css';

        if (is_readable($library)) {
            $parts[] = (string) file_get_contents($library);
        }

        if (function_exists('wp_get_global_stylesheet')) {
            // Theme variables and preset classes the editor uses, without the theme's element styles.
            // Base layout rules (flex, grid, constrained) come from offer.css.
            $parts[] = wp_get_global_stylesheet(['variables', 'presets']);
        }

        if (function_exists('wp_style_engine_get_stylesheet_from_context')) {
            $parts[] = wp_style_engine_get_stylesheet_from_context('block-supports', ['prettify' => false]);
        }

        $offerCss = POFSF_PLUGIN_DIR . 'assets/offer/offer.css';

        if (is_readable($offerCss)) {
            $parts[] = (string) file_get_contents($offerCss);
        }

        $parts[] = $this->rootLayout()['css'];

        if ('' !== $design->customCss) {
            $parts[] = "/* Template CSS */\n" . $design->customCss;
        }

        return implode("\n", array_filter($parts));
    }

    /**
     * Product data for templates. Values are raw; templates escape them.
     *
     * Offers generated before picks had a title and story fall back to the
     * product name and the reason.
     *
     * @return list<array{name: string, title: string, story: string, price_html: string, image: string, image_large: string, reason: string, pick: int, product_id: int, type: string, purchasable: bool, in_stock: bool}>
     */
    private function products(array $picks): array {
        if (!function_exists('wc_get_product')) {
            return [];
        }

        $products = [];

        foreach (array_values($picks) as $index => $pick) {
            if (!is_array($pick)) {
                continue;
            }

            $productId = (int) ($pick['variation_id'] ?? 0) ?: (int) ($pick['product_id'] ?? 0);
            $product = wc_get_product($productId) ?: wc_get_product((int) ($pick['product_id'] ?? 0));

            if (!$product) {
                continue;
            }

            $imageId = (int) $product->get_image_id();
            $placeholder = function_exists('wc_placeholder_img_src') ? (string) wc_placeholder_img_src('woocommerce_single') : '';

            $reason = sanitize_text_field((string) ($pick['reason'] ?? ''));
            $parent = wc_get_product((int) ($pick['product_id'] ?? 0)) ?: $product;
            $variable = $parent->is_type('variable') && (new ProductVariations())->preferred($parent->get_id()) > 0;

            $products[] = [
                'name' => $product->get_name(),
                'title' => sanitize_text_field((string) ($pick['title'] ?? '')) ?: $product->get_name(),
                'story' => sanitize_textarea_field((string) ($pick['story'] ?? '')) ?: $reason,
                'price_html' => wp_kses_post(wc_price((float) $product->get_price())),
                'image' => $imageId ? (string) wp_get_attachment_image_url($imageId, 'woocommerce_thumbnail') : $placeholder,
                'image_large' => $imageId ? (string) wp_get_attachment_image_url($imageId, 'woocommerce_single') : $placeholder,
                'reason' => $reason,
                // For the products' cart buttons: the pick's place in the offer and what can be bought.
                'pick' => $index + 1,
                'product_id' => (int) ($pick['product_id'] ?? 0),
                'type' => $parent->get_type(),
                // A variable product can be bought while any of its variations can (its own stock status may lag behind them).
                'purchasable' => $parent->is_type('variable') ? $variable : $product->is_purchasable(),
                'in_stock' => $parent->is_type('variable') ? $variable : $product->is_in_stock(),
            ];
        }

        return $products;
    }
}
