<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Repository;

use WP_Error;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The plugin's own custom table; this repository is its only reader and writer, and rows change on every request that uses them, so object caching would only serve stale data.

/**
 * {prefix}pofsf_offer_recipients: the customers of a group offer. Each has
 * their own checkout token and use count; the offer's max_uses applies to
 * each recipient. Status: active, used (limit reached) or revoked
 * (removed from the group after using the offer).
 */
final class RecipientRepository {
    public const ACTIVE = 'active';
    public const USED = 'used';
    public const REVOKED = 'revoked';

    private const TABLE = 'pofsf_offer_recipients';

    public function table(): string {
        global $wpdb;

        return $wpdb->prefix . self::TABLE;
    }

    public function create(int $offerId, int $userId, string $token, string $tokenHash): int|WP_Error {
        global $wpdb;

        $result = $wpdb->insert(
            $this->table(),
            ['offer_id' => $offerId, 'user_id' => $userId, 'token' => $token, 'token_hash' => $tokenHash, 'status' => self::ACTIVE],
            ['%d', '%d', '%s', '%s', '%s'],
        );

        return false === $result ? new WP_Error('db_insert_error', (string) $wpdb->last_error) : (int) $wpdb->insert_id;
    }

    public function find(int $id): ?array {
        global $wpdb;

        return $this->decode($wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE id = %d", $this->table(), $id), ARRAY_A));
    }

    public function findByTokenHash(string $tokenHash): ?array {
        global $wpdb;

        return $this->decode($wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE token_hash = %s", $this->table(), $tokenHash), ARRAY_A));
    }

    /**
     * @return list<array>
     */
    public function forOffer(int $offerId): array {
        global $wpdb;

        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE offer_id = %d ORDER BY id", $this->table(), $offerId), ARRAY_A);

        return array_map([$this, 'decode'], is_array($rows) ? $rows : []);
    }

    /**
     * @return list<array>
     */
    public function forUser(int $userId): array {
        global $wpdb;

        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE user_id = %d", $this->table(), $userId), ARRAY_A);

        return array_map([$this, 'decode'], is_array($rows) ? $rows : []);
    }

    /**
     * Recipients per offer, for the offers list: [offer_id => [total, used]].
     *
     * @param list<int> $offerIds
     * @return array<int, array{total: int, used: int}>
     */
    public function counts(array $offerIds): array {
        global $wpdb;

        $offerIds = array_values(array_filter(array_map('intval', $offerIds)));

        if ([] === $offerIds) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($offerIds), '%d'));
        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- $placeholders is one %d per offer ID, filled by the spread $offerIds.
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT offer_id, SUM(status <> %s) AS total, SUM(status = %s) AS used FROM %i WHERE offer_id IN ($placeholders) GROUP BY offer_id",
            self::REVOKED,
            self::USED,
            $this->table(),
            ...$offerIds,
        ), ARRAY_A);
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

        $counts = [];

        foreach (is_array($rows) ? $rows : [] as $row) {
            $counts[(int) $row['offer_id']] = ['total' => (int) $row['total'], 'used' => (int) $row['used']];
        }

        return $counts;
    }

    public function countActive(int $offerId): int {
        global $wpdb;

        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE offer_id = %d AND status = %s", $this->table(), $offerId, self::ACTIVE));
    }

    public function update(int $id, array $data): bool {
        global $wpdb;

        return false !== $wpdb->update($this->table(), $data, ['id' => $id], null, ['%d']);
    }

    /**
     * Counts one use, unless the recipient has reached $maxUses (0 = no
     * limit). A single statement, so two orders at once cannot both take
     * the last use.
     */
    public function incrementUse(int $id, int $maxUses): bool {
        global $wpdb;

        return 1 === (int) $wpdb->query($wpdb->prepare(
            "UPDATE %i SET used_count = used_count + 1 WHERE id = %d AND status = %s AND ( %d = 0 OR used_count < %d )",
            $this->table(),
            $id,
            self::ACTIVE,
            $maxUses,
            $maxUses,
        ));
    }

    public function delete(int $id): bool {
        global $wpdb;

        return (bool) $wpdb->delete($this->table(), ['id' => $id], ['%d']);
    }

    public function deleteForOffer(int $offerId): void {
        global $wpdb;

        $wpdb->delete($this->table(), ['offer_id' => $offerId], ['%d']);
    }

    private function decode(mixed $row): ?array {
        if (!is_array($row)) {
            return null;
        }

        foreach (['id', 'offer_id', 'user_id', 'used_count', 'consent_given'] as $key) {
            $row[$key] = (int) $row[$key];
        }

        return $row;
    }
}
