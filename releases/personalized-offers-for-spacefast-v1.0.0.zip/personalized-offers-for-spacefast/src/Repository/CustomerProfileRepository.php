<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Repository;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The plugin's own custom table; this repository is its only reader and writer.

/**
 * Stored customer profiles, one row per customer: `user:<id>` for an
 * account, `guest:<email>` for orders placed without one. The computed
 * profile, the manager's corrections and what the customer told us
 * (My preferences, searches) are kept apart, so rebuilding the profile
 * never loses the other two.
 */
final class CustomerProfileRepository {
    private const TABLE = 'pofsf_customer_profiles';

    private const JSON = ['profile', 'corrections', 'customer_input'];

    private const FORMATS = [
        'customer_key' => '%s',
        'user_id' => '%d',
        'email' => '%s',
        'name' => '%s',
        'profile' => '%s',
        'corrections' => '%s',
        'customer_input' => '%s',
        'order_count' => '%d',
        'total_spent' => '%f',
        'last_order_at' => '%s',
        'segment' => '%s',
        'built_at' => '%s',
    ];

    /** Columns the customers list can sort by. */
    public const ORDERBY = ['last_order_at', 'total_spent', 'order_count', 'name', 'built_at'];

    public function table(): string {
        global $wpdb;

        return $wpdb->prefix . self::TABLE;
    }

    public function find(string $key): ?array {
        global $wpdb;

        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE customer_key = %s LIMIT 1', $this->table(), $key), ARRAY_A);

        return is_array($row) ? $this->decode($row) : null;
    }

    /**
     * Inserts or updates the row of $key with the given columns.
     */
    public function save(string $key, array $data): bool {
        global $wpdb;

        $data = array_intersect_key($data, self::FORMATS);

        foreach (self::JSON as $column) {
            if (array_key_exists($column, $data) && !is_string($data[$column])) {
                $data[$column] = (string) wp_json_encode($data[$column] ?? (object) []);
            }
        }

        $formats = array_map(static fn (string $column): string => self::FORMATS[$column], array_keys($data));

        if (null === $this->find($key)) {
            $data = ['customer_key' => $key] + $data + ['profile' => '{}', 'corrections' => '{}', 'customer_input' => '{}'];
            $formats = array_map(static fn (string $column): string => self::FORMATS[$column], array_keys($data));

            return $this->changed($key, false !== $wpdb->insert($this->table(), $data, $formats));
        }

        return [] === $data || $this->changed($key, false !== $wpdb->update($this->table(), $data, ['customer_key' => $key], $formats, ['%s']));
    }

    public function delete(string $key): bool {
        global $wpdb;

        return $this->changed($key, (bool) $wpdb->delete($this->table(), ['customer_key' => $key], ['%s']));
    }

    /**
     * Tells others (segments' member counts) that a profile changed.
     */
    private function changed(string $key, bool $ok): bool {
        if ($ok) {
            do_action('pofsf_customer_profile_changed', $key);
        }

        return $ok;
    }

    /**
     * A page of profiles, with the total.
     *
     * @param array{search?: string, segment?: string, kind?: string, orderby?: string, order?: string, page?: int, per_page?: int} $args
     * @return array{rows: list<array>, total: int}
     */
    public function list(array $args = []): array {
        global $wpdb;

        $where = ['1=1'];
        $params = [];
        $search = trim((string) ($args['search'] ?? ''));

        if ('' !== $search) {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where[] = '(email LIKE %s OR name LIKE %s)';
            array_push($params, $like, $like);
        }

        if ('' !== (string) ($args['segment'] ?? '')) {
            $where[] = 'segment = %s';
            $params[] = (string) $args['segment'];
        }

        if ('guest' === ($args['kind'] ?? '')) {
            $where[] = 'user_id = 0';
        } elseif ('registered' === ($args['kind'] ?? '')) {
            $where[] = 'user_id > 0';
        }

        $orderby = in_array($args['orderby'] ?? '', self::ORDERBY, true) ? $args['orderby'] : 'last_order_at';
        $order = 'asc' === strtolower((string) ($args['order'] ?? '')) ? 'ASC' : 'DESC';
        $perPage = max(1, min(100, (int) ($args['per_page'] ?? 20)));
        $page = max(1, (int) ($args['page'] ?? 1));
        $whereSql = implode(' AND ', $where);

        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $whereSql is built from fixed fragments with placeholders; $orderby and $order are allow-listed above.
        $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE $whereSql", $this->table(), ...$params));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM %i WHERE $whereSql ORDER BY $orderby IS NULL, $orderby $order, id DESC LIMIT %d OFFSET %d",
            $this->table(),
            ...[...$params, $perPage, ($page - 1) * $perPage],
        ), ARRAY_A);
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        return ['rows' => array_map([$this, 'decode'], (array) $rows), 'total' => $total];
    }

    /**
     * @return array<string, int> Profiles per segment.
     */
    public function segmentCounts(): array {
        global $wpdb;

        $rows = $wpdb->get_results($wpdb->prepare('SELECT segment, COUNT(*) AS n FROM %i GROUP BY segment', $this->table()), ARRAY_A);

        return array_map('intval', array_column((array) $rows, 'n', 'segment'));
    }

    /**
     * Keys of profiles built before $before, oldest first.
     *
     * @return list<string>
     */
    public function staleKeys(string $before, int $limit): array {
        global $wpdb;

        return array_map('strval', (array) $wpdb->get_col($wpdb->prepare(
            'SELECT customer_key FROM %i WHERE built_at IS NULL OR built_at < %s ORDER BY built_at ASC LIMIT %d',
            $this->table(),
            $before,
            $limit,
        )));
    }

    /**
     * The next profiles after $afterId (by row ID) that pass the column
     * filters, for going through many profiles in batches.
     *
     * @param array{segments?: list<string>, min_orders?: int, min_spent?: float, ordered_since?: string, not_ordered_since?: string, accounts_only?: bool} $filters
     *        Dates as Y-m-d: a last order on or after `ordered_since`, none on or after `not_ordered_since`.
     * @return list<array>
     */
    public function batch(array $filters, int $afterId, int $limit): array {
        global $wpdb;

        $where = ['id > %d'];
        $params = [$afterId];
        $segments = array_values(array_filter(array_map('strval', (array) ($filters['segments'] ?? []))));

        if ([] !== $segments) {
            $where[] = 'segment IN (' . implode(', ', array_fill(0, count($segments), '%s')) . ')';
            array_push($params, ...$segments);
        }

        if ((int) ($filters['min_orders'] ?? 0) > 0) {
            $where[] = 'order_count >= %d';
            $params[] = (int) $filters['min_orders'];
        }

        if ((float) ($filters['min_spent'] ?? 0) > 0) {
            $where[] = 'total_spent >= %f';
            $params[] = (float) $filters['min_spent'];
        }

        if ('' !== (string) ($filters['ordered_since'] ?? '')) {
            $where[] = 'last_order_at >= %s';
            $params[] = (string) $filters['ordered_since'];
        }

        if ('' !== (string) ($filters['not_ordered_since'] ?? '')) {
            $where[] = '(last_order_at IS NULL OR last_order_at < %s)';
            $params[] = (string) $filters['not_ordered_since'];
        }

        if (!empty($filters['accounts_only'])) {
            $where[] = 'user_id > 0';
        }

        $whereSql = implode(' AND ', $where);

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $whereSql is built from fixed fragments with placeholders.
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE $whereSql ORDER BY id ASC LIMIT %d", $this->table(), ...[...$params, max(1, $limit)]), ARRAY_A);

        return array_map([$this, 'decode'], (array) $rows);
    }

    public function count(): int {
        global $wpdb;

        return (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i', $this->table()));
    }

    private function decode(array $row): array {
        foreach (self::JSON as $column) {
            $decoded = json_decode((string) ($row[$column] ?? ''), true);
            $row[$column] = is_array($decoded) ? $decoded : [];
        }

        $row['id'] = (int) $row['id'];
        $row['user_id'] = (int) $row['user_id'];
        $row['order_count'] = (int) $row['order_count'];
        $row['total_spent'] = (float) $row['total_spent'];

        return $row;
    }
}
