<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Repository;

use Micemade\PersonalizedOffers\Service\EditorCopy;
use Micemade\PersonalizedOffers\Value\OfferDesign;
use WP_Error;
use WP_Post;
use WP_REST_Request;

/**
 * Offer templates: a block-editor post type. The post content is the page
 * layout (core blocks plus the dynamic pofsf/* offer blocks); the design
 * (colors, fonts, tone, note guidance) is post meta edited in the
 * editor's "Offer design" panel. The default template applies to offers
 * created without one.
 *
 * Four built-in templates, one per starter layout, are kept up to date
 * automatically. They are read-only: duplicate one to customize it.
 */
final class TemplateRepository {
    public const POST_TYPE = 'pofsf_offer_template';
    public const META_DESIGN = '_pofsf_design';
    private const META_BUILTIN = '_pofsf_builtin';
    private const DEFAULT_OPTION = 'pofsf_default_template_id';
    private const BUILTINS_OPTION = 'pofsf_builtin_templates_version';
    private const BUILTINS_VERSION = 2;

    public function register(): void {
        add_action('init', [$this, 'registerPostType']);
        add_action('admin_init', [$this, 'ensureBuiltins']);
        add_action('load-post.php', [$this, 'ensureEditableContent']);
        add_filter('rest_pre_insert_' . self::POST_TYPE, [$this, 'guardBuiltin'], 10, 2);
        add_filter('preview_post_link', [$this, 'previewLink'], 10, 2);
    }

    public function registerPostType(): void {
        $cap = 'manage_woocommerce';

        register_post_type(self::POST_TYPE, [
            'labels' => [
                'name' => __('Offer templates', 'personalized-offers-for-spacefast'),
                'singular_name' => __('Offer template', 'personalized-offers-for-spacefast'),
                'edit_item' => __('Edit offer template', 'personalized-offers-for-spacefast'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'show_in_rest' => true,
            'rewrite' => false,
            'query_var' => false,
            'supports' => ['title', 'editor', 'excerpt', 'custom-fields'],
            'map_meta_cap' => false,
            'capabilities' => array_fill_keys([
                'edit_post', 'read_post', 'delete_post', 'edit_posts', 'edit_others_posts', 'publish_posts',
                'read_private_posts', 'delete_posts', 'delete_others_posts', 'delete_published_posts',
                'edit_published_posts', 'delete_private_posts', 'edit_private_posts', 'create_posts', 'read',
            ], $cap),
        ]);

        register_post_meta(self::POST_TYPE, self::META_DESIGN, [
            'single' => true,
            'type' => 'object',
            'default' => OfferDesign::brandDefault()->toArray(),
            'show_in_rest' => ['schema' => self::designRestSchema()],
            'auth_callback' => static fn (): bool => current_user_can($cap),
            'sanitize_callback' => static fn (mixed $value): array => OfferDesign::fromArray(is_array($value) ? $value : [])->toArray(),
        ]);
    }

    /**
     * REST schema for the design meta, matching OfferDesign::toArray().
     */
    public static function designRestSchema(): array {
        $colors = [];

        foreach (OfferDesign::COLOR_KEYS as $key) {
            $colors[$key] = ['type' => 'string'];
        }

        return [
            'type' => 'object',
            'additionalProperties' => false,
            'properties' => [
                'base' => ['type' => 'string'],
                'use_brand' => ['type' => 'boolean'],
                'colors' => ['type' => 'object', 'properties' => $colors, 'additionalProperties' => false],
                'fonts' => [
                    'type' => 'object',
                    'properties' => ['heading' => ['type' => 'string'], 'body' => ['type' => 'string']],
                    'additionalProperties' => false,
                ],
                'font_url' => ['type' => 'string'],
                'layout' => ['type' => 'string'],
                'tone' => ['type' => 'string'],
                'note_guidance' => ['type' => 'string'],
                'custom_css' => ['type' => 'string'],
            ],
        ];
    }

    /**
     * Creates missing built-ins and refreshes existing ones (they are
     * read-only, so their content always matches the plugin version).
     */
    public function ensureBuiltins(): void {
        if ((int) get_option(self::BUILTINS_OPTION, 0) >= self::BUILTINS_VERSION) {
            return;
        }

        $existing = [];

        foreach (get_posts(['post_type' => self::POST_TYPE, 'post_status' => 'any', 'numberposts' => -1, 'meta_key' => self::META_BUILTIN]) as $post) { // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- A handful of template posts, read when built-ins are updated.
            $existing[(string) get_post_meta($post->ID, self::META_BUILTIN, true)] = $post->ID;
        }

        foreach (self::builtinDefinitions() as $base => $definition) {
            $postId = wp_insert_post([
                'ID' => $existing[$base] ?? 0,
                'post_type' => self::POST_TYPE,
                'post_status' => 'publish',
                'post_title' => $definition['name'],
                'post_excerpt' => $definition['description'],
                'post_content' => self::starterContent($base),
                'menu_order' => (int) array_search($base, OfferDesign::BASES, true),
            ], true);

            if (!$postId instanceof WP_Error) {
                update_post_meta($postId, self::META_DESIGN, OfferDesign::fromArray($definition['design'])->toArray());
                update_post_meta($postId, self::META_BUILTIN, $base);

                /** See save(): offers using a built-in template follow its update. */
                do_action('pofsf_template_saved', (int) $postId);
            }
        }

        update_option(self::BUILTINS_OPTION, self::BUILTINS_VERSION, false);
    }

    /**
     * Block markup of a starter layout (templates/offer/{base}.html).
     */
    public static function starterContent(string $base): string {
        $base = in_array($base, OfferDesign::BASES, true) ? $base : 'classic';
        $file = POFSF_PLUGIN_DIR . 'templates/offer/' . $base . '.html';

        return is_readable($file) ? (string) file_get_contents($file) : '';
    }

    /**
     * Starting designs, one per starter layout. Fonts are FontCatalog keys.
     *
     * @return array<string, array{name: string, description: string, design: array}>
     */
    public static function builtinDefinitions(): array {
        return [
            'classic' => [
                'name' => __('Feature story', 'personalized-offers-for-spacefast'),
                'description' => __('A clean editorial feature in your store brand: the theme and headline, a pull quote, then each pick as its own story with alternating images. A safe default.', 'personalized-offers-for-spacefast'),
                'design' => [
                    'base' => 'classic',
                    'use_brand' => true,
                    'layout' => 'grid',
                    'tone' => 'warm, confident and editorial, like a short feature written for one reader',
                ],
            ],
            'editorial' => [
                'name' => __('Magazine', 'personalized-offers-for-spacefast'),
                'description' => __('Magazine style: masthead, serif headline beside the introduction, the note as a pull quote and the picks as cover stories.', 'personalized-offers-for-spacefast'),
                'design' => [
                    'base' => 'editorial',
                    'use_brand' => false,
                    'colors' => [
                        'primary' => '#1f1b16',
                        'secondary' => '#7a4b2a',
                        'accent' => '#b08150',
                        'background' => '#faf7f2',
                        'surface' => '#f1ebe1',
                        'border' => '#e4dbcd',
                        'text' => '#1f1b16',
                        'text_muted' => '#6b6158',
                    ],
                    'fonts' => ['heading' => 'fraunces', 'body' => 'inter'],
                    'custom_css' => ':root { --pofsf-radius: 2px; }',
                    'tone' => 'considered, warm and editorial, like a style column written for one reader',
                    'note_guidance' => 'a short, sincere thank-you that mentions what they have enjoyed before',
                ],
            ],
            'letter' => [
                'name' => __('Personal letter', 'personalized-offers-for-spacefast'),
                'description' => __('A heartfelt letter from the shop on a paper card, with the picks woven in as short numbered notes, signed by the team.', 'personalized-offers-for-spacefast'),
                'design' => [
                    'base' => 'letter',
                    'use_brand' => false,
                    'colors' => [
                        'primary' => '#2f4a6d',
                        'secondary' => '#7c3f2c',
                        'accent' => '#d9a441',
                        'background' => '#efe9df',
                        'surface' => '#fffdf8',
                        'border' => '#e2d8c8',
                        'text' => '#2b2622',
                        'text_muted' => '#6e655c',
                    ],
                    'fonts' => ['heading' => 'caveat', 'body' => 'lora'],
                    'custom_css' => ':root { --pofsf-radius: 6px; }',
                    'tone' => 'personal and heartfelt, written by the shop owner to a valued customer',
                    'note_guidance' => 'a heartfelt thank-you for their loyalty in 3-4 sentences, as a handwritten letter from the shop owner, mentioning something specific about their shopping history',
                ],
            ],
            'spotlight' => [
                'name' => __('Campaign', 'personalized-offers-for-spacefast'),
                'description' => __('A bold marketing campaign: big banner headline, perks strip, a captioned lookbook and a sticky call-to-action bar.', 'personalized-offers-for-spacefast'),
                'design' => [
                    'base' => 'spotlight',
                    'use_brand' => false,
                    'colors' => [
                        'primary' => '#e8430c',
                        'secondary' => '#141414',
                        'accent' => '#ffb627',
                        'background' => '#ffffff',
                        'surface' => '#fff4ea',
                        'border' => '#f2ddca',
                        'text' => '#141414',
                        'text_muted' => '#5b5b5b',
                    ],
                    'fonts' => ['heading' => 'archivo-black', 'body' => 'archivo'],
                    'custom_css' => ':root { --pofsf-radius: 16px; }',
                    'tone' => 'energetic, upbeat and playful, with short punchy sentences',
                    'note_guidance' => 'a short, upbeat thank-you for being a loyal customer',
                ],
            ],
        ];
    }

    /**
     * @return list<array{id: int, name: string, description: string, design: OfferDesign, content: string, is_default: bool, builtin: string, updated_at: string}>
     */
    public function all(): array {
        $posts = get_posts([
            'post_type' => self::POST_TYPE,
            'post_status' => 'publish',
            'numberposts' => 100,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);

        $templates = array_map([$this, 'hydrate'], $posts);

        // Built-ins first, in layout order; then custom templates by name.
        $rank = static fn (array $t): int => '' !== $t['builtin'] ? (int) array_search($t['builtin'], OfferDesign::BASES, true) : 100;
        usort($templates, static fn (array $a, array $b): int => [$rank($a), $a['name']] <=> [$rank($b), $b['name']]);

        return $templates;
    }

    public function find(int $id): ?array {
        $post = $id > 0 ? get_post($id) : null;

        return $post instanceof WP_Post && self::POST_TYPE === $post->post_type && in_array($post->post_status, ['publish', 'draft'], true)
            ? $this->hydrate($post)
            : null;
    }

    /**
     * Creates a template, or updates a custom one when $id is given.
     *
     * @param string|null $content Block markup; null keeps the current content
     *                             (or the design's starter layout for a new template).
     */
    public function save(string $name, string $description, OfferDesign $design, int $id = 0, ?string $content = null): int|WP_Error {
        $name = sanitize_text_field($name);

        if ('' === $name) {
            return new WP_Error('pofsf_template_name', __('A template needs a name.', 'personalized-offers-for-spacefast'));
        }

        if ($id > 0) {
            $existing = $this->find($id);

            if (null === $existing) {
                return new WP_Error('pofsf_template_missing', __('Template not found.', 'personalized-offers-for-spacefast'));
            }

            if ('' !== $existing['builtin']) {
                return new WP_Error('pofsf_template_builtin', __('Built-in templates cannot be changed. Duplicate it and edit the copy.', 'personalized-offers-for-spacefast'));
            }
        }

        $post = [
            'ID' => $id,
            'post_type' => self::POST_TYPE,
            'post_status' => 'publish',
            'post_title' => $name,
            'post_excerpt' => sanitize_textarea_field($description),
        ];

        if (null !== $content) {
            $post['post_content'] = $content;
        } elseif (0 === $id) {
            $post['post_content'] = self::starterContent($design->base);
        }

        $postId = wp_insert_post(wp_slash($post), true);

        if ($postId instanceof WP_Error) {
            return $postId;
        }

        update_post_meta($postId, self::META_DESIGN, $design->toArray());

        /**
         * A template was saved with its design; offers using it follow it.
         * (wp_after_insert_post fired above, before the design was stored.)
         */
        do_action('pofsf_template_saved', (int) $postId);

        return (int) $postId;
    }

    /**
     * Copies a template (built-in or custom) into a new custom template.
     */
    public function duplicate(int $id, string $name = ''): int|WP_Error {
        $source = $this->find($id);

        if (null === $source) {
            return new WP_Error('pofsf_template_missing', __('Template not found.', 'personalized-offers-for-spacefast'));
        }

        return $this->save(
            '' !== trim($name) ? $name : sprintf(
                /* translators: %s: template name. */
                __('%s (copy)', 'personalized-offers-for-spacefast'),
                $source['name'],
            ),
            $source['description'],
            $source['design'],
            0,
            $source['content'],
        );
    }

    public function delete(int $id): true|WP_Error {
        $template = $this->find($id);

        if (null === $template) {
            return new WP_Error('pofsf_template_missing', __('Template not found.', 'personalized-offers-for-spacefast'));
        }

        if ('' !== $template['builtin']) {
            return new WP_Error('pofsf_template_builtin', __('Built-in templates cannot be deleted.', 'personalized-offers-for-spacefast'));
        }

        if ($this->defaultId() === $id) {
            delete_option(self::DEFAULT_OPTION);
        }

        return wp_delete_post($id, true) ? true : new WP_Error('pofsf_template_delete', __('The template could not be deleted.', 'personalized-offers-for-spacefast'));
    }

    public function defaultId(): int {
        $id = (int) get_option(self::DEFAULT_OPTION, 0);

        return null !== $this->find($id) ? $id : 0;
    }

    public function setDefault(int $id): bool {
        if (0 === $id) {
            delete_option(self::DEFAULT_OPTION);

            return true;
        }

        if (null === $this->find($id)) {
            return false;
        }

        update_option(self::DEFAULT_OPTION, $id, false);

        return true;
    }

    /**
     * Templates made before block layouts have no content: give them their
     * starter layout before the editor opens, so there is something to edit.
     */
    public function ensureEditableContent(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- The post the block editor (post.php) is opening; the change below is gated by its post type and the capability check.
        $postId = isset($_GET['post']) ? absint($_GET['post']) : 0;
        $post = $postId > 0 ? get_post($postId) : null;

        if (!$post instanceof WP_Post || self::POST_TYPE !== $post->post_type || '' !== trim($post->post_content) || !current_user_can('manage_woocommerce')) {
            return;
        }

        $design = $this->find($postId)['design'] ?? OfferDesign::brandDefault();

        wp_update_post(wp_slash(['ID' => $postId, 'post_content' => self::starterContent($design->base)]));
    }

    /**
     * Built-ins are read-only, including through the block editor's REST saves.
     */
    public function guardBuiltin(mixed $prepared, WP_REST_Request $request): mixed {
        $id = (int) ($request['id'] ?? 0);

        if ($id > 0 && '' !== (string) get_post_meta($id, self::META_BUILTIN, true)) {
            return new WP_Error('pofsf_template_builtin', __('Built-in templates are read-only. Duplicate it from the Templates tab to customize it.', 'personalized-offers-for-spacefast'), ['status' => 403]);
        }

        return $prepared;
    }

    /**
     * The editor's Preview button opens the offer preview with sample data.
     */
    public function previewLink(string $link, WP_Post $post): string {
        if (self::POST_TYPE !== $post->post_type) {
            return $link;
        }

        return add_query_arg(array_filter([
            'page' => 'personalized-offers-for-spacefast',
            'pofsf_preview_template' => $post->ID,
            'pofsf_autosave' => 1,
            // Opened from Edit offer: the preview shows the offer's texts too.
            EditorCopy::PARAM => EditorCopy::requestKey(),
        ]), admin_url('admin.php'));
    }

    public static function editUrl(int $id): string {
        return add_query_arg(['post' => $id, 'action' => 'edit', 'pofsf_frame' => 1], admin_url('post.php'));
    }

    private function hydrate(WP_Post $post): array {
        $design = get_post_meta($post->ID, self::META_DESIGN, true);
        $design = OfferDesign::fromArray(is_array($design) ? $design : []);

        return [
            'id' => $post->ID,
            'name' => $post->post_title,
            'description' => $post->post_excerpt,
            'design' => $design,
            'content' => '' !== trim($post->post_content) ? $post->post_content : self::starterContent($design->base),
            'is_default' => (int) get_option(self::DEFAULT_OPTION, 0) === $post->ID,
            'builtin' => (string) get_post_meta($post->ID, self::META_BUILTIN, true),
            'updated_at' => (string) $post->post_modified_gmt,
        ];
    }
}
