<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Repository;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The plugin's own custom table; this repository is its only reader and writer.

/**
 * Segments the store saved: a name and rules over the stored customer
 * profiles (Segments). Members are never stored: they follow the profiles.
 */
final class SegmentRepository {
    private const TABLE = 'pofsf_segments';

    private const FORMATS = [
        'name' => '%s',
        'description' => '%s',
        'rules' => '%s',
        'created_by' => '%d',
    ];

    public function table(): string {
        global $wpdb;

        return $wpdb->prefix . self::TABLE;
    }

    public function find(int $id): ?array {
        global $wpdb;

        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id = %d LIMIT 1', $this->table(), $id), ARRAY_A);

        return is_array($row) ? $this->decode($row) : null;
    }

    /**
     * @return list<array> Oldest first.
     */
    public function all(): array {
        global $wpdb;

        $rows = $wpdb->get_results($wpdb->prepare('SELECT * FROM %i ORDER BY id ASC LIMIT 200', $this->table()), ARRAY_A);

        return array_map([$this, 'decode'], (array) $rows);
    }

    public function create(array $data): int {
        global $wpdb;

        $data = $this->encode($data) + ['description' => '', 'rules' => '{}'];
        $ok = $wpdb->insert($this->table(), $data, $this->formats($data));

        return false !== $ok ? (int) $wpdb->insert_id : 0;
    }

    public function update(int $id, array $data): bool {
        global $wpdb;

        $data = $this->encode($data);

        return [] === $data || false !== $wpdb->update($this->table(), $data, ['id' => $id], $this->formats($data), ['%d']);
    }

    public function delete(int $id): bool {
        global $wpdb;

        return (bool) $wpdb->delete($this->table(), ['id' => $id], ['%d']);
    }

    private function encode(array $data): array {
        $data = array_intersect_key($data, self::FORMATS);

        if (array_key_exists('rules', $data) && !is_string($data['rules'])) {
            $data['rules'] = (string) wp_json_encode((object) $data['rules']);
        }

        return $data;
    }

    private function formats(array $data): array {
        return array_map(static fn (string $column): string => self::FORMATS[$column], array_keys($data));
    }

    private function decode(array $row): array {
        $rules = json_decode((string) ($row['rules'] ?? ''), true);
        $row['rules'] = is_array($rules) ? $rules : [];
        $row['id'] = (int) $row['id'];
        $row['created_by'] = (int) $row['created_by'];

        return $row;
    }
}
