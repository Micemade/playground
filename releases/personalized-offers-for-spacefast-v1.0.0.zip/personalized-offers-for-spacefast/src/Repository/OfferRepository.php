<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Repository;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Enum\OfferType;
use WP_Error;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The plugin's own custom table; this repository is its only reader and writer, and rows change on every request that uses them, so object caching would only serve stale data.

final class OfferRepository {
    private const TABLE = 'pofsf_offers';

    private const FORMATS_BY_KEY = [
        'token' => '%s',
        'token_hash' => '%s',
        'user_id' => '%d',
        'guest_email' => '%s',
        'offer_data' => '%s',
        'coupon_code' => '%s',
        'status' => '%s',
        'expires_at' => '%s',
        'used_count' => '%d',
        'max_uses' => '%d',
        'consent_given' => '%d',
        'type' => '%s',
    ];

    public function table(): string {
        global $wpdb;

        return $wpdb->prefix . self::TABLE;
    }

    /**
     * @param array{token?:string,token_hash?:string,user_id?:int,guest_email?:?string,offer_data?:array|string,coupon_code?:string,status?:string,expires_at?:string,used_count?:int,max_uses?:int,consent_given?:int|bool,type?:string|OfferType} $data
     */
    public function create(array $data): int|WP_Error {
        global $wpdb;

        $row = array_merge([
            'token' => '',
            'token_hash' => '',
            'user_id' => 0,
            'guest_email' => null,
            'offer_data' => [],
            'coupon_code' => '',
            'status' => OfferStatus::Pending->value,
            'expires_at' => current_time('mysql', true),
            'used_count' => 0,
            'max_uses' => 1,
            'consent_given' => 0,
            'type' => OfferType::Single->value,
        ], $data);

        // Same key order as FORMATS_BY_KEY, which gives the insert formats.
        $row = array_merge(self::FORMATS_BY_KEY, array_intersect_key($row, self::FORMATS_BY_KEY));
        $row['type'] = $row['type'] instanceof OfferType ? $row['type']->value : (string) $row['type'];

        $row['offer_data'] = is_string($row['offer_data']) ? $row['offer_data'] : wp_json_encode($row['offer_data']);

        $result = $wpdb->insert($this->table(), $row, array_values(self::FORMATS_BY_KEY));

        if (false === $result) {
            return new WP_Error('db_insert_error', (string) $wpdb->last_error);
        }

        return (int) $wpdb->insert_id;
    }

    public function update(int $id, array $data): bool|WP_Error {
        global $wpdb;

        if (isset($data['status']) && $data['status'] instanceof OfferStatus) {
            $data['status'] = $data['status']->value;
        }

        if (isset($data['type']) && $data['type'] instanceof OfferType) {
            $data['type'] = $data['type']->value;
        }

        if (isset($data['offer_data']) && is_array($data['offer_data'])) {
            $data['offer_data'] = wp_json_encode($data['offer_data']);
        }

        if ([] === $data) {
            return new WP_Error('db_update_error', __('Nothing to update.', 'personalized-offers-for-spacefast'));
        }

        $format = array_map(
            static fn (string $key): string => self::FORMATS_BY_KEY[$key] ?? '%s',
            array_keys($data),
        );

        $result = $wpdb->update($this->table(), $data, ['id' => $id], $format, ['%d']);

        if (false === $result) {
            return new WP_Error('db_update_error', (string) $wpdb->last_error);
        }

        return true;
    }

    public function find(int $id): ?array {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM %i WHERE id = %d LIMIT 1", $this->table(), $id),
            ARRAY_A,
        );

        return $this->decodeRow($row);
    }

    public function findByTokenHash(string $tokenHash): ?array {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM %i WHERE token_hash = %s LIMIT 1", $this->table(), $tokenHash),
            ARRAY_A,
        );

        return $this->decodeRow($row);
    }

    public function findByUser(int $userId, ?OfferStatus $status = null): array {
        global $wpdb;

        $status = $status instanceof OfferStatus ? $status->value : '';

        // An empty filter value matches every row, so the query string stays fixed.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM %i WHERE user_id = %d AND (%s = '' OR status = %s)",
                $this->table(),
                $userId,
                $status,
                $status,
            ),
            ARRAY_A,
        );

        return $this->decodeRows($rows);
    }

    public function findByGuestEmail(string $email): array {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM %i WHERE guest_email = %s ORDER BY created_at DESC", $this->table(), $email),
            ARRAY_A,
        );

        return $this->decodeRows($rows);
    }

    /**
     * Offers whose design comes from the template $templateId.
     *
     * @return list<array>
     */
    public function findByTemplate(int $templateId): array {
        global $wpdb;

        if ($templateId <= 0) {
            return [];
        }

        // A loose text match narrows the rows (the database may normalize the
        // JSON, e.g. `"template_id": 12`); the decoded value decides, so 12
        // does not match 123 or another key's 12.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM %i WHERE offer_data LIKE %s',
                $this->table(),
                '%' . $wpdb->esc_like('"template_id":') . '%' . $wpdb->esc_like((string) $templateId) . '%',
            ),
            ARRAY_A,
        );

        return array_values(array_filter(
            $this->decodeRows($rows),
            static fn (array $offer): bool => $templateId === (int) ($offer['offer_data']['template_id'] ?? 0),
        ));
    }

    /**
     * Offers published to Spacefast (a loose text match narrows the rows;
     * the caller checks the decoded record).
     *
     * @return list<array>
     */
    public function withSpace(): array {
        global $wpdb;

        return $this->decodeRows($wpdb->get_results(
            $wpdb->prepare('SELECT * FROM %i WHERE offer_data LIKE %s', $this->table(), '%' . $wpdb->esc_like('"space_id"') . '%'),
            ARRAY_A,
        ));
    }

    public function list(array $args = []): array {
        global $wpdb;

        $args = wp_parse_args($args, [
            'status' => '',
            'type' => '',
            'user_id' => 0,
            'limit' => 50,
            'offset' => 0,
            'orderby' => 'created_at',
            'order' => 'DESC',
        ]);

        $orderby = in_array($args['orderby'], ['created_at', 'expires_at', 'status', 'user_id'], true)
            ? $args['orderby']
            : 'created_at';
        [$status, $type, $userId] = $this->filters($args);
        $limit = (int) $args['limit'];
        $offset = (int) $args['offset'];

        // ORDER BY direction cannot be a placeholder, hence one query per direction.
        $rows = 'ASC' === strtoupper((string) $args['order'])
            ? $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM %i WHERE (%s = '' OR status = %s) AND (%s = '' OR type = %s) AND (%d = 0 OR user_id = %d) ORDER BY %i ASC LIMIT %d OFFSET %d",
                    $this->table(),
                    $status,
                    $status,
                    $type,
                    $type,
                    $userId,
                    $userId,
                    $orderby,
                    $limit,
                    $offset,
                ),
                ARRAY_A,
            )
            : $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM %i WHERE (%s = '' OR status = %s) AND (%s = '' OR type = %s) AND (%d = 0 OR user_id = %d) ORDER BY %i DESC LIMIT %d OFFSET %d",
                    $this->table(),
                    $status,
                    $status,
                    $type,
                    $type,
                    $userId,
                    $userId,
                    $orderby,
                    $limit,
                    $offset,
                ),
                ARRAY_A,
            );

        return $this->decodeRows($rows);
    }

    public function count(array $args = []): int {
        global $wpdb;

        $args = wp_parse_args($args, ['status' => '', 'type' => '', 'user_id' => 0]);

        [$status, $type, $userId] = $this->filters($args);

        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM %i WHERE (%s = '' OR status = %s) AND (%s = '' OR type = %s) AND (%d = 0 OR user_id = %d)",
                $this->table(),
                $status,
                $status,
                $type,
                $type,
                $userId,
                $userId,
            ),
        );
    }

    /**
     * The list()/count() filters. Each is passed twice to
     * `(%s = '' OR status = %s)`-style conditions, where an empty value
     * matches every row, so the query string stays fixed.
     *
     * @return array{string, string, int} status, type, user ID
     */
    private function filters(array $args): array {
        return [(string) $args['status'], (string) $args['type'], (int) $args['user_id']];
    }

    public function delete(int $id): bool {
        global $wpdb;

        return (bool) $wpdb->delete($this->table(), ['id' => $id], ['%d']);
    }

    /**
     * Counts one use, unless the offer has reached its limit (max_uses 0 =
     * no limit). A single statement, so two orders at once cannot both take
     * the last use.
     */
    public function incrementUse(int $id): bool {
        global $wpdb;

        return 1 === (int) $wpdb->query(
            $wpdb->prepare(
                "UPDATE %i SET used_count = used_count + 1 WHERE id = %d AND ( max_uses = 0 OR used_count < max_uses )",
                $this->table(),
                $id,
            ),
        );
    }

    /**
     * Counts an order of a group offer: a running total, as each recipient's
     * own limit is kept on their recipient row.
     */
    public function countUse(int $id): bool {
        global $wpdb;

        return 1 === (int) $wpdb->query($wpdb->prepare("UPDATE %i SET used_count = LEAST(used_count + 1, 65535) WHERE id = %d", $this->table(), $id));
    }

    public function expireOverdue(string $now): int {
        global $wpdb;

        return (int) $wpdb->query(
            $wpdb->prepare(
                "UPDATE %i SET status = %s WHERE status IN ( 'ready', 'sent' ) AND expires_at < %s",
                $this->table(),
                OfferStatus::Expired->value,
                $now,
            ),
        );
    }

    public function deleteFailedOlderThan(string $now, int $days = 7): int {
        global $wpdb;

        return (int) $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM %i WHERE status = %s AND created_at < DATE_SUB(%s, INTERVAL %d DAY)",
                $this->table(),
                OfferStatus::Failed->value,
                $now,
                $days,
            ),
        );
    }

    private function decodeRow(mixed $row): ?array {
        if (!is_array($row)) {
            return null;
        }

        $decoded = json_decode((string) ($row['offer_data'] ?? ''), true);
        $row['offer_data'] = is_array($decoded) ? $decoded : [];

        return $row;
    }

    private function decodeRows(mixed $rows): array {
        if (!is_array($rows)) {
            return [];
        }

        return array_map(fn (array $row): array => $this->decodeRow($row) ?? $row, $rows);
    }
}
