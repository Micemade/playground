<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Repository;

use WP_Error;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The plugin's own custom table; this repository is its only reader and writer, and rows change on every request that uses them, so object caching would only serve stale data.

final class BrandSnapshotRepository {
    private const TABLE = 'pofsf_brand_snapshots';
    private const VERSION_OPTION = 'pofsf_brand_snapshot_version';

    public function table(): string {
        global $wpdb;

        return $wpdb->prefix . self::TABLE;
    }

    public function nextVersion(): int {
        global $wpdb;

        return (int) $wpdb->get_var($wpdb->prepare("SELECT MAX(version) FROM %i", $this->table())) + 1;
    }

    public function create(array $data, int $userId): int|WP_Error {
        global $wpdb;

        $version = $this->nextVersion();

        $wpdb->update($this->table(), ['is_active' => 0], ['is_active' => 1], ['%d'], ['%d']);

        $result = $wpdb->insert(
            $this->table(),
            [
                'version' => $version,
                'data' => wp_json_encode($data),
                'is_active' => 1,
                'created_by' => $userId,
            ],
            ['%d', '%s', '%d', '%d'],
        );

        if (false === $result) {
            return new WP_Error('db_insert_error', (string) $wpdb->last_error);
        }

        update_option(self::VERSION_OPTION, $version);

        return (int) $wpdb->insert_id;
    }

    public function findActive(): ?array {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM %i WHERE is_active = 1 LIMIT 1", $this->table()),
            ARRAY_A,
        );

        return $this->decodeRow($row);
    }

    public function activeData(): ?array {
        $row = $this->findActive();

        return $row['data'] ?? null;
    }

    public function findByVersion(int $version): ?array {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM %i WHERE version = %d LIMIT 1", $this->table(), $version),
            ARRAY_A,
        );

        return $this->decodeRow($row);
    }

    /**
     * @return list<array{version:int,created_by:int,created_at:string,is_active:int}>
     */
    public function versions(): array {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT version, created_by, created_at, is_active FROM %i ORDER BY version DESC", $this->table()),
            ARRAY_A,
        );

        return is_array($rows) ? $rows : [];
    }

    public function delete(int $version): bool|WP_Error {
        global $wpdb;

        $active = $this->findActive();

        if ($active && (int) ($active['version'] ?? 0) === $version) {
            return new WP_Error(
                'active_version',
                __('The active brand version cannot be deleted. Activate another version first.', 'personalized-offers-for-spacefast'),
            );
        }

        $deleted = $wpdb->delete($this->table(), ['version' => $version], ['%d']);

        if (false === $deleted) {
            return new WP_Error('db_delete_error', (string) $wpdb->last_error);
        }

        return true;
    }

    public function activate(int $version): bool {
        global $wpdb;

        $wpdb->update($this->table(), ['is_active' => 0], ['is_active' => 1], ['%d'], ['%d']);

        $result = $wpdb->update($this->table(), ['is_active' => 1], ['version' => $version], ['%d'], ['%d']);

        if ($result) {
            update_option(self::VERSION_OPTION, $version);
        }

        return (bool) $result;
    }

    private function decodeRow(mixed $row): ?array {
        if (!is_array($row)) {
            return null;
        }

        $decoded = json_decode((string) ($row['data'] ?? ''), true);
        $row['data'] = is_array($decoded) ? $decoded : [];

        return $row;
    }
}
