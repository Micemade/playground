<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Repository;

/**
 * Per-user assistant conversations, kept in user meta: an index of chats
 * (`_pofsf_chats`) plus one meta row of serialized messages per chat.
 */
final class ChatRepository {
    private const INDEX_KEY = '_pofsf_chats';
    private const MESSAGES_PREFIX = '_pofsf_chat_';

    /** Single conversation stored by earlier versions; migrated on first read. */
    private const LEGACY_KEY = '_pofsf_chat_history';

    private const MAX_CHATS = 50;

    public static function isValidId(string $chatId): bool {
        return 1 === preg_match('/^[a-z0-9]{12}$/', $chatId);
    }

    public static function newId(): string {
        return strtolower(wp_generate_password(12, false));
    }

    /**
     * Chats, most recently updated first. `titled` is true once the title
     * was derived from the conversation; until then it reads "New chat".
     *
     * @return list<array{id: string, title: string, titled: bool, created_at: string, updated_at: string}>
     */
    public function all(int $userId): array {
        $index = $this->index($userId);

        uasort($index, static fn (array $a, array $b): int => strcmp($b['updated_at'], $a['updated_at']));

        return array_values($index);
    }

    public function find(int $userId, string $chatId): ?array {
        return $this->index($userId)[$chatId] ?? null;
    }

    /**
     * @return list<array> Message arrays (Message::toArray() shape).
     */
    public function messages(int $userId, string $chatId): array {
        if (!self::isValidId($chatId)) {
            return [];
        }

        $stored = get_user_meta($userId, self::MESSAGES_PREFIX . $chatId, true);

        return is_array($stored) ? array_values($stored) : [];
    }

    /**
     * Starts a chat so it shows in the history right away. An existing
     * empty chat is reused (and moved to the top) instead of piling up.
     */
    public function create(int $userId): array {
        $index = $this->index($userId);
        $now = gmdate('c');

        foreach ($index as $chatId => $chat) {
            if ([] === $this->messages($userId, $chatId)) {
                $index[$chatId]['updated_at'] = $now;
                $this->storeIndex($userId, $index);

                return $index[$chatId];
            }
        }

        $chatId = self::newId();
        $index[$chatId] = self::entry($chatId, $now);
        $this->storeIndex($userId, $this->prune($userId, $index));

        return $index[$chatId];
    }

    /**
     * Stores a chat's messages, creating the chat if it does not exist yet.
     *
     * @param list<array> $messages
     */
    public function save(int $userId, string $chatId, array $messages): array {
        $index = $this->index($userId);
        $now = gmdate('c');

        $index[$chatId] = array_merge($index[$chatId] ?? self::entry($chatId, $now), ['updated_at' => $now]);

        update_user_meta($userId, self::MESSAGES_PREFIX . $chatId, $messages);
        $this->storeIndex($userId, $this->prune($userId, $index));

        return $index[$chatId];
    }

    /**
     * Sets a title derived from the conversation.
     */
    public function setTitle(int $userId, string $chatId, string $title): ?array {
        $index = $this->index($userId);
        $title = self::title($title);

        if (!isset($index[$chatId]) || '' === $title) {
            return $index[$chatId] ?? null;
        }

        $index[$chatId]['title'] = $title;
        $index[$chatId]['titled'] = true;
        $this->storeIndex($userId, $index);

        return $index[$chatId];
    }

    public function delete(int $userId, string $chatId): bool {
        $index = $this->index($userId);

        if (!isset($index[$chatId])) {
            return false;
        }

        unset($index[$chatId]);
        delete_user_meta($userId, self::MESSAGES_PREFIX . $chatId);
        $this->storeIndex($userId, $index);

        return true;
    }

    /**
     * @return array<string, array{id: string, title: string, created_at: string, updated_at: string}>
     */
    private function index(int $userId): array {
        $this->migrateLegacy($userId);

        $stored = get_user_meta($userId, self::INDEX_KEY, true);

        if (!is_array($stored)) {
            return [];
        }

        $index = array_filter(
            $stored,
            static fn (mixed $chat, mixed $id): bool => is_array($chat) && is_string($id) && self::isValidId($id),
            ARRAY_FILTER_USE_BOTH,
        );

        return array_map(static fn (array $chat): array => $chat + ['titled' => true], $index);
    }

    private function storeIndex(int $userId, array $index): void {
        if ([] === $index) {
            delete_user_meta($userId, self::INDEX_KEY);

            return;
        }

        update_user_meta($userId, self::INDEX_KEY, $index);
    }

    /**
     * Drops the oldest chats beyond MAX_CHATS.
     */
    private function prune(int $userId, array $index): array {
        if (count($index) <= self::MAX_CHATS) {
            return $index;
        }

        uasort($index, static fn (array $a, array $b): int => strcmp($b['updated_at'], $a['updated_at']));

        foreach (array_slice($index, self::MAX_CHATS, null, true) as $chatId => $chat) {
            delete_user_meta($userId, self::MESSAGES_PREFIX . $chatId);
            unset($index[$chatId]);
        }

        return $index;
    }

    private function migrateLegacy(int $userId): void {
        $legacy = get_user_meta($userId, self::LEGACY_KEY, true);

        if ('' === $legacy) {
            return;
        }

        delete_user_meta($userId, self::LEGACY_KEY);

        if (!is_array($legacy) || [] === $legacy) {
            return;
        }

        $firstText = (string) ($legacy[0]['parts'][0]['text'] ?? __('Earlier conversation', 'personalized-offers-for-spacefast'));
        $chatId = self::newId();
        $now = gmdate('c');
        $index = get_user_meta($userId, self::INDEX_KEY, true);
        $index = is_array($index) ? $index : [];

        $index[$chatId] = ['id' => $chatId, 'title' => self::title($firstText), 'titled' => true, 'created_at' => $now, 'updated_at' => $now];

        update_user_meta($userId, self::MESSAGES_PREFIX . $chatId, array_values($legacy));
        update_user_meta($userId, self::INDEX_KEY, $index);
    }

    private static function entry(string $chatId, string $now): array {
        return [
            'id' => $chatId,
            'title' => __('New chat', 'personalized-offers-for-spacefast'),
            'titled' => false,
            'created_at' => $now,
            'updated_at' => $now,
        ];
    }

    private static function title(string $text): string {
        $text = trim((string) preg_replace('/\s+/', ' ', wp_strip_all_tags($text)), " \t\n\r\0\x0B\"'.");

        return wp_html_excerpt($text, 60, '…');
    }
}
