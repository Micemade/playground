<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Service\CustomerProfiles;

/**
 * AJAX for the Customers tab: stored profiles with their segments, a
 * profile's details, the manager's corrections and rebuilding profiles.
 */
final class CustomersController {
    public function __construct(
        private readonly CustomerProfiles $profiles,
    ) {}

    public function register(): void {
        add_action('wp_ajax_pofsf_customers_list', [$this, 'handleList']);
        add_action('wp_ajax_pofsf_customer_get', [$this, 'handleGet']);
        add_action('wp_ajax_pofsf_customer_correct', [$this, 'handleCorrect']);
        add_action('wp_ajax_pofsf_customer_refresh', [$this, 'handleRefresh']);
        add_action('wp_ajax_pofsf_customers_build', [$this, 'handleBuild']);
    }

    public function handleList(): void {
        $request = AjaxRequest::verify();
        $repository = $this->profiles->repository();

        $result = $repository->list([
            'search' => $request->text('search'),
            'segment' => $request->key('segment'),
            'kind' => $request->key('kind'),
            'orderby' => $request->key('orderby'),
            'order' => $request->key('order'),
            'page' => max(1, $request->int('page', 1)),
            'per_page' => 20,
        ]);

        wp_send_json_success([
            'customers' => array_map([self::class, 'summary'], $result['rows']),
            'total' => $result['total'],
            'pages' => (int) ceil($result['total'] / 20),
            'segments' => self::segmentOptions($repository->segmentCounts()),
            'stored' => $repository->count(),
            'building' => $this->profiles->backfillRunning(),
        ]);
    }

    public function handleGet(): void {
        $request = AjaxRequest::verify();
        $row = $this->profiles->row($this->key($request));

        if (null === $row) {
            wp_send_json_error(['message' => __('Customer not found.', 'personalized-offers-for-spacefast')]);
        }

        wp_send_json_success(['customer' => $this->detail($row)] + ($request->bool('with_options') ? ['options' => self::options()] : []));
    }

    public function handleCorrect(): void {
        $request = AjaxRequest::verify();
        $key = $this->key($request);
        $result = $this->profiles->correct($key, (array) $request->json('corrections'), get_current_user_id());

        if ($result instanceof \WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['customer' => $this->detail((array) $this->profiles->repository()->find($key))]);
    }

    public function handleRefresh(): void {
        $request = AjaxRequest::verify();
        $row = $this->profiles->refresh($this->key($request));

        if (null === $row) {
            wp_send_json_error(['message' => __('Customer not found.', 'personalized-offers-for-spacefast')]);
        }

        wp_send_json_success(['customer' => $this->detail($row)]);
    }

    public function handleBuild(): void {
        AjaxRequest::verify();
        $this->profiles->startBackfill();

        wp_send_json_success(['building' => true]);
    }

    private function key(AjaxRequest $request): string {
        $key = $request->text('key');

        return 1 === preg_match('/^(user:\d+|guest:.+@.+)$/', $key) ? $key : '';
    }

    /**
     * A profile row as the customers list shows it.
     */
    public static function summary(array $row): array {
        // As offers see it: with the manager's corrections and the customer's choices.
        $profile = CustomerProfiles::effective($row);
        $segments = CustomerProfiles::segments();
        $sizes = [];

        foreach ((array) ($profile['attributes'] ?? []) as $key => $attribute) {
            if (str_contains((string) $key, 'size')) {
                $sizes = [...$sizes, ...array_column(array_slice((array) $attribute['values'], 0, 2), 'name')];
            }
        }

        return [
            'key' => (string) $row['customer_key'],
            'id' => (int) $row['user_id'],
            'guest' => (int) $row['user_id'] <= 0,
            'name' => '' !== (string) $row['name'] ? (string) $row['name'] : (string) $row['email'],
            'email' => (string) $row['email'],
            'segment' => (string) $row['segment'],
            'segmentLabel' => $segments[(string) $row['segment']] ?? '',
            'orders' => (int) $row['order_count'],
            'spent' => self::money((float) $row['total_spent']),
            'lastOrder' => null !== $row['last_order_at'] ? date_i18n(get_option('date_format'), strtotime((string) $row['last_order_at'])) : '',
            'categories' => array_slice(array_column((array) ($profile['preferred_categories'] ?? []), 'name'), 0, 3),
            'sizes' => array_values(array_unique($sizes)),
            'priceBand' => (string) ($profile['price_range']['band'] ?? ''),
            'corrected' => [] !== array_diff_key((array) $row['corrections'], array_flip(['updated_by', 'updated_at'])),
            'stated' => !empty($row['customer_input']['consent']),
            'editUrl' => (int) $row['user_id'] > 0 ? get_edit_user_link((int) $row['user_id']) : '',
        ];
    }

    /**
     * Everything the profile panel shows: the effective profile, what the
     * manager corrected and what the customer stated.
     */
    private function detail(array $row): array {
        $profile = $this->profiles->effective($row);
        $input = (array) $row['customer_input'];

        return self::summary($row) + [
            'profile' => [
                'categories' => array_map(static fn (array $c): array => [
                    'id' => (int) $c['id'],
                    'name' => (string) $c['name'],
                    'count' => (int) ($c['count'] ?? 0),
                    'pinned' => !empty($c['pinned']),
                ], (array) $profile['preferred_categories']),
                'brands' => array_column((array) $profile['brands'], 'name'),
                'attributes' => array_map(static fn (array $a): array => [
                    'label' => (string) $a['label'],
                    'values' => array_column((array) $a['values'], 'name'),
                    'setBy' => (string) ($a['set_by'] ?? ''),
                ], (array) $profile['attributes']),
                'priceRange' => [] !== (array) $profile['price_range'] ? [
                    'low' => self::money((float) $profile['price_range']['typical_low']),
                    'high' => self::money((float) $profile['price_range']['typical_high']),
                    'band' => (string) $profile['price_range']['band'],
                ] : null,
                'activity' => (array) $profile['activity'],
                'rhythm' => (string) ($profile['buying_rhythm']['most_common'] ?? ''),
                'wishlist' => count((array) $profile['wishlist_products']),
                'searches' => array_column((array) $profile['searches'], 'term'),
                'note' => (string) $profile['manager_note'],
                'builtAt' => '' !== (string) $row['built_at'] ? get_date_from_gmt((string) $row['built_at'], get_option('date_format') . ' ' . get_option('time_format')) : '',
            ],
            'corrections' => [
                'categories_pinned' => array_map('intval', (array) ($row['corrections']['categories_pinned'] ?? [])),
                'categories_excluded' => array_map('intval', (array) ($row['corrections']['categories_excluded'] ?? [])),
                'attributes' => (object) ($row['corrections']['attributes'] ?? []),
                'note' => (string) ($row['corrections']['note'] ?? ''),
            ],
            'customerInput' => [
                'consent' => !empty($input['consent']),
                'consentAt' => !empty($input['consent_at']) ? get_date_from_gmt((string) $input['consent_at'], get_option('date_format')) : '',
                'recordSearches' => !empty($input['record_searches']),
            ],
        ];
    }

    public static function money(float $amount): string {
        return html_entity_decode(wp_strip_all_tags(wc_price($amount)), ENT_QUOTES);
    }

    /**
     * @param array<string, int> $counts
     * @return list<array{value: string, label: string, count: int}>
     */
    private static function segmentOptions(array $counts): array {
        $out = [];

        foreach (CustomerProfiles::segments() as $value => $label) {
            $out[] = ['value' => $value, 'label' => $label, 'count' => (int) ($counts[$value] ?? 0)];
        }

        return $out;
    }

    /**
     * Product categories and global attributes with their values, for the
     * corrections form.
     */
    public static function options(): array {
        $categories = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => false, 'number' => 500, 'orderby' => 'name']);
        $attributes = [];

        foreach (function_exists('wc_get_attribute_taxonomies') ? wc_get_attribute_taxonomies() : [] as $attribute) {
            $taxonomy = wc_attribute_taxonomy_name($attribute->attribute_name);
            $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false, 'number' => 200]);

            $attributes[] = [
                'taxonomy' => $taxonomy,
                'label' => (string) $attribute->attribute_label,
                'values' => is_array($terms) ? array_map(static fn (\WP_Term $t): array => ['value' => $t->slug, 'label' => html_entity_decode($t->name, ENT_QUOTES)], $terms) : [],
            ];
        }

        return [
            'categories' => is_array($categories) ? array_map(static fn (\WP_Term $t): array => [
                'id' => $t->term_id,
                'name' => html_entity_decode(implode(' › ', [...array_reverse(array_map(static fn (int $id): string => (string) get_term_field('name', $id, 'product_cat'), get_ancestors($t->term_id, 'product_cat', 'taxonomy'))), $t->name]), ENT_QUOTES),
            ], $categories) : [],
            'attributes' => $attributes,
        ];
    }
}
