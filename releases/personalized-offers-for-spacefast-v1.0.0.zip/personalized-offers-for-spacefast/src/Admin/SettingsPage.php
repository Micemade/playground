<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Repository\BrandSnapshotRepository;
use Micemade\PersonalizedOffers\Service\Ai\ProviderDetector;
use Micemade\PersonalizedOffers\Service\Settings;

final class SettingsPage {
    public function __construct(
        private readonly BrandSnapshotRepository $brands,
        private readonly ProviderDetector $ai,
    ) {}

    public function register(): void {
        add_filter('woocommerce_settings_tabs_array', [$this, 'addTab'], 50);
        add_action('woocommerce_settings_pofsf', [$this, 'render']);
        add_action('woocommerce_settings_save_pofsf', [$this, 'save']);
        add_action('wp_ajax_pofsf_settings_save', [$this, 'handleAjaxSave']);
        add_action('wp_ajax_pofsf_settings_get', [$this, 'handleAjaxGet']);
    }

    /**
     * What the offers screen's Settings tab needs to show the same
     * settings as this WooCommerce settings tab.
     */
    public function clientConfig(): array {
        $activeBrand = $this->brands->activeData();
        $aiStatus = $this->ai->status();

        return [
            'values' => Settings::editable(),
            'brand' => [
                'versions' => $this->brands->versions(),
                'name' => (string) ($activeBrand['identity']['name'] ?? ''),
            ],
            'ai' => [
                'message' => (string) ($aiStatus['message'] ?? ''),
                'providers' => $aiStatus['providers'] ?? [],
                'supported' => !empty($aiStatus['supported']),
            ],
        ];
    }

    public function addTab(array $tabs): array {
        $tabs['pofsf'] = __('Personalized Offers', 'personalized-offers-for-spacefast');

        return $tabs;
    }

    public function render(): void {
        $settings = Settings::all();
        $active_brand = $this->brands->activeData();
        $brand_versions = $this->brands->versions();
        $ai_status = $this->ai->status();

        include POFSF_PLUGIN_DIR . 'templates/admin/settings-page.php';
    }

    public function save(): void {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        check_admin_referer('woocommerce-settings');

        $posted = isset($_POST['pofsf_settings']) && is_array($_POST['pofsf_settings'])
            ? array_map('sanitize_text_field', wp_unslash($_POST['pofsf_settings']))
            : [];

        Settings::update(Settings::sanitize($posted));
    }

    /** The settings as stored, for the Settings tab after the assistant changed them. */
    public function handleAjaxGet(): void {
        AjaxRequest::verify();

        wp_send_json_success(['values' => Settings::editable()]);
    }

    /** Saves the offers screen's Settings tab. */
    public function handleAjaxSave(): void {
        $posted = AjaxRequest::verify()->json('settings');

        if (null === $posted) {
            wp_send_json_error(['message' => __('No settings received.', 'personalized-offers-for-spacefast')]);
        }

        Settings::update(Settings::sanitize($posted));

        wp_send_json_success([
            'values' => Settings::editable(),
            'message' => __('Settings saved.', 'personalized-offers-for-spacefast'),
        ]);
    }
}
