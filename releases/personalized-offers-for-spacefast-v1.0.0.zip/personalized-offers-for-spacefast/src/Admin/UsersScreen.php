<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Service\Logger;
use Micemade\PersonalizedOffers\Service\OfferPipeline;
use WP_User;

final class UsersScreen {
    public function __construct(
        private readonly OfferPipeline $pipeline,
        private readonly Logger $log,
    ) {}

    public function register(): void {
        add_filter('user_row_actions', [$this, 'rowAction'], 10, 2);
        add_filter('bulk_actions-users', [$this, 'bulkAction']);
        add_filter('handle_bulk_actions-users', [$this, 'handleBulk'], 10, 3);
        add_action('admin_post_pofsf_create_offer', [$this, 'handleSingle']);
        add_action('admin_notices', [$this, 'bulkNotice']);
    }

    public function rowAction(array $actions, WP_User $user): array {
        if ('' === $user->user_email || !current_user_can('manage_woocommerce')) {
            return $actions;
        }

        $url = wp_nonce_url(
            add_query_arg(['action' => 'pofsf_create_offer', 'user_id' => $user->ID], admin_url('admin-post.php')),
            'pofsf_create_offer_' . $user->ID,
        );

        $actions['pofsf_create_offer'] = sprintf(
            '<a href="%s">%s</a>',
            esc_url($url),
            esc_html__('Spacefast Offer', 'personalized-offers-for-spacefast'),
        );

        return $actions;
    }

    public function handleSingle(): void {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Permission denied.', 'personalized-offers-for-spacefast'));
        }

        $userId = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;

        if ($userId <= 0) {
            wp_safe_redirect(admin_url('users.php'));
            exit;
        }

        check_admin_referer('pofsf_create_offer_' . $userId);

        $result = $this->pipeline->queue([$userId], get_current_user_id());

        if ($result instanceof \WP_Error) {
            $this->log->error('Single offer queue failed: ' . $result->get_error_message());
        }

        wp_safe_redirect(add_query_arg('pofsf_offers_queued', $result instanceof \WP_Error ? '0' : '1', admin_url('users.php')));
        exit;
    }

    public function bulkAction(array $bulkActions): array {
        if (current_user_can('manage_woocommerce')) {
            $bulkActions['pofsf_bulk_create_offers'] = __('Personalized Offers', 'personalized-offers-for-spacefast');
        }

        return $bulkActions;
    }

    public function handleBulk(string $redirectTo, string $action, array $ids): string {
        if ('pofsf_bulk_create_offers' !== $action) {
            return $redirectTo;
        }

        if (!current_user_can('manage_woocommerce')) {
            return $redirectTo;
        }

        check_admin_referer('bulk-users');

        $ids = array_values(array_filter(array_map('intval', $ids)));

        if ([] === $ids) {
            return $redirectTo;
        }

        $result = $this->pipeline->queue($ids, get_current_user_id());

        if ($result instanceof \WP_Error) {
            $this->log->error('Bulk offer queue failed: ' . $result->get_error_message());

            return add_query_arg('pofsf_offers_queued', '0', $redirectTo);
        }

        return add_query_arg('pofsf_offers_queued', count($ids), $redirectTo);
    }

    public function bulkNotice(): void {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Only shows how many offers the nonce-checked bulk action queued (its redirect adds the count).
        if (!isset($_GET['pofsf_offers_queued'])) {
            return;
        }

        $count = (int) $_GET['pofsf_offers_queued'];
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if ($count > 0) {
            printf(
                '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
                esc_html(sprintf(
                    /* translators: %d number of queued offers. */
                    _n('Queued %d Spacefast offer.', 'Queued %d Spacefast offers.', $count, 'personalized-offers-for-spacefast'),
                    $count,
                )),
            );

            return;
        }

        echo '<div class="notice notice-error is-dismissible"><p>'
            . esc_html__('Failed to queue Spacefast offers.', 'personalized-offers-for-spacefast')
            . '</p></div>';
    }
}
