<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Repository\BrandSnapshotRepository;

/**
 * The first-run welcome modal on the plugin page: whether it opens, what it
 * starts from, and remembering that a user finished or closed it.
 *
 * A fresh activation sets PENDING_OPTION; the modal then opens once for each
 * user who can manage WooCommerce, until they finish or close it (DONE_META).
 */
final class Welcome {
    public const PENDING_OPTION = 'pofsf_welcome_pending';
    public const DONE_META = 'pofsf_welcome_done';

    public function __construct(private readonly BrandSnapshotRepository $brands) {}

    public function register(): void {
        add_action('wp_ajax_pofsf_welcome_done', [$this, 'handleDone']);
    }

    /**
     * Called on activation before the plugin's tables exist for the first
     * time, so only a fresh install opens the modal, not a reactivation.
     */
    public static function markFreshInstall(bool $fresh): void {
        if ($fresh) {
            update_option(self::PENDING_OPTION, 1, false);
        }
    }

    public function shouldOpen(int $userId): bool {
        return (bool) get_option(self::PENDING_OPTION)
            && $userId > 0
            && user_can($userId, 'manage_woocommerce')
            && !get_user_meta($userId, self::DONE_META, true);
    }

    public function complete(int $userId): void {
        update_user_meta($userId, self::DONE_META, 1);
    }

    /**
     * For the plugin page's app: whether the modal opens by itself, and the
     * brand the brand step starts from.
     *
     * @return array{open: bool, brand: array{name: string, logo: string, colors: list<string>}|null}
     */
    public function clientConfig(int $userId): array {
        return [
            'open' => $this->shouldOpen($userId),
            'brand' => self::brandSummary($this->brands->activeData()),
        ];
    }

    /**
     * The few brand details the brand step shows: name, logo and main colours.
     *
     * @return array{name: string, logo: string, colors: list<string>}|null
     */
    public static function brandSummary(?array $brand): ?array {
        if (!is_array($brand)) {
            return null;
        }

        $colors = [];

        foreach (['primary', 'accent', 'secondary', 'background', 'text'] as $key) {
            $color = sanitize_hex_color((string) ($brand['colors'][$key] ?? ''));

            if ($color && !in_array(strtolower($color), $colors, true)) {
                $colors[] = strtolower($color);
            }
        }

        $logo = (string) ($brand['logo']['url'] ?? '');

        return [
            'name' => (string) ($brand['identity']['name'] ?? ''),
            'logo' => esc_url_raw('' !== $logo ? $logo : (string) ($brand['logo']['icon_url'] ?? '')),
            'colors' => $colors,
        ];
    }

    public function handleDone(): void {
        AjaxRequest::verify();

        $this->complete(get_current_user_id());

        wp_send_json_success();
    }
}
