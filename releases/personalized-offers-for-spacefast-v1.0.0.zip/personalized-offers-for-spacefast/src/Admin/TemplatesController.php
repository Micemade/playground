<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Service\EditorCopy;
use Micemade\PersonalizedOffers\Service\OfferPipeline;
use Micemade\PersonalizedOffers\Repository\TemplateRepository;
use Micemade\PersonalizedOffers\Service\ZipExporter;
use Micemade\PersonalizedOffers\Value\FontCatalog;
use Micemade\PersonalizedOffers\Value\OfferDesign;
use WP_Error;

/**
 * Templates tab endpoints, plus the read-only template preview served from
 * the offers admin page (admin.php?page=personalized-offers-for-spacefast&pofsf_preview_template=ID).
 * Templates themselves are edited in the block editor.
 */
final class TemplatesController {
    public function __construct(
        private readonly TemplateRepository $templates,
        private readonly ZipExporter $zip,
        private readonly OfferPipeline $pipeline,
    ) {}

    public function register(): void {
        add_action('load-' . OffersPage::HOOK_SUFFIX, [$this, 'maybePreview']);
        add_action('wp_ajax_pofsf_templates_list', [$this, 'handleList']);
        add_action('wp_ajax_pofsf_template_create', [$this, 'handleCreate']);
        add_action('wp_ajax_pofsf_template_delete', [$this, 'handleDelete']);
        add_action('wp_ajax_pofsf_template_restore', [$this, 'handleRestore']);
        add_action('wp_ajax_pofsf_template_default', [$this, 'handleDefault']);
        add_action('wp_ajax_pofsf_template_editor_copy', [$this, 'handleEditorCopy']);
    }

    /**
     * Stores the Edit offer form's texts for the template editor it opens;
     * returns the key to add to the editor URL (EditorCopy::PARAM).
     */
    public function handleEditorCopy(): void {
        $request = AjaxRequest::verify();

        wp_send_json_success(['key' => EditorCopy::store($request->json('copy') ?? [])]);
    }

    /**
     * Renders a template with sample content. Read-only, so a capability
     * check suffices and the link can be shared in chat. With
     * pofsf_autosave (the editor's Preview button), unsaved block changes
     * from the current user's autosave are shown.
     */
    public function maybePreview(): void {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only page (renders a template with sample content), gated by the capability check; its links are shared in the assistant chat, so they carry no nonce.
        if (!isset($_GET['pofsf_preview_template']) || !current_user_can('manage_woocommerce')) {
            return;
        }

        $id = absint($_GET['pofsf_preview_template']);
        $template = $id > 0 ? $this->templates->find($id) : null;
        $design = $template['design'] ?? OfferDesign::brandDefault();
        $content = $template['content'] ?? '';

        if (null !== $template && isset($_GET['pofsf_autosave'])) {
            $autosave = wp_get_post_autosave($id, get_current_user_id());

            if ($autosave && '' !== trim($autosave->post_content)) {
                $content = $autosave->post_content;
            }
        }

        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('X-Robots-Tag: noindex, nofollow');

        echo $this->zip->renderSample($design, $content, EditorCopy::fromRequest()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Rendered from blocks that escape their output.
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
        exit;
    }

    public function handleList(): void {
        AjaxRequest::verify();

        wp_send_json_success(['templates' => $this->present()]);
    }

    /**
     * New template copied from an existing one (built-in or custom), then
     * opened in the block editor.
     */
    public function handleCreate(): void {
        $request = AjaxRequest::verify();

        $sourceId = $request->id('source_id');
        $name = $request->text('name');
        $id = $this->templates->duplicate($sourceId, $name);

        if ($id instanceof WP_Error) {
            wp_send_json_error(['message' => $id->get_error_message()]);
        }

        wp_send_json_success([
            'templates' => $this->present(),
            'template_id' => $id,
            'editUrl' => TemplateRepository::editUrl($id),
        ]);
    }

    public function handleDelete(): void {
        $request = AjaxRequest::verify();

        $deleted = $this->templates->delete($request->id('template_id'));

        if ($deleted instanceof WP_Error) {
            wp_send_json_error(['message' => $deleted->get_error_message()]);
        }

        wp_send_json_success(['templates' => $this->present()]);
    }

    /**
     * Recreates an offer's deleted template from the offer's copy of it.
     */
    public function handleRestore(): void {
        $request = AjaxRequest::verify();

        $id = $this->pipeline->restoreTemplate($request->id('offer_id'));

        if ($id instanceof WP_Error) {
            wp_send_json_error(['message' => $id->get_error_message()]);
        }

        wp_send_json_success(['templates' => $this->present(), 'template_id' => $id]);
    }

    public function handleDefault(): void {
        $request = AjaxRequest::verify();

        if (!$this->templates->setDefault($request->id('template_id'))) {
            wp_send_json_error(['message' => __('Template not found.', 'personalized-offers-for-spacefast')]);
        }

        wp_send_json_success(['templates' => $this->present()]);
    }

    private function present(): array {
        $fonts = FontCatalog::all();

        return array_map(static function (array $t) use ($fonts): array {
            $design = $t['design']->toArray();

            return [
                'id' => $t['id'],
                'name' => $t['name'],
                'description' => $t['description'],
                'isDefault' => $t['is_default'],
                'builtin' => $t['builtin'],
                'design' => $design,
                'fonts' => [
                    'heading' => $fonts[$design['fonts']['heading']]['label'] ?? '',
                    'body' => $fonts[$design['fonts']['body']]['label'] ?? '',
                ],
                // `v` changes with every save, so no cached copy of an older version is shown.
                'previewUrl' => add_query_arg([
                    'page' => OffersPage::SLUG,
                    'pofsf_preview_template' => $t['id'],
                    'v' => substr(md5($t['updated_at'] . $t['content'] . wp_json_encode($design)), 0, 10),
                ], admin_url('admin.php')),
                'editUrl' => '' === $t['builtin'] ? TemplateRepository::editUrl($t['id']) : '',
                'updatedAt' => $t['updated_at'],
            ];
        }, $this->templates->all());
    }
}
