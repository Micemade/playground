<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Repository\BrandSnapshotRepository;
use Micemade\PersonalizedOffers\Service\Ai\ProviderDetector;
use Micemade\PersonalizedOffers\Service\BrandTemplate;
use Micemade\PersonalizedOffers\Value\BrandSnapshot;
use WP_Error;

final class AjaxHandler {
    public function __construct(
        private readonly BrandTemplate $brandTemplate,
        private readonly BrandSnapshotRepository $brands,
        private readonly ProviderDetector $ai,
    ) {}

    public function register(): void {
        foreach (['lock_brand', 'activate_brand_version', 'delete_brand_version', 'brand_versions', 'check_ai_connector'] as $action) {
            add_action('wp_ajax_pofsf_' . $action, [$this, 'handle' . $this->studly($action)]);
        }
    }

    public function handleLockBrand(): void {
        AjaxRequest::verify();

        // Captured again here rather than taken from the browser, so only what the site holds is stored.
        $brand = $this->brandTemplate->capture();

        if ($brand instanceof WP_Error) {
            wp_send_json_error(['message' => $brand->get_error_message()]);
        }

        $result = $this->brands->create($brand->toArray(), get_current_user_id());

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success([
            'message' => __('Brand snapshot locked successfully.', 'personalized-offers-for-spacefast'),
            'version' => $this->brands->nextVersion() - 1,
        ]);
    }

    public function handleActivateBrandVersion(): void {
        $request = AjaxRequest::verify();

        $version = $request->int('version');

        if ($version <= 0) {
            wp_send_json_error(['message' => __('Invalid version.', 'personalized-offers-for-spacefast')]);
        }

        if (!$this->brands->activate($version)) {
            wp_send_json_error(['message' => __('Failed to activate brand version.', 'personalized-offers-for-spacefast')]);
        }

        wp_send_json_success([
            /* translators: %d brand version number. */
            'message' => sprintf(__('Brand version %d activated.', 'personalized-offers-for-spacefast'), $version),
        ]);
    }

    public function handleDeleteBrandVersion(): void {
        $request = AjaxRequest::verify();

        $version = $request->int('version');

        if ($version <= 0) {
            wp_send_json_error(['message' => __('Invalid version.', 'personalized-offers-for-spacefast')]);
        }

        $result = $this->brands->delete($version);

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        if (!$result) {
            wp_send_json_error(['message' => __('Brand version not found.', 'personalized-offers-for-spacefast')]);
        }

        wp_send_json_success([
            /* translators: %d brand version number. */
            'message' => sprintf(__('Brand version %d deleted.', 'personalized-offers-for-spacefast'), $version),
        ]);
    }

    public function handleBrandVersions(): void {
        AjaxRequest::verify();

        $active = $this->brands->findActive();
        $identity = $active['data']['identity'] ?? [];

        wp_send_json_success([
            'versions' => $this->brands->versions(),
            'brand_name' => is_array($identity) ? (string) ($identity['name'] ?? '') : '',
        ]);
    }

    public function handleCheckAiConnector(): void {
        AjaxRequest::verify();

        wp_send_json_success($this->ai->status());
    }

    private function preview(BrandSnapshot $snapshot): string {
        $brand = $snapshot->toArray();

        ob_start();
        include POFSF_PLUGIN_DIR . 'templates/admin/brand-preview.php';

        return (string) ob_get_clean();
    }

    private function studly(string $snake): string {
        return str_replace(' ', '', ucwords(str_replace('_', ' ', $snake)));
    }
}
