<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

final class Assets {
    public function register(): void {
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
    }

    public function enqueue(string $hook): void {
        if (!in_array($hook, ['woocommerce_page_wc-settings', OffersPage::HOOK_SUFFIX], true)) {
            return;
        }

        wp_enqueue_style('pofsf-admin', POFSF_PLUGIN_URL . 'assets/css/admin.css', ['wp-components'], POFSF_VERSION);

        $assetFile = POFSF_PLUGIN_DIR . 'assets/build/index.asset.php';

        if (!is_readable($assetFile)) {
            return;
        }

        $asset = include $assetFile;

        if (!is_array($asset)) {
            return;
        }

        wp_enqueue_script(
            'pofsf-admin',
            POFSF_PLUGIN_URL . 'assets/build/index.js',
            $asset['dependencies'] ?? [],
            $asset['version'] ?? POFSF_VERSION,
            true,
        );
        wp_set_script_translations('pofsf-admin', 'personalized-offers-for-spacefast', POFSF_PLUGIN_DIR . 'languages');

        // The offer email's logo is chosen from the media library.
        if (OffersPage::HOOK_SUFFIX === $hook) {
            wp_enqueue_media();
        }

        wp_localize_script('pofsf-admin', 'pofsfAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce(AjaxRequest::NONCE),
            // Previews that run scripts get the admin's origin (WordPress Playground needs it); off by default.
            'previewSameOrigin' => (bool) apply_filters('pofsf_preview_same_origin', false),
        ]);
    }
}
