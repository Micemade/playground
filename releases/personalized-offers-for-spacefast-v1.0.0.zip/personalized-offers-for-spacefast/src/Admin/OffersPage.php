<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Repository\ChatRepository;
use Micemade\PersonalizedOffers\Service\Ai\ChatAgent;
use Micemade\PersonalizedOffers\Service\Ai\ProviderDetector;
use Micemade\PersonalizedOffers\Service\Spacefast\AccessRequests;
use Micemade\PersonalizedOffers\Service\Spacefast\SpacefastClient;
use WP_Error;

/**
 * WooCommerce → Personalized Offers for Spacefast: the offers list plus a chat with the
 * connected AI provider, which creates offers through the plugin's abilities.
 */
final class OffersPage {
    public const SLUG = 'personalized-offers-for-spacefast';
    public const HOOK_SUFFIX = 'woocommerce_page_' . self::SLUG;

    private const MAX_MESSAGE_LENGTH = 4000;

    public function __construct(
        private readonly ChatAgent $agent,
        private readonly ProviderDetector $ai,
        private readonly SpacefastClient $spacefast,
        private readonly SettingsPage $settings,
        private readonly ?AccessRequests $accessRequests = null,
        private readonly ?Welcome $welcome = null,
        private readonly ?OnboardingController $onboarding = null,
    ) {}

    public function register(): void {
        add_action('admin_menu', [$this, 'addMenu'], 60);
        add_action('wp_ajax_pofsf_chat_send', [$this, 'handleSend']);
        add_action('wp_ajax_pofsf_chat_list', [$this, 'handleList']);
        add_action('wp_ajax_pofsf_chat_create', [$this, 'handleCreate']);
        add_action('wp_ajax_pofsf_chat_history', [$this, 'handleHistory']);
        add_action('wp_ajax_pofsf_chat_delete', [$this, 'handleDelete']);
    }

    public function addMenu(): void {
        add_submenu_page(
            'woocommerce',
            __('Personalized Offers for Spacefast', 'personalized-offers-for-spacefast'),
            __('Personalized Offers for Spacefast', 'personalized-offers-for-spacefast'),
            'manage_woocommerce',
            self::SLUG,
            [$this, 'render'],
        );
    }

    public function render(): void {
        $chatAvailable = $this->agent->hasConfiguredProvider();
        $config = [
            'chat' => [
                'available' => $chatAvailable,
                'message' => $chatAvailable ? '' : (string) $this->ai->status()['message'],
                'connectorsUrl' => admin_url('options-connectors.php'),
            ],
            'spacefast' => $this->spacefast->status() + [
                'dashboardUrl' => 'https://my.spacefast.com/',
            ],
            // Sign in with Spacefast: for the welcome modal and the Reconnect notice.
            'oauth' => $this->onboarding?->clientConfig(get_current_user_id()),
            'settings' => $this->settings->clientConfig(),
            'settingsUrl' => admin_url('admin.php?page=wc-settings&tab=pofsf'),
            'usersUrl' => admin_url('users.php'),
            // Only from the cache, so the page never waits on Spacefast; the Spaces tab asks.
            'accessRequests' => $this->accessRequests?->cachedCount(),
            'welcome' => $this->welcome?->clientConfig(get_current_user_id()),
            // ?tab=spaces, e.g. from the access request email.
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only picks the tab shown first.
            'initialTab' => isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : '',
        ];

        printf(
            '<div class="wrap pofsf-offers-wrap"><h1>%s</h1><div id="pofsf-offers-app" data-config="%s"></div></div>',
            esc_html__('Personalized Offers for Spacefast', 'personalized-offers-for-spacefast'),
            esc_attr((string) wp_json_encode($config)),
        );
    }

    public function handleSend(): void {
        $request = AjaxRequest::verify();

        $text = $request->textarea('message');
        $text = trim(mb_substr($text, 0, self::MAX_MESSAGE_LENGTH));

        if ('' === $text) {
            wp_send_json_error(['message' => __('Message is empty.', 'personalized-offers-for-spacefast')]);
        }

        $result = $this->agent->send(get_current_user_id(), $this->chatId($request), $text);

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success($result);
    }

    public function handleList(): void {
        AjaxRequest::verify();

        wp_send_json_success(['chats' => $this->agent->chats(get_current_user_id())]);
    }

    public function handleCreate(): void {
        AjaxRequest::verify();

        $chat = $this->agent->createChat(get_current_user_id());

        wp_send_json_success(['chat' => $chat, 'chats' => $this->agent->chats(get_current_user_id())]);
    }

    public function handleHistory(): void {
        $request = AjaxRequest::verify();

        wp_send_json_success(['messages' => $this->agent->transcript(get_current_user_id(), $this->chatId($request))]);
    }

    public function handleDelete(): void {
        $request = AjaxRequest::verify();

        if (!$this->agent->deleteChat(get_current_user_id(), $this->chatId($request))) {
            wp_send_json_error(['message' => __('Chat not found.', 'personalized-offers-for-spacefast')]);
        }

        wp_send_json_success(['chats' => $this->agent->chats(get_current_user_id())]);
    }

    private function chatId(AjaxRequest $request): string {
        $chatId = $request->key('chat_id');

        return ChatRepository::isValidId($chatId) ? $chatId : '';
    }
}
