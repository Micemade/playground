<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Service\OfferEditor;
use Micemade\PersonalizedOffers\Service\Spacefast\AccessRequests;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;
use Micemade\PersonalizedOffers\Service\Spacefast\SpacefastClient;
use Micemade\PersonalizedOffers\Service\Spacefast\SpaceInventory;
use Micemade\PersonalizedOffers\Service\Spacefast\Webhooks;
use WP_Error;

/**
 * AJAX for the Spaces tab: the connection and plan usage, the team's
 * Spaces next to the offers (leftovers to delete or link to an offer,
 * offers whose Space is gone), requests to open private offers, an offer
 * Space's custom domains, and live updates (the webhook).
 */
final class SpacesController {
    public function __construct(
        private readonly SpacefastClient $client,
        private readonly SpaceInventory $inventory,
        private readonly OfferPublisher $publisher,
        private readonly OfferRepository $offers,
        private readonly Webhooks $webhooks,
        private readonly AccessRequests $accessRequests,
    ) {}

    public function register(): void {
        add_action('wp_ajax_pofsf_spaces_overview', [$this, 'handleOverview']);
        add_action('wp_ajax_pofsf_space_delete', [$this, 'handleDelete']);
        add_action('wp_ajax_pofsf_space_link', [$this, 'handleLink']);
        add_action('wp_ajax_pofsf_space_forget', [$this, 'handleForget']);
        add_action('wp_ajax_pofsf_space_domains', [$this, 'handleDomains']);
        add_action('wp_ajax_pofsf_space_domain_add', [$this, 'handleDomainAdd']);
        add_action('wp_ajax_pofsf_space_domain_verify', [$this, 'handleDomainVerify']);
        add_action('wp_ajax_pofsf_space_domain_remove', [$this, 'handleDomainRemove']);
        add_action('wp_ajax_pofsf_spacefast_webhook', [$this, 'handleWebhook']);
        add_action('wp_ajax_pofsf_access_request_decide', [$this, 'handleDecide']);
    }

    public function handleOverview(): void {
        $request = AjaxRequest::verify();

        if (!$this->client->status()['connected']) {
            wp_send_json_success(['connected' => false]);
        }

        $fresh = $request->bool('fresh');
        $usage = $this->inventory->usage($fresh);
        $spaces = $this->inventory->spaces($fresh);
        $storage = $usage instanceof WP_Error ? [] : $usage['space_storage'];
        $webhook = $this->webhooks->status();

        wp_send_json_success([
            'connected' => true,
            'team' => $this->client->status()['team_name'],
            'health' => $this->client->check(),
            'plan' => $usage instanceof WP_Error ? null : self::plan($usage),
            'usageError' => $usage instanceof WP_Error ? $usage->get_error_message() : '',
            'spaces' => $spaces instanceof WP_Error ? [] : array_map(fn (array $space): array => $this->presentSpace($space, $storage), $spaces),
            'spacesError' => $spaces instanceof WP_Error ? $spaces->get_error_message() : '',
            'missing' => $spaces instanceof WP_Error ? [] : array_map(fn (array $m): array => [
                'offerId' => $m['offer_id'],
                'spaceId' => $m['space_id'],
                'offer' => $this->offerSummary($m['offer_id']),
            ], $this->inventory->missing($spaces)),
            'linkable' => $this->linkable(),
            'requests' => $this->requests($fresh),
            'webhook' => $webhook + ['remote' => $webhook['enabled'] ? $this->webhooks->remoteStatus() : ''],
        ]);
    }

    public function handleDelete(): void {
        $request = AjaxRequest::verify();
        $this->respond($this->inventory->deleteLeftover($request->text('space_id')));
    }

    public function handleLink(): void {
        $request = AjaxRequest::verify();
        $result = $this->inventory->link($request->text('space_id'), $request->id('offer_id'));
        $this->respond($result instanceof WP_Error ? $result : true);
    }

    /**
     * Unpublishes, here only, an offer whose Space was deleted in Spacefast.
     */
    public function handleForget(): void {
        $request = AjaxRequest::verify();
        $offerId = $request->id('offer_id');
        $spaces = $this->inventory->spaces(true);

        if ($spaces instanceof WP_Error) {
            $this->respond($spaces);
        }

        if (!in_array($offerId, array_column($this->inventory->missing($spaces), 'offer_id'), true)) {
            wp_send_json_error(['message' => __('This offer’s Space still exists in Spacefast.', 'personalized-offers-for-spacefast')]);
        }

        $this->publisher->detach($offerId);
        wp_send_json_success();
    }

    public function handleDomains(): void {
        $request = AjaxRequest::verify();
        $spaceId = $this->offerSpace($request->id('offer_id'));
        $this->respond($this->client->domains($spaceId), 'domains');
    }

    public function handleDomainAdd(): void {
        $request = AjaxRequest::verify();
        $offerId = $request->id('offer_id');
        $spaceId = $this->offerSpace($offerId);
        $hostname = self::hostname($request->text('hostname'));

        if ('' === $hostname) {
            wp_send_json_error(['message' => __('Enter a domain name, such as offers.yourshop.com.', 'personalized-offers-for-spacefast')]);
        }

        $added = $this->client->addDomain($spaceId, $hostname);

        if ($added instanceof WP_Error) {
            $this->respond($added);
        }

        $this->publisher->refreshAddress($offerId);
        $this->respond($this->client->domains($spaceId), 'domains');
    }

    public function handleDomainVerify(): void {
        $request = AjaxRequest::verify();
        $offerId = $request->id('offer_id');
        $spaceId = $this->offerSpace($offerId);
        $verified = $this->client->verifyDomain($spaceId, $request->text('domain_id'));

        if ($verified instanceof WP_Error) {
            $this->respond($verified);
        }

        $this->publisher->refreshAddress($offerId);
        $this->respond($this->client->domains($spaceId), 'domains');
    }

    public function handleDomainRemove(): void {
        $request = AjaxRequest::verify();
        $offerId = $request->id('offer_id');
        $spaceId = $this->offerSpace($offerId);
        $removed = $this->client->removeDomain($spaceId, $request->text('domain_id'));

        if ($removed instanceof WP_Error) {
            $this->respond($removed);
        }

        $this->publisher->refreshAddress($offerId);
        $this->respond($this->client->domains($spaceId), 'domains');
    }

    public function handleWebhook(): void {
        $request = AjaxRequest::verify();
        $result = $request->bool('enable') ? $this->webhooks->enable() : $this->webhooks->disable();

        if ($result instanceof WP_Error) {
            $this->respond($result);
        }

        $status = $this->webhooks->status();
        wp_send_json_success(['webhook' => $status + ['remote' => $status['enabled'] ? 'active' : '']]);
    }

    /**
     * Approves or declines a request to open a private offer, then answers
     * with the requests still waiting.
     */
    public function handleDecide(): void {
        $request = AjaxRequest::verify();
        $offerId = $request->id('offer_id');
        $requestId = $request->text('request_id');
        $result = 'approve' === $request->key('decision')
            ? $this->accessRequests->approve($offerId, $requestId)
            : $this->accessRequests->deny($offerId, $requestId);

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message(), 'requests' => $this->requests(true)]);
        }

        wp_send_json_success(['email' => $result['email'], 'requests' => $this->requests(false)]);
    }

    /**
     * A hostname from what was typed: no scheme, path or port; lowercase.
     */
    public static function hostname(string $input): string {
        $input = strtolower(trim($input));
        $host = (string) (wp_parse_url(str_contains($input, '://') ? $input : 'https://' . $input, PHP_URL_HOST) ?? '');
        $host = rtrim($host, '.');

        return 1 === preg_match('/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{1,62}$/', $host) ? $host : '';
    }

    /**
     * The plan for the usage card. Limits are null when unlimited.
     */
    private static function plan(array $usage): array {
        $names = ['free' => __('Personal', 'personalized-offers-for-spacefast'), 'go' => 'Go', 'plus' => 'Plus', 'gold' => 'Gold', 'enterprise' => 'Enterprise', 'internal' => 'Internal'];

        return [
            'name' => $names[$usage['plan']] ?? ucfirst($usage['plan']),
            'limits' => $usage['limits'],
            'usage' => $usage['usage'],
            'warnings' => $usage['warnings'],
        ];
    }

    private function presentSpace(array $space, array $storage): array {
        return [
            'id' => $space['id'],
            'title' => $space['title'],
            'liveUrl' => $space['live_url'],
            'status' => $space['status'],
            'createdAt' => $space['created_at'],
            'updatedAt' => $space['updated_at'],
            'kind' => $space['kind'],
            'offer' => $space['offer_id'] > 0 ? $this->offerSummary($space['offer_id']) : null,
            'storage' => (int) ($storage[$space['id']] ?? 0),
        ];
    }

    /**
     * @return array{id: int, headline: string, status: string, type: string}|null
     */
    private function offerSummary(int $offerId): ?array {
        $offer = $this->offers->find($offerId);

        return null === $offer ? null : [
            'id' => $offerId,
            'headline' => (string) ($offer['offer_data']['offer_json']['headline'] ?? ''),
            'status' => (string) $offer['status'],
            'type' => OfferEditor::typeOf($offer)->value,
        ];
    }

    /**
     * Requests waiting for a decision, each with its offer.
     *
     * @return array{items: list<array>, error: string}
     */
    private function requests(bool $fresh): array {
        $pending = $this->accessRequests->pending($fresh);

        return [
            'items' => array_map(fn (array $r): array => [
                'id' => $r['id'],
                'email' => $r['email'],
                'name' => $r['name'],
                'message' => $r['message'],
                'createdAt' => $r['created_at'],
                'match' => $r['match'],
                'account' => $r['account'],
                'offer' => $this->offerSummary($r['offer_id']),
            ], $pending['requests']),
            'error' => $pending['error'],
        ];
    }

    /**
     * Offers a leftover Space can be given to: built, not published.
     *
     * @return list<array{id: int, headline: string, status: string, type: string}>
     */
    private function linkable(): array {
        $rows = [];

        foreach ($this->offers->list(['limit' => 100]) as $offer) {
            $status = OfferStatus::tryFrom((string) $offer['status']);

            if ($status instanceof OfferStatus && $status->isExportable() && '' === OfferPublisher::record($offer)['space_id']) {
                $rows[] = $this->offerSummary((int) $offer['id']);
            }
        }

        return array_values(array_filter($rows));
    }

    /**
     * The Space of an offer, for domain changes: only offers' Spaces are
     * changed from here. Ends the request when there is none.
     */
    private function offerSpace(int $offerId): string {
        $offer = $offerId > 0 ? $this->offers->find($offerId) : null;
        $spaceId = null === $offer ? '' : OfferPublisher::record($offer)['space_id'];

        if ('' === $spaceId) {
            wp_send_json_error(['message' => __('This offer is not published on Spacefast.', 'personalized-offers-for-spacefast')]);
        }

        return $spaceId;
    }

    private function respond(mixed $result, string $key = ''): void {
        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success('' === $key ? null : [$key => $result]);
    }
}
