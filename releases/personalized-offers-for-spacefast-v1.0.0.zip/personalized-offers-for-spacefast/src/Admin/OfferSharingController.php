<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Enum\OfferType;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Service\OfferEditor;
use Micemade\PersonalizedOffers\Service\OfferEmail;
use Micemade\PersonalizedOffers\Service\OfferShare;

/**
 * admin-ajax endpoints behind the offers table's "Send email(s)" and
 * "Social share" modals.
 */
final class OfferSharingController {
    public function __construct(
        private readonly OfferRepository $offers,
        private readonly OfferEmail $email,
    ) {}

    public function register(): void {
        add_action('wp_ajax_pofsf_offer_email_get', [$this, 'handleEmailGet']);
        add_action('wp_ajax_pofsf_offer_email_preview', [$this, 'handleEmailPreview']);
        add_action('wp_ajax_pofsf_offer_email_save', [$this, 'handleEmailSave']);
        add_action('wp_ajax_pofsf_offer_email_send', [$this, 'handleEmailSend']);
        add_action('wp_ajax_pofsf_offer_share_get', [$this, 'handleShareGet']);
    }

    /** The email modal: the design, who it goes to and when it was last sent. */
    public function handleEmailGet(): void {
        $offer = $this->offer(AjaxRequest::verify());
        $this->notPublic($offer);
        $last = OfferEmail::lastSend($offer);
        $user = wp_get_current_user();

        wp_send_json_success([
            'type' => OfferEditor::typeOf($offer)->value,
            'design' => $this->email->design($offer),
            'defaults' => $this->email->defaults($offer),
            'limits' => OfferEmail::LIMITS,
            'page_url' => OfferEmail::pageUrl($offer),
            'recipients' => array_map(static fn (array $person): array => array_diff_key($person, ['first_name' => 0]), $this->email->recipients($offer)),
            'admin_email' => $user->user_email,
            // The store's email design (WooCommerce > Settings > Emails), for "Reset to WooCommerce settings".
            'style_defaults' => OfferEmail::styleDefaults(),
            'fonts' => OfferEmail::fonts(),
            'alignments' => OfferEmail::ALIGNMENTS,
            // Logo width, header alignment and font apply with WooCommerce's newer email templates only.
            'improvements' => OfferEmail::improvements(),
            'settings_url' => admin_url('admin.php?page=wc-settings&tab=email'),
            'last_sent' => null === $last ? null : [
                'at' => wp_date(get_option('date_format') . ' ' . get_option('time_format'), (int) strtotime($last['at'] . ' UTC')),
                'count' => (int) $last['count'],
            ],
        ]);
    }

    /** The email for the design posted, as the first recipient would get it. */
    public function handleEmailPreview(): void {
        $request = AjaxRequest::verify();
        $offer = $this->offer($request);
        $person = $this->email->recipients($offer)[0] ?? ['name' => __('Customer', 'personalized-offers-for-spacefast'), 'first_name' => '', 'link' => OfferEmail::pageUrl($offer)];

        wp_send_json_success(['html' => $this->email->render($this->design($request), (string) $person['link'], $person)]);
    }

    public function handleEmailSave(): void {
        $request = AjaxRequest::verify();
        $offer = $this->offer($request);
        $this->email->saveDesign((int) $offer['id'], $this->design($request));

        wp_send_json_success(['design' => $this->email->design((array) $this->offers->find((int) $offer['id']))]);
    }

    /**
     * Sends the email: `test` to the current user (with the first
     * recipient's link), otherwise to the customer, or the group's customers
     * in `recipient_ids` (a JSON list).
     */
    public function handleEmailSend(): void {
        $request = AjaxRequest::verify();
        $offer = $this->offer($request);
        $blocked = OfferEmail::sendBlocked($offer);

        if (null !== $blocked) {
            wp_send_json_error(['message' => $blocked]);
        }

        $pageUrl = OfferEmail::pageUrl($offer);

        $design = $this->design($request);

        if ('' === $design['subject']) {
            wp_send_json_error(['message' => __('Enter the email subject.', 'personalized-offers-for-spacefast')]);
        }

        $people = $this->email->recipients($offer);
        $type = OfferEditor::typeOf($offer);

        if ($request->bool('test')) {
            $user = wp_get_current_user();
            $sample = $people[0] ?? ['name' => $user->display_name, 'first_name' => $user->first_name, 'link' => $pageUrl];
            $to = [['email' => $user->user_email, 'link' => $sample['link'], 'name' => $sample['name'], 'first_name' => $sample['first_name']]];
        } else {
            $ids = OfferType::Group === $type && $request->has('recipient_ids') ? $request->ids('recipient_ids') : null;
            $to = array_values(array_filter($people, static fn (array $person): bool => '' !== $person['email'] && (null === $ids || in_array((int) $person['id'], $ids, true))));
        }

        if ([] === $to) {
            wp_send_json_error(['message' => __('Choose who to send the email to.', 'personalized-offers-for-spacefast')]);
        }

        $result = $this->email->send($offer, $design, $to, $request->bool('test'));

        if (0 === $result['sent']) {
            wp_send_json_error(['message' => __('The email could not be sent. Check the site’s email setup.', 'personalized-offers-for-spacefast')]);
        }

        wp_send_json_success($result);
    }

    /** The Social share modal: the link to share and its card. */
    public function handleShareGet(): void {
        $offer = $this->offer(AjaxRequest::verify());
        $json = is_array($offer['offer_data']['offer_json'] ?? null) ? $offer['offer_data']['offer_json'] : [];

        wp_send_json_success([
            'url' => OfferEmail::pageUrl($offer),
            'card' => OfferShare::card($json),
        ]);
    }

    private function notPublic(array $offer): void {
        if (OfferType::Public === OfferEditor::typeOf($offer)) {
            wp_send_json_error(['message' => __('Public offers are shared with their link, not emailed.', 'personalized-offers-for-spacefast')]);
        }
    }

    private function design(AjaxRequest $request): array {
        return OfferEmail::sanitize($request->json('design'));
    }

    /** The offer the verified request names. */
    private function offer(AjaxRequest $request): array {
        $offer = $this->offers->find($request->id('offer_id'));

        if (null === $offer) {
            wp_send_json_error(['message' => __('Offer not found.', 'personalized-offers-for-spacefast')]);
        }

        return $offer;
    }
}
