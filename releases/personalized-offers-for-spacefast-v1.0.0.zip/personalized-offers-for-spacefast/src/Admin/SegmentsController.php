<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Service\CustomerProfiles;
use Micemade\PersonalizedOffers\Service\Segments;

/**
 * AJAX for the Segments tab: the segments with member counts, a segment's
 * members and what they share, saving and deleting the store's own
 * segments, and a live member count while rules are edited.
 */
final class SegmentsController {
    private const PER_PAGE = 20;

    public function __construct(
        private readonly Segments $segments,
        private readonly CustomerProfiles $profiles,
    ) {}

    public function register(): void {
        add_action('wp_ajax_pofsf_segments_list', [$this, 'handleList']);
        add_action('wp_ajax_pofsf_segment_get', [$this, 'handleGet']);
        add_action('wp_ajax_pofsf_segment_preview', [$this, 'handlePreview']);
        add_action('wp_ajax_pofsf_segment_save', [$this, 'handleSave']);
        add_action('wp_ajax_pofsf_segment_delete', [$this, 'handleDelete']);
    }

    public function handleList(): void {
        $request = AjaxRequest::verify();

        wp_send_json_success([
            'segments' => array_map([self::class, 'present'], $this->segments->all()),
            'suggestions' => array_map(static fn (array $s): array => [
                'name' => $s['name'],
                'description' => $s['description'],
                'rules' => (object) $s['rules'],
                'members' => (int) $s['members'],
            ], $this->segments->suggestions()),
            'stored' => $this->profiles->repository()->count(),
            'building' => $this->profiles->backfillRunning(),
        ] + ($request->bool('with_options') ? ['options' => CustomersController::options()] : []));
    }

    public function handleGet(): void {
        $request = AjaxRequest::verify();
        $segment = $this->segments->find($request->text('id'));

        if (null === $segment) {
            wp_send_json_error(['message' => __('Segment not found.', 'personalized-offers-for-spacefast')]);
        }

        $members = $this->segments->members($segment['rules']);
        $page = max(1, $request->int('page', 1));
        $rows = [];

        foreach (array_slice($members['keys'], ($page - 1) * self::PER_PAGE, self::PER_PAGE) as $key) {
            $row = $this->profiles->repository()->find($key);

            if (null !== $row) {
                $rows[] = CustomersController::summary($row);
            }
        }

        wp_send_json_success(['segment' => self::present($segment + ['members' => $members['total'], 'accounts' => $members['accounts']]) + [
            'shared' => self::shared($members['shared']),
            'customers' => $rows,
            'page' => $page,
            'pages' => (int) ceil($members['total'] / self::PER_PAGE),
            // For "Create group offer": its customers with an account, most spent first.
            'recipients' => $members['recipients'],
        ]]);
    }

    public function handlePreview(): void {
        $request = AjaxRequest::verify();
        $rules = Segments::sanitizeRules((array) $request->json('rules'));

        if ([] === $rules) {
            wp_send_json_success(['members' => null, 'accounts' => 0, 'names' => [], 'rules' => []]);
        }

        $members = $this->segments->members($rules, 5);

        wp_send_json_success([
            'members' => $members['total'],
            'accounts' => $members['accounts'],
            'names' => array_column($members['recipients'], 'name'),
            'rules' => Segments::describe($rules),
        ]);
    }

    public function handleSave(): void {
        $request = AjaxRequest::verify();
        $id = $request->text('id');

        if ('' !== $id && !ctype_digit($id)) {
            wp_send_json_error(['message' => __('Built-in segments cannot be changed. Save a copy with your own rules instead.', 'personalized-offers-for-spacefast')]);
        }

        $saved = $this->segments->save((array) $request->json('segment'), (int) $id, get_current_user_id());

        if ($saved instanceof \WP_Error) {
            wp_send_json_error(['message' => $saved->get_error_message()]);
        }

        wp_send_json_success(['segment' => self::present($saved + $this->count($saved))]);
    }

    public function handleDelete(): void {
        $request = AjaxRequest::verify();
        $deleted = $this->segments->delete($request->text('id'));

        if ($deleted instanceof \WP_Error) {
            wp_send_json_error(['message' => $deleted->get_error_message()]);
        }

        wp_send_json_success(['deleted' => true]);
    }

    /**
     * @return array{members: int, accounts: int}
     */
    private function count(array $segment): array {
        $members = $this->segments->members($segment['rules'], 0);

        return ['members' => $members['total'], 'accounts' => $members['accounts']];
    }

    /**
     * A segment as the tab and the assistant show it.
     */
    public static function present(array $segment): array {
        return [
            'id' => (string) $segment['id'],
            'name' => (string) $segment['name'],
            'description' => (string) $segment['description'],
            'builtIn' => !empty($segment['built_in']),
            'rules' => (object) $segment['rules'],
            'ruleText' => Segments::describe((array) $segment['rules']),
            'members' => (int) ($segment['members'] ?? 0),
            'accounts' => (int) ($segment['accounts'] ?? 0),
        ];
    }

    /**
     * What a segment's customers share, ready to show.
     */
    public static function shared(array $shared): array {
        $labels = CustomerProfiles::segments();
        $buying = [];

        foreach ((array) $shared['buying'] as $key => $count) {
            $buying[] = ['label' => $labels[$key] ?? (string) $key, 'members' => (int) $count];
        }

        // Two categories with one name (Men › Tops › Hoodies, Women › Tops › Hoodies) are shown with their path.
        $names = array_count_values(array_map('strval', array_column((array) $shared['categories'], 'name')));
        $categoryName = static function (array $category) use ($names): string {
            if (($names[(string) $category['name']] ?? 0) < 2) {
                return (string) $category['name'];
            }

            $path = array_map(static fn (int $id): string => html_entity_decode((string) get_term_field('name', $id, 'product_cat'), ENT_QUOTES), array_reverse(get_ancestors((int) $category['id'], 'product_cat', 'taxonomy')));

            return implode(' › ', [...$path, (string) $category['name']]);
        };

        return [
            'categories' => array_map(static fn (array $c): array => ['id' => (int) $c['id'], 'name' => $categoryName($c), 'members' => (int) $c['members']], (array) $shared['categories']),
            'attributes' => array_map(static fn (array $a): array => [
                'label' => (string) $a['label'],
                'values' => array_map(static fn (array $v): array => ['name' => (string) $v['name'], 'members' => (int) $v['members']], $a['values']),
            ], (array) $shared['attributes']),
            'bands' => (object) $shared['bands'],
            'buying' => $buying,
            'typicalPrice' => (float) $shared['typical_price'] > 0 ? CustomersController::money((float) $shared['typical_price']) : '',
            'totalSpent' => CustomersController::money((float) $shared['total_spent']),
            'averageOrders' => (float) $shared['average_orders'],
        ];
    }
}
