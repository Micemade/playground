<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Service\Spacefast\SpacefastClient;
use Micemade\PersonalizedOffers\Service\Spacefast\SpacefastOAuth;
use WP_Error;

/**
 * "Continue with Spacefast" in the welcome modal: the sign-in round trip
 * (start → Spacefast → callback), then the team the site connects to.
 *
 * The browser leaves wp-admin in the same tab and comes back to the plugin
 * page with `pofsf_welcome` set (connected, team or error), where the modal
 * opens on the right step. Codes and tokens never reach the browser.
 */
final class OnboardingController {
    public const START_ACTION = 'pofsf_spacefast_oauth_start';
    public const CALLBACK_ACTION = 'pofsf_spacefast_oauth_callback';

    private const PENDING_PREFIX = 'pofsf_oauth_pending_';
    private const ERROR_PREFIX = 'pofsf_oauth_error_';
    private const PENDING_TTL = 10 * MINUTE_IN_SECONDS;

    public function __construct(
        private readonly SpacefastOAuth $oauth,
        private readonly SpacefastClient $spacefast,
    ) {}

    public function register(): void {
        add_action('admin_post_' . self::START_ACTION, [$this, 'handleStart']);
        add_action('admin_post_' . self::CALLBACK_ACTION, [$this, 'handleCallback']);
        add_action('wp_ajax_pofsf_spacefast_pick_team', [$this, 'handlePickTeam']);
    }

    /**
     * For the welcome modal and the connection card.
     *
     * @return array{available: bool, needsHttps: bool, startUrl: string, step: string, error: string, teams: list<array{id: string, name: string, slug: string}>}
     */
    public function clientConfig(int $userId): array {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only picks the modal step shown after the return.
        $step = isset($_GET['pofsf_welcome']) ? sanitize_key(wp_unslash($_GET['pofsf_welcome'])) : '';
        $step = in_array($step, ['connected', 'team', 'error'], true) ? $step : '';
        $error = '';
        $pending = $this->pending($userId);

        if ('error' === $step) {
            $error = (string) get_transient(self::ERROR_PREFIX . $userId);
            delete_transient(self::ERROR_PREFIX . $userId);
            $error = '' !== $error ? $error : __('The Spacefast sign-in did not finish. Try again.', 'personalized-offers-for-spacefast');
        }

        if ('team' === $step && null === $pending) {
            $step = 'error';
            $error = __('This sign-in link expired. Try again.', 'personalized-offers-for-spacefast');
        }

        return [
            'available' => $this->oauth->canSignIn(),
            // Why sign-in is missing, when that is the reason.
            'needsHttps' => !$this->oauth->hasHttps(),
            'startUrl' => wp_nonce_url(admin_url('admin-post.php?action=' . self::START_ACTION), self::START_ACTION),
            'step' => $step,
            'error' => $error,
            'teams' => null === $pending ? [] : $pending['teams'],
        ];
    }

    public function handleStart(): void {
        check_admin_referer(self::START_ACTION);
        $this->authorize();

        if (!$this->oauth->canSignIn()) {
            $this->fail(__('Signing in with Spacefast needs HTTPS. Use an API key instead.', 'personalized-offers-for-spacefast'));
        }

        $url = $this->oauth->authorizeUrl(get_current_user_id());

        if ($url instanceof WP_Error) {
            $this->fail($url->get_error_message());
        }

        // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- Spacefast's sign-in page, on the API host.
        wp_redirect($url);
        exit;
    }

    /**
     * Spacefast's return: `code`, `state` and `iss`, or `error`. The `state`
     * transient stands in for a nonce here.
     */
    public function handleCallback(): void {
        $this->authorize();
        $userId = get_current_user_id();

        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Checked against the single-use state instead.
        $read = static fn (string $key): string => isset($_GET[$key]) && is_string($_GET[$key]) ? sanitize_text_field(wp_unslash($_GET[$key])) : '';
        $code = $read('code');
        $state = $read('state');
        $iss = isset($_GET['iss']) && is_string($_GET['iss']) ? esc_url_raw(wp_unslash($_GET['iss'])) : '';
        $error = sanitize_key($read('error'));
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        if ('' !== $error) {
            $this->oauth->forgetState($state, $userId);

            // The stored client can't ask for these scopes: the next sign-in registers again.
            if (in_array($error, ['invalid_scope', 'unauthorized_client', 'invalid_client'], true)) {
                delete_option(SpacefastOAuth::CLIENT_OPTION);
            }

            $this->fail('access_denied' === $error
                ? __('You cancelled the Spacefast sign-in.', 'personalized-offers-for-spacefast')
                : sprintf(
                    /* translators: %s: OAuth error code from Spacefast, e.g. invalid_scope. */
                    __('Spacefast did not complete the sign-in (%s). Try again, or use an API key instead.', 'personalized-offers-for-spacefast'),
                    $error,
                ));
        }

        $tokens = $this->oauth->exchange($code, $state, $iss, $userId);

        if ($tokens instanceof WP_Error) {
            $this->fail($tokens->get_error_message());
        }

        $account = $this->spacefast->account($tokens['access_token']);

        if ($account instanceof WP_Error) {
            $this->discard($tokens);
            $this->fail($account->get_error_message());
        }

        $teams = $account['teams'];

        if ([] === $teams) {
            $team = $this->spacefast->createTeam($tokens['access_token'], (string) get_bloginfo('name'));

            if ($team instanceof WP_Error) {
                $this->discard($tokens);
                $this->fail($team->get_error_message());
            }

            $teams = [$team];
        }

        if (1 === count($teams)) {
            $this->spacefast->connectOAuth($tokens, $teams[0], $account['email']);
            $this->back('connected');
        }

        // Several teams: Spacefast's approval page doesn't ask, so the modal does.
        set_transient(self::PENDING_PREFIX . $userId, [
            'tokens' => $tokens,
            'email' => $account['email'],
            'teams' => $teams,
        ], self::PENDING_TTL);
        $this->back('team');
    }

    /**
     * The team chosen in the modal; an empty `team_id` cancels the sign-in.
     */
    public function handlePickTeam(): void {
        $request = AjaxRequest::verify();
        $userId = get_current_user_id();
        $pending = $this->pending($userId);

        if (null === $pending) {
            wp_send_json_error(['message' => __('This sign-in link expired. Try again.', 'personalized-offers-for-spacefast')]);
        }

        $teamId = $request->text('team_id');
        delete_transient(self::PENDING_PREFIX . $userId);

        if ('' === $teamId) {
            $this->discard($pending['tokens']);
            wp_send_json_success(['spacefast' => $this->spacefast->status()]);
        }

        foreach ($pending['teams'] as $team) {
            if ($teamId === $team['id']) {
                wp_send_json_success(['spacefast' => $this->spacefast->connectOAuth($pending['tokens'], $team, $pending['email'])]);
            }
        }

        $this->discard($pending['tokens']);
        wp_send_json_error(['message' => __('That team is not in your Spacefast account.', 'personalized-offers-for-spacefast')]);
    }

    /**
     * @return array{tokens: array{access_token: string, refresh_token: string, access_expires: int, client_id: string}, email: string, teams: list<array{id: string, name: string, slug: string}>}|null
     */
    private function pending(int $userId): ?array {
        $pending = $userId > 0 ? get_transient(self::PENDING_PREFIX . $userId) : false;

        return is_array($pending) && isset($pending['tokens'], $pending['teams']) && is_array($pending['teams']) ? $pending : null;
    }

    private function authorize(): void {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Permission denied.', 'personalized-offers-for-spacefast'), '', ['response' => 403]);
        }

        if (defined('POFSF_SPACEFAST_API_KEY') && '' !== (string) constant('POFSF_SPACEFAST_API_KEY')) {
            $this->fail(__('This site connects to Spacefast with the POFSF_SPACEFAST_API_KEY constant.', 'personalized-offers-for-spacefast'));
        }
    }

    /** Revokes tokens the site won't keep. */
    private function discard(array $tokens): void {
        $this->oauth->revoke((string) $tokens['refresh_token'], 'refresh_token', (string) $tokens['client_id']);
        $this->oauth->revoke((string) $tokens['access_token'], 'access_token', (string) $tokens['client_id']);
    }

    /** Back to the modal's Spacefast step with the message; the connection is unchanged. */
    private function fail(string $message): never {
        set_transient(self::ERROR_PREFIX . get_current_user_id(), $message, self::PENDING_TTL);
        $this->back('error');
    }

    private function back(string $step): never {
        wp_safe_redirect(add_query_arg('pofsf_welcome', $step, admin_url('admin.php?page=' . OffersPage::SLUG)));
        exit;
    }
}
