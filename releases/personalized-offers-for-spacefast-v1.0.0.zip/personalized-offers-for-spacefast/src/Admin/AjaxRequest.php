<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

/**
 * An admin-ajax request after its checks: the admin nonce and the
 * manage_woocommerce capability. Handlers read their input only through
 * the typed getters, which sanitize each value as it is read.
 */
final class AjaxRequest {
    public const NONCE = 'pofsf_admin_nonce';

    /**
     * @param array<string, mixed> $input Unslashed request values.
     */
    private function __construct(private readonly array $input) {}

    /**
     * A request from the admin app (POST); answers with a JSON error and
     * stops if a check fails.
     */
    public static function verify(): self {
        check_ajax_referer(self::NONCE, 'nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('Permission denied.', 'personalized-offers-for-spacefast')], 403);
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Kept unslashed only; every value is sanitized by the getter that reads it.
        return new self(wp_unslash($_POST));
    }

    /**
     * A link opened in a browser tab (GET), where a JSON error would be
     * unreadable: a failed check shows an error page instead.
     */
    public static function verifyLink(): self {
        if (false === check_ajax_referer(self::NONCE, 'nonce', false)) {
            wp_die(esc_html__('This link has expired. Reload the offers page and try again.', 'personalized-offers-for-spacefast'), '', ['response' => 403, 'back_link' => true]);
        }

        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Permission denied.', 'personalized-offers-for-spacefast'), '', ['response' => 403]);
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Kept unslashed only; every value is sanitized by the getter that reads it.
        return new self(wp_unslash($_GET));
    }

    public function has(string $key): bool {
        return isset($this->input[$key]);
    }

    /** A truthy flag ("1", "true"); missing, empty or "0" is false. */
    public function bool(string $key): bool {
        return !empty($this->input[$key]);
    }

    /** A whole number, which may be negative. */
    public function int(string $key, int $default = 0): int {
        return is_scalar($this->input[$key] ?? null) ? (int) $this->input[$key] : $default;
    }

    /** A non-negative ID. */
    public function id(string $key): int {
        return is_scalar($this->input[$key] ?? null) ? absint($this->input[$key]) : 0;
    }

    /** A slug-like value: lowercase letters, digits, dashes and underscores. */
    public function key(string $key): string {
        return is_scalar($this->input[$key] ?? null) ? sanitize_key((string) $this->input[$key]) : '';
    }

    /** A single line of plain text. */
    public function text(string $key): string {
        return is_scalar($this->input[$key] ?? null) ? sanitize_text_field((string) $this->input[$key]) : '';
    }

    /** Plain text that may span lines. */
    public function textarea(string $key): string {
        return is_scalar($this->input[$key] ?? null) ? sanitize_textarea_field((string) $this->input[$key]) : '';
    }

    /**
     * A JSON list of IDs; anything that is not a positive whole number is dropped.
     *
     * @return list<int>
     */
    public function ids(string $key): array {
        $list = $this->json($key);

        return null === $list ? [] : array_values(array_filter(array_map(
            static fn (mixed $id): int => is_scalar($id) ? absint($id) : 0,
            $list,
        )));
    }

    /**
     * A JSON object or list, decoded but not yet sanitized: the caller
     * passes it to the sanitizer of its own shape (the offer editor,
     * OfferEmail::sanitize(), Settings::sanitize(), EditorCopy::store()).
     *
     * @return array<mixed>|null Null when missing or not a JSON object/list.
     */
    public function json(string $key): ?array {
        $value = $this->input[$key] ?? null;
        $decoded = is_string($value) ? json_decode($value, true) : null;

        return is_array($decoded) ? $decoded : null;
    }
}
