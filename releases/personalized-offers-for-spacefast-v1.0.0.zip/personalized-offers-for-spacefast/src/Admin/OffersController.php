<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Admin;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Enum\OfferType;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\CustomerProfileRepository;
use Micemade\PersonalizedOffers\Repository\RecipientRepository;
use Micemade\PersonalizedOffers\Service\Ai\ChatAgent;
use Micemade\PersonalizedOffers\Service\CustomerFinder;
use Micemade\PersonalizedOffers\Service\ProductVariations;
use Micemade\PersonalizedOffers\Service\OfferEditor;
use Micemade\PersonalizedOffers\Service\OfferPipeline;
use Micemade\PersonalizedOffers\Service\Segments;
use Micemade\PersonalizedOffers\Service\JobScheduler;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;
use Micemade\PersonalizedOffers\Service\Spacefast\SpacefastClient;
use Micemade\PersonalizedOffers\Service\ZipExporter;
use WP_Error;
use WP_User;

/**
 * admin-ajax endpoints behind the Offers tab: list, preview, ZIP download,
 * Spacefast connection and publishing.
 */
final class OffersController {
    private const PAGE_SIZE = 20;

    public function __construct(
        private readonly OfferRepository $offers,
        private readonly ZipExporter $zip,
        private readonly OfferPublisher $publisher,
        private readonly SpacefastClient $spacefast,
        private readonly OfferPipeline $pipeline,
        private readonly OfferEditor $editor,
        private readonly CustomerFinder $customers,
        private readonly ProductVariations $variations = new ProductVariations(),
        private readonly RecipientRepository $recipients = new RecipientRepository(),
        private readonly CustomerProfileRepository $profiles = new CustomerProfileRepository(),
        private readonly ?Segments $segments = null,
    ) {}

    public function register(): void {
        add_action('wp_ajax_pofsf_offers_list', [$this, 'handleList']);
        add_action('wp_ajax_pofsf_offer_preview', [$this, 'handlePreview']);
        add_action('wp_ajax_pofsf_offer_download', [$this, 'handleDownload']);
        add_action('wp_ajax_pofsf_offer_publish', [$this, 'handlePublish']);
        add_action('wp_ajax_pofsf_offer_delete', [$this, 'handleDelete']);
        add_action('wp_ajax_pofsf_offer_get', [$this, 'handleGet']);
        add_action('wp_ajax_pofsf_offer_stats', [$this, 'handleStats']);
        add_action('wp_ajax_pofsf_offer_update', [$this, 'handleUpdate']);
        add_action('wp_ajax_pofsf_offer_new', [$this, 'handleNew']);
        add_action('wp_ajax_pofsf_offer_create', [$this, 'handleCreate']);
        add_action('wp_ajax_pofsf_offer_draft_preview', [$this, 'handleDraftPreview']);
        add_action('wp_ajax_pofsf_customers_search', [$this, 'handleCustomersSearch']);
        add_action('wp_ajax_pofsf_product_variations', [$this, 'handleProductVariations']);
        add_action('wp_ajax_pofsf_offer_publish_status', [$this, 'handlePublishStatus']);
        add_action('wp_ajax_pofsf_offers_status', [$this, 'handleOffersStatus']);
        add_action('wp_ajax_pofsf_offers_notice_seen', [$this, 'handleOffersNoticeSeen']);
        add_action('wp_ajax_pofsf_spacefast_connect', [$this, 'handleConnect']);
        add_action('wp_ajax_pofsf_spacefast_disconnect', [$this, 'handleDisconnect']);
    }

    public function handleList(): void {
        $request = AjaxRequest::verify();

        $page = max(1, $request->int('page', 1));
        $status = $request->key('status');
        $status = null !== OfferStatus::tryFrom($status) ? $status : '';
        $type = OfferType::tryFrom($request->key('type'))?->value ?? '';

        $rows = $this->offers->list([
            'status' => $status,
            'type' => $type,
            'limit' => self::PAGE_SIZE,
            'offset' => ($page - 1) * self::PAGE_SIZE,
        ]);

        wp_send_json_success([
            'offers' => array_map([$this, 'present'], $rows),
            'total' => $this->offers->count(['status' => $status, 'type' => $type]),
            'page' => $page,
            'pageSize' => self::PAGE_SIZE,
        ]);
    }

    /**
     * Streams the rendered offer page so the admin can see it before sharing.
     */
    public function handlePreview(): void {
        $request = AjaxRequest::verifyLink();

        $html = $this->zip->renderHtml($request->id('offer_id'));

        if ($html instanceof WP_Error) {
            wp_die(esc_html($html->get_error_message()), esc_html__('Offer preview', 'personalized-offers-for-spacefast'), ['response' => 400, 'back_link' => true]);
        }

        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('X-Robots-Tag: noindex, nofollow');

        echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts in ZipExporter::renderPage().
        exit;
    }

    public function handleDownload(): void {
        $request = AjaxRequest::verifyLink();

        $offerId = $request->id('offer_id');
        $path = $this->zip->export($offerId);

        if ($path instanceof WP_Error) {
            wp_die(esc_html($path->get_error_message()), esc_html__('Offer download', 'personalized-offers-for-spacefast'), ['response' => 400, 'back_link' => true]);
        }

        nocache_headers();
        header('Content-Description: File Transfer');
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="spacefast-offer-' . $offerId . '.zip"');
        header('Content-Length: ' . (string) filesize($path));

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Streams the generated ZIP to the browser; WP_Filesystem has no streaming read.
        readfile($path);
        wp_delete_file($path);
        exit;
    }

    public function handlePublish(): void {
        $request = AjaxRequest::verify();

        $access = 'public' === $request->key('access') ? 'public' : 'private';
        $offerId = $request->id('offer_id');
        $result = $this->publisher->publish($offerId, $access);

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['offer' => $this->presentById($offerId)]);
    }

    public function handleGet(): void {
        $request = AjaxRequest::verify();

        $result = $this->editor->editable($request->id('offer_id'));

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        $offer = $this->offers->find($request->id('offer_id'));
        $opens = null !== $offer && !empty($result['recipients']) ? $this->publisher->linkOpens($offer) : null;

        // How often each group customer opened their personal link.
        foreach ($result['recipients'] ?? [] as $i => $row) {
            if (isset($opens['opens'][$row['id']])) {
                $result['recipients'][$i]['opens'] = $opens['opens'][$row['id']];
            }
        }

        wp_send_json_success(['offer' => $result]);
    }

    /**
     * One listed offer's view counts and link opens (OfferPublisher::stats()),
     * requested after the list loads: first with `cached` (quick: link opens
     * and cached views), then without, a few offers at a time, as Spacefast's
     * analytics can take 20 s or more.
     */
    public function handleStats(): void {
        $request = AjaxRequest::verify();
        $offer = $this->offers->find($request->id('offer_id'));

        if (function_exists('set_time_limit')) {
            set_time_limit(90); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- Waits on Spacefast's slow analytics (up to 45 s).
        }

        wp_send_json_success(['stats' => null !== $offer ? $this->publisher->stats($offer, '1' === $request->key('cached')) : null]);
    }

    /**
     * Saves edits from the Edit offer and Template modals. `changes` is a
     * JSON object holding only the fields to change.
     */
    public function handleUpdate(): void {
        $request = AjaxRequest::verify();

        $changes = $this->formInput($request, 'changes');

        if (null === $changes) {
            wp_send_json_error(['message' => __('Nothing to save.', 'personalized-offers-for-spacefast')]);
        }

        $result = $this->editor->update($request->id('offer_id'), $changes);

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['offer' => $this->presentById($request->id('offer_id'))]);
    }

    /**
     * The Create new offer form for a customer, a group (customer_ids, a
     * JSON list) or a public offer: suggested products and defaults.
     */
    public function handleNew(): void {
        $request = AjaxRequest::verify();

        $type = $this->offerType($request);
        $result = $this->editor->blank($request->id('customer_id'), $type, $request->ids('customer_ids'), $request->text('customer_email'));

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        // A group offer for a segment: products from what its customers share.
        $segment = OfferType::Group === $type ? $this->segment($request->text('segment')) : null;

        if (null !== $segment) {
            $result['suggested'] = $this->segments->suggestedProducts($segment['rules']) ?: $result['suggested'];
            $result['segment'] = ['id' => $segment['id'], 'name' => $segment['name']];
        }

        wp_send_json_success(['offer' => $result]);
    }

    public function handleCreate(): void {
        $request = AjaxRequest::verify();

        $input = $this->formInput($request, 'offer');

        if (null === $input) {
            wp_send_json_error(['message' => __('Nothing to save.', 'personalized-offers-for-spacefast')]);
        }

        $segment = $this->segment((string) ($input['segment'] ?? ''));
        $input['segment'] = null !== $segment ? ['id' => $segment['id'], 'name' => $segment['name']] : null;

        $offerId = $this->editor->create($request->id('customer_id'), get_current_user_id(), $input, $this->offerType($request), $request->text('customer_email'));

        if ($offerId instanceof WP_Error) {
            wp_send_json_error(['message' => $offerId->get_error_message()]);
        }

        wp_send_json_success(['offer' => $this->presentById($offerId)]);
    }

    /**
     * The offer page for the form's current, unsaved state (offer_id 0 for
     * a new offer). Returned as HTML for the form's preview frame.
     */
    public function handleDraftPreview(): void {
        $request = AjaxRequest::verify();

        $offer = $this->editor->draft($request->id('offer_id'), $this->formInput($request, 'offer') ?? []);

        if ($offer instanceof WP_Error) {
            wp_send_json_error(['message' => $offer->get_error_message()]);
        }

        wp_send_json_success(['html' => $this->zip->renderDraft($offer)]);
    }

    public function handleCustomersSearch(): void {
        $request = AjaxRequest::verify();

        $search = $request->text('search');
        $customers = array_map(static fn (WP_User $user): array => [
            'id' => $user->ID,
            'name' => $user->display_name,
            'email' => $user->user_email,
        ], $this->customers->find($search, 20));

        // Single offers can also be for guests: customers who ordered without an account.
        if ($request->bool('guests')) {
            foreach ($this->profiles->list(['search' => $search, 'kind' => 'guest', 'per_page' => 10])['rows'] as $row) {
                $customers[] = OfferEditor::guestCustomer((string) $row['email'], ['user_name' => $row['name']]);
            }
        }

        wp_send_json_success(['customers' => $customers]);
    }

    /**
     * Variation choices for a product picked in the offer form, with the
     * one to preselect.
     */
    public function handleProductVariations(): void {
        $request = AjaxRequest::verify();

        $productId = $request->id('product_id');

        wp_send_json_success([
            'variations' => $this->variations->options($productId),
            'preferred' => $this->variations->preferred($productId),
        ]);
    }

    /**
     * Offer form fields posted as a JSON object, limited to the editable ones.
     */
    private function formInput(AjaxRequest $request, string $key): ?array {
        $input = $request->json($key);

        if (null === $input) {
            return null;
        }

        // Every key the edit form, the create form or the draft preview sends; others are dropped.
        return array_intersect_key($input, array_flip([
            'headline',
            'button_text',
            'fields',
            'picks',
            'expires_on',
            'template_id',
            'max_uses',
            'coupon',
            'recipients',
            'type',
            'customer_id',
            'customer_email',
            'refresh_template',
            'segment',
        ]));
    }

    /**
     * A segment by its ID ('loyal', '12'), or null.
     */
    private function segment(string $id): ?array {
        return null !== $this->segments && '' !== $id ? $this->segments->find($id) : null;
    }

    private function offerType(AjaxRequest $request): OfferType {
        return OfferType::tryFrom($request->key('type')) ?? OfferType::Single;
    }

    /**
     * Deletes an offer, and optionally its Spacefast Space first. If the
     * Space cannot be deleted the offer is kept, so the link is not lost.
     */
    public function handleDelete(): void {
        $request = AjaxRequest::verify();

        $offer = $this->offers->find($request->id('offer_id'));

        if (null === $offer) {
            wp_send_json_error(['message' => __('Offer not found.', 'personalized-offers-for-spacefast')]);
        }

        if ($request->bool('delete_space')) {
            $deleted = $this->publisher->deleteSpace($offer);

            if ($deleted instanceof WP_Error) {
                wp_send_json_error(['message' => sprintf(
                    /* translators: %s: error message from Spacefast. */
                    __('The offer was not deleted because its Spacefast Space could not be removed: %s', 'personalized-offers-for-spacefast'),
                    $deleted->get_error_message(),
                )]);
            }
        }

        $result = $this->pipeline->delete((int) $offer['id']);

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['deleted' => (int) $offer['id']]);
    }

    public function handlePublishStatus(): void {
        $request = AjaxRequest::verify();

        $result = $this->publisher->refresh($request->id('offer_id'));

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['offer' => $this->presentById($request->id('offer_id'))]);
    }

    public function handleConnect(): void {
        $request = AjaxRequest::verify();

        $key = $request->text('api_key');
        $result = $this->spacefast->connect($key);

        if ($result instanceof WP_Error) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['spacefast' => $result]);
    }

    public function handleDisconnect(): void {
        AjaxRequest::verify();

        $this->spacefast->disconnect();

        wp_send_json_success(['spacefast' => $this->spacefast->status()]);
    }

    /**
     * For the notice after the assistant created offers: the offers it
     * has not shown yet (`pending`) and the build status of those and of
     * `offer_ids` (a JSON list). Deleted offers are dropped from the list.
     */
    public function handleOffersStatus(): void {
        $request = AjaxRequest::verify();

        $userId = get_current_user_id();
        $pending = ChatAgent::newOffers($userId);
        $ids = $request->ids('offer_ids');
        $statuses = [];
        $gone = [];

        foreach (array_slice(array_unique([...$pending, ...$ids]), 0, 100) as $id) {
            $offer = $id > 0 ? $this->offers->find($id) : null;

            if (null !== $offer) {
                $statuses[(string) $id] = (string) $offer['status'];
            } else {
                $gone[] = $id;
            }
        }

        if ([] !== $gone) {
            ChatAgent::forgetNewOffers($userId, $gone);
        }

        wp_send_json_success([
            'pending' => array_values(array_diff($pending, $gone)),
            'statuses' => (object) $statuses,
        ]);
    }

    /**
     * The notice has shown the offers in `offer_ids` (a JSON list).
     */
    public function handleOffersNoticeSeen(): void {
        $request = AjaxRequest::verify();

        ChatAgent::forgetNewOffers(get_current_user_id(), $request->ids('offer_ids'));

        wp_send_json_success();
    }

    private function presentById(int $offerId): ?array {
        $row = $this->offers->find($offerId);

        return null === $row ? null : $this->present($row);
    }

    /**
     * Offer row as the admin UI sees it. Tokens and coupon codes stay server-side.
     */
    private function present(array $row): array {
        $offerId = (int) $row['id'];
        $userId = (int) ($row['user_id'] ?? 0);
        $user = $userId > 0 ? get_userdata($userId) : false;
        $offerJson = $row['offer_data']['offer_json'] ?? [];
        $status = OfferStatus::tryFrom((string) $row['status']);
        $nonce = wp_create_nonce(AjaxRequest::NONCE);

        $type = OfferEditor::typeOf($row);
        $guestName = trim((string) ($row['offer_data']['profile']['user_name'] ?? ''));

        return [
            'id' => $offerId,
            'type' => $type->value,
            'recipients' => OfferType::Group === $type ? ($this->recipients->counts([$offerId])[$offerId] ?? ['total' => 0, 'used' => 0]) : null,
            // The segment a group offer was made for (its name then).
            'segment' => OfferType::Group === $type ? (string) ($row['offer_data']['segment']['name'] ?? '') : '',
            'customer' => [
                'name' => $user instanceof WP_User ? $user->display_name : ('' !== $guestName ? $guestName : (string) ($row['guest_email'] ?? '')),
                'email' => $user instanceof WP_User ? $user->user_email : (string) ($row['guest_email'] ?? ''),
                'guest' => !$user instanceof WP_User && '' !== (string) ($row['guest_email'] ?? ''),
                'editUrl' => $user instanceof WP_User ? get_edit_user_link($userId) : '',
            ],
            'headline' => is_array($offerJson) ? (string) ($offerJson['headline'] ?? '') : '',
            'picks' => is_array($offerJson['product_picks'] ?? null) ? count($offerJson['product_picks']) : 0,
            'error' => (string) ($row['offer_data']['error'] ?? ''),
            'template' => (string) ($row['offer_data']['template_name'] ?? ''),
            'templateId' => (int) ($row['offer_data']['template_id'] ?? 0),
            'editable' => $status instanceof OfferStatus && OfferStatus::Building !== $status && is_array($offerJson) && [] !== $offerJson,
            'status' => (string) $row['status'],
            'exportable' => $status instanceof OfferStatus && $status->isExportable(),
            'createdAt' => $this->localDate($row['created_at'] ?? ''),
            'expiresAt' => $this->localDate($row['expires_at'] ?? ''),
            'previewUrl' => add_query_arg(['action' => 'pofsf_offer_preview', 'offer_id' => $offerId, 'nonce' => $nonce], admin_url('admin-ajax.php')),
            'downloadUrl' => add_query_arg(['action' => 'pofsf_offer_download', 'offer_id' => $offerId, 'nonce' => $nonce], admin_url('admin-ajax.php')),
            'spacefast' => $this->presentSpace(OfferPublisher::record($row), $offerId),
        ];
    }

    private function presentSpace(array $record, int $offerId): ?array {
        if ('' === $record['space_id']) {
            return null;
        }

        return [
            'spaceId' => $record['space_id'],
            'status' => $record['status'],
            'access' => $record['access'],
            'liveUrl' => $record['live_url'],
            'accessUrl' => $record['access_url'],
            'accessExpiresAt' => $this->localDate($record['access_expires_at']),
            'publishedAt' => $this->localDate($record['published_at']),
            'notes' => $record['notes'],
            'outdated' => (bool) $record['outdated'],
            // Making the Space public or private (to match the offer type) failed.
            'accessError' => (string) $record['access_error'],
            // The offer expired or was revoked: nobody can open the Space.
            'closed' => (bool) $record['closed'],
            // A background publish after a template change is queued or running.
            'updating' => (bool) $record['outdated'] && function_exists('as_has_scheduled_action')
                && as_has_scheduled_action(JobScheduler::REPUBLISH_HOOK, [$offerId], JobScheduler::GROUP),
        ];
    }

    private function localDate(mixed $value): string {
        $value = (string) $value;

        if ('' === $value) {
            return '';
        }

        $timestamp = strtotime(str_contains($value, 'T') ? $value : $value . ' UTC');

        return false === $timestamp ? $value : wp_date(get_option('date_format') . ' ' . get_option('time_format'), $timestamp);
    }
}
