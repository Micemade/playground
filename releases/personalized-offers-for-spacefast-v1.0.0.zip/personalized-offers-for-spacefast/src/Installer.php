<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers;

use Micemade\PersonalizedOffers\Service\CleanupService;

final class Installer {
    /** Bump when createTables() changes, so existing sites get the change without reactivating. */
    private const DB_VERSION = 5;
    private const DB_VERSION_OPTION = 'pofsf_db_version';

    public static function activate(): void {
        $errors = self::requirementErrors();

        if ([] !== $errors) {
            deactivate_plugins(plugin_basename(POFSF_PLUGIN_FILE));
            wp_die(
                '<strong>' . esc_html__('Personalized Offers for Spacefast cannot activate:', 'personalized-offers-for-spacefast') . '</strong><br>'
                . esc_html(implode(' ', $errors)),
                esc_html__('Plugin activation failed', 'personalized-offers-for-spacefast'),
                ['back_link' => true],
            );
        }

        self::createTables();
        update_option(self::DB_VERSION_OPTION, self::DB_VERSION);
        self::scheduleCleanup();

        if (!defined('WP_UNINSTALL_PLUGIN')) {
            flush_rewrite_rules();
        }

        do_action('pofsf_activated');
    }

    /**
     * Brings the tables up to date after a plugin update (activation does
     * not run on updates).
     */
    public static function maybeUpgrade(): void {
        if ((int) get_option(self::DB_VERSION_OPTION, 1) >= self::DB_VERSION) {
            return;
        }

        self::createTables();
        update_option(self::DB_VERSION_OPTION, self::DB_VERSION);
    }

    public static function deactivate(): void {
        wp_clear_scheduled_hook(CleanupService::HOOK);

        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions('', [], \Micemade\PersonalizedOffers\Service\CustomerProfiles::GROUP);
        }

        flush_rewrite_rules();

        do_action('pofsf_deactivated');
    }

    public static function uninstall(): void {
        global $wpdb;

        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange -- Uninstall removes the plugin's own tables and data.
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}pofsf_offers");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}pofsf_offer_recipients");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}pofsf_brand_snapshots");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}pofsf_customer_profiles");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}pofsf_segments");

        delete_option('pofsf_settings');
        delete_option('pofsf_brand_snapshot_version');
        delete_option('pofsf_token_hmac_key');
        // Stop Spacefast posting to a site that no longer listens (best effort).
        $webhook = get_option('pofsf_spacefast_webhook');

        if (is_array($webhook) && '' !== (string) ($webhook['id'] ?? '')) {
            (new \Micemade\PersonalizedOffers\Service\Spacefast\SpacefastClient())->deleteWebhook((string) $webhook['id']);
        }

        delete_option('pofsf_spacefast_webhook');
        delete_option('pofsf_spacefast_events');
        delete_transient('pofsf_spacefast_spaces');
        delete_transient('pofsf_spacefast_usage');
        delete_transient('pofsf_spacefast_access_requests');
        delete_option('pofsf_spacefast_connection');
        delete_option('pofsf_default_template_id');
        delete_option('pofsf_offers_follow_templates');
        delete_option('pofsf_offer_fields_version');
        delete_option(self::DB_VERSION_OPTION);
        delete_option('pofsf_profiles_backfilled');
        delete_option('pofsf_profiles_last_run');
        delete_transient('pofsf_segment_overview');
        delete_transient('pofsf_store_price_thirds');
        $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE '\\_pofsf\\_chat%'");
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
        delete_metadata('user', 0, '_pofsf_assistant_new_offers', '', true);
        delete_metadata('user', 0, 'pofsf_consent_given', '', true);

        foreach (get_posts(['post_type' => 'pofsf_offer_template', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids']) as $templateId) {
            wp_delete_post((int) $templateId, true);
        }
    }

    /**
     * @return list<string>
     */
    public static function requirementErrors(): array {
        $errors = [];

        if (version_compare((string) get_bloginfo('version'), '7.0', '<')) {
            $errors[] = sprintf(
                /* translators: %s WordPress version. */
                __('Personalized Offers for Spacefast requires WordPress 7.0 or higher (current: %s).', 'personalized-offers-for-spacefast'),
                get_bloginfo('version'),
            );
        }

        if (!class_exists('WooCommerce')) {
            $errors[] = __('Personalized Offers for Spacefast requires WooCommerce to be installed and active.', 'personalized-offers-for-spacefast');
        } elseif (function_exists('WC') && WC() && version_compare((string) WC()->version, '8.0', '<')) {
            $errors[] = sprintf(
                /* translators: %s WooCommerce version. */
                __('Personalized Offers for Spacefast requires WooCommerce 8.0 or higher (current: %s).', 'personalized-offers-for-spacefast'),
                WC()->version,
            );
        }

        if (version_compare(PHP_VERSION, '8.3', '<')) {
            $errors[] = sprintf(
                /* translators: %s PHP version. */
                __('Personalized Offers for Spacefast requires PHP 8.3 or higher (current: %s).', 'personalized-offers-for-spacefast'),
                PHP_VERSION,
            );
        }

        if (!function_exists('as_schedule_single_action')) {
            $errors[] = __('Personalized Offers for Spacefast requires Action Scheduler (bundled with WooCommerce).', 'personalized-offers-for-spacefast');
        }

        if (!function_exists('wp_ai_client_prompt')) {
            $errors[] = __('Personalized Offers for Spacefast requires WordPress 7.0+ with AI Client support.', 'personalized-offers-for-spacefast');
        }

        return $errors;
    }

    private static function createTables(): void {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $collate = $wpdb->get_charset_collate();

        dbDelta("CREATE TABLE {$wpdb->prefix}pofsf_offers (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            token CHAR(32) NOT NULL,
            token_hash CHAR(64) NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            guest_email VARCHAR(320) DEFAULT NULL,
            offer_data JSON NOT NULL,
            coupon_code VARCHAR(50) NOT NULL,
            status ENUM('pending','building','ready','sent','used','expired','revoked','failed') NOT NULL DEFAULT 'pending',
            expires_at DATETIME NOT NULL,
            used_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            max_uses SMALLINT UNSIGNED NOT NULL DEFAULT 1,
            consent_given TINYINT(1) NOT NULL DEFAULT 0,
            type VARCHAR(10) NOT NULL DEFAULT 'single',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY token_hash (token_hash),
            KEY user_id (user_id),
            KEY guest_email (guest_email),
            KEY status_expires (status, expires_at),
            KEY type (type)
        ) $collate;");

        // Customers of a group offer, each with their own checkout token and uses.
        dbDelta("CREATE TABLE {$wpdb->prefix}pofsf_offer_recipients (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            offer_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            token CHAR(32) NOT NULL,
            token_hash CHAR(64) NOT NULL,
            status VARCHAR(10) NOT NULL DEFAULT 'active',
            used_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            consent_given TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY token_hash (token_hash),
            UNIQUE KEY offer_user (offer_id, user_id),
            KEY user_id (user_id)
        ) $collate;");

        dbDelta("CREATE TABLE {$wpdb->prefix}pofsf_brand_snapshots (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            version INT UNSIGNED NOT NULL,
            data JSON NOT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 0,
            created_by BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY version (version),
            KEY is_active (is_active)
        ) $collate;");

        // One per customer: user:<id> or guest:<email> (CustomerProfileRepository).
        dbDelta("CREATE TABLE {$wpdb->prefix}pofsf_customer_profiles (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            customer_key VARCHAR(200) NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            email VARCHAR(190) NOT NULL DEFAULT '',
            name VARCHAR(255) NOT NULL DEFAULT '',
            profile JSON NOT NULL,
            corrections JSON NOT NULL,
            customer_input JSON NOT NULL,
            order_count INT UNSIGNED NOT NULL DEFAULT 0,
            total_spent DECIMAL(19,4) NOT NULL DEFAULT 0,
            last_order_at DATE DEFAULT NULL,
            segment VARCHAR(20) NOT NULL DEFAULT '',
            built_at DATETIME DEFAULT NULL,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY customer_key (customer_key),
            KEY user_id (user_id),
            KEY email (email),
            KEY segment (segment),
            KEY last_order_at (last_order_at)
        ) $collate;");

        // Segments the store saved: rules over the stored profiles (SegmentRepository).
        dbDelta("CREATE TABLE {$wpdb->prefix}pofsf_segments (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL DEFAULT '',
            description TEXT NOT NULL,
            rules JSON NOT NULL,
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $collate;");
    }

    private static function scheduleCleanup(): void {
        if (!wp_next_scheduled(CleanupService::HOOK)) {
            wp_schedule_event(time() + 3600, 'daily', CleanupService::HOOK);
        }
    }
}
