<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Enum;

/**
 * Who an offer is for. Single offers are written for one customer; group
 * offers are one page for chosen customers, each with a personal link;
 * public offers are one link anyone can use. Only single offers carry
 * anything personal in their content.
 */
enum OfferType: string {
    case Single = 'single';
    case Group = 'group';
    case Public = 'public';

    public function isPersonal(): bool {
        return self::Single === $this;
    }
}
