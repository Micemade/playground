<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Enum;

enum OfferStatus: string {
    case Pending = 'pending';
    case Building = 'building';
    case Ready = 'ready';
    case Sent = 'sent';
    case Used = 'used';
    case Expired = 'expired';
    case Revoked = 'revoked';
    case Failed = 'failed';

    public function isTerminal(): bool {
        return match ($this) {
            self::Used, self::Expired, self::Revoked, self::Failed => true,
            default => false,
        };
    }

    public function isExportable(): bool {
        return match ($this) {
            self::Ready, self::Sent => true,
            default => false,
        };
    }
}
