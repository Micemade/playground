<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers;

use Micemade\PersonalizedOffers\Abilities\CustomerAbilities;
use Micemade\PersonalizedOffers\Abilities\SegmentAbilities;
use Micemade\PersonalizedOffers\Abilities\OfferAbilities;
use Micemade\PersonalizedOffers\Abilities\OfferManagementAbilities;
use Micemade\PersonalizedOffers\Abilities\SettingsAbilities;
use Micemade\PersonalizedOffers\Abilities\SpacefastAbilities;
use Micemade\PersonalizedOffers\Abilities\SharedOfferAbilities;
use Micemade\PersonalizedOffers\Abilities\TemplateAbilities;
use Micemade\PersonalizedOffers\Admin\AjaxHandler;
use Micemade\PersonalizedOffers\Admin\CustomersController;
use Micemade\PersonalizedOffers\Admin\SegmentsController;
use Micemade\PersonalizedOffers\Admin\SpacesController;
use Micemade\PersonalizedOffers\Blocks\OfferBlocks;
use Micemade\PersonalizedOffers\Admin\Assets;
use Micemade\PersonalizedOffers\Admin\OffersController;
use Micemade\PersonalizedOffers\Admin\OfferSharingController;
use Micemade\PersonalizedOffers\Admin\OffersPage;
use Micemade\PersonalizedOffers\Admin\SettingsPage;
use Micemade\PersonalizedOffers\Admin\TemplatesController;
use Micemade\PersonalizedOffers\Admin\UsersScreen;
use Micemade\PersonalizedOffers\Repository\BrandSnapshotRepository;
use Micemade\PersonalizedOffers\Repository\ChatRepository;
use Micemade\PersonalizedOffers\Repository\CustomerProfileRepository;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\TemplateRepository;
use Micemade\PersonalizedOffers\Service\Ai\ChatAgent;
use Micemade\PersonalizedOffers\Service\OfferComposer;
use Micemade\PersonalizedOffers\Service\Ai\ProviderDetector;
use Micemade\PersonalizedOffers\Service\BrandTemplate;
use Micemade\PersonalizedOffers\Service\CheckoutHandler;
use Micemade\PersonalizedOffers\Service\CleanupService;
use Micemade\PersonalizedOffers\Service\ContentMigration;
use Micemade\PersonalizedOffers\Service\CouponFactory;
use Micemade\PersonalizedOffers\Service\JobScheduler;
use Micemade\PersonalizedOffers\Service\Logger;
use Micemade\PersonalizedOffers\Service\CustomerFinder;
use Micemade\PersonalizedOffers\Service\CustomerPreferencesPage;
use Micemade\PersonalizedOffers\Service\CustomerProfiles;
use Micemade\PersonalizedOffers\Service\Segments;
use Micemade\PersonalizedOffers\Service\OfferEditor;
use Micemade\PersonalizedOffers\Service\OfferPageRenderer;
use Micemade\PersonalizedOffers\Service\OfferPipeline;
use Micemade\PersonalizedOffers\Service\PrivacyEraser;
use Micemade\PersonalizedOffers\Service\PrivacyExporter;
use Micemade\PersonalizedOffers\Service\ProfileBuilder;
use Micemade\PersonalizedOffers\Service\ShortlistBuilder;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;
use Micemade\PersonalizedOffers\Service\Spacefast\SpacefastClient;
use Micemade\PersonalizedOffers\Service\Spacefast\AccessRequests;
use Micemade\PersonalizedOffers\Service\Spacefast\SpaceInventory;
use Micemade\PersonalizedOffers\Service\Spacefast\Webhooks;
use Micemade\PersonalizedOffers\Service\StyleInspector;
use Micemade\PersonalizedOffers\Service\TokenService;
use Micemade\PersonalizedOffers\Service\Wishlist\AdapterRegistry;
use Micemade\PersonalizedOffers\Service\ZipExporter;

/**
 * Composition root: builds the object graph once and wires every hook.
 */
final class Plugin {
    private function __construct(
        private readonly Assets $assets,
        private readonly SettingsPage $settingsPage,
        private readonly OffersPage $offersPage,
        private readonly OffersController $offersController,
        private readonly OfferSharingController $sharingController,
        private readonly OfferAbilities $abilities,
        private readonly TemplateAbilities $templateAbilities,
        private readonly SharedOfferAbilities $sharedOfferAbilities,
        private readonly OfferManagementAbilities $offerManagementAbilities,
        private readonly SpacefastAbilities $spacefastAbilities,
        private readonly SettingsAbilities $settingsAbilities,
        private readonly CustomerAbilities $customerAbilities,
        private readonly CustomersController $customersController,
        private readonly Segments $segments,
        private readonly SegmentAbilities $segmentAbilities,
        private readonly SegmentsController $segmentsController,
        private readonly CustomerProfiles $customerProfiles,
        private readonly CustomerPreferencesPage $preferencesPage,
        private readonly TemplatesController $templatesController,
        private readonly TemplateRepository $templates,
        private readonly OfferBlocks $blocks,
        private readonly UsersScreen $usersScreen,
        private readonly AjaxHandler $ajax,
        private readonly CheckoutHandler $checkout,
        private readonly PrivacyEraser $privacy,
        private readonly PrivacyExporter $exporter,
        private readonly CleanupService $cleanup,
        private readonly OfferPipeline $pipeline,
        private readonly OfferPublisher $publisher,
        private readonly ContentMigration $migration,
        private readonly SpaceInventory $spaceInventory,
        private readonly Webhooks $webhooks,
        private readonly SpacesController $spacesController,
        private readonly AccessRequests $accessRequests,
    ) {}

    public static function boot(): self {
        $log = new Logger();
        $tokens = new TokenService();
        $offers = new OfferRepository();
        $brands = new BrandSnapshotRepository();
        $brandTemplate = new BrandTemplate();
        $wishlists = new AdapterRegistry();
        $ai = new ProviderDetector();
        $profiles = new ProfileBuilder($wishlists, $log);
        $customerProfiles = new CustomerProfiles($profiles, $profileRepository = new CustomerProfileRepository(), $log);
        $segments = new Segments($profileRepository);
        $templates = new TemplateRepository();
        $zip = new ZipExporter($offers, $brands, $brandTemplate, new OfferPageRenderer());
        $spacefast = new SpacefastClient();
        $accessRequests = new AccessRequests($spacefast, $offers, new \Micemade\PersonalizedOffers\Repository\RecipientRepository(), $log);

        $pipeline = new OfferPipeline(
            $customerProfiles,
            new ShortlistBuilder(),
            new OfferComposer(),
            new JobScheduler(),
            $offers,
            $templates,
            $tokens,
            new CouponFactory(),
            $log,
        );

        return new self(
            new Assets(),
            $settingsPage = new SettingsPage($brands, $ai),
            new OffersPage(new ChatAgent($log, new ChatRepository()), $ai, $spacefast, $settingsPage, $accessRequests),
            new OffersController($offers, $zip, $publisher = new OfferPublisher($offers, new \Micemade\PersonalizedOffers\Repository\RecipientRepository(), $zip, $spacefast, $log), $spacefast, $pipeline, $editor = new OfferEditor($offers, $pipeline, $templates), new CustomerFinder(), segments: $segments),
            new OfferSharingController($offers, $email = new \Micemade\PersonalizedOffers\Service\OfferEmail($offers)),
            new OfferAbilities($pipeline, $offers),
            new TemplateAbilities($templates, $pipeline, $offers, new StyleInspector()),
            new SharedOfferAbilities($editor, $publisher, $spacefast, $offers, segments: $segments),
            new OfferManagementAbilities($offers, $editor, $pipeline, $publisher, $spacefast, $email),
            new SpacefastAbilities($spacefast, $publisher, $offers, $inventory = new SpaceInventory($spacefast, $offers, $publisher), $webhooks = new Webhooks($spacefast, $publisher, $log)),
            new SettingsAbilities($brandTemplate, $brands),
            new CustomerAbilities($customerProfiles),
            new CustomersController($customerProfiles),
            $segments,
            new SegmentAbilities($segments),
            new SegmentsController($segments, $customerProfiles),
            $customerProfiles,
            new CustomerPreferencesPage($customerProfiles),
            new TemplatesController($templates, $zip, $pipeline),
            $templates,
            new OfferBlocks(
                $templates,
                static fn (\Micemade\PersonalizedOffers\Value\OfferDesign $design, array $copy = []): array => $zip->sampleVars($design, $copy),
                static fn (): \Micemade\PersonalizedOffers\Value\BrandSnapshot => $zip->brand(),
            ),
            new UsersScreen($pipeline, $log),
            new AjaxHandler($brandTemplate, $brands, $ai),
            new CheckoutHandler($offers, $tokens, $profiles, $log),
            new PrivacyEraser($offers, $pipeline, $customerProfiles),
            new PrivacyExporter($offers, $customerProfiles),
            new CleanupService($offers, $log),
            $pipeline,
            $publisher,
            new ContentMigration($offers, static fn (): bool => null !== ($brandTemplate->assets($zip->brand())['logo'] ?? null)),
            $inventory,
            $webhooks,
            new SpacesController($spacefast, $inventory, $publisher, $offers, $webhooks, $accessRequests),
            $accessRequests,
        );
    }

    public function register(): void {
        // Admin-only notice; runs after init so its messages can be translated.
        add_action('admin_init', [$this, 'checkRequirements']);
        add_action('init', [Installer::class, 'maybeUpgrade'], 1);
        // Offers and templates from before offer text fields; any request, as a background publish may render one.
        add_action('init', [$this->migration, 'maybeRun'], 2);
        add_filter('plugin_action_links_' . plugin_basename(POFSF_PLUGIN_FILE), [$this, 'actionLinks']);

        $this->assets->register();
        $this->settingsPage->register();
        $this->offersPage->register();
        $this->offersController->register();
        $this->sharingController->register();
        $this->abilities->register();
        $this->templateAbilities->register();
        $this->sharedOfferAbilities->register();
        $this->offerManagementAbilities->register();
        $this->spacefastAbilities->register();
        $this->spaceInventory->register();
        $this->webhooks->register();
        $this->spacesController->register();
        $this->accessRequests->register();
        $this->settingsAbilities->register();
        $this->customerAbilities->register();
        $this->customersController->register();
        $this->segments->register();
        $this->segmentAbilities->register();
        $this->segmentsController->register();
        $this->customerProfiles->register();
        $this->preferencesPage->register();
        $this->templatesController->register();
        $this->templates->register();
        $this->blocks->register();
        $this->usersScreen->register();
        $this->ajax->register();
        $this->checkout->register();
        $this->privacy->register();
        $this->exporter->register();
        $this->cleanup->register();

        add_action(JobScheduler::HOOK, [$this->pipeline, 'run']);
        add_action(JobScheduler::LEGACY_HOOK, [$this->pipeline, 'runLegacy'], 10, 2);

        // Offers follow their template: a saved template updates the offers using it.
        add_action('wp_after_insert_post', [$this->pipeline, 'onTemplateSaved'], 10, 2);
        add_action('pofsf_template_saved', [$this->pipeline, 'syncTemplate']);
        add_action(JobScheduler::REPUBLISH_HOOK, [$this->publisher, 'republish']);
        add_action(JobScheduler::ACCESS_HOOK, [$this->publisher, 'syncAccess']);
        add_action('admin_init', [$this, 'syncOffersOnce']);
    }

    /**
     * Once: offers created while offers kept a fixed copy of their template
     * take their template's current version.
     */
    public function syncOffersOnce(): void {
        if (get_option('pofsf_offers_follow_templates')) {
            return;
        }

        update_option('pofsf_offers_follow_templates', 1, false);
        $this->pipeline->syncAllTemplates();
    }

    public function checkRequirements(): void {
        $errors = Installer::requirementErrors();

        if ([] !== $errors) {
            add_action('admin_notices', static function () use ($errors): void {
                echo '<div class="notice notice-error"><p><strong>'
                    . esc_html__('Personalized Offers for Spacefast - Requirements Not Met', 'personalized-offers-for-spacefast')
                    . '</strong><br>'
                    . esc_html(implode(' ', $errors))
                    . '</p></div>';
            });
        }
    }

    public function actionLinks(array $links): array {
        $settings = sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('admin.php?page=wc-settings&tab=pofsf')),
            esc_html__('Settings', 'personalized-offers-for-spacefast'),
        );

        return array_merge([$settings], $links);
    }
}
