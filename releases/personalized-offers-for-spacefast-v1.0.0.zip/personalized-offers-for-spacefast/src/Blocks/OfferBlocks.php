<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Blocks;

use Micemade\PersonalizedOffers\Service\EditorCopy;
use Closure;
use Micemade\PersonalizedOffers\Repository\TemplateRepository;
use Micemade\PersonalizedOffers\Value\BrandSnapshot;
use Micemade\PersonalizedOffers\Value\FontCatalog;
use Micemade\PersonalizedOffers\Value\OfferCopy;
use Micemade\PersonalizedOffers\Value\OfferDesign;
use WP_Block;

/**
 * Dynamic "Spacefast offer" blocks used in offer templates, plus the block
 * editor integration for the template post type.
 *
 * Blocks render the offer that OfferPageRenderer is currently building
 * (see renderWith()). In the editor, where there is no offer, they render
 * sample content so the template can be designed visually.
 */
final class OfferBlocks {
    public const CATEGORY = 'pofsf-offer';
    public const EDITOR_HANDLE = 'pofsf-offer-editor';
    public const STYLE_HANDLE = 'pofsf-offer-blocks';

    /** Group block styles the starter layouts are built from. */
    public const GROUP_STYLES = [
        'pofsf-banner' => 'Offer banner',
        'pofsf-paper' => 'Paper card',
        'pofsf-masthead' => 'Masthead',
        'pofsf-strip' => 'Dark strip',
        'pofsf-sticky-bar' => 'Sticky checkout bar',
    ];

    /** Offer text block styles (is-style-*), from the former personal note styles. */
    public const TEXT_STYLES = [
        'pofsf-card' => 'Card',
        'pofsf-quote' => 'Pull quote',
        'pofsf-letter' => 'Letter',
        'pofsf-sticker' => 'Sticker',
    ];

    /**
     * Blocks the Offer text block replaced, and the field type each shows.
     * Old markup is upgraded when rendered (legacyBlock()) and stored
     * templates once (ContentMigration).
     */
    public const LEGACY_TEXT_BLOCKS = [
        'pofsf/theme' => 'overheadline',
        'pofsf/greeting' => 'greeting',
        'pofsf/body-copy' => 'body',
        'pofsf/personal-note' => 'additional',
        'pofsf/closing' => 'additional',
    ];

    /**
     * Former names of the Offer action button block: the Checkout button,
     * which always opened checkout with the picks, and the Action button.
     */
    public const LEGACY_ACTION_BUTTONS = ['pofsf/checkout-button', 'pofsf/action-button'];

    /** Offer action button block styles (is-style-*). */
    public const ACTION_STYLES = [
        'pofsf-outline' => 'Outline',
        'pofsf-pill' => 'Pill',
        'pofsf-soft' => 'Soft',
        'pofsf-raised' => 'Raised',
        'pofsf-link' => 'Text link',
    ];

    /** The headline block is legacy: kept so older templates render; the editor turns it into the Offer headline variation of core/heading. */
    private const BLOCKS = ['branding', 'headline', 'offer-text', 'products', 'offer-action-button'];

    /** Block bindings source of the Offer headline (a core/heading variation): {"key":"headline"}. */
    public const BINDINGS_SOURCE = 'pofsf/offer';

    /**
     * Offer products styles: editorial (story, numbered "Index"), presentational
     * (feature "Cover", lookbook, showcase) and catalogue (catalogue, gallery).
     */
    public const PRODUCT_VARIANTS = ['story', 'feature', 'lookbook', 'numbered', 'catalogue', 'gallery', 'showcase'];

    /** Former webshop-like product styles and the style that replaced each. */
    public const LEGACY_PRODUCT_VARIANTS = ['grid' => 'catalogue', 'list' => 'numbered', 'tiles' => 'gallery', 'compact' => 'numbered'];

    /** Image aspect ratios the products block's Styles offer ("auto": each image's own). */
    private const IMAGE_RATIOS = ['auto', '1', '4/5', '3/4', '2/3', '3/2', '16/9'];

    /**
     * Grid of products blocks saved before the block used the grid layout
     * support, matching how each style used to lay out: [columns, gap].
     * Gaps are single plain lengths: core drops gap values containing "(",
     * and a split row/column gap breaks its responsive column formula.
     * Keep in sync with LEGACY_GRID in assets/src/editor/blocks.js.
     */
    private const LEGACY_GRID = [
        'grid' => [3, '16px'],
        'list' => [1, '16px'],
        'tiles' => [3, '24px'],
        'numbered' => [2, '40px'],
        'compact' => [1, '0px'],
        'feature' => [1, '24px'],
        'story' => [1, '2rem'],
        'lookbook' => [2, '48px'],
        // Current styles without a saved layout (e.g. written by the AI assistant).
        'catalogue' => [3, '24px'],
        'gallery' => [3, '32px'],
        'showcase' => [1, '0px'],
    ];

    /** Offer data for the page being rendered; null in the editor. */
    private static ?array $context = null;

    /**
     * @param Closure(OfferDesign, array): array $sample Builds sample offer data for the editor, with the offer texts (EditorCopy) if any.
     * @param Closure(): BrandSnapshot   $brand  The active brand snapshot.
     */
    public function __construct(
        private readonly TemplateRepository $templates,
        private readonly Closure $sample,
        private readonly Closure $brand,
    ) {}

    public function register(): void {
        add_action('init', [$this, 'registerBlocks']);
        add_action('init', [self::class, 'registerBindings']);
        add_filter('render_block_core/heading', [self::class, 'headlineClass'], 10, 2);
        add_filter('render_block_data', [self::class, 'legacyProductsGrid']);
        add_filter('render_block_data', [self::class, 'legacyBlock']);
        add_filter('block_categories_all', [$this, 'category'], 10, 2);
        add_action('enqueue_block_editor_assets', [$this, 'editorAssets']);
        add_action('enqueue_block_assets', [$this, 'canvasAssets']);
        add_filter('admin_body_class', [$this, 'frameBodyClass']);
        add_action('admin_head', [$this, 'frameStyles']);
    }

    /**
     * Renders block markup with $vars as the current offer.
     */
    public static function renderWith(array $vars, string $content): string {
        $previous = self::$context;
        self::$context = $vars;

        try {
            return do_blocks($content);
        } finally {
            self::$context = $previous;
        }
    }

    public function registerBlocks(): void {
        foreach (self::BLOCKS as $name) {
            register_block_type(POFSF_PLUGIN_DIR . 'blocks/' . $name, [
                'render_callback' => fn (array $attributes, string $content, WP_Block $block): string => $this->render($name, $attributes, $block),
            ]);
        }

        foreach (self::GROUP_STYLES as $style => $label) {
            register_block_style('core/group', ['name' => $style, 'label' => $label]);
        }

        foreach (self::TEXT_STYLES as $style => $label) {
            register_block_style('pofsf/offer-text', ['name' => $style, 'label' => $label]);
        }

        foreach (self::ACTION_STYLES as $style => $label) {
            register_block_style('pofsf/offer-action-button', ['name' => $style, 'label' => $label]);
        }
    }

    /**
     * The Offer headline: a core Heading whose text is bound to the offer's
     * headline, so it has all the Heading settings but its text cannot be
     * edited. Outside an offer page (no offer being rendered) the heading
     * keeps its saved text.
     */
    public static function registerBindings(): void {
        if (!function_exists('register_block_bindings_source')) {
            return;
        }

        register_block_bindings_source(self::BINDINGS_SOURCE, [
            'label' => __('Offer', 'personalized-offers-for-spacefast'),
            'get_value_callback' => static function (array $args): ?string {
                if (null === self::$context || 'headline' !== ($args['key'] ?? '')) {
                    return null;
                }

                return esc_html((string) self::$context['headline']);
            },
        ]);
    }

    /**
     * Gives the Offer headline the pofsf-headline class the offer styles
     * (and template CSS) use, without it showing among the block's own classes.
     */
    public static function headlineClass(string $content, array $block): string {
        if (self::BINDINGS_SOURCE !== ($block['attrs']['metadata']['bindings']['content']['source'] ?? '')) {
            return $content;
        }

        $tags = new \WP_HTML_Tag_Processor($content);

        if ($tags->next_tag()) {
            $tags->add_class('pofsf-headline');
        }

        return $tags->get_updated_html();
    }

    /**
     * The current block in place of a block it replaced, keeping its
     * settings: an Offer text block for the theme, greeting, body copy,
     * personal note and closing blocks (a personal note's style becomes the
     * matching block style), an Offer action button for the Checkout button
     * (to the cart) and the Action button.
     */
    public static function legacyBlock(array $block): array {
        $name = (string) ($block['blockName'] ?? '');

        if (in_array($name, self::LEGACY_ACTION_BUTTONS, true)) {
            $block['blockName'] = 'pofsf/offer-action-button';

            return $block;
        }

        $field = self::LEGACY_TEXT_BLOCKS[$name] ?? null;

        if (null === $field) {
            return $block;
        }

        $attrs = $block['attrs'] ?? [];

        if ('pofsf/personal-note' === $name) {
            $variant = (string) ($attrs['variant'] ?? 'card');

            if (isset(self::TEXT_STYLES['pofsf-' . $variant])) {
                $attrs['className'] = trim(($attrs['className'] ?? '') . ' is-style-pofsf-' . $variant);
            }

            unset($attrs['variant'], $attrs['showSignature'], $attrs['signoff']);
        }

        // Former helper class for the display-size closing line.
        if (isset($attrs['className'])) {
            $attrs['className'] = trim(str_replace('pofsf-closing--display', 'pofsf-display-text', (string) $attrs['className']));
        }

        $block['blockName'] = 'pofsf/offer-text';
        $block['attrs'] = ['field' => $field] + array_filter($attrs, static fn (mixed $value): bool => '' !== $value);

        return $block;
    }

    /**
     * Gives products blocks saved before the grid layout support (offer
     * snapshots keep their template markup) the grid they used to have,
     * and the current style for a former one. $savedBefore: saved before
     * the editorial styles (ContentMigration), so no style means the grid.
     */
    public static function legacyProductsGrid(array $block, bool $savedBefore = false): array {
        if ('pofsf/products' !== ($block['blockName'] ?? '')) {
            return $block;
        }

        $attrs = $block['attrs'] ?? [];
        // A block without a style has the default one: the grid before the
        // editorial styles (content ContentMigration upgrades, and blocks with
        // the even older columns setting), the story since.
        $variant = (string) ($attrs['variant'] ?? ($savedBefore || isset($attrs['columns']) ? 'grid' : 'story'));

        if (!isset($attrs['layout'])) {
            [$columns, $gap] = self::LEGACY_GRID[$variant] ?? self::LEGACY_GRID['grid'];

            if (in_array($variant, ['grid', 'tiles', 'numbered'], true) && isset($attrs['columns'])) {
                $columns = max(1, min('numbered' === $variant ? 2 : 4, (int) $attrs['columns']));
            }

            $attrs['layout'] = ['type' => 'grid', 'columnCount' => $columns] + ($columns > 1 ? ['minimumColumnWidth' => '12rem'] : []);
            $attrs['style']['spacing']['blockGap'] ??= $gap;
            unset($attrs['columns']);
        }

        // Webshop-like styles became editorial ones.
        if (!in_array($variant, self::PRODUCT_VARIANTS, true)) {
            $attrs['variant'] = self::LEGACY_PRODUCT_VARIANTS[$variant] ?? 'catalogue';
        }

        // Settings the block no longer has (ContentMigration moved their effect into the template).
        unset($attrs['offset'], $attrs['limit'], $attrs['heading'], $attrs['backgroundColor'], $attrs['gradient'], $attrs['style']['color']['background'], $attrs['style']['color']['gradient']);
        $block['attrs'] = $attrs;

        return $block;
    }

    public function category(array $categories, mixed $context): array {
        return array_merge([['slug' => self::CATEGORY, 'title' => __('Spacefast offer', 'personalized-offers-for-spacefast'), 'icon' => null]], $categories);
    }

    public function editorAssets(): void {
        if (!$this->isTemplateEditor()) {
            return;
        }

        $asset = $this->asset('editor');

        wp_enqueue_script(self::EDITOR_HANDLE, POFSF_PLUGIN_URL . 'assets/build/editor.js', $asset['dependencies'], $asset['version'], true);
        wp_enqueue_style(self::EDITOR_HANDLE, POFSF_PLUGIN_URL . 'assets/build/editor.css', ['wp-components'], $asset['version']);
        wp_set_script_translations(self::EDITOR_HANDLE, 'personalized-offers-for-spacefast', POFSF_PLUGIN_DIR . 'languages');
        $brand = ($this->brand)();
        $brandFonts = OfferDesign::fromArray(['use_brand' => true])->fontsFor($brand);

        wp_localize_script(self::EDITOR_HANDLE, 'pofsfEditor', [
            'fonts' => FontCatalog::options(),
            'colorKeys' => OfferDesign::COLOR_KEYS,
            'defaultColors' => OfferDesign::defaultColors(),
            'defaultFont' => OfferDesign::defaultFont(),
            'brandColors' => OfferDesign::fromArray(['use_brand' => true])->palette($brand),
            'brandFonts' => $brandFonts,
            'defaults' => OfferDesign::brandDefault()->toArray(),
            'builtin' => '' !== (string) ($this->currentTemplate()['builtin'] ?? ''),
            'fieldTypes' => OfferCopy::typeLabels(),
            // What the Offer headline shows in the editor: the offer's (Edit offer) or a sample.
            'headline' => (string) (($this->sample)($this->currentTemplate()['design'] ?? OfferDesign::brandDefault(), EditorCopy::fromRequest())['headline'] ?? ''),
        ]);
    }

    /**
     * Block styles and the current design inside the editor canvas (iframe).
     */
    public function canvasAssets(): void {
        if (!is_admin() || !$this->isTemplateEditor()) {
            return;
        }

        $design = $this->currentTemplate()['design'] ?? OfferDesign::brandDefault();

        wp_enqueue_style(self::STYLE_HANDLE, POFSF_PLUGIN_URL . 'assets/offer/offer.css', [], POFSF_VERSION);
        wp_add_inline_style(self::STYLE_HANDLE, self::tokensCss($design, ($this->brand)()));
        // Editor-only canvas styles (template name label); not part of offer pages.
        wp_enqueue_style('pofsf-editor-canvas', POFSF_PLUGIN_URL . 'assets/css/editor-canvas.css', [], POFSF_VERSION);

        foreach ($design->fontUrls() as $index => $url) {
            wp_enqueue_style('pofsf-offer-font-' . $index, $url, [], POFSF_VERSION);
        }
    }

    /**
     * CSS variables for a design. The renderer passes the brand palette;
     * the editor falls back to the design's own colors and defaults.
     */
    public static function tokensCss(OfferDesign $design, ?BrandSnapshot $brand): string {
        $brand ??= BrandSnapshot::fromArray([]);
        $vars = '';

        foreach ($design->palette($brand) as $key => $color) {
            $vars .= '--pofsf-' . str_replace('_', '-', $key) . ':' . $color . ';';
        }

        $fonts = $design->fontsFor($brand);

        return ':root{' . $vars . '--pofsf-font-heading:' . $fonts['heading'] . ';--pofsf-font-body:' . $fonts['body'] . '}';
    }

    /**
     * Template editor opened from the Templates tab in a modal: hide the admin chrome.
     */
    public function frameBodyClass(string $classes): string {
        return $this->isFrame() ? $classes . ' pofsf-frame' : $classes;
    }

    public function frameStyles(): void {
        if (!$this->isFrame()) {
            return;
        }

        echo '<style>'
            . 'html.wp-toolbar{padding-top:0!important}'
            . 'body.pofsf-frame #wpadminbar,body.pofsf-frame #adminmenumain,body.pofsf-frame #wpfooter{display:none!important}'
            . 'body.pofsf-frame #wpcontent{margin-left:0!important}'
            . 'body.pofsf-frame .interface-interface-skeleton{top:0!important;left:0!important}'
            . '</style>';
    }

    private function render(string $name, array $attributes, WP_Block $block): string {
        // Editor previews: the offer's own texts when opened from Edit offer (EditorCopy), else samples.
        $vars = self::$context ?? ($this->sample)($this->templateDesign($block), EditorCopy::fromRequest());

        return match ($name) {
            'branding' => $this->branding((array) $vars['branding'], $attributes),
            'headline' => $this->wrap('h' . max(1, min(3, (int) ($attributes['level'] ?? 1))), 'pofsf-headline', esc_html($vars['headline'])),
            'offer-text' => $this->text($vars, $attributes),
            'products' => $this->products($vars['products'], $attributes, (string) ($vars['offer_url'] ?? '')),
            'offer-action-button' => $this->offerActionButton($vars, $attributes),
            default => '',
        };
    }

    /**
     * The store's logo and name. The logo is the site logo, or the site
     * icon when the store has none; the name shows when chosen, and also
     * when nothing else would (so the block is never empty). The block's
     * typography settings style the name, not the logo.
     *
     * @param array{logo?: string, icon?: string, name?: string, url?: string} $branding Image src, store name and home URL (raw).
     */
    private function branding(array $branding, array $attributes): string {
        $name = (string) ($branding['name'] ?? '');
        $logoSrc = (string) ($branding['logo'] ?? '');
        $iconSrc = (string) ($branding['icon'] ?? '');
        $width = max(0, min(600, (int) ($attributes['logoWidth'] ?? 0)));
        $image = null;

        if (!isset($attributes['showLogo']) || !empty($attributes['showLogo'])) {
            $image = match (true) {
                // Logo size: the logo's width (its height follows), or the icon's width and height.
                '' !== $logoSrc => [$logoSrc, 'pofsf-logo', '', sprintf('width:%dpx;max-height:none', $width)],
                '' !== $iconSrc => [$iconSrc, 'pofsf-site-icon', ' width="48" height="48"', sprintf('width:%1$dpx;height:%1$dpx', $width)],
                default => null,
            };
        }

        $showTitle = null === $image || !isset($attributes['showTitle']) || !empty($attributes['showTitle']);
        $title = '';

        if ($showTitle) {
            [$titleClass, $titleStyle] = self::brandingTypography($attributes);
            $title = sprintf(
                '<span class="%s"%s>%s</span>',
                esc_attr(trim('pofsf-store-name ' . $titleClass)),
                '' !== $titleStyle ? ' style="' . esc_attr($titleStyle) . '"' : '',
                esc_html($name),
            );
        }

        if (null !== $image) {
            // Next to the name the image is decorative; alone it names the store.
            $image = sprintf(
                '<img src="%s" alt="%s" class="%s"%s%s />',
                esc_attr($image[0]),
                $showTitle ? '' : esc_attr($name),
                $image[1],
                $image[2],
                $width > 0 ? ' style="' . $image[3] . '"' : '',
            );
        }

        $inner = (string) $image . $title;
        $url = (string) ($branding['url'] ?? '');

        if (!empty($attributes['isLink']) && '' !== $url) {
            $inner = sprintf('<a class="pofsf-branding__link" href="%s">%s</a>', esc_url($url), $inner);
        }

        return $this->wrap('div', 'pofsf-branding', $inner);
    }

    /**
     * Classes and inline style for the block's typography settings, as
     * core's typography support makes them, for the store name (the block
     * skips serializing them on its wrapper).
     *
     * @return array{0: string, 1: string}
     */
    private static function brandingTypography(array $attributes): array {
        $custom = (array) ($attributes['style']['typography'] ?? []);
        $fontSize = '' !== (string) ($attributes['fontSize'] ?? '') ? 'var:preset|font-size|' . $attributes['fontSize'] : ($custom['fontSize'] ?? null);

        if (is_string($fontSize) && !str_starts_with($fontSize, 'var:') && function_exists('wp_get_typography_font_size_value')) {
            $fontSize = wp_get_typography_font_size_value(['size' => $fontSize]);
        }

        $typography = array_filter([
            'fontSize' => $fontSize,
            'fontFamily' => '' !== (string) ($attributes['fontFamily'] ?? '') ? 'var:preset|font-family|' . $attributes['fontFamily'] : ($custom['fontFamily'] ?? null),
            'fontWeight' => $custom['fontWeight'] ?? null,
            'fontStyle' => $custom['fontStyle'] ?? null,
            'lineHeight' => $custom['lineHeight'] ?? null,
            'letterSpacing' => $custom['letterSpacing'] ?? null,
            'textTransform' => $custom['textTransform'] ?? null,
            'textDecoration' => $custom['textDecoration'] ?? null,
        ], static fn (mixed $value): bool => (is_string($value) || is_int($value) || is_float($value)) && '' !== (string) $value);

        if ([] === $typography || !function_exists('wp_style_engine_get_styles')) {
            return ['', ''];
        }

        $styles = wp_style_engine_get_styles(['typography' => $typography], ['convert_vars_to_classnames' => true]);

        return [(string) ($styles['classnames'] ?? ''), (string) ($styles['css'] ?? '')];
    }

    private function wrap(string $tag, string $class, string $inner, array $extra = []): string {
        return sprintf('<%1$s %2$s>%3$s</%1$s>', $tag, get_block_wrapper_attributes(['class' => $class] + $extra), $inner);
    }

    /**
     * The offer's text of the block's field type, a paragraph per text
     * (older offers may hold more than one).
     */
    private function text(array $vars, array $attributes): string {
        $field = (string) ($attributes['field'] ?? 'body');
        $texts = (array) ($vars['texts'][$field] ?? []);
        $class = 'pofsf-text pofsf-text--' . sanitize_html_class($field);

        if ([] === $texts) {
            // In the editor an empty block would read "Block rendered as empty": say what it shows.
            return null === self::$context ? $this->wrap('div', $class . ' pofsf-text--empty', '<p class="pofsf-text__item">' . esc_html(self::emptyText($field)) . '</p>') : '';
        }

        return $this->wrap('div', $class, implode('', array_map(
            static fn (string $text): string => '<p class="pofsf-text__item">' . nl2br(esc_html($text)) . '</p>',
            array_map('strval', $texts),
        )));
    }

    private static function emptyText(string $field): string {
        /* translators: %s: field type, e.g. "Body text". */
        return sprintf(__('%s: shown when the offer has a field of this type.', 'personalized-offers-for-spacefast'), OfferCopy::typeLabels()[$field] ?? $field);
    }

    /**
     * The offer's products. Every style shows each pick the same way, a
     * label (product name and price), its title, its story and (showCart)
     * its cart button; the style and the block's Styles settings
     * (appearance, as CSS variables) set how they are presented.
     */
    private function products(array $products, array $attributes, string $offerUrl = ''): string {
        if ([] === $products) {
            return '';
        }

        $showCart = !isset($attributes['showCart']) || !empty($attributes['showCart']);

        $variant = in_array($attributes['variant'] ?? '', self::PRODUCT_VARIANTS, true) ? (string) $attributes['variant'] : 'story';
        $showStory = !isset($attributes['showReason']) || !empty($attributes['showReason']);
        $showPrice = !isset($attributes['showPrice']) || !empty($attributes['showPrice']);
        [$classes, $style] = self::productsAppearance((array) ($attributes['appearance'] ?? []));
        $items = '';

        foreach (array_values($products) as $index => $product) {
            $image = $product['image_large'] ?: $product['image'];
            $media = '' !== $image
                ? sprintf('<div class="pofsf-product__media"><img src="%s" alt="%s" loading="lazy" /></div>', esc_url($image), esc_attr($product['name']))
                : '';
            $label = sprintf(
                '<p class="pofsf-product__label"><span class="pofsf-product__number" aria-hidden="true">%s</span><span class="pofsf-product__name">%s</span>%s</p>',
                esc_html(str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT)),
                esc_html($product['name']),
                $showPrice ? '<span class="pofsf-product__leader" aria-hidden="true"></span><span class="pofsf-product__price">' . wp_kses_post($product['price_html']) . '</span>' : '',
            );

            $items .= sprintf(
                '<article class="pofsf-product%s"%s>%s<div class="pofsf-product__text">%s<h3 class="pofsf-product__title">%s</h3>%s%s</div></article>',
                0 === $index ? ' pofsf-product--first' : '',
                isset($product['pick']) ? ' data-pofsf-pick="' . (int) $product['pick'] . '"' : '',
                $media,
                $label,
                esc_html($product['title']),
                $showStory && '' !== $product['story'] ? '<p class="pofsf-product__story">' . esc_html($product['story']) . '</p>' : '',
                $showCart ? self::cartButton($product, $offerUrl) : '',
            );
        }

        // The products are the block's own grid items (layout support adds
        // the grid classes and styles to this wrapper).
        return $this->wrap(
            'section',
            trim('pofsf-products pofsf-products--' . $variant . ' ' . $classes),
            $items,
            '' !== $style ? ['style' => $style] : [],
        );
    }

    /**
     * A product's cart button, as WooCommerce names it: "Add to cart" for
     * a simple product, "Select options" for a variable one, "Read more"
     * when it cannot be bought. On the offer page the cart script
     * (offer-cart.js) adds to the page's own cart or opens the options;
     * without it the link goes through the offer link: the cart with this
     * product, or the product page to choose its options.
     */
    private static function cartButton(array $product, string $offerUrl): string {
        $pick = (int) ($product['pick'] ?? 0);
        $buyable = !empty($product['purchasable']) && !empty($product['in_stock']);
        $variable = 'variable' === ($product['type'] ?? '');

        if ($pick <= 0 || '' === $offerUrl) {
            return '';
        }

        [$action, $label, $args] = match (true) {
            !$buyable => ['more', __('Read more', 'personalized-offers-for-spacefast'), ['pofsf_to' => 'product', 'pofsf_pick' => $pick]],
            $variable => ['options', __('Select options', 'personalized-offers-for-spacefast'), ['pofsf_to' => 'product', 'pofsf_pick' => $pick]],
            default => ['add', __('Add to cart', 'personalized-offers-for-spacefast'), ['pofsf_to' => 'cart', 'items' => (int) ($product['product_id'] ?? 0) . ':1']],
        };

        return sprintf(
            '<div class="pofsf-product__buy"><a class="pofsf-product__button pofsf-product__button--%1$s" href="%2$s" data-pofsf-action="%1$s">%3$s</a>%4$s</div>',
            esc_attr($action),
            esc_url(add_query_arg($args, $offerUrl)),
            esc_html($label),
            $buyable ? '' : '<span class="pofsf-product__stock">' . esc_html__('Out of stock', 'personalized-offers-for-spacefast') . '</span>',
        );
    }

    /**
     * Classes and CSS variables for the products block's Styles settings
     * (the `appearance` attribute). Unset values keep the style's own look.
     *
     * @return array{0: string, 1: string}
     */
    public static function productsAppearance(array $appearance): array {
        $vars = [];
        $classes = [];
        $pick = static fn (string $key, array $allowed): ?string => in_array($appearance[$key] ?? null, $allowed, true) ? (string) $appearance[$key] : null;

        if (null !== ($ratio = $pick('imageRatio', self::IMAGE_RATIOS))) {
            $vars['--pofsfp-ratio'] = $ratio;
        }

        if (null !== ($fit = $pick('imageFit', ['cover', 'contain']))) {
            $vars['--pofsfp-fit'] = $fit;
        }

        if (isset($appearance['imageInset']) && is_numeric($appearance['imageInset'])) {
            $vars['--pofsfp-inset'] = max(0, min(20, (int) $appearance['imageInset'])) . '%';
        }

        if (isset($appearance['imageRadius']) && is_numeric($appearance['imageRadius'])) {
            $vars['--pofsfp-radius'] = max(0, min(64, (int) $appearance['imageRadius'])) . 'px';
        }

        $colors = [
            'imageBackdrop' => '--pofsfp-backdrop',
            'cardColor' => '--pofsfp-card',
            'lineColor' => '--pofsfp-line',
            'titleColor' => '--pofsfp-title',
            'storyColor' => '--pofsfp-story',
            'labelColor' => '--pofsfp-label',
            'priceColor' => '--pofsfp-price',
            'numberColor' => '--pofsfp-number',
        ];

        foreach ($colors as $key => $var) {
            $color = self::colorValue($appearance[$key] ?? '');

            if ('' !== $color) {
                $vars[$var] = $color;
            }
        }

        if (isset($vars['--pofsfp-card'])) {
            $classes[] = 'has-product-card';
        }

        foreach (['titleSize' => '--pofsfp-title-size', 'storySize' => '--pofsfp-story-size', 'labelSize' => '--pofsfp-label-size'] as $key => $var) {
            $size = self::lengthValue($appearance[$key] ?? '');

            if ('' !== $size) {
                $vars[$var] = $size;
            }
        }

        if (null !== ($font = $pick('titleFont', ['heading', 'body']))) {
            $vars['--pofsfp-title-font'] = 'var(--pofsf-font-' . $font . ')';
        }

        if (null !== ($weight = $pick('titleWeight', ['300', '400', '500', '600', '700', '800', '900']))) {
            $vars['--pofsfp-title-weight'] = $weight;
        }

        if (null !== ($fontStyle = $pick('titleStyle', ['normal', 'italic']))) {
            $vars['--pofsfp-title-style'] = $fontStyle;
        }

        if (null !== ($transform = $pick('titleTransform', ['none', 'uppercase', 'lowercase', 'capitalize']))) {
            $vars['--pofsfp-title-transform'] = $transform;
        }

        if (null !== ($align = $pick('textAlign', ['left', 'center', 'right']))) {
            $classes[] = 'has-product-text-' . $align;
        }

        $style = '';

        foreach ($vars as $name => $value) {
            $style .= $name . ':' . $value . ';';
        }

        return [implode(' ', $classes), $style];
    }

    /**
     * A color from the color pickers: hex, or a theme preset variable
     * (WordPress' CSS filter drops rgb() and hsl() in custom properties).
     */
    private static function colorValue(mixed $value): string {
        $value = is_string($value) ? trim($value) : '';

        return 1 === preg_match('/^(#[0-9a-f]{3,8}|var\(--[\w-]+\))$/i', $value) ? $value : '';
    }

    /** A font size from the font size pickers (a length, clamp() or a theme preset variable). */
    private static function lengthValue(mixed $value): string {
        if (is_int($value) || is_float($value)) {
            return $value . 'px';
        }

        $value = is_string($value) ? trim($value) : '';

        return '' !== $value && strlen($value) <= 120 && 1 === preg_match('/^[\w\s().,%+*\/-]+$/', $value) ? $value : '';
    }

    /**
     * The Offer action button: a form that sends the products the customer
     * put in the page's cart (offer-cart.js fills pofsf_cart) to the store's
     * checkout through the offer link (CheckoutHandler), which applies the
     * offer's coupon and counts the order. With an empty cart, or without
     * the script, checkout gets all of the offer's products. Its color
     * settings style the button itself, not the block around it.
     *
     * Its text is the offer's own (Personalize → Button text), else the
     * block's (a fallback), else the default. In the template editor and in
     * admin previews (inert) the button does not submit.
     */
    private function offerActionButton(array $vars, array $attributes): string {
        $label = trim((string) ($vars['button_text'] ?? '')) ?: trim((string) ($attributes['label'] ?? '')) ?: $vars['cta_label'];
        $inert = null === self::$context || !empty($vars['inert']);
        [$colorClass, $colorStyle] = self::actionButtonColors($attributes);
        $offerUrl = (string) ($vars['offer_url'] ?? '');
        $query = [];
        parse_str((string) wp_parse_url($offerUrl, PHP_URL_QUERY), $query);
        $action = strtok($offerUrl, '?#') ?: home_url('/');
        $fields = '';

        foreach (['pofsf_to' => 'checkout'] + $query as $name => $value) {
            if (is_scalar($value)) {
                $fields .= sprintf('<input type="hidden" name="%s" value="%s" />', esc_attr((string) $name), esc_attr((string) $value));
            }
        }

        $button = sprintf(
            // In the template editor and admin previews the button must not submit (it would load the store).
            '<button type="%s" class="%s"%s%s>%s<span class="pofsf-offer-action__count" hidden></span>%s</button>',
            $inert ? 'button' : 'submit',
            esc_attr(trim('pofsf-offer-action__button ' . $colorClass)),
            '' !== $colorStyle ? ' style="' . esc_attr($colorStyle) . '"' : '',
            null !== self::$context && $inert ? ' aria-disabled="true" title="' . esc_attr__('Checkout is turned off in previews.', 'personalized-offers-for-spacefast') . '"' : '',
            esc_html($label),
            !empty($attributes['arrow']) ? ' <span aria-hidden="true">→</span>' : '',
        );

        return $this->wrap('div', 'pofsf-offer-action', sprintf(
            '<form class="pofsf-offer-action__form" method="get" action="%s" data-pofsf-checkout>%s<input type="hidden" name="pofsf_cart" value="" disabled />%s</form>',
            esc_url($action),
            $fields,
            $button,
        ));
    }

    /**
     * Classes and inline style for the block's color settings, as core's
     * color support makes them, for the button (the block skips serializing
     * them on its wrapper).
     *
     * @return array{0: string, 1: string}
     */
    private static function actionButtonColors(array $attributes): array {
        $preset = static fn (string $key, string $type): ?string => '' !== (string) ($attributes[$key] ?? '') ? 'var:preset|' . $type . '|' . $attributes[$key] : null;
        $custom = (array) ($attributes['style']['color'] ?? []);
        $color = array_filter([
            'text' => $preset('textColor', 'color') ?? ($custom['text'] ?? null),
            'background' => $preset('backgroundColor', 'color') ?? ($custom['background'] ?? null),
            'gradient' => $preset('gradient', 'gradient') ?? ($custom['gradient'] ?? null),
        ], static fn (mixed $value): bool => is_string($value) && '' !== $value);

        if ([] === $color || !function_exists('wp_style_engine_get_styles')) {
            return ['', ''];
        }

        $styles = wp_style_engine_get_styles(['color' => $color], ['convert_vars_to_classnames' => true]);
        $classes = array_filter([
            (string) ($styles['classnames'] ?? ''),
            isset($color['text']) ? 'has-text-color' : '',
            isset($color['background']) || isset($color['gradient']) ? 'has-background' : '',
        ]);

        return [implode(' ', $classes), (string) ($styles['css'] ?? '')];
    }

    private function templateDesign(WP_Block $block): OfferDesign {
        $postId = (int) ($block->context['postId'] ?? 0) ?: (int) get_the_ID();
        $template = $postId > 0 ? $this->templates->find($postId) : null;

        return null !== $template ? $template['design'] : OfferDesign::brandDefault();
    }

    private function isTemplateEditor(): bool {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;

        return null !== $screen && TemplateRepository::POST_TYPE === $screen->post_type;
    }

    private function currentTemplate(): ?array {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reads which post the block editor (post.php) has open; nothing is changed.
        $postId = isset($_GET['post']) ? absint($_GET['post']) : 0;

        return $postId > 0 ? $this->templates->find($postId) : null;
    }

    private function isFrame(): bool {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- A display flag for the editor canvas; nothing is changed.
        return isset($_GET['pofsf_frame']) && $this->isTemplateEditor();
    }

    /**
     * @return array{dependencies: list<string>, version: string}
     */
    private function asset(string $entry): array {
        $file = POFSF_PLUGIN_DIR . 'assets/build/' . $entry . '.asset.php';
        $asset = is_readable($file) ? include $file : [];

        return [
            'dependencies' => (array) ($asset['dependencies'] ?? []),
            'version' => (string) ($asset['version'] ?? POFSF_VERSION),
        ];
    }
}
