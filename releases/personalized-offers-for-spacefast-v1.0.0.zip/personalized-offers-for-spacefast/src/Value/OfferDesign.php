<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Value;

/**
 * Visual and copy design for an offer page: colors, fonts, layout, tone and
 * personal-note guidance. Corner radius, banner color and header branding
 * are no longer part of it: the radius is the --pofsf-radius CSS variable
 * (offer.css, overridable in the extra CSS), the banner and the branding
 * are set on their blocks (ContentMigration moved older settings there). Every field is sanitized on the way in, because
 * designs come from the AI assistant and end up inside published HTML/CSS.
 */
final readonly class OfferDesign {
    public const COLOR_KEYS = ['primary', 'secondary', 'background', 'surface', 'text', 'text_muted', 'border', 'accent'];
    /**
     * Starter layouts, block markup in templates/offer/{base}.html:
     * classic ("Feature story"): centered hero, pull quote, alternating product stories;
     * editorial ("Magazine"): masthead, split headline and intro, pull quote, the picks as covers;
     * letter: a personal letter with the picks as short numbered notes;
     * spotlight ("Campaign"): bold banner, perks strip, captioned lookbook, sticky call-to-action bar.
     */
    public const BASES = ['classic', 'editorial', 'letter', 'spotlight'];

    /** Product arrangement within the classic and editorial layouts. */
    public const LAYOUTS = ['grid', 'list'];

    private const DEFAULT_COLORS = [
        'primary' => '#1d4ed8',
        'secondary' => '#0f172a',
        'background' => '#ffffff',
        'surface' => '#f8fafc',
        'text' => '#0f172a',
        'text_muted' => '#475569',
        'border' => '#e2e8f0',
        'accent' => '#f59e0b',
    ];

    private const DEFAULT_FONT = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';

    /**
     * @param array<string, string> $colors Only the colors this design sets.
     */
    public function __construct(
        public string $base = 'classic',
        public bool $useBrand = true,
        public array $colors = [],
        public string $headingFont = '',
        public string $bodyFont = '',
        public string $fontUrl = '',
        public string $layout = 'grid',
        public string $tone = '',
        public string $noteGuidance = '',
        public string $customCss = '',
    ) {}

    /**
     * @return array<string, string>
     */
    public static function defaultColors(): array {
        return self::DEFAULT_COLORS;
    }

    public static function defaultFont(): string {
        return self::DEFAULT_FONT;
    }

    /**
     * The plain brand look used by offers without a design.
     */
    public static function brandDefault(): self {
        return new self();
    }

    /**
     * The design stored on an offer row; offers made before templates use the brand look.
     */
    public static function fromOffer(array $offer): self {
        $design = $offer['offer_data']['design'] ?? null;

        return is_array($design) ? self::fromArray($design) : self::brandDefault();
    }

    public static function fromArray(array $data): self {
        $colors = [];

        foreach (self::COLOR_KEYS as $key) {
            $color = self::color($data['colors'][$key] ?? '');

            if ('' !== $color) {
                $colors[$key] = $color;
            }
        }

        $fonts = is_array($data['fonts'] ?? null) ? $data['fonts'] : [];

        return new self(
            base: in_array($data['base'] ?? '', self::BASES, true) ? $data['base'] : 'classic',
            useBrand: (bool) ($data['use_brand'] ?? true),
            colors: $colors,
            headingFont: self::font((string) ($fonts['heading'] ?? '')),
            bodyFont: self::font((string) ($fonts['body'] ?? '')),
            fontUrl: self::fontUrl((string) ($data['font_url'] ?? '')),
            layout: in_array($data['layout'] ?? '', self::LAYOUTS, true) ? $data['layout'] : 'grid',
            tone: self::text((string) ($data['tone'] ?? ''), 300),
            noteGuidance: self::text((string) ($data['note_guidance'] ?? ''), 500),
            customCss: self::css((string) ($data['custom_css'] ?? '')),
        );
    }

    public function toArray(): array {
        return [
            'base' => $this->base,
            'use_brand' => $this->useBrand,
            'colors' => $this->colors,
            'fonts' => ['heading' => $this->headingFont, 'body' => $this->bodyFont],
            'font_url' => $this->fontUrl,
            'layout' => $this->layout,
            'tone' => $this->tone,
            'note_guidance' => $this->noteGuidance,
            'custom_css' => $this->customCss,
        ];
    }

    /**
     * Final color palette: defaults, then the brand snapshot (if this design
     * uses it), then the design's own colors.
     *
     * @return array<string, string>
     */
    public function palette(BrandSnapshot $brand): array {
        $palette = self::DEFAULT_COLORS;

        if ($this->useBrand) {
            foreach (self::COLOR_KEYS as $key) {
                $color = self::color($brand->colors[$key] ?? '');

                if ('' !== $color) {
                    $palette[$key] = $color;
                }
            }
        }

        return array_merge($palette, $this->colors);
    }

    /**
     * @return array{heading: string, body: string}
     */
    public function fontsFor(BrandSnapshot $brand): array {
        $brandHeading = $this->useBrand ? self::fontStack((string) ($brand->fonts['heading'] ?? '')) : '';
        $brandBody = $this->useBrand ? self::fontStack((string) ($brand->fonts['body'] ?? '')) : '';
        $body = self::resolve($this->bodyFont) ?: $brandBody ?: self::DEFAULT_FONT;

        return [
            'heading' => self::resolve($this->headingFont) ?: $brandHeading ?: $body,
            'body' => $body,
        ];
    }

    /**
     * Accepts #rgb / #rrggbb / #rrggbbaa hex colors only.
     */
    public static function color(mixed $value): string {
        $value = is_string($value) ? strtolower(trim($value)) : '';

        return 1 === preg_match('/^#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/', $value) ? $value : '';
    }

    /**
     * Stylesheets that load this design's fonts: one per Google font from
     * the catalog (so one font cannot break another), or the legacy
     * font_url of templates made before the catalog.
     *
     * @return list<string>
     */
    public function fontUrls(): array {
        $urls = array_filter([FontCatalog::url($this->headingFont), FontCatalog::url($this->bodyFont)]);

        if ('' !== $this->fontUrl && (!FontCatalog::has($this->headingFont) || !FontCatalog::has($this->bodyFont))) {
            $urls[] = $this->fontUrl;
        }

        return array_values(array_unique($urls));
    }

    /**
     * A catalog key (e.g. "fraunces"), or a sanitized CSS stack kept from older designs.
     */
    private static function font(string $value): string {
        $value = trim($value);

        return FontCatalog::has($value) ? $value : self::fontStack($value);
    }

    private static function resolve(string $font): string {
        return FontCatalog::has($font) ? FontCatalog::stack($font) : $font;
    }

    private static function fontStack(string $value): string {
        $value = trim((string) preg_replace('/[^A-Za-z0-9 ,\'"\-]/', '', $value));

        return mb_substr($value, 0, 200);
    }

    /**
     * Web fonts may only come from Google Fonts or Bunny Fonts stylesheets.
     */
    private static function fontUrl(string $value): string {
        $url = esc_url_raw(trim($value), ['https']);
        $host = (string) wp_parse_url($url, PHP_URL_HOST);

        return in_array($host, ['fonts.googleapis.com', 'fonts.bunny.net'], true) ? $url : '';
    }

    private static function text(string $value, int $max): string {
        return mb_substr(sanitize_textarea_field($value), 0, $max);
    }

    /**
     * Extra CSS is kept inside the page's <style> element: anything that
     * could close it or pull in remote code is removed.
     */
    private static function css(string $value): string {
        // Without "<" nothing can close the <style> element; ">" stays for child selectors.
        $value = str_replace('<', '', $value);
        $value = (string) preg_replace('/@import[^;]*;?|expression\s*\(|javascript\s*:|behavior\s*:/i', '', $value);

        return mb_substr(trim($value), 0, 6000);
    }
}
