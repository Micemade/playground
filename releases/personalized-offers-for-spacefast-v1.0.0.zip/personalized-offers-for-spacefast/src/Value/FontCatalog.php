<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Value;

/**
 * Fonts offered for offer templates: system stacks (no download) and a
 * curated set of Google Fonts. Each Google font lists the weights it
 * actually has, because the css2 API rejects a request for missing ones.
 */
final class FontCatalog {
    /**
     * @return array<string, array{label: string, stack: string, google: string, weights: string, category: string}>
     */
    public static function all(): array {
        $system = [
            'system-sans' => ['System sans-serif', 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif'],
            'system-serif' => ['System serif', 'Iowan Old Style, "Palatino Linotype", Palatino, Georgia, serif'],
            'system-rounded' => ['System rounded', 'ui-rounded, "SF Pro Rounded", "Hiragino Maru Gothic ProN", Quicksand, Comfortaa, sans-serif'],
            'system-mono' => ['System monospace', 'ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace'],
            'georgia' => ['Georgia', 'Georgia, "Times New Roman", serif'],
            'helvetica' => ['Helvetica / Arial', '"Helvetica Neue", Helvetica, Arial, sans-serif'],
        ];

        // [label, category, weights]
        $google = [
            'Inter' => ['sans-serif', '400;600;700'],
            'Roboto' => ['sans-serif', '400;500;700'],
            'Open Sans' => ['sans-serif', '400;600;700'],
            'Lato' => ['sans-serif', '400;700'],
            'Montserrat' => ['sans-serif', '400;600;800'],
            'Poppins' => ['sans-serif', '400;600;700'],
            'Nunito' => ['sans-serif', '400;600;800'],
            'Work Sans' => ['sans-serif', '400;600;700'],
            'DM Sans' => ['sans-serif', '400;600;700'],
            'Manrope' => ['sans-serif', '400;600;800'],
            'Rubik' => ['sans-serif', '400;600;800'],
            'Karla' => ['sans-serif', '400;600;700'],
            'Source Sans 3' => ['sans-serif', '400;600;700'],
            'IBM Plex Sans' => ['sans-serif', '400;600;700'],
            'Space Grotesk' => ['sans-serif', '400;600;700'],
            'Archivo' => ['sans-serif', '400;600;800'],
            'Raleway' => ['sans-serif', '400;600;800'],
            'Archivo Black' => ['sans-serif', '400'],
            'Bebas Neue' => ['display', '400'],
            'Oswald' => ['display', '400;600;700'],
            'Anton' => ['display', '400'],
            'Fraunces' => ['serif', '400;600;700'],
            'Playfair Display' => ['serif', '400;600;800'],
            'Lora' => ['serif', '400;600;700'],
            'Merriweather' => ['serif', '400;700'],
            'Libre Baskerville' => ['serif', '400;700'],
            'EB Garamond' => ['serif', '400;600;700'],
            'Cormorant Garamond' => ['serif', '400;600;700'],
            'DM Serif Display' => ['serif', '400'],
            'Crimson Pro' => ['serif', '400;600;700'],
            'Caveat' => ['handwriting', '400;700'],
            'Dancing Script' => ['handwriting', '400;700'],
            'Pacifico' => ['handwriting', '400'],
            'Space Mono' => ['monospace', '400;700'],
        ];

        $fallback = [
            'sans-serif' => 'system-ui, sans-serif',
            'display' => 'Impact, "Arial Narrow", sans-serif',
            'serif' => 'Georgia, serif',
            'handwriting' => '"Segoe Script", "Bradley Hand", cursive',
            'monospace' => 'ui-monospace, monospace',
        ];

        $fonts = [];

        foreach ($system as $key => [$label, $stack]) {
            $fonts[$key] = ['label' => $label, 'stack' => $stack, 'google' => '', 'weights' => '', 'category' => 'system'];
        }

        foreach ($google as $family => [$category, $weights]) {
            $fonts[sanitize_title($family)] = [
                'label' => $family,
                'stack' => '"' . $family . '", ' . $fallback[$category],
                'google' => $family,
                'weights' => $weights,
                'category' => $category,
            ];
        }

        return $fonts;
    }

    public static function has(string $key): bool {
        return isset(self::all()[$key]);
    }

    public static function stack(string $key): string {
        return self::all()[$key]['stack'] ?? '';
    }

    /**
     * Google Fonts stylesheet for one font, or '' for system fonts.
     */
    public static function url(string $key): string {
        $font = self::all()[$key] ?? null;

        if (null === $font || '' === $font['google']) {
            return '';
        }

        return 'https://fonts.googleapis.com/css2?family=' . str_replace(' ', '+', $font['google']) . ':wght@' . $font['weights'] . '&display=swap';
    }

    /**
     * Font list for editor UIs, grouped by category.
     *
     * @return list<array{value: string, label: string, category: string, stack: string, url: string}>
     */
    public static function options(): array {
        $options = [];

        foreach (self::all() as $key => $font) {
            $options[] = ['value' => $key, 'label' => $font['label'], 'category' => $font['category'], 'stack' => $font['stack'], 'url' => self::url($key)];
        }

        return $options;
    }
}
