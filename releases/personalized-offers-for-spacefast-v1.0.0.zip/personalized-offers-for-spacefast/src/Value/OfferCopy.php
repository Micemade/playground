<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Value;

/**
 * The shape of an offer's copy: a fixed headline plus the text fields the
 * manager adds, at most one of each type (FIELD_TYPES), which decides where
 * the template shows it (the "Offer text" block shows the field of one type).
 * Also the character limits and how many products an offer picks.
 *
 * Offer JSON: {headline: string, button_text?: string (the Offer action button's text), fields: list<{type: string, text: string}>, product_picks: [...]}.
 * Offers saved before fields existed had fixed keys (LEGACY_FIELDS); fields() reads both.
 */
final class OfferCopy {
    /** An edit, not a catalog: few enough picks that each gets its own story. */
    public const MAX_PICKS = 6;

    /** Field types, in the order the form offers them. */
    public const FIELD_TYPES = ['overheadline', 'subheadline', 'greeting', 'body', 'additional'];

    public const LIMITS = [
        'headline' => 80,
        'button_text' => 40,
        'overheadline' => 60,
        'subheadline' => 160,
        'greeting' => 120,
        'body' => 600,
        'additional' => 600,
        'title' => 70,
        'story' => 360,
        'reason' => 200,
    ];

    /** Fixed copy keys of older offers and the field type each became, in page order. */
    public const LEGACY_FIELDS = [
        'theme' => 'overheadline',
        'greeting' => 'greeting',
        'body_copy' => 'body',
        'personal_note' => 'additional',
        'closing' => 'additional',
    ];

    /**
     * Field type labels for the form and the block settings.
     *
     * @return array<string, string>
     */
    public static function typeLabels(): array {
        return [
            'overheadline' => __('Overheadline', 'personalized-offers-for-spacefast'),
            'subheadline' => __('Subheadline', 'personalized-offers-for-spacefast'),
            'greeting' => __('Greeting', 'personalized-offers-for-spacefast'),
            'body' => __('Body text', 'personalized-offers-for-spacefast'),
            'additional' => __('Additional text', 'personalized-offers-for-spacefast'),
        ];
    }

    /**
     * An offer's text fields, from either JSON shape.
     *
     * @return list<array{type: string, text: string}>
     */
    public static function fields(array $json): array {
        if (is_array($json['fields'] ?? null)) {
            return self::sanitizeFields($json['fields'], true);
        }

        $fields = [];

        foreach (self::LEGACY_FIELDS as $key => $type) {
            $fields[] = ['type' => $type, 'text' => (string) ($json[$key] ?? '')];
        }

        return self::sanitizeFields($fields, true);
    }

    /**
     * Offer JSON in the current shape: legacy keys become fields.
     */
    public static function normalize(array $json): array {
        if ([] === $json) {
            return $json;
        }

        $fields = self::fields($json);
        $json = array_diff_key($json, self::LEGACY_FIELDS);
        $json['headline'] = (string) ($json['headline'] ?? '');
        $json['fields'] = $fields;

        return $json;
    }

    /**
     * Fields as posted (form, AI, editor copy): known types only, one field
     * per type, texts sanitized and cut to their limits. A repeated type
     * (older offers had a personal note and a closing line, both Additional
     * text) becomes one field, its texts joined as paragraphs.
     *
     * @param bool $dropEmpty Leave out fields without text (stored offers); the form keeps them while editing.
     * @return list<array{type: string, text: string}>
     */
    public static function sanitizeFields(mixed $fields, bool $dropEmpty = false): array {
        $clean = [];

        foreach (is_array($fields) ? $fields : [] as $field) {
            $type = is_array($field) ? (string) ($field['type'] ?? '') : '';

            if (!in_array($type, self::FIELD_TYPES, true)) {
                continue;
            }

            $text = trim(sanitize_textarea_field((string) ($field['text'] ?? '')));

            if ($dropEmpty && '' === $text) {
                continue;
            }

            if (isset($clean[$type])) {
                $text = trim($clean[$type]['text'] . "\n\n" . $text);
            }

            $clean[$type] = ['type' => $type, 'text' => mb_substr($text, 0, self::LIMITS[$type])];
        }

        return array_values($clean);
    }

    /**
     * The texts of each type, in field order.
     *
     * @param list<array{type: string, text: string}> $fields
     * @return array<string, list<string>>
     */
    public static function textsByType(array $fields): array {
        $texts = array_fill_keys(self::FIELD_TYPES, []);

        foreach ($fields as $field) {
            if ('' !== $field['text']) {
                $texts[$field['type']][] = $field['text'];
            }
        }

        return $texts;
    }

    /**
     * $fields, plus $fallback's fields of the types $fields has no text for
     * (the template editor shows an offer's texts and samples for the rest).
     *
     * @param list<array{type: string, text: string}> $fields
     * @param list<array{type: string, text: string}> $fallback
     * @return list<array{type: string, text: string}>
     */
    public static function withFallback(array $fields, array $fallback): array {
        $present = array_keys(array_filter(self::textsByType($fields)));

        return array_values(array_merge(
            array_filter($fields, static fn (array $field): bool => '' !== $field['text']),
            array_filter($fallback, static fn (array $field): bool => !in_array($field['type'], $present, true)),
        ));
    }
}
