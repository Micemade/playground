<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Value;

final readonly class BrandSnapshot {
    public function __construct(
        public array $logo = [],
        public array $identity = [],
        public array $colors = [],
        public array $fonts = [],
        public array $emailBranding = [],
        public array $wooBranding = [],
        public string $capturedAt = '',
        public int $capturedBy = 0,
    ) {}

    public static function fromArray(array $data): self {
        return new self(
            logo: $data['logo'] ?? [],
            identity: $data['identity'] ?? [],
            colors: $data['colors'] ?? [],
            fonts: $data['fonts'] ?? [],
            emailBranding: $data['email_branding'] ?? [],
            wooBranding: $data['woocommerce_branding'] ?? [],
            capturedAt: $data['captured_at'] ?? '',
            capturedBy: (int) ($data['captured_by'] ?? 0),
        );
    }

    public function toArray(): array {
        return [
            'logo' => $this->logo,
            'identity' => $this->identity,
            'colors' => $this->colors,
            'fonts' => $this->fonts,
            'email_branding' => $this->emailBranding,
            'woocommerce_branding' => $this->wooBranding,
            'captured_at' => $this->capturedAt,
            'captured_by' => $this->capturedBy,
        ];
    }

    public function storeName(): string {
        $name = $this->identity['name'] ?? '';
        return is_string($name) && '' !== $name ? $name : (string) get_option('blogname');
    }
}
