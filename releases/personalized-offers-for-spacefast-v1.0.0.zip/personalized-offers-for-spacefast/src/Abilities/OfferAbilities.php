<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Abilities;

use Micemade\PersonalizedOffers\Enum\OfferStatus;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Service\OfferPipeline;
use WP_Error;
use WP_User;
use Micemade\PersonalizedOffers\Service\CustomerFinder;

/**
 * Registers the plugin's Abilities API entries. The admin chat hands these
 * to the AI model as tools; they are also exposed over REST for MCP clients.
 */
final class OfferAbilities {
    public const CATEGORY = 'personalized-offers-for-spacefast';
    public const FIND_CUSTOMERS = 'personalized-offers-for-spacefast/find-customers';
    public const CREATE_OFFERS = 'personalized-offers-for-spacefast/create-offers';
    public const LIST_OFFERS = 'personalized-offers-for-spacefast/list-offers';

    private const MAX_OFFER_BATCH = 20;

    public function __construct(
        private readonly OfferPipeline $pipeline,
        private readonly OfferRepository $offers,
        private readonly CustomerFinder $customers = new CustomerFinder(),
    ) {}

    public function register(): void {
        add_action('wp_abilities_api_categories_init', [$this, 'registerCategory']);
        add_action('wp_abilities_api_init', [$this, 'registerAbilities']);
    }

    /**
     * @return list<string>
     */
    public static function names(): array {
        return [self::FIND_CUSTOMERS, self::CREATE_OFFERS, self::LIST_OFFERS];
    }

    public function registerCategory(): void {
        wp_register_ability_category(self::CATEGORY, [
            'label' => __('Personalized Offers', 'personalized-offers-for-spacefast'),
            'description' => __('Find WooCommerce customers and create personalized Spacefast offers for them.', 'personalized-offers-for-spacefast'),
        ]);
    }

    public function registerAbilities(): void {
        $permission = static fn (): bool => current_user_can('manage_woocommerce');

        wp_register_ability(self::FIND_CUSTOMERS, [
            'label' => __('Find customers', 'personalized-offers-for-spacefast'),
            'description' => 'Search registered WooCommerce customers by name or email, and/or by what they bought (bought: product names, '
                . 'categories or tags, e.g. ["fitness", "dumbbell", "yoga"]; subcategories included, paid orders only). Returns user IDs needed to create offers. '
                . 'When a purchase search finds nothing, retry with related or broader words, or one of the store_categories it returns.',
            'category' => self::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'search' => [
                        'type' => 'string',
                        'description' => 'Name or email fragment. Leave empty to list the most recent customers.',
                    ],
                    'bought' => [
                        'type' => 'array',
                        'items' => ['type' => 'string', 'minLength' => 2],
                        'maxItems' => 10,
                        'description' => 'Only customers who bought a product matching any of these words (product name, category or tag).',
                    ],
                    'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 50, 'default' => 10],
                ],
                'default' => [],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'customers' => [
                        'type' => 'array',
                        'items' => [
                            'type' => 'object',
                            'properties' => [
                                'user_id' => ['type' => 'integer'],
                                'name' => ['type' => 'string'],
                                'email' => ['type' => 'string'],
                                'order_count' => ['type' => 'integer'],
                                'open_offers' => ['type' => 'integer'],
                                'bought' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Up to three matching products this customer bought.'],
                            ],
                        ],
                    ],
                    'matched_categories' => ['type' => 'array', 'items' => ['type' => 'string']],
                    'matched_products' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Up to 15 of the matching products.'],
                    'matched_product_count' => ['type' => 'integer'],
                    'store_categories' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'When nothing matched: the store\'s product categories to retry with.'],
                ],
            ],
            'execute_callback' => [$this, 'findCustomers'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::CREATE_OFFERS, [
            'label' => __('Create offers', 'personalized-offers-for-spacefast'),
            'description' => 'Create separate personalized offers, ONE PER CUSTOMER, for registered customers (user_ids) and/or guest customers (guest_emails, from list-customer-profiles kind guest), optionally with a design template and an Additional text (e.g. a personal note). '
                . 'For one offer shared by several customers, or chosen products, use create-shared-offer instead. '
                . 'Each offer picks products from the customer\'s order history and uses standard wording (no AI writing); the manager can edit the copy in the Offers tab. '
                . 'Offers are built in the background and are usually ready within a minute. '
                . 'Only call this after the store manager has confirmed which customers to include.',
            'category' => self::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'user_ids' => [
                        'type' => 'array',
                        'items' => ['type' => 'integer', 'minimum' => 1],
                        'maxItems' => self::MAX_OFFER_BATCH,
                        'uniqueItems' => true,
                        'description' => 'Customer user IDs from find-customers.',
                    ],
                    'guest_emails' => [
                        'type' => 'array',
                        'items' => ['type' => 'string', 'format' => 'email'],
                        'maxItems' => self::MAX_OFFER_BATCH,
                        'uniqueItems' => true,
                        'description' => 'Guest customers (ordered without an account) by email.',
                    ],
                    'template_id' => [
                        'type' => 'integer',
                        'minimum' => 0,
                        'description' => 'Design template from list-templates or save-template. Omit to use the default template.',
                    ],
                    'additional_text' => [
                        'type' => 'string',
                        'maxLength' => 600,
                        'description' => 'Exact text for an Additional text field on every offer in this batch, e.g. a personal note. Omit for none.',
                    ],
                ],
                // No top-level anyOf (AI providers reject it in tool schemas): createOffers() needs user_ids or guest_emails.
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'queued' => ['type' => 'array', 'items' => ['type' => ['integer', 'string']]],
                    'offer_ids' => ['type' => 'array', 'items' => ['type' => 'integer']],
                    'skipped' => [
                        'type' => 'array',
                        'items' => [
                            'type' => 'object',
                            'properties' => [
                                'user_id' => ['type' => 'integer'],
                                'email' => ['type' => 'string'],
                                'reason' => ['type' => 'string'],
                            ],
                        ],
                    ],
                    'message' => ['type' => 'string'],
                ],
            ],
            'execute_callback' => [$this, 'createOffers'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => false],
            ],
        ]);

        wp_register_ability(self::LIST_OFFERS, [
            'label' => __('List offers', 'personalized-offers-for-spacefast'),
            'description' => 'List existing Spacefast offers, newest first, optionally filtered by status or customer.',
            'category' => self::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'status' => [
                        'type' => 'string',
                        'enum' => array_map(static fn (OfferStatus $s): string => $s->value, OfferStatus::cases()),
                    ],
                    'user_id' => ['type' => 'integer', 'minimum' => 1],
                    'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 50, 'default' => 10],
                ],
                'default' => [],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'total' => ['type' => 'integer'],
                    'offers' => [
                        'type' => 'array',
                        'items' => [
                            'type' => 'object',
                            'properties' => [
                                'offer_id' => ['type' => 'integer'],
                                'type' => ['type' => 'string', 'enum' => ['single', 'group', 'public'], 'description' => 'single = one customer; group = chosen customers, each with a personal link (user_id 0); public = one link anyone can use (user_id 0).'],
                                'user_id' => ['type' => 'integer'],
                                'customer' => ['type' => 'string'],
                                'status' => ['type' => 'string'],
                                'headline' => ['type' => 'string'],
                                'template' => ['type' => 'string'],
                                'error' => ['type' => 'string'],
                                'expires_at' => ['type' => 'string'],
                                'created_at' => ['type' => 'string'],
                            ],
                        ],
                    ],
                ],
            ],
            'execute_callback' => [$this, 'listOffers'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);
    }

    public function findCustomers(array $input = []): array {
        $search = (string) ($input['search'] ?? '');
        $limit = (int) ($input['limit'] ?? 10);
        $bought = array_slice(array_map('strval', (array) ($input['bought'] ?? [])), 0, 10);
        $result = [];
        $purchases = [];

        if ([] !== $bought) {
            $match = $this->customers->findByPurchase($bought, $search, $limit);
            $users = $match['customers'];
            $purchases = $match['purchases'];
            $result = [
                'matched_categories' => $match['categories'],
                'matched_products' => $match['products'],
                'matched_product_count' => $match['product_count'],
            ];

            if ([] === $users) {
                $result['store_categories'] = $this->storeCategories();
            }
        } else {
            $users = $this->customers->find($search, $limit);
        }

        return [
            'customers' => array_map(fn (WP_User $user): array => [
                'user_id' => $user->ID,
                'name' => $user->display_name,
                'email' => $user->user_email,
                'order_count' => function_exists('wc_get_customer_order_count') ? (int) wc_get_customer_order_count($user->ID) : 0,
                'open_offers' => $this->offers->count(['user_id' => $user->ID, 'status' => OfferStatus::Ready->value]),
            ] + ([] !== $bought ? ['bought' => $purchases[$user->ID] ?? []] : []), $users),
        ] + $result;
    }

    /**
     * Names of the store's product categories that have products.
     *
     * @return list<string>
     */
    private function storeCategories(): array {
        $terms = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => true, 'fields' => 'names', 'number' => 100]);

        return is_array($terms) ? array_values(array_unique(array_map(static fn ($name): string => html_entity_decode((string) $name, ENT_QUOTES), $terms))) : [];
    }

    public function createOffers(array $input): array|WP_Error {
        $queue = [];
        $skipped = [];

        foreach (array_unique(array_map('intval', (array) ($input['user_ids'] ?? []))) as $userId) {
            $user = get_userdata($userId);

            if (!$user instanceof WP_User) {
                $skipped[] = ['user_id' => $userId, 'reason' => 'User not found.'];
            } elseif ('' === $user->user_email) {
                $skipped[] = ['user_id' => $userId, 'reason' => 'User has no email address.'];
            } else {
                $queue[] = $userId;
            }
        }

        $guests = [];

        foreach (array_unique(array_map('strval', (array) ($input['guest_emails'] ?? []))) as $email) {
            $clean = strtolower(sanitize_email($email));

            if ('' === $clean || !is_email($clean)) {
                $skipped[] = ['email' => $email, 'reason' => 'Not a valid email address.'];
            } elseif ($user = get_user_by('email', $clean)) {
                // An account's email: the offer is for the account.
                $queue[] = (int) $user->ID;
            } else {
                $guests[] = $clean;
            }
        }

        $queue = array_values(array_unique($queue));

        if ([] === $queue && [] === $guests) {
            return [
                'queued' => [],
                'skipped' => $skipped,
                'message' => 'No offers were queued.',
            ];
        }

        $result = $this->pipeline->queue($queue, get_current_user_id(), [
            'template_id' => (int) ($input['template_id'] ?? 0),
            'additional_text' => (string) ($input['additional_text'] ?? ''),
        ], $guests);

        if ($result instanceof WP_Error) {
            return $result;
        }

        return [
            'queued' => [...$queue, ...$guests],
            'offer_ids' => $result,
            'skipped' => $skipped,
            'message' => sprintf('Queued %d offer(s) as offer IDs %s. They will be ready in a few minutes; check with list-offers.', count($result), implode(', ', $result)),
        ];
    }

    public function listOffers(array $input = []): array {
        $filters = [
            'status' => (string) ($input['status'] ?? ''),
            'user_id' => (int) ($input['user_id'] ?? 0),
        ];

        $rows = $this->offers->list($filters + ['limit' => max(1, min(50, (int) ($input['limit'] ?? 10)))]);

        return [
            'total' => $this->offers->count($filters),
            'offers' => array_map(static function (array $row): array {
                $userId = (int) ($row['user_id'] ?? 0);
                $user = $userId > 0 ? get_userdata($userId) : false;
                $headline = $row['offer_data']['offer_json']['headline'] ?? '';

                return [
                    'offer_id' => (int) $row['id'],
                    'type' => (string) ($row['type'] ?? 'single'),
                    'user_id' => $userId,
                    'customer' => $user instanceof WP_User ? $user->display_name : (string) ($row['guest_email'] ?? ''),
                    'status' => (string) $row['status'],
                    'headline' => is_string($headline) ? $headline : '',
                    'template' => (string) ($row['offer_data']['template_name'] ?? ''),
                    'error' => (string) ($row['offer_data']['error'] ?? ''),
                    'expires_at' => (string) ($row['expires_at'] ?? ''),
                    'created_at' => (string) ($row['created_at'] ?? ''),
                ];
            }, $rows),
        ];
    }
}
