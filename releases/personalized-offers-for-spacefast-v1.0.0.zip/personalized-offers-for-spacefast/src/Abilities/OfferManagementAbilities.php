<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Abilities;

use Micemade\PersonalizedOffers\Enum\OfferType;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Service\OfferEditor;
use Micemade\PersonalizedOffers\Service\OfferEmail;
use Micemade\PersonalizedOffers\Service\OfferLimits;
use Micemade\PersonalizedOffers\Service\OfferPipeline;
use Micemade\PersonalizedOffers\Service\OfferShare;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;
use Micemade\PersonalizedOffers\Service\Spacefast\SpacefastClient;
use Micemade\PersonalizedOffers\Value\OfferCopy;
use WP_Error;

/**
 * Abilities for offers that already exist: read one, change it (copy,
 * products, coupon, expiry, usage limit, template), delete it, email it
 * and share it on social networks. They call the same code as the Offers
 * tab's Edit offer, Delete, Send email(s) and Social share actions, so the
 * same checks apply.
 */
final class OfferManagementAbilities {
    public const GET_OFFER = 'personalized-offers-for-spacefast/get-offer';
    public const UPDATE_OFFER = 'personalized-offers-for-spacefast/update-offer';
    public const DELETE_OFFER = 'personalized-offers-for-spacefast/delete-offer';
    public const SEND_OFFER_EMAIL = 'personalized-offers-for-spacefast/send-offer-email';
    public const SHARE_OFFER = 'personalized-offers-for-spacefast/share-offer';

    /**
     * Social networks' share addresses, as the Social share modal builds them
     * (assets/src/components/OfferSharing.js). `limit`: characters a post may
     * have; `textless`: the network takes only the link.
     */
    private const NETWORKS = [
        'linkedin' => ['label' => 'LinkedIn', 'limit' => 3000],
        'x' => ['label' => 'X', 'limit' => 280],
        'bluesky' => ['label' => 'Bluesky', 'limit' => 300],
        'facebook' => ['label' => 'Facebook', 'textless' => true],
        'mastodon' => ['label' => 'Mastodon', 'limit' => 500],
        'threads' => ['label' => 'Threads', 'limit' => 500],
        'whatsapp' => ['label' => 'WhatsApp'],
        'telegram' => ['label' => 'Telegram'],
        'reddit' => ['label' => 'Reddit', 'limit' => 300],
        'pinterest' => ['label' => 'Pinterest', 'limit' => 500],
    ];

    public function __construct(
        private readonly OfferRepository $offers,
        private readonly OfferEditor $editor,
        private readonly OfferPipeline $pipeline,
        private readonly OfferPublisher $publisher,
        private readonly SpacefastClient $spacefast,
        private readonly OfferEmail $email,
    ) {}

    public function register(): void {
        add_action('wp_abilities_api_init', [$this, 'registerAbilities']);
    }

    /**
     * @return list<string>
     */
    public static function names(): array {
        return [self::GET_OFFER, self::UPDATE_OFFER, self::DELETE_OFFER, self::SEND_OFFER_EMAIL, self::SHARE_OFFER];
    }

    public function registerAbilities(): void {
        $permission = static fn (): bool => current_user_can('manage_woocommerce');
        $offerId = ['type' => 'integer', 'minimum' => 1];
        $texts = [];

        foreach (OfferCopy::FIELD_TYPES as $type) {
            $texts[$type] = ['type' => 'string', 'maxLength' => OfferCopy::LIMITS[$type]];
        }

        wp_register_ability(self::GET_OFFER, [
            'label' => __('Get an offer', 'personalized-offers-for-spacefast'),
            'description' => 'Read one existing offer in full: its copy (headline, button text, texts by type), products, coupon (code, discount type, amount, '
                . 'free shipping), expiry, usage limit, template, customer or group, Spacefast state (published, outdated = changes not on the page yet, '
                . 'views: page views and visitors in the last 30 days, including the store\'s own visits, null if not loaded yet; '
                . 'for a group, link_opens per recipient: times they opened their personal link) '
                . 'and email. Call it before update-offer, send-offer-email or share-offer.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => ['offer_id' => $offerId],
                'required' => ['offer_id'],
            ],
            'output_schema' => ['type' => 'object'],
            'execute_callback' => [$this, 'getOffer'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::UPDATE_OFFER, [
            'label' => __('Update an offer', 'personalized-offers-for-spacefast'),
            'description' => 'Change an EXISTING offer in place, like saving the Edit offer form. Only the keys you pass change. Use it for every correction '
                . 'or change to an offer: never create a new offer instead. texts: the offer\'s text fields by type ("" removes that text). '
                . 'products: the full new product list, in order (titles and stories of products already in the offer are kept unless given). '
                . 'coupon: the offer\'s own WooCommerce coupon; pass only what changes (e.g. {"code": "TEES15"}); the code must not be used by another coupon. '
                . 'max_uses: 0 = no limit. A published offer becomes outdated until it is published again with publish-offer.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'offer_id' => $offerId,
                    'headline' => ['type' => 'string', 'minLength' => 1, 'maxLength' => OfferCopy::LIMITS['headline']],
                    'button_text' => ['type' => 'string', 'maxLength' => OfferCopy::LIMITS['button_text']],
                    'texts' => ['type' => 'object', 'properties' => $texts, 'additionalProperties' => false],
                    'products' => [
                        'type' => 'array',
                        'minItems' => 1,
                        'maxItems' => OfferCopy::MAX_PICKS,
                        'items' => [
                            'type' => 'object',
                            'properties' => [
                                'product_id' => ['type' => 'integer', 'minimum' => 1],
                                'title' => ['type' => 'string', 'maxLength' => OfferCopy::LIMITS['title']],
                                'story' => ['type' => 'string', 'maxLength' => OfferCopy::LIMITS['story']],
                            ],
                            'required' => ['product_id'],
                        ],
                    ],
                    'coupon' => [
                        'type' => 'object',
                        'properties' => [
                            'code' => ['type' => 'string', 'minLength' => 1],
                            'discount_type' => ['type' => 'string', 'enum' => ['percent', 'fixed_cart', 'fixed_product']],
                            'amount' => ['type' => 'number', 'minimum' => 0],
                            'free_shipping' => ['type' => 'boolean'],
                        ],
                        'additionalProperties' => false,
                    ],
                    'expires_on' => ['type' => 'string', 'format' => 'date', 'description' => 'Last day (YYYY-MM-DD).'],
                    'max_uses' => ['type' => 'integer', 'minimum' => 0, 'maximum' => OfferLimits::MAX],
                    'template_id' => ['type' => 'integer', 'minimum' => 0, 'description' => 'From list-templates; 0 = the default template.'],
                    'recipients' => [
                        'type' => 'array',
                        'items' => ['type' => 'integer', 'minimum' => 1],
                        'maxItems' => OfferEditor::MAX_RECIPIENTS,
                        'uniqueItems' => true,
                        'description' => 'Group offers only: the full new list of customers (user IDs from find-customers). Removed customers\' links stop working.',
                    ],
                ],
                'required' => ['offer_id'],
            ],
            'output_schema' => ['type' => 'object'],
            'execute_callback' => [$this, 'updateOffer'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::DELETE_OFFER, [
            'label' => __('Delete an offer', 'personalized-offers-for-spacefast'),
            'description' => 'Permanently delete an offer, its coupon and its customers\' links. delete_space (default true) also removes its Spacefast Space; '
                . 'if that fails the offer is kept. Cannot be undone: only call after the manager confirmed this exact offer (ID and headline).',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'offer_id' => $offerId,
                    'delete_space' => ['type' => 'boolean', 'default' => true],
                ],
                'required' => ['offer_id'],
            ],
            'output_schema' => ['type' => 'object'],
            'execute_callback' => [$this, 'deleteOffer'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => true, 'idempotent' => false],
            ],
        ]);

        wp_register_ability(self::SEND_OFFER_EMAIL, [
            'label' => __('Email an offer', 'personalized-offers-for-spacefast'),
            'description' => 'Email a single or group offer\'s page link, like the Send email(s) button: to the customer, or each group customer with their '
                . 'personal link. The offer must be published and not outdated (publish-offer first). Public offers are shared, not emailed. '
                . 'test=true sends one sample to the manager only. email: optional changes to the saved email (subject, title, body, button_text, footer; '
                . 'placeholders {first_name}, {customer_name}, {site_title}), saved before sending. recipient_ids: a group\'s customers to send to '
                . '(default all). Emails cannot be unsent: only send for real after the manager confirmed who gets it.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'offer_id' => $offerId,
                    'test' => ['type' => 'boolean', 'default' => false],
                    'recipient_ids' => ['type' => 'array', 'items' => ['type' => 'integer', 'minimum' => 1], 'uniqueItems' => true],
                    'email' => [
                        'type' => 'object',
                        'properties' => [
                            'subject' => ['type' => 'string', 'minLength' => 1, 'maxLength' => OfferEmail::LIMITS['subject']],
                            'title' => ['type' => 'string', 'maxLength' => OfferEmail::LIMITS['title']],
                            'body' => ['type' => 'string', 'maxLength' => OfferEmail::LIMITS['body']],
                            'button_text' => ['type' => 'string', 'maxLength' => OfferEmail::LIMITS['button_text']],
                            'footer' => ['type' => 'string', 'maxLength' => OfferEmail::LIMITS['footer']],
                        ],
                        'additionalProperties' => false,
                    ],
                ],
                'required' => ['offer_id'],
            ],
            'output_schema' => ['type' => 'object'],
            'execute_callback' => [$this, 'sendOfferEmail'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => false],
            ],
        ]);

        wp_register_ability(self::SHARE_OFFER, [
            'label' => __('Share an offer on social networks', 'personalized-offers-for-spacefast'),
            'description' => 'Prepare a public offer for social networks, like the Social share modal: returns its link, the link card networks show, and a '
                . 'share link per network that opens the network\'s post composer with the text filled in. You cannot post yourself: give the manager the '
                . 'share links to open. The offer must be public, published and not outdated. text: the post text (default: headline and description); '
                . 'keep it within the network\'s limit. networks: which ones (default all).',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'offer_id' => $offerId,
                    'text' => ['type' => 'string', 'maxLength' => 3000],
                    'networks' => ['type' => 'array', 'items' => ['type' => 'string', 'enum' => array_keys(self::NETWORKS)], 'uniqueItems' => true],
                    'mastodon_instance' => ['type' => 'string', 'description' => 'Mastodon server, e.g. mastodon.social (the default).'],
                ],
                'required' => ['offer_id'],
            ],
            'output_schema' => ['type' => 'object'],
            'execute_callback' => [$this, 'shareOffer'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);
    }

    public function getOffer(array $input): array|WP_Error {
        $offerId = (int) ($input['offer_id'] ?? 0);
        $offer = $this->offers->find($offerId);
        $form = $this->editor->editable($offerId);

        if (null === $offer || $form instanceof WP_Error) {
            return $form instanceof WP_Error ? $form : self::notFound($offerId);
        }

        $space = OfferPublisher::record($offer);
        $type = OfferEditor::typeOf($offer);
        $last = OfferEmail::lastSend($offer);
        // Views only if cached (Spacefast's analytics is slow); link opens are quick.
        $stats = $this->publisher->stats($offer, true);
        $texts = [];

        foreach ((array) $form['fields'] as $field) {
            $texts[(string) $field['type']] = (string) $field['text'];
        }

        return [
            'offer_id' => $offerId,
            'type' => $type->value,
            'status' => (string) $offer['status'],
            'customer' => $form['customer'],
            // Personal links carry the customer's token; they stay in the Offers tab.
            'recipients' => array_map(static fn (array $row): array => array_diff_key($row, ['link' => 0]) + (isset($stats['opens'][$row['id']]) ? ['link_opens' => $stats['opens'][$row['id']]] : []), (array) ($form['recipients'] ?? [])),
            'headline' => $form['headline'],
            'button_text' => $form['button_text'],
            'texts' => (object) $texts,
            'products' => array_map(static fn (array $pick): array => [
                'product_id' => $pick['product_id'],
                'name' => html_entity_decode((string) $pick['name'], ENT_QUOTES),
                'price' => $pick['price'],
                'in_stock' => $pick['in_stock'],
                'title' => $pick['title'],
                'story' => $pick['story'],
            ], (array) $form['picks']),
            'coupon' => $form['coupon_missing'] ? null : $form['coupon'],
            'expires_on' => $form['expires_on'],
            'max_uses' => $form['usage_limit'] ? $form['max_uses'] : 0,
            'used_count' => $form['used_count'],
            'template_id' => $form['template_id'],
            'template' => (string) ($offer['offer_data']['template_name'] ?? ''),
            // The offer keeps its copy of a deleted template (restore-template brings it back).
            'template_deleted' => $form['template_id'] > 0 && $this->pipeline->designFor((int) $form['template_id']) instanceof WP_Error,
            'spacefast' => [
                'published' => '' !== $space['space_id'],
                'status' => $space['status'],
                'access' => $space['access'],
                'outdated' => $space['outdated'],
                'live_url' => 'public' === $space['access'] ? $space['live_url'] : '',
                // Null when not loaded yet (the Offers tab loads them).
                'views' => null === ($stats['views'] ?? null) ? null : ['page_views_30d' => $stats['views'], 'visitors_30d' => $stats['visitors']],
            ],
            'email' => OfferType::Public === $type ? null : [
                'subject' => $this->email->design($offer)['subject'],
                'can_send' => null === OfferEmail::sendBlocked($offer),
                'last_sent' => $last,
            ],
        ];
    }

    public function updateOffer(array $input): array|WP_Error {
        $offerId = (int) ($input['offer_id'] ?? 0);
        $offer = $this->offers->find($offerId);
        $form = $this->editor->editable($offerId);

        if (null === $offer || $form instanceof WP_Error) {
            return $form instanceof WP_Error ? $form : self::notFound($offerId);
        }

        $changes = array_intersect_key($input, array_flip(['headline', 'button_text', 'expires_on', 'max_uses', 'template_id']));

        if (is_array($input['texts'] ?? null)) {
            // Changed texts replace their type's text; the others are kept, in their order.
            $fields = [];

            foreach ((array) $form['fields'] as $field) {
                $fields[(string) $field['type']] = (string) $field['text'];
            }

            foreach (OfferCopy::FIELD_TYPES as $type) {
                if (array_key_exists($type, $input['texts'])) {
                    $fields[$type] = (string) $input['texts'][$type];
                }
            }

            $changes['fields'] = array_map(static fn (string $type, string $text): array => ['type' => $type, 'text' => $text], array_keys($fields), $fields);
        }

        if (is_array($input['products'] ?? null)) {
            $current = array_column((array) $form['picks'], null, 'product_id');
            $changes['picks'] = array_map(static function (mixed $pick) use ($current): array {
                $productId = (int) (is_array($pick) ? ($pick['product_id'] ?? 0) : 0);
                $old = $current[$productId] ?? [];

                return [
                    'product_id' => $productId,
                    'variation_id' => (int) ($old['variation_id'] ?? 0),
                    'title' => (string) ($pick['title'] ?? $old['title'] ?? ''),
                    'story' => (string) ($pick['story'] ?? $old['story'] ?? ''),
                    'reason' => (string) ($old['reason'] ?? ''),
                ];
            }, array_values($input['products']));
        }

        if (is_array($input['coupon'] ?? null)) {
            $changes['coupon'] = array_intersect_key($input['coupon'], array_flip(['code', 'discount_type', 'amount', 'free_shipping'])) + (array) $form['coupon'];
        }

        if (array_key_exists('recipients', $input)) {
            if (OfferType::Group !== OfferEditor::typeOf($offer)) {
                return new WP_Error('offer_not_group', 'Only a group offer has a list of customers.');
            }

            $changes['recipients'] = array_map('intval', (array) $input['recipients']);
        }

        if ([] === $changes) {
            return new WP_Error('offer_no_changes', 'Nothing to change: pass at least one field to update.');
        }

        $result = $this->editor->update($offerId, $changes);

        if ($result instanceof WP_Error) {
            return $result;
        }

        $updated = $this->getOffer(['offer_id' => $offerId]);
        $outdated = is_array($updated) && $updated['spacefast']['outdated'];

        return [
            'offer_id' => $offerId,
            'changed' => array_keys(array_intersect_key($input, array_flip(['headline', 'button_text', 'texts', 'products', 'coupon', 'expires_on', 'max_uses', 'template_id', 'recipients']))),
            'offer' => $updated,
            'message' => sprintf('Offer #%d updated.', $offerId) . ($outdated ? ' Its Spacefast page is now outdated: publish it again with publish-offer (ask first) so the link shows the changes.' : ''),
        ];
    }

    public function deleteOffer(array $input): array|WP_Error {
        $offerId = (int) ($input['offer_id'] ?? 0);
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return self::notFound($offerId);
        }

        $hasSpace = '' !== OfferPublisher::record($offer)['space_id'];
        $deleteSpace = $hasSpace && ($input['delete_space'] ?? true);

        if ($deleteSpace) {
            if (!$this->spacefast->status()['connected']) {
                return new WP_Error('spacefast_not_connected', 'Spacefast is not connected, so the offer\'s Space cannot be deleted. Connect it, or delete with delete_space=false and remove the Space in the Spacefast dashboard.');
            }

            $deleted = $this->publisher->deleteSpace($offer);

            if ($deleted instanceof WP_Error) {
                return new WP_Error('space_delete_failed', 'The offer was not deleted because its Spacefast Space could not be removed: ' . $deleted->get_error_message());
            }
        }

        $result = $this->pipeline->delete($offerId);

        if ($result instanceof WP_Error) {
            return $result;
        }

        return [
            'offer_id' => $offerId,
            'space_deleted' => $deleteSpace,
            'message' => sprintf('Offer #%d deleted.', $offerId) . ($hasSpace && !$deleteSpace ? ' Its Spacefast Space still exists.' : ''),
        ];
    }

    public function sendOfferEmail(array $input): array|WP_Error {
        $offerId = (int) ($input['offer_id'] ?? 0);
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return self::notFound($offerId);
        }

        $blocked = OfferEmail::sendBlocked($offer);

        if (null !== $blocked) {
            return new WP_Error('offer_email_blocked', $blocked);
        }

        $design = $this->email->design($offer);

        if (is_array($input['email'] ?? null)) {
            $design = OfferEmail::sanitize(array_intersect_key($input['email'], OfferEmail::LIMITS) + $design);
            $this->email->saveDesign($offerId, $design);
            $offer = (array) $this->offers->find($offerId);
        }

        if ('' === $design['subject']) {
            return new WP_Error('offer_email_subject', 'The email has no subject: pass email.subject.');
        }

        $test = (bool) ($input['test'] ?? false);
        $people = $this->email->recipients($offer);
        $pageUrl = OfferEmail::pageUrl($offer);

        if ($test) {
            $user = wp_get_current_user();
            $sample = $people[0] ?? ['name' => $user->display_name, 'first_name' => $user->first_name, 'link' => $pageUrl];
            $to = [['email' => $user->user_email, 'link' => $sample['link'], 'name' => $sample['name'], 'first_name' => $sample['first_name']]];
        } else {
            $ids = OfferType::Group === OfferEditor::typeOf($offer) && isset($input['recipient_ids']) ? array_map('intval', (array) $input['recipient_ids']) : null;
            $to = array_values(array_filter($people, static fn (array $person): bool => '' !== $person['email'] && (null === $ids || in_array((int) $person['id'], $ids, true))));
        }

        if ([] === $to) {
            return new WP_Error('offer_email_no_recipients', 'Nobody to send the email to: check recipient_ids against get-offer\'s recipients.');
        }

        $result = $this->email->send($offer, $design, $to, $test);

        if (0 === $result['sent']) {
            return new WP_Error('offer_email_failed', 'The email could not be sent. Check the site\'s email setup.');
        }

        return [
            'offer_id' => $offerId,
            'test' => $test,
            'sent' => $result['sent'],
            'failed' => $result['failed'],
            'message' => $test
                ? sprintf('Test email sent to %s.', wp_get_current_user()->user_email)
                : sprintf('Sent to %d customer(s).', $result['sent']) . ([] !== $result['failed'] ? ' Failed: ' . implode(', ', $result['failed']) . '.' : ''),
        ];
    }

    public function shareOffer(array $input): array|WP_Error {
        $offerId = (int) ($input['offer_id'] ?? 0);
        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return self::notFound($offerId);
        }

        if (OfferType::Public !== OfferEditor::typeOf($offer)) {
            return new WP_Error('offer_not_public', 'Only public offers are shared on social networks: single and group offers have personal links. Email them with send-offer-email.');
        }

        $url = OfferEmail::pageUrl($offer);

        if ('' === $url) {
            return new WP_Error('offer_not_published', 'Publish the offer to Spacefast first (publish-offer): the post links to its page.');
        }

        if (OfferPublisher::record($offer)['outdated']) {
            return new WP_Error('offer_outdated', 'The offer has changes that are not on its Spacefast page yet. Publish it again (publish-offer) before sharing.');
        }

        $json = is_array($offer['offer_data']['offer_json'] ?? null) ? $offer['offer_data']['offer_json'] : [];
        $card = OfferShare::card($json);
        $text = trim((string) ($input['text'] ?? '')) ?: ('' !== $card['description'] ? $card['title'] . "\n\n" . $card['description'] : $card['title']);
        $instance = (string) preg_replace('/[^a-z0-9.-]/', '', strtolower((string) ($input['mastodon_instance'] ?? ''))) ?: 'mastodon.social';
        $chosen = array_intersect(array_keys(self::NETWORKS), (array) ($input['networks'] ?? array_keys(self::NETWORKS)));
        $links = [];

        foreach ($chosen as $network) {
            if ('pinterest' === $network && '' === $card['image']) {
                continue;
            }

            $links[] = [
                'network' => self::NETWORKS[$network]['label'],
                'share_url' => self::shareUrl($network, $text, $url, $card, $instance),
                'limit' => self::NETWORKS[$network]['limit'] ?? null,
                'text_included' => empty(self::NETWORKS[$network]['textless']),
            ];
        }

        return [
            'offer_id' => $offerId,
            'url' => $url,
            'card' => $card,
            'text' => $text,
            'share_links' => $links,
            'message' => 'Give the manager the share links: each opens the network\'s post composer, where they review and post it.',
        ];
    }

    private static function shareUrl(string $network, string $text, string $url, array $card, string $instance): string {
        $both = rawurlencode($text . "\n\n" . $url);

        return match ($network) {
            'linkedin' => 'https://www.linkedin.com/feed/?shareActive=true&text=' . $both,
            'x' => 'https://x.com/intent/post?text=' . rawurlencode($text) . '&url=' . rawurlencode($url),
            'bluesky' => 'https://bsky.app/intent/compose?text=' . $both,
            'facebook' => 'https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode($url),
            'mastodon' => 'https://' . $instance . '/share?text=' . $both,
            'threads' => 'https://www.threads.net/intent/post?text=' . rawurlencode($text) . '&url=' . rawurlencode($url),
            'whatsapp' => 'https://wa.me/?text=' . $both,
            'telegram' => 'https://t.me/share/url?url=' . rawurlencode($url) . '&text=' . rawurlencode($text),
            'reddit' => 'https://www.reddit.com/submit?url=' . rawurlencode($url) . '&title=' . rawurlencode((string) $card['title']),
            'pinterest' => 'https://www.pinterest.com/pin/create/button/?url=' . rawurlencode($url) . '&media=' . rawurlencode((string) $card['image']) . '&description=' . rawurlencode($text),
            default => '',
        };
    }

    private static function notFound(int $offerId): WP_Error {
        return new WP_Error('offer_not_found', sprintf('Offer #%d not found.', $offerId));
    }
}
