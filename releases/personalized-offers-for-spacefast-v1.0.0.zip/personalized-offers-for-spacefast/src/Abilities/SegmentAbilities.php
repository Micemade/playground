<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Abilities;

use Micemade\PersonalizedOffers\Admin\SegmentsController;
use Micemade\PersonalizedOffers\Service\CustomerProfiles;
use Micemade\PersonalizedOffers\Service\Segments;
use WP_Error;

/**
 * Abilities for customer segments: list them, save one from rules, and
 * read a segment's customers with what they share and the products to
 * offer them (for create-shared-offer).
 */
final class SegmentAbilities {
    public const LIST_SEGMENTS = 'personalized-offers-for-spacefast/list-segments';
    public const CREATE_SEGMENT = 'personalized-offers-for-spacefast/create-segment';
    public const SEGMENT_CUSTOMERS = 'personalized-offers-for-spacefast/segment-customers';

    public function __construct(
        private readonly Segments $segments,
    ) {}

    public function register(): void {
        add_action('wp_abilities_api_init', [$this, 'registerAbilities']);
    }

    /**
     * @return list<string>
     */
    public static function names(): array {
        return [self::LIST_SEGMENTS, self::CREATE_SEGMENT, self::SEGMENT_CUSTOMERS];
    }

    public function registerAbilities(): void {
        $permission = static fn (): bool => current_user_can('manage_woocommerce');
        $segmentId = ['type' => 'string', 'description' => 'A segment ID from list-segments: a built-in key (loyal, active, new, at_risk, lapsed) or a saved segment\'s number.'];

        wp_register_ability(self::LIST_SEGMENTS, [
            'label' => __('List customer segments', 'personalized-offers-for-spacefast'),
            'description' => 'Customer segments with their rules in words and member counts (all customers, and those with an account, who can get a group offer). '
                . 'Built-in: loyal (best customers), active, new, at_risk, lapsed; plus the store\'s own, from favourite categories, sizes, colours, '
                . 'price band, orders and spending. Members follow the stored profiles. Also suggests segments worth saving.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => ['type' => 'object', 'properties' => (object) [], 'default' => []],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'segments' => ['type' => 'array', 'items' => ['type' => 'object']],
                    'suggestions' => ['type' => 'array', 'items' => ['type' => 'object']],
                ],
            ],
            'execute_callback' => [$this, 'listSegments'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::CREATE_SEGMENT, [
            'label' => __('Create a customer segment', 'personalized-offers-for-spacefast'),
            'description' => 'Save a segment (or change one: segment_id) from rules over the stored customer profiles. Every rule given must match; '
                . 'within a rule any value does. categories: product category names or IDs among the customer\'s favourites (subcategories count). '
                . 'attributes: attribute => values, e.g. {"size": ["M", "L"]}. price_bands: budget, mid, premium. buying: buying patterns. '
                . 'When changing a segment, pass its name and all its rules: they replace the old ones. '
                . 'Only call after the manager agreed to the name and rules. Returns the segment with its member count.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'segment_id' => ['type' => 'integer', 'minimum' => 1, 'description' => 'Change this saved segment instead of creating one.'],
                    'name' => ['type' => 'string', 'minLength' => 1, 'maxLength' => 100],
                    'description' => ['type' => 'string', 'maxLength' => 500],
                    'buying' => ['type' => 'array', 'items' => ['type' => 'string', 'enum' => array_keys(CustomerProfiles::segments())]],
                    'categories' => ['type' => 'array', 'items' => ['type' => 'string'], 'maxItems' => 20, 'description' => 'Category names or IDs.'],
                    'attributes' => ['type' => 'object', 'additionalProperties' => ['type' => 'array', 'items' => ['type' => 'string']]],
                    'price_bands' => ['type' => 'array', 'items' => ['type' => 'string', 'enum' => Segments::BANDS]],
                    'min_orders' => ['type' => 'integer', 'minimum' => 1],
                    'min_spent' => ['type' => 'number', 'minimum' => 0],
                    'ordered_within_days' => ['type' => 'integer', 'minimum' => 1, 'description' => 'Ordered in the last N days.'],
                    'not_ordered_for_days' => ['type' => 'integer', 'minimum' => 1, 'description' => 'No order in the last N days.'],
                    'accounts_only' => ['type' => 'boolean', 'description' => 'Only customers with an account.'],
                ],
                'required' => ['name'],
            ],
            'output_schema' => ['type' => 'object'],
            'execute_callback' => [$this, 'createSegment'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => false],
            ],
        ]);

        wp_register_ability(self::SEGMENT_CUSTOMERS, [
            'label' => __('Get a segment\'s customers', 'personalized-offers-for-spacefast'),
            'description' => 'A segment\'s customers, most spent first, and what they share: favourite categories, sizes, colours and other attributes, '
                . 'price bands, typical price. user_ids: its customers with an account (at most 100), for create-shared-offer with audience "group" '
                . 'and this segment; guests cannot get a group offer. suggested_products: products from what they share, for that offer.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'segment' => $segmentId,
                    'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 50, 'default' => 20, 'description' => 'Customers listed by name.'],
                ],
                'required' => ['segment'],
            ],
            'output_schema' => ['type' => 'object'],
            'execute_callback' => [$this, 'segmentCustomers'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);
    }

    public function listSegments(array $input = []): array {
        return [
            'segments' => array_map(static fn (array $s): array => [
                'id' => $s['id'],
                'name' => $s['name'],
                'built_in' => !empty($s['built_in']),
                'description' => $s['description'],
                'rules' => Segments::describe($s['rules']),
                'members' => (int) $s['members'],
                'with_account' => (int) $s['accounts'],
            ], $this->segments->all()),
            'suggestions' => array_map(static fn (array $s): array => ['name' => $s['name'], 'rules' => $s['description'], 'members' => (int) $s['members']], $this->segments->suggestions()),
        ];
    }

    public function createSegment(array $input): array|WP_Error {
        $rules = $this->rulesFrom($input);

        if ($rules instanceof WP_Error) {
            return $rules;
        }

        $saved = $this->segments->save(['name' => (string) ($input['name'] ?? ''), 'description' => (string) ($input['description'] ?? ''), 'rules' => $rules], (int) ($input['segment_id'] ?? 0), get_current_user_id());

        if ($saved instanceof WP_Error) {
            return $saved;
        }

        $members = $this->segments->members($saved['rules'], 0);

        return [
            'segment_id' => $saved['id'],
            'name' => $saved['name'],
            'rules' => Segments::describe($saved['rules']),
            'members' => $members['total'],
            'with_account' => $members['accounts'],
            'message' => 'Saved. It is in the Segments tab; its members follow the customer profiles.',
        ];
    }

    public function segmentCustomers(array $input): array|WP_Error {
        $segment = $this->segments->find((string) ($input['segment'] ?? ''));

        if (null === $segment) {
            return new WP_Error('segment_not_found', 'Segment not found. Use an ID from list-segments.');
        }

        $members = $this->segments->members($segment['rules']);
        $limit = max(1, min(50, (int) ($input['limit'] ?? 20)));
        $repository = $this->segments->profiles();
        $customers = [];

        foreach (array_slice($members['keys'], 0, $limit) as $key) {
            $row = $repository->find($key);

            if (null !== $row) {
                $summary = \Micemade\PersonalizedOffers\Admin\CustomersController::summary($row);
                $customers[] = array_intersect_key($summary, array_flip(['id', 'guest', 'name', 'email', 'segment', 'orders', 'spent', 'lastOrder', 'categories', 'sizes', 'priceBand']));
            }
        }

        $products = [];

        foreach ($this->segments->suggestedProducts($segment['rules'], $members['shared']) as $productId) {
            $product = wc_get_product($productId);

            if ($product instanceof \WC_Product && count($products) < 12) {
                $products[] = ['product_id' => $productId, 'name' => html_entity_decode($product->get_name(), ENT_QUOTES), 'price' => html_entity_decode(wp_strip_all_tags(wc_price((float) $product->get_price())), ENT_QUOTES)];
            }
        }

        return [
            'segment' => ['id' => $segment['id'], 'name' => $segment['name'], 'rules' => Segments::describe($segment['rules'])],
            'members' => $members['total'],
            'with_account' => $members['accounts'],
            'customers' => $customers,
            'shared' => SegmentsController::shared($members['shared']),
            'user_ids' => array_column($members['recipients'], 'id'),
            'suggested_products' => $products,
        ];
    }

    /**
     * The global attribute taxonomy (pa_size) for a name, slug or label
     * ("Size", "size", "pa_size"); '' when there is none.
     */
    private function attributeTaxonomy(string $name): string {
        $slug = (string) preg_replace('/^pa_/', '', sanitize_title($name));

        if (taxonomy_exists('pa_' . $slug)) {
            return 'pa_' . $slug;
        }

        foreach (wc_get_attribute_taxonomies() as $attribute) {
            if ($attribute->attribute_name === $slug || 0 === strcasecmp((string) $attribute->attribute_label, trim($name))) {
                return wc_attribute_taxonomy_name($attribute->attribute_name);
            }
        }

        return '';
    }

    /**
     * Rules from the ability's input: category names or IDs, attribute
     * names (size or pa_size) and value names or slugs.
     */
    private function rulesFrom(array $input): array|WP_Error {
        $categories = [];

        foreach ((array) ($input['categories'] ?? []) as $category) {
            $term = is_int($category) || ctype_digit((string) $category)
                ? get_term((int) $category, 'product_cat')
                : (get_term_by('name', (string) $category, 'product_cat') ?: get_term_by('slug', sanitize_title((string) $category), 'product_cat'));

            if (!$term instanceof \WP_Term) {
                return new WP_Error('segment_category_unknown', sprintf('No product category "%s". Use find-products to see category names.', (string) $category));
            }

            $categories[] = $term->term_id;
        }

        $attributes = [];

        foreach ((array) ($input['attributes'] ?? []) as $name => $values) {
            $taxonomy = $this->attributeTaxonomy((string) $name);

            if ('' === $taxonomy) {
                $known = array_map(static fn (object $a): string => (string) $a->attribute_label, wc_get_attribute_taxonomies());

                return new WP_Error('segment_attribute_unknown', sprintf('No product attribute "%s" in the store. Its attributes: %s.', (string) $name, implode(', ', $known)));
            }

            foreach ((array) $values as $value) {
                $term = get_term_by('name', (string) $value, $taxonomy) ?: get_term_by('slug', sanitize_title((string) $value), $taxonomy);
                $attributes[$taxonomy][] = $term instanceof \WP_Term ? $term->slug : sanitize_title((string) $value);
            }
        }

        $rules = array_intersect_key($input, array_flip(['buying', 'price_bands', 'min_orders', 'min_spent', 'ordered_within_days', 'not_ordered_for_days', 'accounts_only']))
            + ['categories' => $categories, 'attributes' => $attributes];

        return $rules;
    }
}
