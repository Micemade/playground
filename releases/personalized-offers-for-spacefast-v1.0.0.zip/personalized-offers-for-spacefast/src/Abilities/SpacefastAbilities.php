<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Abilities;

use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;
use Micemade\PersonalizedOffers\Service\Spacefast\SpacefastClient;
use Micemade\PersonalizedOffers\Service\Spacefast\SpaceInventory;
use Micemade\PersonalizedOffers\Service\Spacefast\Webhooks;
use WP_Error;

/**
 * Abilities for the Spacefast account as a whole: the connection, the
 * team's Spaces (which offer each belongs to, and leftovers), and taking a
 * Space down while keeping its offer.
 */
final class SpacefastAbilities {
    public const STATUS = 'personalized-offers-for-spacefast/spacefast-status';
    public const LIST_SPACES = 'personalized-offers-for-spacefast/list-spaces';
    public const DELETE_SPACE = 'personalized-offers-for-spacefast/delete-space';

    public function __construct(
        private readonly SpacefastClient $client,
        private readonly OfferPublisher $publisher,
        private readonly OfferRepository $offers,
        private readonly SpaceInventory $inventory,
        private readonly Webhooks $webhooks,
    ) {}

    public function register(): void {
        add_action('wp_abilities_api_init', [$this, 'registerAbilities']);
    }

    /**
     * @return list<string>
     */
    public static function names(): array {
        return [self::STATUS, self::LIST_SPACES, self::DELETE_SPACE];
    }

    public function registerAbilities(): void {
        $permission = static fn (): bool => current_user_can('manage_woocommerce');

        wp_register_ability(self::STATUS, [
            'label' => __('Spacefast connection status', 'personalized-offers-for-spacefast'),
            'description' => 'Whether the store is connected to Spacefast, to which team, the hint of the API key (never the key), whether Spacefast '
                . 'answers now, and the plan: its limits and what is used (live Spaces, storage, publishes today, custom domains; a null limit is '
                . 'unlimited), with Spacefast\'s warnings. live_updates: whether Spacefast tells this site at once (a webhook) when a publish finishes '
                . 'or fails, a Space is deleted in Spacefast, a custom domain changes, or someone asks to open a private offer (the store\'s admin '
                . 'email is then told), or why it can\'t; without them the plugin checks Spacefast itself, so publishing works the same. '
                . 'Requests to open a private offer are approved or declined by the manager in the Spaces tab (Access requests), not here. '
                . 'Connecting or disconnecting is done by the manager in the Offers tab; plan, Spaces and live updates are in the Spaces tab.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => ['type' => 'object', 'properties' => (object) [], 'default' => []],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'connected' => ['type' => 'boolean'],
                    'team_name' => ['type' => 'string'],
                    'team_slug' => ['type' => 'string'],
                    'key_hint' => ['type' => 'string'],
                    'key_from_constant' => ['type' => 'boolean', 'description' => 'The key comes from the POFSF_SPACEFAST_API_KEY constant in wp-config.php.'],
                    'reachable' => ['type' => 'boolean'],
                    'problem' => ['type' => 'string', 'description' => 'Why Spacefast did not answer, if it did not.'],
                    'plan' => ['type' => 'object'],
                    'live_updates' => ['type' => 'object'],
                ],
            ],
            'execute_callback' => [$this, 'status'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::LIST_SPACES, [
            'label' => __('List Spacefast Spaces', 'personalized-offers-for-spacefast'),
            'description' => 'List the Spacefast team\'s Spaces, newest first, each with the offer it belongs to (offer_id, 0 if none). '
                . 'Spaces with leftover = true are titled like this store\'s offer Spaces but belong to no offer (an earlier publish, or a '
                . 'deleted offer whose Space stayed); delete-space with space_id removes them. Another site on the same team (a staging copy) '
                . 'may use the same store name, so check with the manager before deleting.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'leftovers_only' => ['type' => 'boolean', 'default' => false],
                ],
                'default' => [],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'spaces' => [
                        'type' => 'array',
                        'items' => [
                            'type' => 'object',
                            'properties' => [
                                'space_id' => ['type' => 'string'],
                                'title' => ['type' => 'string'],
                                'live_url' => ['type' => 'string'],
                                'created_at' => ['type' => 'string'],
                                'offer_id' => ['type' => 'integer'],
                                'leftover' => ['type' => 'boolean'],
                            ],
                        ],
                    ],
                    'count' => ['type' => 'integer'],
                ],
            ],
            'execute_callback' => [$this, 'listSpaces'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::DELETE_SPACE, [
            'label' => __('Delete a Spacefast Space', 'personalized-offers-for-spacefast'),
            'description' => 'Permanently delete a Spacefast Space. With offer_id: the offer\'s Space is deleted and the offer is kept, unpublished '
                . '(its links stop working; publish-offer makes a new Space with new links). With space_id: only a leftover Space that belongs '
                . 'to no offer (see list-spaces). To delete an offer and its Space together, use delete-offer. Confirm with the manager first.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'offer_id' => ['type' => 'integer', 'minimum' => 1],
                    'space_id' => ['type' => 'string', 'pattern' => '^[A-Za-z0-9_-]+$'],
                ],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'space_id' => ['type' => 'string'],
                    'offer_id' => ['type' => 'integer'],
                    'message' => ['type' => 'string'],
                ],
            ],
            'execute_callback' => [$this, 'deleteSpace'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => true, 'idempotent' => true],
            ],
        ]);
    }

    public function status(): array {
        $status = $this->client->status();
        $result = [
            'connected' => $status['connected'],
            'team_name' => $status['team_name'],
            'team_slug' => $status['team_slug'],
            'key_hint' => $status['key_hint'],
            'key_from_constant' => $status['from_constant'],
        ];

        if (!$status['connected']) {
            return $result;
        }

        $check = $this->client->check();
        $usage = $this->inventory->usage();
        $webhook = $this->webhooks->status();

        return $result + [
            'reachable' => $check['ok'],
            'problem' => $check['error'],
            'plan' => $usage instanceof WP_Error
                ? ['unavailable' => $usage->get_error_message()]
                : ['plan' => $usage['plan'], 'limits' => $usage['limits'], 'usage' => $usage['usage'], 'warnings' => $usage['warnings']],
            'live_updates' => [
                'on' => $webhook['enabled'],
                'events_received' => $webhook['received'],
                'last_event_at' => $webhook['last_at'],
                'unavailable_because' => $webhook['reason'],
            ],
        ];
    }

    public function listSpaces(array $input = []): array|WP_Error {
        $spaces = $this->inventory->spaces(true);

        if ($spaces instanceof WP_Error) {
            return $spaces;
        }

        $rows = [];

        foreach ($spaces as $space) {
            $row = [
                'space_id' => $space['id'],
                'title' => $space['title'],
                'live_url' => $space['live_url'],
                'created_at' => $space['created_at'],
                'offer_id' => $space['offer_id'],
                'leftover' => SpaceInventory::LEFTOVER === $space['kind'],
            ];

            if (empty($input['leftovers_only']) || $row['leftover']) {
                $rows[] = $row;
            }
        }

        $missing = $this->inventory->missing($spaces);

        return ['spaces' => $rows, 'count' => count($rows)] + ([] === $missing ? [] : [
            // Deleted in Spacefast; the Spaces tab can unpublish these offers here too.
            'offers_without_their_space' => array_column($missing, 'offer_id'),
        ]);
    }

    public function deleteSpace(array $input): array|WP_Error {
        $offerId = (int) ($input['offer_id'] ?? 0);
        $spaceId = (string) ($input['space_id'] ?? '');

        if ($offerId > 0) {
            $offer = $this->offers->find($offerId);

            if (null === $offer) {
                return new WP_Error('pofsf_offer_missing', 'Offer not found.');
            }

            $spaceId = OfferPublisher::record($offer)['space_id'];
            $result = $this->publisher->unpublish($offerId);

            return $result instanceof WP_Error ? $result : [
                'space_id' => $spaceId,
                'offer_id' => $offerId,
                'message' => sprintf('The Space of offer #%d was deleted; the offer is kept, unpublished. Its links no longer work.', $offerId),
            ];
        }

        if ('' === $spaceId) {
            return new WP_Error('pofsf_space_missing', 'Pass offer_id, or the space_id of a leftover Space from list-spaces.');
        }

        $result = $this->inventory->deleteLeftover($spaceId);

        return $result instanceof WP_Error ? $result : ['space_id' => $spaceId, 'offer_id' => 0, 'message' => sprintf('Space %s deleted.', $spaceId)];
    }
}
