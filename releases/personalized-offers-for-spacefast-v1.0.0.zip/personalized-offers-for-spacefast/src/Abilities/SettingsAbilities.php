<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Abilities;

use Micemade\PersonalizedOffers\Repository\BrandSnapshotRepository;
use Micemade\PersonalizedOffers\Service\BrandTemplate;
use Micemade\PersonalizedOffers\Service\Settings;
use WP_Error;

/**
 * Abilities for the plugin's settings (offer defaults, notifications,
 * logging) and the store brand that offer pages are styled with.
 */
final class SettingsAbilities {
    public const GET_SETTINGS = 'personalized-offers-for-spacefast/get-settings';
    public const UPDATE_SETTINGS = 'personalized-offers-for-spacefast/update-settings';
    public const BRAND_STATUS = 'personalized-offers-for-spacefast/brand-status';
    public const LOCK_BRAND = 'personalized-offers-for-spacefast/lock-brand';

    /** What each editable setting means, for the assistant. */
    private const SETTINGS = [
        'offer_default_expiry' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 365, 'description' => 'Days a new offer stays valid.'],
        'offer_max_uses' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 1000000, 'description' => 'Default usage limit of a new offer.'],
        'free_shipping_coupon' => ['type' => 'boolean', 'description' => 'New offers\' coupons allow free shipping by default.'],
        'email_notifications' => ['type' => 'boolean', 'description' => 'Email the manager who asked for offers when they are ready.'],
        'debug_logging' => ['type' => 'boolean', 'description' => 'Write debug details to the WooCommerce log.'],
        'preferences_page' => ['type' => 'boolean', 'description' => 'Show customers a "My preferences" page in My Account, where they can agree to personalized offers and state their sizes, colours and favourite categories.'],
        'record_searches' => ['type' => 'boolean', 'description' => 'Remember product searches of customers who allowed it on My preferences (needs preferences_page).'],
    ];

    public function __construct(
        private readonly BrandTemplate $brandTemplate,
        private readonly BrandSnapshotRepository $brands,
    ) {}

    public function register(): void {
        add_action('wp_abilities_api_init', [$this, 'registerAbilities']);
    }

    /**
     * @return list<string>
     */
    public static function names(): array {
        return [self::GET_SETTINGS, self::UPDATE_SETTINGS, self::BRAND_STATUS, self::LOCK_BRAND];
    }

    public function registerAbilities(): void {
        $permission = static fn (): bool => current_user_can('manage_woocommerce');
        $settingsSchema = ['type' => 'object', 'properties' => self::SETTINGS];

        wp_register_ability(self::GET_SETTINGS, [
            'label' => __('Get plugin settings', 'personalized-offers-for-spacefast'),
            'description' => 'Read the plugin settings: defaults for new offers (expiry days, usage limit, free shipping), notifications and debug logging.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => ['type' => 'object', 'properties' => (object) [], 'default' => []],
            'output_schema' => $settingsSchema,
            'execute_callback' => [$this, 'getSettings'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::UPDATE_SETTINGS, [
            'label' => __('Update plugin settings', 'personalized-offers-for-spacefast'),
            'description' => 'Change plugin settings; only the settings passed change. They apply to offers created afterwards, not to existing offers '
                . '(update-offer changes those). Returns all settings.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => $settingsSchema + ['minProperties' => 1],
            'output_schema' => $settingsSchema,
            'execute_callback' => [$this, 'updateSettings'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::BRAND_STATUS, [
            'label' => __('Store brand status', 'personalized-offers-for-spacefast'),
            'description' => 'The store brand offer pages are styled with: the active locked version (name, logo, colors, fonts, when captured) '
                . 'and all saved versions. With no locked version, pages use the brand as the site shows it now.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => ['type' => 'object', 'properties' => (object) [], 'default' => []],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'active' => ['type' => ['object', 'null']],
                    'versions' => ['type' => 'array', 'items' => ['type' => 'object']],
                ],
            ],
            'execute_callback' => [$this, 'brandStatus'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::LOCK_BRAND, [
            'label' => __('Lock store brand', 'personalized-offers-for-spacefast'),
            'description' => 'Capture the store brand as the site shows it now (logo, name, colors, fonts from the theme and WooCommerce email '
                . 'settings) and save it as a new active version, so offer pages keep this look even if the theme changes. '
                . 'Published pages change on their next update.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => ['type' => 'object', 'properties' => (object) [], 'default' => []],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'version' => ['type' => 'integer'],
                    'brand' => ['type' => 'object'],
                    'message' => ['type' => 'string'],
                ],
            ],
            'execute_callback' => [$this, 'lockBrand'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => false],
            ],
        ]);
    }

    public function getSettings(): array {
        return array_intersect_key(Settings::editable(), self::SETTINGS);
    }

    public function updateSettings(array $input): array|WP_Error {
        $changes = array_intersect_key($input, self::SETTINGS);

        if ([] === $changes) {
            return new WP_Error('pofsf_settings_none', 'No known setting given. Settings: ' . implode(', ', array_keys(self::SETTINGS)) . '.');
        }

        // sanitize() reads a whole form (a missing box is off), so it gets the current values with the changes over them.
        Settings::update(Settings::sanitize(array_merge(Settings::editable(), $changes)));

        return $this->getSettings();
    }

    public function brandStatus(): array {
        $active = $this->brands->findActive();

        return [
            'active' => null === $active ? null : ['version' => (int) $active['version']] + self::summary((array) ($active['data'] ?? [])),
            'versions' => array_map(static fn (array $row): array => [
                'version' => (int) $row['version'],
                'created_at' => (string) $row['created_at'],
                'active' => (bool) (int) $row['is_active'],
            ], $this->brands->versions()),
        ];
    }

    public function lockBrand(): array|WP_Error {
        $brand = $this->brandTemplate->capture();

        if ($brand instanceof WP_Error) {
            return $brand;
        }

        $result = $this->brands->create($brand->toArray(), get_current_user_id());

        if ($result instanceof WP_Error) {
            return $result;
        }

        $version = $this->brands->nextVersion() - 1;

        return [
            'version' => $version,
            'brand' => self::summary($brand->toArray()),
            'message' => sprintf('Brand locked as version %d, now active. Published offer pages show it after their next update.', $version),
        ];
    }

    /**
     * The parts of a brand snapshot worth reporting.
     */
    private static function summary(array $brand): array {
        return [
            'name' => (string) ($brand['identity']['name'] ?? ''),
            'logo' => (string) ($brand['logo']['url'] ?? ''),
            'colors' => (array) ($brand['colors'] ?? []),
            'fonts' => (array) ($brand['fonts'] ?? []),
            'captured_at' => (string) ($brand['captured_at'] ?? ''),
        ];
    }
}
