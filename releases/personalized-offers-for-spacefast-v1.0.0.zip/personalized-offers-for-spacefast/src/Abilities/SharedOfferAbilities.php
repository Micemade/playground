<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Abilities;

use Micemade\PersonalizedOffers\Enum\OfferType;
use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Service\CustomerFinder;
use Micemade\PersonalizedOffers\Service\OfferEditor;
use Micemade\PersonalizedOffers\Service\OfferLimits;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;
use Micemade\PersonalizedOffers\Service\Spacefast\SpacefastClient;
use Micemade\PersonalizedOffers\Value\OfferCopy;
use WP_Error;

/**
 * Abilities for the offers the Offers tab creates by hand: one offer page
 * with chosen products, for a group of customers (each with a personal
 * link) or for anyone (public), and publishing an offer to Spacefast.
 * They call the same code as the Create new offer form and the Publish
 * button.
 */
final class SharedOfferAbilities {
    public const FIND_PRODUCTS = 'personalized-offers-for-spacefast/find-products';
    public const CREATE_SHARED_OFFER = 'personalized-offers-for-spacefast/create-shared-offer';
    public const PUBLISH_OFFER = 'personalized-offers-for-spacefast/publish-offer';

    public function __construct(
        private readonly OfferEditor $editor,
        private readonly OfferPublisher $publisher,
        private readonly SpacefastClient $spacefast,
        private readonly OfferRepository $offers,
        private readonly CustomerFinder $finder = new CustomerFinder(),
        private readonly ?\Micemade\PersonalizedOffers\Service\Segments $segments = null,
    ) {}

    public function register(): void {
        add_action('wp_abilities_api_init', [$this, 'registerAbilities']);
    }

    /**
     * @return list<string>
     */
    public static function names(): array {
        return [self::FIND_PRODUCTS, self::CREATE_SHARED_OFFER, self::PUBLISH_OFFER];
    }

    public function registerAbilities(): void {
        $permission = static fn (): bool => current_user_can('manage_woocommerce');

        wp_register_ability(self::FIND_PRODUCTS, [
            'label' => __('Find products', 'personalized-offers-for-spacefast'),
            'description' => 'Find products that can be put in an offer, by product name, category or tag words (subcategories included), '
                . 'e.g. ["fitness", "dumbbell", "yoga mat"]. Without keywords, returns the bestsellers. Returns product IDs for create-shared-offer.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'keywords' => ['type' => 'array', 'items' => ['type' => 'string', 'minLength' => 2], 'maxItems' => 10],
                    'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 40, 'default' => 20],
                ],
                'default' => [],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'products' => [
                        'type' => 'array',
                        'items' => [
                            'type' => 'object',
                            'properties' => [
                                'product_id' => ['type' => 'integer'],
                                'name' => ['type' => 'string'],
                                'price' => ['type' => 'string'],
                                'categories' => ['type' => 'array', 'items' => ['type' => 'string']],
                                'in_stock' => ['type' => 'boolean'],
                                'total_sales' => ['type' => 'integer'],
                            ],
                        ],
                    ],
                    'matched_categories' => ['type' => 'array', 'items' => ['type' => 'string']],
                ],
            ],
            'execute_callback' => [$this, 'findProducts'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::CREATE_SHARED_OFFER, [
            'label' => __('Create a group or public offer', 'personalized-offers-for-spacefast'),
            'description' => 'Create ONE offer page with chosen products and your own copy. audience "group": for chosen customers (user IDs from find-customers), '
                . 'each gets a personal link to the same page and can use it once per the usage limit; use it for any request for one offer for several, '
                . 'many or a segment of customers. audience "public": one link anyone can use (newsletter, social media, website). '
                . 'The page is not personalized per customer, so write copy that suits everyone (no names). The offer is ready at once; '
                . 'publish it with publish-offer. Only call after the manager confirmed the customers (for a group) and the products.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'audience' => ['type' => 'string', 'enum' => ['group', 'public']],
                    'user_ids' => [
                        'type' => 'array',
                        'items' => ['type' => 'integer', 'minimum' => 1],
                        'maxItems' => OfferEditor::MAX_RECIPIENTS,
                        'uniqueItems' => true,
                        'description' => 'For a group: the customers, from find-customers or segment-customers.',
                    ],
                    'segment' => ['type' => 'string', 'description' => 'For a group made for a segment (ID from list-segments): noted on the offer; without user_ids, its customers with an account (at most 100).'],
                    'products' => [
                        'type' => 'array',
                        'minItems' => 1,
                        'maxItems' => OfferCopy::MAX_PICKS,
                        'description' => 'Products from find-products, in display order.',
                        'items' => [
                            'type' => 'object',
                            'properties' => [
                                'product_id' => ['type' => 'integer', 'minimum' => 1],
                                'title' => ['type' => 'string', 'maxLength' => OfferCopy::LIMITS['title'], 'description' => 'Optional short title shown instead of the product name.'],
                                'story' => ['type' => 'string', 'maxLength' => OfferCopy::LIMITS['story'], 'description' => 'Optional one or two sentences about the product.'],
                            ],
                            'required' => ['product_id'],
                        ],
                    ],
                    'headline' => ['type' => 'string', 'minLength' => 1, 'maxLength' => OfferCopy::LIMITS['headline']],
                    'overheadline' => ['type' => 'string', 'maxLength' => OfferCopy::LIMITS['overheadline'] ?? 120, 'description' => 'Optional small line above the headline.'],
                    'subheadline' => ['type' => 'string', 'maxLength' => OfferCopy::LIMITS['subheadline'] ?? 200],
                    'body' => ['type' => 'string', 'maxLength' => OfferCopy::LIMITS['body'] ?? 1000, 'description' => 'Main text of the offer.'],
                    'additional_text' => ['type' => 'string', 'maxLength' => OfferCopy::LIMITS['additional'] ?? 600],
                    'template_id' => ['type' => 'integer', 'minimum' => 0, 'description' => 'From list-templates or save-template. Omit for the default template.'],
                    'expires_on' => ['type' => 'string', 'format' => 'date', 'description' => 'Last day (YYYY-MM-DD). Omit for the default expiry.'],
                    'max_uses' => ['type' => 'integer', 'minimum' => 1, 'description' => 'How often each link can be used. Omit for the default.'],
                ],
                'required' => ['audience', 'products', 'headline'],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'offer_id' => ['type' => 'integer'],
                    'audience' => ['type' => 'string'],
                    'recipients' => ['type' => 'integer'],
                    'message' => ['type' => 'string'],
                ],
            ],
            'execute_callback' => [$this, 'createSharedOffer'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => false],
            ],
        ]);

        wp_register_ability(self::PUBLISH_OFFER, [
            'label' => __('Publish an offer to Spacefast', 'personalized-offers-for-spacefast'),
            'description' => 'Upload an offer page to Spacefast (first time) or update its Space (later times), like the Publish to Spacefast / Update Space button. '
                . 'Use for requests to upload, publish, put online, share or update an offer. access "private": only people with the link; '
                . '"public": anyone with the address. Omit it to follow the offer type (public offers public, personal and group offers private). '
                . 'Changing an offer\'s type later makes its Space public or private to match. Only call after the manager asked or confirmed.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'offer_id' => ['type' => 'integer', 'minimum' => 1],
                    'access' => ['type' => 'string', 'enum' => ['private', 'public']],
                ],
                'required' => ['offer_id'],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'offer_id' => ['type' => 'integer'],
                    'status' => ['type' => 'string'],
                    'access' => ['type' => 'string'],
                    'live_url' => ['type' => 'string'],
                    'message' => ['type' => 'string'],
                ],
            ],
            'execute_callback' => [$this, 'publishOffer'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => true],
            ],
        ]);
    }

    public function findProducts(array $input = []): array {
        $limit = max(1, min(40, (int) ($input['limit'] ?? 20)));
        $keywords = array_slice(array_map('strval', (array) ($input['keywords'] ?? [])), 0, 10);
        $categories = [];

        if ([] !== array_filter($keywords, static fn (string $k): bool => '' !== trim($k))) {
            [$ids, $categories] = $this->finder->productsMatching($keywords);
            $products = [] === $ids ? [] : wc_get_products(['include' => $ids, 'status' => 'publish', 'limit' => -1]);
            // Best sellers first among the matches.
            usort($products, static fn ($a, $b): int => (int) $b->get_total_sales() <=> (int) $a->get_total_sales());
        } else {
            $products = wc_get_products(['status' => 'publish', 'limit' => $limit * 2, 'orderby' => 'meta_value_num', 'meta_key' => 'total_sales', 'order' => 'DESC']); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Best sellers, as WooCommerce sorts by popularity; the result is limited.
        }

        $rows = [];

        foreach ($products as $product) {
            if (!$product instanceof \WC_Product || in_array($product->get_type(), ['grouped', 'external'], true) || !$product->is_purchasable()) {
                continue;
            }

            $rows[] = [
                'product_id' => $product->get_id(),
                'name' => html_entity_decode($product->get_name(), ENT_QUOTES),
                'price' => html_entity_decode(wp_strip_all_tags(wc_price((float) $product->get_price())), ENT_QUOTES),
                'categories' => array_map(static fn ($name): string => html_entity_decode((string) $name, ENT_QUOTES), wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'names']) ?: []),
                'in_stock' => $product->is_in_stock(),
                'total_sales' => (int) $product->get_total_sales(),
            ];

            if (count($rows) >= $limit) {
                break;
            }
        }

        return ['products' => $rows, 'matched_categories' => $categories];
    }

    public function createSharedOffer(array $input): array|WP_Error {
        $type = 'public' === ($input['audience'] ?? '') ? OfferType::Public : OfferType::Group;
        $userIds = array_values(array_unique(array_map('intval', (array) ($input['user_ids'] ?? []))));
        $segment = OfferType::Group === $type && null !== $this->segments && '' !== (string) ($input['segment'] ?? '') ? $this->segments->find((string) $input['segment']) : null;

        if (OfferType::Group === $type && '' !== (string) ($input['segment'] ?? '') && null === $segment) {
            return new WP_Error('segment_not_found', 'Segment not found. Use an ID from list-segments.');
        }

        if (null !== $segment && [] === $userIds) {
            $userIds = array_column($this->segments->members($segment['rules'])['recipients'], 'id');
        }

        if (OfferType::Group === $type && [] === $userIds) {
            return new WP_Error('offer_no_recipients', null !== $segment ? 'This segment has no customers with an account; group offers need one.' : 'A group offer needs user_ids from find-customers.');
        }

        $fields = [];

        foreach (['overheadline', 'subheadline', 'body', 'additional_text' => 'additional'] as $key => $fieldType) {
            $key = is_int($key) ? $fieldType : $key;
            $text = trim((string) ($input[$key] ?? ''));

            if ('' !== $text) {
                $fields[] = ['type' => $fieldType, 'text' => $text];
            }
        }

        $form = [
            'headline' => (string) ($input['headline'] ?? ''),
            'fields' => $fields,
            'picks' => array_map(static fn ($pick): array => [
                'product_id' => (int) ($pick['product_id'] ?? 0),
                'title' => (string) ($pick['title'] ?? ''),
                'story' => (string) ($pick['story'] ?? ''),
            ], array_slice((array) ($input['products'] ?? []), 0, OfferCopy::MAX_PICKS)),
            'template_id' => max(0, (int) ($input['template_id'] ?? 0)),
            'expires_on' => (string) ($input['expires_on'] ?? '') ?: wp_date('Y-m-d', strtotime('+' . max(1, (int) \Micemade\PersonalizedOffers\Service\Settings::get('offer_default_expiry', 30)) . ' days')),
            'max_uses' => isset($input['max_uses']) ? (int) $input['max_uses'] : OfferLimits::defaultMax(),
            'recipients' => OfferType::Group === $type ? $userIds : [],
            'segment' => null !== $segment ? ['id' => $segment['id'], 'name' => $segment['name']] : null,
        ];

        $offerId = $this->editor->create(0, get_current_user_id(), $form, $type);

        if ($offerId instanceof WP_Error) {
            return $offerId;
        }

        return [
            'offer_id' => $offerId,
            'audience' => $type->value,
            'recipients' => count($form['recipients']),
            'message' => OfferType::Group === $type
                ? sprintf('Created group offer #%d for %d customer(s). After publishing, each customer\'s personal link is under Edit offer in the Offers tab.', $offerId, count($userIds))
                : sprintf('Created public offer #%d. Publish it to get its link.', $offerId),
        ];
    }

    public function publishOffer(array $input): array|WP_Error {
        $offerId = (int) ($input['offer_id'] ?? 0);

        $offer = $this->offers->find($offerId);

        if (null === $offer) {
            return new WP_Error('offer_not_found', sprintf('Offer #%d not found.', $offerId));
        }

        if (!$this->spacefast->status()['connected']) {
            return new WP_Error('spacefast_not_connected', 'Spacefast is not connected. Connect it under Settings in the Personalized Offers page first.');
        }

        // Without a choice, a public offer's Space is public and a personal or group one private.
        $access = (string) ($input['access'] ?? ('public' === (string) $offer['type'] ? 'public' : 'private'));
        $result = $this->publisher->publish($offerId, 'public' === $access ? 'public' : 'private');

        if ($result instanceof WP_Error) {
            return $result;
        }

        $record = OfferPublisher::record($this->offers->find($offerId) ?? []);

        return [
            'offer_id' => $offerId,
            'status' => $record['status'] ?: $record['version_status'],
            'access' => $record['access'],
            'live_url' => 'public' === $record['access'] ? $record['live_url'] : '',
            'message' => 'public' === $record['access']
                ? 'Published. The Space may take a moment to go live.'
                : 'Published as a private Space. Its sharing link (and, for a group offer, each customer\'s personal link) is in the Offers tab.',
        ];
    }
}
