<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Abilities;

use Micemade\PersonalizedOffers\Admin\CustomersController;
use Micemade\PersonalizedOffers\Service\CustomerProfiles;
use WP_Error;

/**
 * Abilities for stored customer profiles: list customers by segment, read
 * a profile, and correct the preferences offers are built from.
 */
final class CustomerAbilities {
    public const LIST_CUSTOMERS = 'personalized-offers-for-spacefast/list-customer-profiles';
    public const GET_PROFILE = 'personalized-offers-for-spacefast/get-customer-profile';
    public const UPDATE_PREFERENCES = 'personalized-offers-for-spacefast/update-customer-preferences';

    /** A customer: their account, or a guest's email. */
    private const CUSTOMER = [
        'user_id' => ['type' => 'integer', 'minimum' => 1, 'description' => 'The customer\'s account (user ID).'],
        'email' => ['type' => 'string', 'format' => 'email', 'description' => 'A guest customer (no account) by the email they ordered with; an account\'s email means that account.'],
    ];

    public function __construct(
        private readonly CustomerProfiles $profiles,
    ) {}

    public function register(): void {
        add_action('wp_abilities_api_init', [$this, 'registerAbilities']);
    }

    /**
     * @return list<string>
     */
    public static function names(): array {
        return [self::LIST_CUSTOMERS, self::GET_PROFILE, self::UPDATE_PREFERENCES];
    }

    public function registerAbilities(): void {
        $permission = static fn (): bool => current_user_can('manage_woocommerce');
        $segments = array_keys(CustomerProfiles::segments());

        wp_register_ability(self::LIST_CUSTOMERS, [
            'label' => __('List customer profiles', 'personalized-offers-for-spacefast'),
            'description' => 'Customers with a stored shopping profile (registered and guests), newest order first: segment ('
                . implode(', ', $segments) . '), orders, amount spent, favourite categories and sizes. Filter by segment, '
                . 'kind (registered or guest) or a name/email search.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'search' => ['type' => 'string'],
                    'segment' => ['type' => 'string', 'enum' => $segments],
                    'kind' => ['type' => 'string', 'enum' => ['registered', 'guest']],
                    'orderby' => ['type' => 'string', 'enum' => ['last_order_at', 'total_spent', 'order_count', 'name']],
                    'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 50, 'default' => 20],
                ],
                'default' => [],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'customers' => ['type' => 'array', 'items' => ['type' => 'object']],
                    'total' => ['type' => 'integer'],
                ],
            ],
            'execute_callback' => [$this, 'listCustomers'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::GET_PROFILE, [
            'label' => __('Get customer profile', 'personalized-offers-for-spacefast'),
            'description' => 'A customer\'s stored shopping profile, as offers use it: favourite categories (weighted by amount and recency; '
                . 'pinned ones first), brands, attributes such as size, colour or material, typical price and band (budget, mid, '
                . 'premium), how recently, often and much they buy, segment, wishlist size, and the manager\'s corrections and note. '
                . 'Built on first request. refresh: rebuild from their orders now.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => self::CUSTOMER + ['refresh' => ['type' => 'boolean', 'default' => false]],
            ],
            'output_schema' => ['type' => 'object'],
            'execute_callback' => [$this, 'getProfile'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::UPDATE_PREFERENCES, [
            'label' => __('Update customer preferences', 'personalized-offers-for-spacefast'),
            'description' => 'Correct the preferences new offers for a customer are built from; only the fields passed change. '
                . 'categories_pinned: product category IDs to treat as favourites (first). categories_excluded: category IDs never to '
                . 'suggest. attributes: attribute taxonomy => term slugs, e.g. {"pa_size": ["m"]}, replacing what their orders show. '
                . 'note: for the store team. reset: remove all corrections. Existing offers don\'t change. Returns the profile.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => self::CUSTOMER + [
                    'categories_pinned' => ['type' => 'array', 'items' => ['type' => 'integer'], 'maxItems' => 20],
                    'categories_excluded' => ['type' => 'array', 'items' => ['type' => 'integer'], 'maxItems' => 20],
                    'attributes' => ['type' => 'object', 'additionalProperties' => ['type' => 'array', 'items' => ['type' => 'string']]],
                    'note' => ['type' => 'string', 'maxLength' => 1000],
                    'reset' => ['type' => 'boolean'],
                ],
            ],
            'output_schema' => ['type' => 'object'],
            'execute_callback' => [$this, 'updatePreferences'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => true],
            ],
        ]);
    }

    public function listCustomers(array $input = []): array {
        $result = $this->profiles->repository()->list([
            'search' => (string) ($input['search'] ?? ''),
            'segment' => (string) ($input['segment'] ?? ''),
            'kind' => (string) ($input['kind'] ?? ''),
            'orderby' => (string) ($input['orderby'] ?? ''),
            'per_page' => (int) ($input['limit'] ?? 20),
        ]);

        return [
            'customers' => array_map(static fn (array $row): array => array_intersect_key(
                CustomersController::summary($row),
                array_flip(['id', 'guest', 'name', 'email', 'segment', 'orders', 'spent', 'lastOrder', 'categories', 'sizes', 'priceBand', 'corrected']),
            ), $result['rows']),
            'total' => $result['total'],
        ];
    }

    public function getProfile(array $input = []): array|WP_Error {
        $key = $this->key($input);

        if ($key instanceof WP_Error) {
            return $key;
        }

        $row = $this->profiles->row($key, !empty($input['refresh']));

        return null === $row ? self::notFound() : $this->present($row);
    }

    public function updatePreferences(array $input = []): array|WP_Error {
        $key = $this->key($input);

        if ($key instanceof WP_Error) {
            return $key;
        }

        $changes = array_intersect_key($input, array_flip(['categories_pinned', 'categories_excluded', 'attributes', 'note', 'reset']));

        if ([] === $changes) {
            return new WP_Error('pofsf_preferences_none', 'Nothing to change: pass categories_pinned, categories_excluded, attributes, note or reset.');
        }

        $result = $this->profiles->correct($key, $changes, get_current_user_id());

        return $result instanceof WP_Error ? $result : $this->present((array) $this->profiles->repository()->find($key));
    }

    private function key(array $input): string|WP_Error {
        $userId = (int) ($input['user_id'] ?? 0);
        $email = sanitize_email((string) ($input['email'] ?? ''));

        if ($userId <= 0 && '' === $email) {
            return new WP_Error('pofsf_customer_missing', 'Pass user_id, or email for a guest customer.');
        }

        if ($userId > 0 && !get_userdata($userId)) {
            return self::notFound();
        }

        return CustomerProfiles::keyFor($userId, $email);
    }

    private static function notFound(): WP_Error {
        return new WP_Error('pofsf_customer_missing', __('Customer not found.', 'personalized-offers-for-spacefast'));
    }

    private function present(array $row): array {
        $profile = $this->profiles->effective($row);

        return [
            'user_id' => (int) $row['user_id'],
            'email' => (string) $row['email'],
            'name' => (string) $row['name'],
            'guest' => (int) $row['user_id'] <= 0,
            'segment' => $profile['segment'],
            'categories' => array_map(static fn (array $c): array => array_intersect_key($c, array_flip(['id', 'name', 'count', 'pinned'])), (array) $profile['preferred_categories']),
            'categories_excluded' => $profile['excluded_categories'],
            'brands' => array_column((array) $profile['brands'], 'name'),
            'attributes' => array_map(static fn (array $a): array => [
                'label' => $a['label'],
                'values' => array_map(static fn (array $v): array => ['slug' => $v['value'], 'name' => $v['name']], (array) $a['values']),
                'set_by' => $a['set_by'] ?? 'orders',
            ], (array) $profile['attributes']),
            'price_range' => $profile['price_range'],
            'activity' => $profile['activity'],
            'buying_rhythm' => (string) ($profile['buying_rhythm']['most_common'] ?? ''),
            'wishlist_count' => count((array) $profile['wishlist_products']),
            'searches' => array_column((array) $profile['searches'], 'term'),
            'note' => $profile['manager_note'],
            'stated_by_customer' => !empty($row['customer_input']['consent']),
            'built_at' => (string) $row['built_at'],
        ];
    }
}
