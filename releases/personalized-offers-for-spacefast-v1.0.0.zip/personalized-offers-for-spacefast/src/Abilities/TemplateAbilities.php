<?php

declare(strict_types=1);

namespace Micemade\PersonalizedOffers\Abilities;

use Micemade\PersonalizedOffers\Repository\OfferRepository;
use Micemade\PersonalizedOffers\Repository\TemplateRepository;
use Micemade\PersonalizedOffers\Service\OfferPipeline;
use Micemade\PersonalizedOffers\Service\Spacefast\OfferPublisher;
use Micemade\PersonalizedOffers\Service\StyleInspector;
use Micemade\PersonalizedOffers\Value\FontCatalog;
use Micemade\PersonalizedOffers\Value\OfferDesign;
use WP_Error;

/**
 * Abilities for designing offers: reusable design templates, restyling an
 * existing offer, and reading a website's style for inspiration.
 */
final class TemplateAbilities {
    public const LIST_TEMPLATES = 'personalized-offers-for-spacefast/list-templates';
    public const SAVE_TEMPLATE = 'personalized-offers-for-spacefast/save-template';
    public const APPLY_TEMPLATE = 'personalized-offers-for-spacefast/apply-template';
    public const INSPECT_WEBSITE = 'personalized-offers-for-spacefast/inspect-website-style';
    public const RESTORE_TEMPLATE = 'personalized-offers-for-spacefast/restore-template';
    public const DELETE_TEMPLATE = 'personalized-offers-for-spacefast/delete-template';

    public function __construct(
        private readonly TemplateRepository $templates,
        private readonly OfferPipeline $pipeline,
        private readonly OfferRepository $offers,
        private readonly StyleInspector $inspector,
    ) {}

    public function register(): void {
        add_action('wp_abilities_api_init', [$this, 'registerAbilities']);
    }

    /**
     * @return list<string>
     */
    public static function names(): array {
        return [self::LIST_TEMPLATES, self::SAVE_TEMPLATE, self::APPLY_TEMPLATE, self::DELETE_TEMPLATE, self::RESTORE_TEMPLATE, self::INSPECT_WEBSITE];
    }

    public function registerAbilities(): void {
        $permission = static fn (): bool => current_user_can('manage_woocommerce');
        $templateSchema = [
            'type' => 'object',
            'properties' => [
                'template_id' => ['type' => 'integer'],
                'name' => ['type' => 'string'],
                'description' => ['type' => 'string'],
                'is_default' => ['type' => 'boolean'],
                'builtin' => ['type' => 'string', 'description' => 'Base layout of a read-only built-in template, or empty for custom templates.'],
                'design' => ['type' => 'object'],
            ],
        ];

        wp_register_ability(self::LIST_TEMPLATES, [
            'label' => __('List offer templates', 'personalized-offers-for-spacefast'),
            'description' => 'List offer design templates with their full designs: four read-only built-ins (one per base layout) and custom templates. '
                . 'The default template is used when create-offers gets no template_id. To build on a template, copy its design into save-template without template_id.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => ['type' => 'object', 'properties' => (object) [], 'default' => []],
            'output_schema' => [
                'type' => 'object',
                'properties' => ['templates' => ['type' => 'array', 'items' => $templateSchema]],
            ],
            'execute_callback' => [$this, 'listTemplates'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::SAVE_TEMPLATE, [
            'label' => __('Save offer template', 'personalized-offers-for-spacefast'),
            'description' => 'Create a reusable offer design template, or update one by passing template_id. '
                . 'A design sets colors (hex), fonts (CSS font stacks, optionally loaded from a Google Fonts stylesheet URL), '
                . 'product layout, copy tone, personal-note guidance and optional extra CSS (the corner radius is the --pofsf-radius variable there, 8px by default). '
                . 'A template is a block-editor page layout plus this design. For a new template the layout is copied from source_template_id, '
                . 'or else is the starter layout named by design.base (classic, editorial, letter, spotlight). Updating keeps the current layout '
                . 'unless content is given. Set use_brand=false to ignore the store\'s captured brand colors and fonts. '
                . 'Built-in templates cannot be updated; save a new one instead. '
                . 'Returns a preview_url the store manager can open to see the design with sample content.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'template_id' => ['type' => 'integer', 'minimum' => 1, 'description' => 'Template to update. Omit to create a new one.'],
                    'name' => ['type' => 'string', 'minLength' => 1, 'maxLength' => 100],
                    'description' => ['type' => 'string', 'maxLength' => 300],
                    'set_default' => ['type' => 'boolean', 'description' => 'Make this the default template for new offers.'],
                    'source_template_id' => ['type' => 'integer', 'minimum' => 1, 'description' => 'New templates only: copy the page layout of this template.'],
                    'content' => [
                        'type' => 'string',
                        'maxLength' => 60000,
                        'description' => 'Advanced: full page layout as WordPress block markup. Use core blocks (group, columns, column, paragraph, heading, spacer, image) and the dynamic, self-closing offer blocks: '
                            . 'pofsf/branding {"showLogo":true,"showTitle":true,"logoWidth":0,"isLink":false} (site logo, or site icon without one, and the store name; align left|center|right|wide|full, textAlign, typography settings style the name, backgroundColor), the Offer headline: a core Heading bound to the offer headline, <!-- wp:heading {"level":1,"metadata":{"bindings":{"content":{"source":"pofsf/offer","args":{"key":"headline"}}}}} --><h1 class="wp-block-heading"></h1><!-- /wp:heading --> (any Heading settings: level, textAlign, fontSize, colors, align wide|full, className; its text comes from the offer), pofsf/offer-text {"field":"overheadline|subheadline|greeting|body|additional"} (shows the offer\'s text field of that type, if it has one; '
                            . 'block styles className is-style-pofsf-card, is-style-pofsf-quote, is-style-pofsf-letter, is-style-pofsf-sticker), '
                            . 'pofsf/products {"variant":"story|feature|lookbook|numbered|catalogue|gallery|showcase","showPrice":true,"showReason":true,"showCart":true,"layout":{"type":"grid","columnCount":1-6,"minimumColumnWidth":"12rem"},"style":{"spacing":{"blockGap":"24px"}},"fontSize":"…","appearance":{"imageRatio":"auto|1|4/5|3/4|2/3|3/2|16/9","imageFit":"cover|contain","imageInset":0-20,"imageRadius":0-64,"titleColor":"#hex","storyColor":"#hex","labelColor":"#hex","priceColor":"#hex","numberColor":"#hex","cardColor":"#hex","imageBackdrop":"#hex","lineColor":"#hex","titleSize":"2rem","storySize":"1rem","labelSize":"0.75rem","titleFont":"heading|body","titleWeight":"300-900","titleStyle":"normal|italic","titleTransform":"none|uppercase","textAlign":"left|center|right"}} (all of the offer\'s picks, as a grid: each product is a grid item; story = editorial image/text alternating, 1 column; feature = cover, text on the image, first spans the row; lookbook = staggered captioned images, 2 columns; numbered = numbered index entries; catalogue = product plates with "No. 01 name … price" lines, 3 columns; gallery = framed prints with centred captions, 3 columns; showcase = one centred product per row; showCart = Add to cart / Select options buttons and the page cart; appearance values are all optional), pofsf/offer-action-button {"label":"…","arrow":true} (sends the cart to checkout with the coupon) '
                            . '(cart: fills the cart with the offer\'s products; shop: the shop showing them; product: the product at that place among them; its text and background colors style the button; block styles className is-style-pofsf-outline, is-style-pofsf-pill, is-style-pofsf-soft, is-style-pofsf-raised, is-style-pofsf-link). Group block styles: is-style-pofsf-banner (primary background; give the group its own backgroundColor or style.color.gradient for another, e.g. "linear-gradient(120deg,var(--pofsf-primary) 0%,var(--pofsf-accent) 100%)"), is-style-pofsf-paper, is-style-pofsf-masthead, is-style-pofsf-strip, is-style-pofsf-sticky-bar. '
                            . 'Offer pages are editorial or marketing stories, not shop listings: every product style shows each pick with its title and story. '
                            . 'Always include pofsf/products and a pofsf/offer-action-button. Omit to keep or copy a layout.',
                    ],
                    'design' => self::designSchema(),
                ],
                'required' => ['name', 'design'],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'template_id' => ['type' => 'integer'],
                    'preview_url' => ['type' => 'string'],
                    'message' => ['type' => 'string'],
                ],
            ],
            'execute_callback' => [$this, 'saveTemplate'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => false],
            ],
        ]);

        wp_register_ability(self::APPLY_TEMPLATE, [
            'label' => __('Apply template to offer', 'personalized-offers-for-spacefast'),
            'description' => 'Change the design of an existing offer without regenerating its copy, and optionally replace its Additional text. '
                . 'template_id 0 restores the plain brand look. Offers already published to Spacefast need "Update Space" in the Offers tab to publish the change.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'offer_id' => ['type' => 'integer', 'minimum' => 1],
                    'template_id' => ['type' => 'integer', 'minimum' => 0],
                    'additional_text' => ['type' => 'string', 'maxLength' => 600, 'description' => 'New Additional text (replaces the offer\'s Additional text fields). Omit to keep them.'],
                ],
                'required' => ['offer_id', 'template_id'],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => ['message' => ['type' => 'string']],
            ],
            'execute_callback' => [$this, 'applyTemplate'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::DELETE_TEMPLATE, [
            'label' => __('Delete offer template', 'personalized-offers-for-spacefast'),
            'description' => 'Permanently delete a custom offer template (built-ins cannot be deleted). Offers using it keep their copy of it, '
                . 'so their pages do not change; restore-template can bring it back from any of them. Confirm with the manager first, '
                . 'naming the offers that use it (offer_ids in the result of a call with dry_run = true).',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'template_id' => ['type' => 'integer', 'minimum' => 1],
                    'dry_run' => ['type' => 'boolean', 'default' => false, 'description' => 'Only report what would be deleted and which offers use the template.'],
                ],
                'required' => ['template_id'],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'template_id' => ['type' => 'integer'],
                    'name' => ['type' => 'string'],
                    'deleted' => ['type' => 'boolean'],
                    'offer_ids' => ['type' => 'array', 'items' => ['type' => 'integer'], 'description' => 'Offers that use the template and keep their copy of it.'],
                    'message' => ['type' => 'string'],
                ],
            ],
            'execute_callback' => [$this, 'deleteTemplate'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => true, 'idempotent' => true],
            ],
        ]);

        wp_register_ability(self::RESTORE_TEMPLATE, [
            'label' => __('Restore deleted template', 'personalized-offers-for-spacefast'),
            'description' => 'Recreate an offer\'s deleted template from the copy the offer keeps (name, design, block layout). '
                . 'Use when get-offer shows template_deleted = true. The template gets a new ID and every offer that used the deleted '
                . 'template follows the restored one again. The offers\' pages do not change.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => [
                    'offer_id' => ['type' => 'integer', 'minimum' => 1, 'description' => 'An offer that used the deleted template.'],
                ],
                'required' => ['offer_id'],
            ],
            'output_schema' => [
                'type' => 'object',
                'properties' => [
                    'template_id' => ['type' => 'integer'],
                    'name' => ['type' => 'string'],
                    'offer_ids' => ['type' => 'array', 'items' => ['type' => 'integer'], 'description' => 'Offers now following the restored template.'],
                    'preview_url' => ['type' => 'string'],
                    'message' => ['type' => 'string'],
                ],
            ],
            'execute_callback' => [$this, 'restoreTemplate'],
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => false, 'destructive' => false, 'idempotent' => false],
            ],
        ]);

        wp_register_ability(self::INSPECT_WEBSITE, [
            'label' => __('Inspect website style', 'personalized-offers-for-spacefast'),
            'description' => 'Read a public website\'s most used colors, color CSS variables, font stacks and web font stylesheets, '
                . 'to design an offer template inspired by it. Use the result as inspiration; do not copy logos or trademarks.',
            'category' => OfferAbilities::CATEGORY,
            'input_schema' => [
                'type' => 'object',
                'properties' => ['url' => ['type' => 'string', 'description' => 'https:// address of the website.']],
                'required' => ['url'],
            ],
            'output_schema' => ['type' => 'object'],
            'execute_callback' => fn (array $input): array|WP_Error => $this->inspector->inspect((string) $input['url']),
            'permission_callback' => $permission,
            'meta' => [
                'show_in_rest' => true,
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true],
            ],
        ]);
    }

    public static function designSchema(): array {
        $colors = [];

        foreach (OfferDesign::COLOR_KEYS as $key) {
            $colors[$key] = ['type' => 'string', 'pattern' => '^#[0-9a-fA-F]{3,8}$'];
        }

        return [
            'type' => 'object',
            'properties' => [
                'base' => [
                    'type' => 'string',
                    'enum' => OfferDesign::BASES,
                    'description' => 'Starter layout for a new template without source_template_id or content. classic: centered header, hero, note, product cards. editorial: magazine masthead, split headline and intro, note as pull quote, the picks as covers. letter: personal letter on a paper card led by the note, compact product list. spotlight: bold full-bleed banner, perks strip, big product tiles with price tags, sticky checkout bar.',
                ],
                'use_brand' => ['type' => 'boolean', 'description' => 'Start from the store\'s captured brand colors/fonts. Default true.'],
                'colors' => [
                    'type' => 'object',
                    'description' => 'Hex colors. primary: buttons, greeting and banners; secondary: prices and button hover; accent: highlights and gradient end; background/surface/border: page, cards, lines; text/text_muted: copy. Text must contrast with background and surface; background must contrast with primary (it is the button text color).',
                    'properties' => $colors,
                ],
                'fonts' => [
                    'type' => 'object',
                    'description' => 'Font keys. System fonts need no download; the others are Google Fonts loaded automatically: ' . implode(', ', array_map(static fn (array $f): string => $f['value'] . ' (' . $f['label'] . ', ' . $f['category'] . ')', FontCatalog::options())),
                    'properties' => [
                        'heading' => ['type' => 'string', 'enum' => array_keys(FontCatalog::all())],
                        'body' => ['type' => 'string', 'enum' => array_keys(FontCatalog::all())],
                    ],
                ],
                'tone' => ['type' => 'string', 'maxLength' => 300, 'description' => 'Copy tone for the AI writer, e.g. "warm, playful, eco-conscious".'],
                'note_guidance' => ['type' => 'string', 'maxLength' => 500, 'description' => 'What the personal note to each customer should say; leave empty for no note.'],
                'custom_css' => ['type' => 'string', 'maxLength' => 6000, 'description' => 'Optional extra CSS, e.g. :root { --pofsf-radius: 12px; } for the corner radius of cards, images and buttons. Block classes: .pofsf-branding (.pofsf-logo, .pofsf-site-icon, .pofsf-store-name, .pofsf-branding__link), .pofsf-headline, .pofsf-text (--overheadline, --subheadline, --greeting, --body, --additional; each text a p.pofsf-text__item), .pofsf-products (--story, --feature, --lookbook, --numbered, --catalogue, --gallery, --showcase), .pofsf-product (--first), .pofsf-product__media, .pofsf-product__label, .pofsf-product__number, .pofsf-product__name, .pofsf-product__price, .pofsf-product__title, .pofsf-product__story, .pofsf-offer-action (--cart, --shop, --product), .pofsf-offer-action__button. Group styles: .is-style-pofsf-banner, -paper, -masthead, -strip, -sticky-bar. Variables: --pofsf-primary, --pofsf-secondary, --pofsf-accent, --pofsf-background, --pofsf-surface, --pofsf-border, --pofsf-text, --pofsf-text-muted, --pofsf-radius, --pofsf-font-heading, --pofsf-font-body.'],
            ],
        ];
    }

    public function listTemplates(): array {
        return [
            'templates' => array_map(static fn (array $t): array => [
                'template_id' => $t['id'],
                'name' => $t['name'],
                'description' => $t['description'],
                'is_default' => $t['is_default'],
                'builtin' => $t['builtin'],
                'design' => $t['design']->toArray(),
            ], $this->templates->all()),
        ];
    }

    public function saveTemplate(array $input): array|WP_Error {
        $templateId = (int) ($input['template_id'] ?? 0);
        $content = isset($input['content']) && '' !== trim((string) $input['content'])
            // AI-written markup: strip scripts and anything else post content may not contain.
            ? wp_kses_post((string) $input['content'])
            : null;

        if (null === $content && 0 === $templateId && !empty($input['source_template_id'])) {
            $source = $this->templates->find((int) $input['source_template_id']);

            if (null === $source) {
                return new WP_Error('pofsf_template_missing', 'Source template not found.');
            }

            $content = $source['content'];
        }

        $id = $this->templates->save(
            (string) $input['name'],
            (string) ($input['description'] ?? ''),
            OfferDesign::fromArray((array) $input['design']),
            $templateId,
            $content,
        );

        if ($id instanceof WP_Error) {
            return $id;
        }

        if (!empty($input['set_default'])) {
            $this->templates->setDefault($id);
        }

        return [
            'template_id' => $id,
            'preview_url' => self::previewUrl($id),
            'message' => sprintf('Template "%s" saved as ID %d.', sanitize_text_field((string) $input['name']), $id)
                . (!empty($input['set_default']) ? ' It is now the default for new offers.' : ''),
        ];
    }

    public function applyTemplate(array $input): array|WP_Error {
        $offerId = (int) $input['offer_id'];
        $result = $this->pipeline->restyle(
            $offerId,
            (int) $input['template_id'],
            isset($input['additional_text']) ? (string) $input['additional_text'] : null,
        );

        if ($result instanceof WP_Error) {
            return $result;
        }

        $offer = $this->offers->find($offerId);
        $published = null !== $offer && '' !== OfferPublisher::record($offer)['space_id'];

        return [
            'message' => sprintf('Offer #%d restyled.', $offerId)
                . ($published ? ' It is already on Spacefast: use "Update Space" in the Offers tab to publish the new design.' : ''),
        ];
    }

    public function deleteTemplate(array $input): array|WP_Error {
        $id = (int) ($input['template_id'] ?? 0);
        $template = $this->templates->find($id);

        if (null === $template) {
            return new WP_Error('pofsf_template_missing', 'Template not found.');
        }

        if ('' !== $template['builtin']) {
            return new WP_Error('pofsf_template_builtin', 'Built-in templates cannot be deleted.');
        }

        $offerIds = array_map(static fn (array $o): int => (int) $o['id'], $this->offers->findByTemplate($id));
        $uses = [] === $offerIds ? 'No offers use it.' : 'Offers #' . implode(', #', $offerIds) . ' keep their copy of it, so their pages do not change.';

        if (!empty($input['dry_run'])) {
            return ['template_id' => $id, 'name' => $template['name'], 'deleted' => false, 'offer_ids' => $offerIds, 'message' => sprintf('Would delete template "%s". %s', $template['name'], $uses)];
        }

        $deleted = $this->templates->delete($id);

        if ($deleted instanceof WP_Error) {
            return $deleted;
        }

        return ['template_id' => $id, 'name' => $template['name'], 'deleted' => true, 'offer_ids' => $offerIds, 'message' => sprintf('Template "%s" deleted. %s', $template['name'], $uses)];
    }

    public function restoreTemplate(array $input): array|WP_Error {
        $offer = $this->offers->find((int) $input['offer_id']);

        if (null === $offer) {
            return new WP_Error('pofsf_offer_missing', 'Offer not found.');
        }

        $oldId = (int) ($offer['offer_data']['template_id'] ?? 0);
        $offerIds = array_map(static fn (array $o): int => (int) $o['id'], $this->offers->findByTemplate($oldId));
        $id = $this->pipeline->restoreTemplate((int) $offer['id']);

        if ($id instanceof WP_Error) {
            return $id;
        }

        $name = (string) ($this->templates->find($id)['name'] ?? '');

        return [
            'template_id' => $id,
            'name' => $name,
            'offer_ids' => $offerIds,
            'preview_url' => self::previewUrl($id),
            'message' => sprintf('Template "%s" restored as ID %d; offers %s follow it again. It can be edited in the Templates tab.', $name, $id, '#' . implode(', #', $offerIds)),
        ];
    }

    /**
     * Read-only admin URL (no nonce) so it can be shared in chat replies.
     */
    public static function previewUrl(int $templateId): string {
        return add_query_arg([
            'page' => \Micemade\PersonalizedOffers\Admin\OffersPage::SLUG,
            'pofsf_preview_template' => $templateId,
        ], admin_url('admin.php'));
    }
}
