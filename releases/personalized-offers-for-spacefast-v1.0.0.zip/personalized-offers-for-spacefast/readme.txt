=== Personalized Offers for Spacefast ===
Contributors: micemade
Tags: woocommerce, personalization, offers, coupons, landing page
Requires at least: 7.0
Tested up to: 7.1
Requires PHP: 8.3
Stable tag: 1.0.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Personalized offer pages for your WooCommerce customers, published as Spacefast sites, with a one-click way back to checkout.

== Description ==

Personalized Offers for Spacefast turns a customer's shopping history into a small, on-brand offer page: a few products picked from the categories they like, a personal greeting, and an offer action button that fills their cart with the picks and applies a free-shipping coupon, or opens the shop or a product page showing the picks.

* **Offers for one customer, a group, or everyone** – single, group and public offers, each with an expiry date and a usage limit.
* **Product picks from purchase history** – favourite categories, sizes and colours, price range and wishlists; products the customer already bought are left out.
* **Your brand** – the store logo, colours and fonts are captured from your site and kept as versioned brand snapshots.
* **Block-based templates** – design offer pages in the block editor with dedicated offer blocks (branding, headline, offer texts, products, offer action button). The Offer branding block shows the store logo and/or title, with its own size, alignment, background, typography and link settings. Offer texts are fields you add per offer, one of each type — greeting, overheadline, subheadline, body text, additional text — and the template shows each where you place an Offer text block of that type.
* **Publish to Spacefast** – each offer becomes its own Spacefast Space with a private share link or a public address. Re-publishing an edited offer keeps the links you already shared.
* **Checkout hand-off** – the offer link rebuilds the cart, prefills the customer's address and applies an email-restricted free-shipping coupon.
* **Assistant** – an in-admin chat assistant (using the AI provider connected in WordPress) helps create and edit offers and templates. Plugin functions are also exposed as WordPress Abilities.
* **Privacy** – integrates with the WordPress personal data eraser.

Without a Spacefast account you can still download each offer page as a ZIP file.

== External services ==

This plugin connects to the following external services. Nothing is sent until a store manager uses the feature described.

= Spacefast =

Used to publish offer pages as Spacefast Spaces (static websites). Requests go to `https://api.spacefast.com` only when a store manager connects a Spacefast account, publishes, updates or deletes an offer page.

* Sent when connecting with an API key: the API key.
* Sent when signing in with Spacefast: once per site, the site's name and address and the plugin's return address, to register the site for sign-in. The store manager then signs in or creates an account on Spacefast's own page; the plugin receives a sign-in code, swaps it for tokens, and reads the account's email address and teams. If the account has no team, one named after the store is created.
* Sent while signed in: the stored tokens, to renew the sign-in. On Disconnect or uninstall the plugin asks Spacefast to revoke them.
* Sent when publishing: the offer page as a ZIP file (page HTML with the customer's first name if used in the copy, the offered products with names, images and prices, the store's logo, colours and fonts, and the checkout link) and the page title.
* Sent when deleting: the ID of the offer's Space.

Spacefast website and documentation: https://spacefast.com/ and https://spacefast.com/docs

= Google Fonts =

Offer pages and templates may use web fonts from Google Fonts. When an offer page that uses one is opened, the visitor's browser loads the font stylesheet from `https://fonts.googleapis.com` and font files from `https://fonts.gstatic.com`. Google receives the visitor's IP address and browser details.

Google Fonts privacy FAQ: https://developers.google.com/fonts/faq/privacy – Google privacy policy: https://policies.google.com/privacy

= Website style inspection =

When a store manager asks the assistant to design a template inspired by a website, the plugin fetches that public web page (and its stylesheets) to read its colours and fonts. Only the address the manager entered is requested; no store or customer data is sent.

= AI provider =

The assistant uses the AI provider connected in WordPress (Settings → Connectors). The manager's chat messages and the offer, template and customer-summary data needed to answer them are sent to that provider under its own terms and privacy policy. Offers themselves are composed without AI.

== Installation ==

1. Install and activate WooCommerce (8.0 or newer).
2. Upload the plugin to `/wp-content/plugins/personalized-offers-for-spacefast` or install it from the Plugins screen, then activate it.
3. Go to WooCommerce → Personalized Offers for Spacefast. The setup guide opens on first visit: it captures your brand, then connects Spacefast. Choose **Continue with Spacefast** to sign in or create a free account, or paste a team API key (or define `POFSF_SPACEFAST_API_KEY` in `wp-config.php`).
4. Create an offer, preview it, and publish it to Spacefast or download it as a ZIP.

== Frequently Asked Questions ==

= Do I need a Spacefast account? =

Only to publish offer pages from WordPress. You can create a free account from the plugin's setup guide with **Continue with Spacefast**, without copying an API key. Without an account you can download each offer page as a ZIP file and host it yourself.

= Why would I use an API key instead of signing in? =

Signing in needs a site served over `https://`. Live updates (Spacefast telling the plugin when a Space changes) also need a team API key, which you create in the Spacefast dashboard. Everything else works the same either way.

= Who can see a published offer? =

By default an offer is published with a private Spacefast share link that only people you send it to can open. Public offers can be published at the Space's public address.

= What happens when a customer uses an offer? =

The checkout link checks the offer's expiry and usage limit, fills the cart with the offered products, prefills the customer's address, applies the free-shipping coupon and opens checkout. The order is counted as a use of the offer.

== Changelog ==

= 1.0.0 =
* First release.
