<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var array $settings */
/** @var array|null $active_brand */
/** @var array $brand_versions */
/** @var array $ai_status */
?>
<div class="pofsf-settings-wrap">
	<h2><?php esc_html_e( 'Brand Snapshot', 'personalized-offers-for-spacefast' ); ?></h2>
	<p><?php esc_html_e( 'A locked brand snapshot is active. Generated pages use these tokens only.', 'personalized-offers-for-spacefast' ); ?></p>
	<div
		id="pofsf-brand-app"
		data-versions="<?php echo esc_attr( wp_json_encode( $brand_versions ) ); ?>"
		data-brand-name="<?php echo esc_attr( $active_brand['identity']['name'] ?? '' ); ?>"
	>
		<p><?php esc_html_e( 'Loading brand panel…', 'personalized-offers-for-spacefast' ); ?></p>
	</div>

	<h2><?php esc_html_e( 'AI Connector', 'personalized-offers-for-spacefast' ); ?></h2>
	<div
		id="pofsf-ai-app"
		data-message="<?php echo esc_attr( $ai_status['message'] ?? '' ); ?>"
		data-providers="<?php echo esc_attr( wp_json_encode( $ai_status['providers'] ?? [] ) ); ?>"
		data-supported="<?php echo ! empty( $ai_status['supported'] ) ? '1' : '0'; ?>"
	>
		<p><?php esc_html_e( 'Loading AI status…', 'personalized-offers-for-spacefast' ); ?></p>
	</div>

	<h2><?php esc_html_e( 'Offer defaults', 'personalized-offers-for-spacefast' ); ?></h2>
	<table class="form-table" role="presentation">
		<tr>
			<th scope="row"><label for="pofsf-offer-expiry"><?php esc_html_e( 'Default offer expiry (days)', 'personalized-offers-for-spacefast' ); ?></label></th>
			<td><input type="number" id="pofsf-offer-expiry" name="pofsf_settings[offer_default_expiry]" min="1" max="365" value="<?php echo esc_attr( $settings['offer_default_expiry'] ); ?>" class="small-text" /></td>
		</tr>
		<tr>
			<th scope="row"><label for="pofsf-max-uses"><?php esc_html_e( 'Max uses per offer', 'personalized-offers-for-spacefast' ); ?></label></th>
			<td><input type="number" id="pofsf-max-uses" name="pofsf_settings[offer_max_uses]" min="1" max="1000000" value="<?php echo esc_attr( $settings['offer_max_uses'] ); ?>" class="small-text" /></td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Coupon', 'personalized-offers-for-spacefast' ); ?></th>
			<td>
				<label>
					<input type="checkbox" name="pofsf_settings[free_shipping_coupon]" value="1" <?php checked( ! empty( $settings['free_shipping_coupon'] ) ); ?> />
					<?php esc_html_e( 'Free shipping on offer coupon', 'personalized-offers-for-spacefast' ); ?>
				</label>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Notifications', 'personalized-offers-for-spacefast' ); ?></th>
			<td>
				<label>
					<input type="checkbox" name="pofsf_settings[email_notifications]" value="1" <?php checked( ! empty( $settings['email_notifications'] ) ); ?> />
					<?php esc_html_e( 'Email me when offer ZIP is ready', 'personalized-offers-for-spacefast' ); ?>
				</label>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Customer preferences', 'personalized-offers-for-spacefast' ); ?></th>
			<td>
				<label style="display:block;">
					<input type="checkbox" name="pofsf_settings[preferences_page]" value="1" <?php checked( ! empty( $settings['preferences_page'] ) ); ?> />
					<?php esc_html_e( 'Add a “My preferences” page to My Account', 'personalized-offers-for-spacefast' ); ?>
				</label>
				<label style="display:block;">
					<input type="checkbox" name="pofsf_settings[record_searches]" value="1" <?php checked( ! empty( $settings['record_searches'] ) ); ?> />
					<?php esc_html_e( 'Let customers allow recording their product searches', 'personalized-offers-for-spacefast' ); ?>
				</label>
				<p class="description"><?php esc_html_e( 'Customers choose their sizes, colours and favourite categories, with their consent, and new offers for them use these. Mention it in your privacy policy.', 'personalized-offers-for-spacefast' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Advanced', 'personalized-offers-for-spacefast' ); ?></th>
			<td>
				<label style="display:block;">
					<input type="checkbox" name="pofsf_settings[debug_logging]" value="1" <?php checked( ! empty( $settings['debug_logging'] ) ); ?> />
					<?php esc_html_e( 'Enable debug logging', 'personalized-offers-for-spacefast' ); ?>
				</label>
			</td>
		</tr>
	</table>
</div>
