/**
 * The offer page's own cart (published on Spacefast, no build step).
 *
 * Product data comes from products.json next to the page (or, in admin
 * previews, the inline #pofsf-offer-data): the offer's picks as the
 * WooCommerce Store API describes them, with each variable product's
 * variations. "Add to cart" opens a quantity popup, "Select options" a
 * popup with the product's options and quantity; the cart lives in this browser (localStorage).
 * "Complete purchase" leads through the offer link to the store's checkout
 * with the chosen lines (pofsf_cart), where WooCommerce prices them, checks
 * stock and applies the offer's discount.
 *
 * When the store is reachable, prices and stock are refreshed from the
 * public Store API (GET /wc/store/v1/products); otherwise the published
 * data is used.
 */
(function () {
	'use strict';

	var script = document.currentScript;
	var CART_TTL = 14 * 24 * 60 * 60 * 1000;
	var data;
	var cart = [];
	var storageKey;
	var drawer;
	var toggle;
	var lastFocus;

	function t(key) {
		return (data.i18n && data.i18n[key]) || key;
	}

	function el(tag, attrs, children) {
		var node = document.createElement(tag);

		Object.keys(attrs || {}).forEach(function (name) {
			var value = attrs[name];

			if (value === false || value === null || value === undefined) {
				return;
			}

			if (name === 'text') {
				node.textContent = value;
			} else if (name.indexOf('on') === 0) {
				node.addEventListener(name.slice(2), value);
			} else {
				node.setAttribute(name, value === true ? '' : value);
			}
		});

		(children || []).forEach(function (child) {
			if (child) {
				node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
			}
		});

		return node;
	}

	/* ---------- Prices (Store API minor units) ---------- */

	function formatPrice(minor) {
		var c = data.currency || {};
		var unit = Number(c.minor_unit || 0);
		var value = Number(minor || 0) / Math.pow(10, unit);
		var parts = value.toFixed(unit).split('.');

		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, c.thousand_separator === undefined ? ',' : c.thousand_separator);

		return (c.prefix || '') + parts.join(c.decimal_separator || '.') + (c.suffix || '');
	}

	/* ---------- Products and variations ---------- */

	function productOf(pick) {
		for (var i = 0; i < data.products.length; i++) {
			if (data.products[i].pick === pick) {
				return data.products[i];
			}
		}

		return null;
	}

	function productById(id) {
		for (var i = 0; i < data.products.length; i++) {
			if (data.products[i].id === id) {
				return data.products[i];
			}
		}

		return null;
	}

	function variationById(product, id) {
		for (var i = 0; i < (product.variations || []).length; i++) {
			if (product.variations[i].id === id) {
				return product.variations[i];
			}
		}

		return null;
	}

	/** The variation matching every chosen value ('' on a variation = any value). */
	function findVariation(product, chosen) {
		var keys = product.attributes.map(function (attribute) {
			return attribute.key;
		});

		if (keys.some(function (key) { return !chosen[key]; })) {
			return null;
		}

		for (var i = 0; i < product.variations.length; i++) {
			var variation = product.variations[i];
			var matches = keys.every(function (key) {
				var value = variation.attributes[key];

				return value === undefined || value === '' || value === chosen[key];
			});

			if (matches) {
				return variation;
			}
		}

		return null;
	}

	function buyable(item) {
		return Boolean(item && item.purchasable && item.in_stock);
	}

	function limitsOf(product, variation) {
		var limits = (variation && variation.limits) || product.limits || {};
		var max = product.sold_individually ? 1 : Number(limits.maximum || 99);

		return { min: Number(limits.minimum || 1), max: Math.max(1, Math.min(99, max)), step: Number(limits.multiple_of || 1) };
	}

	/** "Size: L, Color: Purple" for a cart line. */
	function summary(product, attributes) {
		return product.attributes
			.map(function (attribute) {
				var value = attributes[attribute.key];
				var option = attribute.options.filter(function (o) { return o.value === value; })[0];

				return value ? attribute.label + ': ' + (option ? option.label : value) : '';
			})
			.filter(Boolean)
			.join(', ');
	}

	/* ---------- Cart storage ---------- */

	function load() {
		try {
			var stored = JSON.parse(window.localStorage.getItem(storageKey) || 'null');

			if (stored && Date.now() - stored.saved < CART_TTL && Array.isArray(stored.lines)) {
				cart = stored.lines.filter(function (line) {
					return productById(line.p);
				});
			}
		} catch (e) {
			cart = [];
		}
	}

	function save() {
		try {
			window.localStorage.setItem(storageKey, JSON.stringify({ saved: Date.now(), lines: cart }));
		} catch (e) {
			// Private mode: the cart lasts while the page is open.
		}
	}

	function add(product, variation, attributes, quantity) {
		var key = product.id + ':' + (variation ? variation.id : 0) + ':' + JSON.stringify(attributes || {});
		var limits = limitsOf(product, variation);
		var line = cart.filter(function (l) { return l.key === key; })[0];

		if (line) {
			line.q = Math.min(limits.max, line.q + quantity);
		} else {
			cart.push({ key: key, p: product.id, v: variation ? variation.id : 0, a: attributes || {}, q: Math.min(limits.max, quantity) });
		}

		save();
		renderCart();
		announce(t('added') + ': ' + product.name);
		bump();
	}

	function lineInfo(line) {
		var product = productById(line.p);
		var variation = line.v ? variationById(product, line.v) : null;
		var item = variation || product;

		return {
			product: product,
			variation: variation,
			price: Number((item.prices && item.prices.price) || 0),
			image: (variation && variation.image) || product.image,
			available: buyable(item),
		};
	}

	/* ---------- Checkout ---------- */

	function base64url(text) {
		var bytes = new TextEncoder().encode(text);
		var binary = '';

		bytes.forEach(function (b) {
			binary += String.fromCharCode(b);
		});

		return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
	}

	/** Group offers: each customer's link ends in #r=TOKEN, which replaces the page's own token. */
	function checkoutBase() {
		var url = data.checkout;
		var match = /(?:^#|&)r=([0-9a-f]{32})(?:&|$)/.exec(window.location.hash);

		return match ? url.replace(/([?&]pofsf_offer=)[^&#]*/, '$1' + match[1]) : url;
	}

	/** The cart as pofsf_cart lines: [product_id, variation_id, quantity, {open attribute: value}]. */
	function cartLines() {
		return cart
			.filter(function (line) { return lineInfo(line).available; })
			.map(function (line) {
				var product = productById(line.p);
				var variation = line.v ? variationById(product, line.v) : null;
				var open = {};

				// Only the values the variation leaves open ("any") travel; the rest are the variation's own.
				Object.keys(line.a || {}).forEach(function (key) {
					if (variation && variation.attributes[key] === '') {
						open[key] = line.a[key];
					}
				});

				return [line.p, line.v, line.q, open];
			});
	}

	function checkoutUrl() {
		var base = checkoutBase();

		return base + (base.indexOf('?') === -1 ? '?' : '&') + 'pofsf_cart=' + base64url(JSON.stringify(cartLines()));
	}

	/* ---------- Cart drawer ---------- */

	var live;

	function announce(text) {
		if (live) {
			live.textContent = '';
			window.setTimeout(function () { live.textContent = text; }, 50);
		}
	}

	function bump() {
		toggle.classList.remove('is-bumped');
		void toggle.offsetWidth;
		toggle.classList.add('is-bumped');
	}

	function count() {
		return cart.reduce(function (sum, line) { return sum + line.q; }, 0);
	}

	function buildCart() {
		live = el('div', { class: 'pofsf-visually-hidden', 'aria-live': 'polite' });
		toggle = el('button', { type: 'button', class: 'pofsf-cart-toggle', 'aria-label': t('openCart'), hidden: true, onclick: openCart }, [
			el('span', { class: 'pofsf-cart-toggle__icon', 'aria-hidden': 'true' }),
			el('span', { class: 'pofsf-cart-toggle__count' }),
		]);
		drawer = el('div', { class: 'pofsf-cart', hidden: true }, [
			el('div', { class: 'pofsf-cart__backdrop', onclick: closeCart }),
			el('aside', { class: 'pofsf-cart__panel', role: 'dialog', 'aria-modal': 'true', 'aria-label': t('cart'), tabindex: '-1' }),
		]);

		document.body.appendChild(live);
		document.body.appendChild(toggle);
		document.body.appendChild(drawer);
		document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape' && !drawer.hidden) {
				closeCart();
			}
		});
	}

	function openCart() {
		lastFocus = document.activeElement;
		renderCart();
		drawer.hidden = false;
		document.documentElement.classList.add('pofsf-cart-open');
		drawer.querySelector('.pofsf-cart__panel').focus();
	}

	function closeCart() {
		drawer.hidden = true;
		document.documentElement.classList.remove('pofsf-cart-open');

		if (lastFocus && lastFocus.focus) {
			lastFocus.focus();
		}
	}

	function setQuantity(line, quantity) {
		var info = lineInfo(line);
		var limits = limitsOf(info.product, info.variation);

		if (quantity <= 0) {
			cart = cart.filter(function (l) { return l !== line; });
		} else {
			line.q = Math.max(limits.min, Math.min(limits.max, quantity));
		}

		save();
		renderCart();
	}

	function renderCart() {
		var items = count();
		var panel = drawer.querySelector('.pofsf-cart__panel');
		var subtotal = 0;
		var list = el('ul', { class: 'pofsf-cart__lines' });

		toggle.hidden = items === 0;
		renderActionCounts();
		toggle.querySelector('.pofsf-cart-toggle__count').textContent = String(items);

		cart.forEach(function (line) {
			var info = lineInfo(line);
			var limits = limitsOf(info.product, info.variation);

			if (info.available) {
				subtotal += info.price * line.q;
			}

			list.appendChild(
				el('li', { class: 'pofsf-cart__line' + (info.available ? '' : ' is-unavailable') }, [
					info.image ? el('img', { class: 'pofsf-cart__image', src: info.image, alt: '' }) : null,
					el('div', { class: 'pofsf-cart__info' }, [
						el('p', { class: 'pofsf-cart__name', text: info.product.name }),
						line.v ? el('p', { class: 'pofsf-cart__meta', text: summary(info.product, Object.assign({}, info.variation ? info.variation.attributes : {}, line.a)) }) : null,
						info.available ? null : el('p', { class: 'pofsf-cart__meta', text: t('outOfStock') }),
						el('div', { class: 'pofsf-cart__qty' }, [
							el('button', { type: 'button', 'aria-label': t('decrease'), text: '−', onclick: function () { setQuantity(line, line.q - limits.step); } }),
							el('span', { 'aria-label': t('quantity'), text: String(line.q) }),
							el('button', { type: 'button', 'aria-label': t('increase'), text: '+', disabled: line.q >= limits.max, onclick: function () { setQuantity(line, line.q + limits.step); } }),
							el('button', { type: 'button', class: 'pofsf-cart__remove', text: t('remove'), onclick: function () { setQuantity(line, 0); } }),
						]),
					]),
					el('p', { class: 'pofsf-cart__total', text: formatPrice(info.price * line.q) }),
				])
			);
		});

		var complete = el('a', { class: 'pofsf-cart__complete', href: items ? checkoutUrl() : '#', 'aria-disabled': items ? false : 'true', text: t('complete') });

		if (!items) {
			complete.addEventListener('click', function (event) { event.preventDefault(); });
		}

		panel.replaceChildren(
			el('div', { class: 'pofsf-cart__header' }, [
				el('h2', { class: 'pofsf-cart__title', text: t('cart') }),
				el('button', { type: 'button', class: 'pofsf-cart__close', 'aria-label': t('close'), text: '×', onclick: closeCart }),
			]),
			items ? list : el('p', { class: 'pofsf-cart__empty', text: t('empty') }),
			el('div', { class: 'pofsf-cart__footer' }, [
				el('p', { class: 'pofsf-cart__subtotal' }, [el('span', { text: t('subtotal') }), el('strong', { text: formatPrice(subtotal) })]),
				el('p', { class: 'pofsf-cart__note', text: t('note') }),
				complete,
			])
		);
	}

	/* ---------- Product buttons and options ---------- */

	function setPrice(article, item) {
		var price = article.querySelector('.pofsf-product__price');

		if (price && item && item.prices) {
			price.textContent = formatPrice(item.prices.price);
		}
	}

	function setImage(article, src) {
		var image = article.querySelector('.pofsf-product__media img');

		if (image && src) {
			image.removeAttribute('srcset');
			image.src = src;
		}
	}

	function initialChoice(product) {
		var chosen = {};
		var selected = product.selected ? variationById(product, product.selected) : null;

		product.attributes.forEach(function (attribute) {
			var value = (selected && selected.attributes[attribute.key]) || (product.defaults || {})[attribute.key] || '';

			chosen[attribute.key] = value;
		});

		return chosen;
	}

	/* ---------- Popover (quantity, options) ---------- */

	var popover = null;

	/**
	 * One small popup at a time, absolutely positioned in the page under the
	 * button that opened it (in <body>, so product cards that clip their
	 * content cannot cut it off). Closes on Escape, a click outside it, and
	 * after adding to the cart.
	 */
	function closePopover(returnFocus) {
		if (!popover) {
			return;
		}

		var current = popover;

		popover = null;
		current.node.remove();
		current.button.setAttribute('aria-expanded', 'false');
		window.removeEventListener('resize', current.place);

		if (returnFocus) {
			current.button.focus();
		}
	}

	function openPopover(button, label, content) {
		var node = el('div', { class: 'pofsf-pop', role: 'dialog', 'aria-label': label }, [content]);

		closePopover(false);

		function place() {
			var rect = button.getBoundingClientRect();
			var width = node.offsetWidth;
			var left = Math.max(8, Math.min(rect.left, document.documentElement.clientWidth - width - 8));
			var below = rect.bottom + 8;
			// Above the button when there is no room under it.
			var top = below + node.offsetHeight > window.innerHeight && rect.top - node.offsetHeight - 8 > 0 ? rect.top - node.offsetHeight - 8 : below;

			node.style.left = left + window.scrollX + 'px';
			node.style.top = top + window.scrollY + 'px';
			node.classList.toggle('is-above', top < rect.top);
		}

		document.body.appendChild(node);
		popover = { node: node, button: button, place: place };
		button.setAttribute('aria-expanded', 'true');
		place();
		window.addEventListener('resize', place);

		var first = node.querySelector('select, input, button');

		if (first) {
			first.focus();
		}

		return popover;
	}

	document.addEventListener('mousedown', function (event) {
		if (popover && !popover.node.contains(event.target) && !popover.button.contains(event.target)) {
			closePopover(false);
		}
	});

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape' && popover) {
			closePopover(true);
		}
	});

	/** − [n] + within the product's limits (Store API add_to_cart). */
	function stepper(initial) {
		var limits = initial;
		var input = el('input', { type: 'number', class: 'pofsf-qty__input', inputmode: 'numeric', min: String(limits.min), max: String(limits.max), step: String(limits.step), value: String(limits.min), 'aria-label': t('quantity') });

		function clamp(value) {
			return Math.max(limits.min, Math.min(limits.max, value));
		}

		function step(delta) {
			input.value = String(clamp((parseInt(input.value, 10) || limits.min) + delta * limits.step));
		}

		return {
			node: el('div', { class: 'pofsf-qty' }, [
				el('button', { type: 'button', class: 'pofsf-qty__step', 'aria-label': t('decrease'), text: '−', onclick: function () { step(-1); } }),
				input,
				el('button', { type: 'button', class: 'pofsf-qty__step', 'aria-label': t('increase'), text: '+', onclick: function () { step(1); } }),
			]),
			value: function () {
				return clamp(parseInt(input.value, 10) || limits.min);
			},
			setLimits: function (next) {
				limits = next;
				input.min = String(next.min);
				input.max = String(next.max);
				input.step = String(next.step);
				input.value = String(clamp(parseInt(input.value, 10) || next.min));
			},
		};
	}

	/** Brief "Added" on the button that opened the popup. */
	function confirmAdded(button) {
		var text = button.textContent;

		button.classList.add('is-added');
		button.textContent = '✓ ' + t('added');
		window.setTimeout(function () {
			button.classList.remove('is-added');
			button.textContent = text;
		}, 1600);
	}

	/** Simple product: the quantity, then Add to cart. */
	function quantityPopover(product, button) {
		var qty = stepper(limitsOf(product, null));
		var form = el('form', { class: 'pofsf-pop__form' }, [
			el('p', { class: 'pofsf-pop__title', text: product.name }),
			el('div', { class: 'pofsf-pop__row' }, [qty.node, el('button', { type: 'submit', class: 'pofsf-pop__add', text: t('addToCart') })]),
		]);

		form.addEventListener('submit', function (event) {
			event.preventDefault();
			add(product, null, {}, qty.value());
			closePopover(true);
			confirmAdded(button);
		});

		openPopover(button, product.name, form);
	}

	/** Variable product: its options and the quantity, then Add to cart. */
	function optionsPopover(article, product, button) {
		var chosen = initialChoice(product);
		var qty = stepper(limitsOf(product, null));
		var status = el('p', { class: 'pofsf-pop__status', 'aria-live': 'polite' });
		var price = el('strong', { class: 'pofsf-pop__price' });
		var submit = el('button', { type: 'submit', class: 'pofsf-pop__add', text: t('addToCart') });
		var fields = product.attributes.map(function (attribute) {
			var id = 'pofsf-' + product.pick + '-' + attribute.key;
			var select = el('select', { id: id }, [el('option', { value: '', text: t('chooseAn') })].concat(
				attribute.options.map(function (option) {
					return el('option', { value: option.value, text: option.label, selected: chosen[attribute.key] === option.value });
				})
			));

			select.addEventListener('change', function () {
				chosen[attribute.key] = select.value;
				update();
			});

			return el('p', { class: 'pofsf-pop__field' }, [el('label', { for: id, text: attribute.label }), select]);
		});

		var form = el('form', { class: 'pofsf-pop__form' }, [el('p', { class: 'pofsf-pop__title', text: product.name })].concat(fields, [
			el('div', { class: 'pofsf-pop__summary' }, [price, status]),
			el('div', { class: 'pofsf-pop__row' }, [qty.node, submit]),
		]));

		function update() {
			var variation = findVariation(product, chosen);
			var ok = buyable(variation);

			submit.disabled = !ok;
			qty.setLimits(limitsOf(product, variation));
			price.textContent = variation ? formatPrice(variation.prices.price) : '';
			status.textContent = !variation
				? (product.attributes.every(function (a) { return chosen[a.key]; }) ? t('unavailable') : '')
				: ok ? (variation.stock || '') : t('outOfStock');

			if (variation) {
				setPrice(article, variation);
				setImage(article, variation.image);
			}

			if (popover) {
				popover.place();
			}
		}

		form.addEventListener('submit', function (event) {
			var variation = findVariation(product, chosen);
			var attributes = {};

			event.preventDefault();

			if (!buyable(variation)) {
				update();
				return;
			}

			product.attributes.forEach(function (attribute) {
				attributes[attribute.key] = chosen[attribute.key];
			});

			add(product, variation, attributes, qty.value());
			closePopover(true);
			confirmAdded(button);
		});

		openPopover(button, product.name, form);
		update();
	}

	/** Toggles the button's popup. */
	function toggleWith(button, open) {
		button.setAttribute('aria-haspopup', 'dialog');
		button.setAttribute('aria-expanded', 'false');
		button.setAttribute('role', 'button');
		button.addEventListener('click', function (event) {
			event.preventDefault();

			if (popover && popover.button === button) {
				closePopover(true);
			} else {
				open();
			}
		});
	}

	/** The published "Out of stock" note, once the data says the product can be bought. */
	function removeStock(button) {
		var stock = button.parentNode.querySelector('.pofsf-product__stock');

		if (stock) {
			stock.remove();
		}

		button.classList.remove('pofsf-product__button--more');
	}

	function enhanceProducts() {
		document.querySelectorAll('[data-pofsf-pick]').forEach(function (article) {
			var product = productOf(Number(article.getAttribute('data-pofsf-pick')));
			var button = article.querySelector('[data-pofsf-action]');

			if (!product || !button) {
				return;
			}

			if (product.type === 'variable' && product.attributes.length && product.variations.length) {
				button.setAttribute('data-pofsf-action', 'options');
				button.textContent = t('selectOptions');
				removeStock(button);
				toggleWith(button, function () { optionsPopover(article, product, button); });
			} else if (buyable(product) && product.type !== 'variable') {
				button.setAttribute('data-pofsf-action', 'add');
				button.textContent = t('addToCart');
				removeStock(button);
				toggleWith(button, function () { quantityPopover(product, button); });
			}
		});
	}

	/* ---------- Offer action button: the cart to checkout ---------- */

	/**
	 * The Offer action button's form (OfferBlocks::offerActionButton()) sends
	 * the cart's lines to checkout (pofsf_cart); the store applies the offer's
	 * coupon. With an empty cart the form goes without them, and checkout
	 * gets all of the offer's products.
	 */
	function enhanceActionButtons() {
		document.querySelectorAll('form[data-pofsf-checkout]').forEach(function (form) {
			form.addEventListener('submit', function () {
				var field = form.querySelector('input[name="pofsf_cart"]');
				var lines = cartLines();

				if (field) {
					field.value = lines.length ? base64url(JSON.stringify(lines)) : '';
					field.disabled = !lines.length;
				}

				save();
			});
		});
	}

	/** The cart's count on the Offer action buttons. */
	function renderActionCounts() {
		var items = count();

		document.querySelectorAll('.pofsf-offer-action__count').forEach(function (badge) {
			badge.hidden = items === 0;
			badge.textContent = String(items);
		});
	}

	/* ---------- Live prices and stock (Store API) ---------- */

	function storeGet(path) {
		var controller = window.AbortController ? new AbortController() : null;
		var timer = controller ? window.setTimeout(function () { controller.abort(); }, 6000) : null;

		return fetch(data.storeApi + path, { credentials: 'omit', signal: controller ? controller.signal : undefined })
			.then(function (response) {
				window.clearTimeout(timer);

				if (!response.ok) {
					throw new Error(String(response.status));
				}

				return response.json();
			});
	}

	function apply(target, row) {
		if (!target || !row) {
			return;
		}

		target.prices = { price: row.prices.price, regular_price: row.prices.regular_price, sale_price: row.prices.sale_price };
		target.in_stock = Boolean(row.is_in_stock);
		target.purchasable = Boolean(row.is_purchasable);
	}

	function refresh() {
		if (!data.storeApi || !window.fetch) {
			return;
		}

		var ids = data.products.map(function (product) { return product.id; });
		var parents = data.products.filter(function (product) { return product.type === 'variable'; }).map(function (product) { return product.id; });
		var query = ids.map(function (id) { return 'include[]=' + id; }).join('&');

		storeGet('products?per_page=100&' + query)
			.then(function (rows) {
				rows.forEach(function (row) {
					apply(productById(row.id), row);
				});

				if (!parents.length) {
					return null;
				}

				return storeGet('products?type=variation&per_page=100&' + parents.map(function (id) { return 'parent[]=' + id; }).join('&')).then(function (variations) {
					variations.forEach(function (row) {
						data.products.forEach(function (product) {
							apply(variationById(product, row.id), row);
						});
					});
				});
			})
			.then(function () {
				document.querySelectorAll('[data-pofsf-pick]').forEach(function (article) {
					var product = productOf(Number(article.getAttribute('data-pofsf-pick')));

					if (product && product.type !== 'variable') {
						setPrice(article, product);
					}
				});
				renderCart();
			})
			.catch(function () {
				// The store is not reachable from here (local or private): the published data stays.
			});
	}

	/* ---------- Start ---------- */

	function start(loaded) {
		data = loaded;

		if (!data || !Array.isArray(data.products) || !data.products.length) {
			return;
		}

		storageKey = 'pofsf-cart-' + data.offer;
		load();
		buildCart();
		enhanceProducts();
		enhanceActionButtons();
		renderCart();
		refresh();
	}

	function boot() {
		var inline = document.getElementById('pofsf-offer-data');

		if (inline) {
			try {
				start(JSON.parse(inline.textContent));
			} catch (e) {
				// Bad data: the buttons keep their links to the store.
			}

			return;
		}

		var src = script && script.getAttribute('data-pofsf-data');

		if (src && window.fetch) {
			// The data path is relative to the page, like the script's own src.
			fetch(new URL(src, document.baseURI).href)
				.then(function (response) { return response.json(); })
				.then(start)
				.catch(function () {
					// No data (e.g. opened from disk): the buttons keep their links to the store.
				});
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
