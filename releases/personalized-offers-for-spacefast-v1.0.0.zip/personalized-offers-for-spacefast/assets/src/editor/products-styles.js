/**
 * Styles tab of the Offer products block: how the picks look (images,
 * colors, type), stored in the block's `appearance` attribute and applied
 * as CSS variables by OfferBlocks::productsAppearance(). Unset values keep
 * the chosen style's own look.
 */
import { FontSizePicker, PanelColorSettings } from '@wordpress/block-editor';
import {
	BaseControl,
	Button,
	PanelBody,
	RangeControl,
	SelectControl,
	__experimentalToggleGroupControl as ToggleGroupControl,
	__experimentalToggleGroupControlOption as ToggleGroupControlOption,
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';

const STYLE_DEFAULT = __('Style default', 'personalized-offers-for-spacefast');

const RATIOS = [
	{ value: '', label: STYLE_DEFAULT },
	{ value: 'auto', label: __('Original', 'personalized-offers-for-spacefast') },
	{ value: '1', label: __('Square 1:1', 'personalized-offers-for-spacefast') },
	{ value: '4/5', label: __('Portrait 4:5', 'personalized-offers-for-spacefast') },
	{ value: '3/4', label: __('Portrait 3:4', 'personalized-offers-for-spacefast') },
	{ value: '2/3', label: __('Portrait 2:3', 'personalized-offers-for-spacefast') },
	{ value: '3/2', label: __('Landscape 3:2', 'personalized-offers-for-spacefast') },
	{ value: '16/9', label: __('Wide 16:9', 'personalized-offers-for-spacefast') },
];

const WEIGHTS = [
	{ value: '', label: STYLE_DEFAULT },
	{ value: '300', label: __('Light', 'personalized-offers-for-spacefast') },
	{ value: '400', label: __('Regular', 'personalized-offers-for-spacefast') },
	{ value: '500', label: __('Medium', 'personalized-offers-for-spacefast') },
	{ value: '600', label: __('Semi-bold', 'personalized-offers-for-spacefast') },
	{ value: '700', label: __('Bold', 'personalized-offers-for-spacefast') },
	{ value: '800', label: __('Extra bold', 'personalized-offers-for-spacefast') },
	{ value: '900', label: __('Black', 'personalized-offers-for-spacefast') },
];

export default function ProductsStyles({ attributes, setAttributes }) {
	const appearance = attributes.appearance && !Array.isArray(attributes.appearance) ? attributes.appearance : {};

	const set = (key, value) => {
		const next = { ...appearance, [key]: value };

		if (value === '' || value === undefined || value === null) {
			delete next[key];
		}

		setAttributes({ appearance: next });
	};

	const color = (key, label) => ({ label, value: appearance[key], onChange: (value) => set(key, value) });
	const number = (key) => (typeof appearance[key] === 'number' ? appearance[key] : undefined);

	return (
		<>
			<PanelBody title={__('Product images', 'personalized-offers-for-spacefast')} initialOpen={false}>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Aspect ratio', 'personalized-offers-for-spacefast')}
					value={appearance.imageRatio || ''}
					options={RATIOS}
					onChange={(value) => set('imageRatio', value)}
				/>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Fit', 'personalized-offers-for-spacefast')}
					value={appearance.imageFit || ''}
					options={[
						{ value: '', label: STYLE_DEFAULT },
						{ value: 'cover', label: __('Fill the frame (crop)', 'personalized-offers-for-spacefast') },
						{ value: 'contain', label: __('Whole product (no crop)', 'personalized-offers-for-spacefast') },
					]}
					onChange={(value) => set('imageFit', value)}
				/>
				<RangeControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Frame around the image (%)', 'personalized-offers-for-spacefast')}
					min={0}
					max={20}
					allowReset
					value={number('imageInset')}
					onChange={(value) => set('imageInset', value)}
				/>
				<RangeControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Corner radius (px)', 'personalized-offers-for-spacefast')}
					min={0}
					max={64}
					allowReset
					value={number('imageRadius')}
					onChange={(value) => set('imageRadius', value)}
				/>
			</PanelBody>

			<PanelColorSettings
				title={__('Product colors', 'personalized-offers-for-spacefast')}
				initialOpen={false}
				colorSettings={[
					color('titleColor', __('Title', 'personalized-offers-for-spacefast')),
					color('storyColor', __('Story', 'personalized-offers-for-spacefast')),
					color('labelColor', __('Name and details', 'personalized-offers-for-spacefast')),
					color('priceColor', __('Price', 'personalized-offers-for-spacefast')),
					color('numberColor', __('Numbers', 'personalized-offers-for-spacefast')),
					color('cardColor', __('Card background (cover: shade)', 'personalized-offers-for-spacefast')),
					color('imageBackdrop', __('Behind the image', 'personalized-offers-for-spacefast')),
					color('lineColor', __('Lines and frames', 'personalized-offers-for-spacefast')),
				]}
			/>

			<PanelBody title={__('Product typography', 'personalized-offers-for-spacefast')} initialOpen={false}>
				<BaseControl __nextHasNoMarginBottom label={__('Title size', 'personalized-offers-for-spacefast')} id="pofsf-products-title-size">
					<FontSizePicker __next40pxDefaultSize value={appearance.titleSize} onChange={(value) => set('titleSize', value)} withReset />
				</BaseControl>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Title font', 'personalized-offers-for-spacefast')}
					value={appearance.titleFont || ''}
					options={[
						{ value: '', label: STYLE_DEFAULT },
						{ value: 'heading', label: __('Heading font', 'personalized-offers-for-spacefast') },
						{ value: 'body', label: __('Body font', 'personalized-offers-for-spacefast') },
					]}
					onChange={(value) => set('titleFont', value)}
				/>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Title weight', 'personalized-offers-for-spacefast')}
					value={appearance.titleWeight || ''}
					options={WEIGHTS}
					onChange={(value) => set('titleWeight', value)}
				/>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Title style', 'personalized-offers-for-spacefast')}
					value={appearance.titleStyle || ''}
					options={[
						{ value: '', label: STYLE_DEFAULT },
						{ value: 'normal', label: __('Regular', 'personalized-offers-for-spacefast') },
						{ value: 'italic', label: __('Italic', 'personalized-offers-for-spacefast') },
					]}
					onChange={(value) => set('titleStyle', value)}
				/>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Title letter case', 'personalized-offers-for-spacefast')}
					value={appearance.titleTransform || ''}
					options={[
						{ value: '', label: STYLE_DEFAULT },
						{ value: 'none', label: __('As written', 'personalized-offers-for-spacefast') },
						{ value: 'uppercase', label: __('Uppercase', 'personalized-offers-for-spacefast') },
						{ value: 'lowercase', label: __('Lowercase', 'personalized-offers-for-spacefast') },
						{ value: 'capitalize', label: __('Capitalize', 'personalized-offers-for-spacefast') },
					]}
					onChange={(value) => set('titleTransform', value)}
				/>
				<BaseControl __nextHasNoMarginBottom label={__('Story size', 'personalized-offers-for-spacefast')} id="pofsf-products-story-size">
					<FontSizePicker __next40pxDefaultSize value={appearance.storySize} onChange={(value) => set('storySize', value)} withReset />
				</BaseControl>
				<BaseControl __nextHasNoMarginBottom label={__('Name and details size', 'personalized-offers-for-spacefast')} id="pofsf-products-label-size">
					<FontSizePicker __next40pxDefaultSize value={appearance.labelSize} onChange={(value) => set('labelSize', value)} withReset />
				</BaseControl>
				<ToggleGroupControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					isBlock
					isDeselectable
					label={__('Text alignment', 'personalized-offers-for-spacefast')}
					value={appearance.textAlign || undefined}
					onChange={(value) => set('textAlign', value)}
				>
					<ToggleGroupControlOption value="left" label={__('Left', 'personalized-offers-for-spacefast')} />
					<ToggleGroupControlOption value="center" label={__('Center', 'personalized-offers-for-spacefast')} />
					<ToggleGroupControlOption value="right" label={__('Right', 'personalized-offers-for-spacefast')} />
				</ToggleGroupControl>
			</PanelBody>

			{Object.keys(appearance).length > 0 && (
				<PanelBody>
					<Button variant="secondary" onClick={() => setAttributes({ appearance: {} })}>
						{__('Reset product styles', 'personalized-offers-for-spacefast')}
					</Button>
				</PanelBody>
			)}
		</>
	);
}
