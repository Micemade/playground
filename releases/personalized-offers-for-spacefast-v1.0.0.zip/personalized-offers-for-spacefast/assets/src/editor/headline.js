/**
 * The Offer headline: a variation of the core Heading block whose text is
 * bound to the offer's headline (block bindings source "pofsf/offer", see
 * OfferBlocks::registerBindings()). It keeps every Heading setting except
 * the Elements (link color) panel; its text cannot be edited.
 *
 * The former pofsf/headline block becomes this variation when a template is
 * opened, with its settings (both use the same block supports).
 */
import { registerBlockBindingsSource, registerBlockVariation, createBlock } from '@wordpress/blocks';
import { store as blockEditorStore } from '@wordpress/block-editor';
import { createHigherOrderComponent } from '@wordpress/compose';
import { select } from '@wordpress/data';
import { addFilter } from '@wordpress/hooks';
import { __ } from '@wordpress/i18n';

export const SOURCE = 'pofsf/offer';

const HEADLINE = window.pofsfEditor?.headline || __('Picked just for you', 'personalized-offers-for-spacefast');

export const headlineBinding = () => ({ content: { source: SOURCE, args: { key: 'headline' } } });

export const isOfferHeadline = (attributes) => attributes?.metadata?.bindings?.content?.source === SOURCE;

/** Attributes of an Offer headline with the former pofsf/headline block's settings. */
export function legacyHeadline(attributes) {
	const { level, metadata, ...rest } = attributes;

	return createBlock('core/heading', {
		...rest,
		level: level || 1,
		content: '',
		metadata: { ...metadata, bindings: headlineBinding() },
	});
}

/** Color settings the Elements panel shows; off for the Offer headline. */
const ELEMENT_SETTINGS = /^color\.(link|heading|button|caption)$|^elements\./;

export function registerOfferHeadline() {
	registerBlockBindingsSource({
		name: SOURCE,
		label: __('Offer', 'personalized-offers-for-spacefast'),
		getValues({ bindings }) {
			return Object.fromEntries(
				Object.entries(bindings).map(([attribute, binding]) => [attribute, binding?.args?.key === 'headline' ? HEADLINE : ''])
			);
		},
		canUserEditValue: () => false,
	});

	registerBlockVariation('core/heading', {
		name: 'pofsf-offer-headline',
		title: __('Offer headline', 'personalized-offers-for-spacefast'),
		description: __('The offer’s headline, with all the Heading settings. Its text comes from the offer.', 'personalized-offers-for-spacefast'),
		category: 'pofsf-offer',
		icon: 'heading',
		keywords: [__('headline', 'personalized-offers-for-spacefast'), __('title', 'personalized-offers-for-spacefast')],
		attributes: { level: 1, metadata: { bindings: headlineBinding() } },
		isActive: (attributes) => isOfferHeadline(attributes),
		scope: ['inserter', 'transform'],
	});

	addFilter('blockEditor.useSetting.before', 'pofsf/offer-headline-elements', (value, path, clientId, blockName) => {
		if (blockName !== 'core/heading' || !clientId || !ELEMENT_SETTINGS.test(path)) {
			return value;
		}

		return isOfferHeadline(select(blockEditorStore).getBlockAttributes(clientId)) ? false : value;
	});

	// The class offer.css and template CSS style the headline with, as on the page (OfferBlocks::headlineClass()).
	addFilter(
		'editor.BlockListBlock',
		'pofsf/offer-headline-class',
		createHigherOrderComponent(
			(BlockListBlock) => (props) =>
				props.name === 'core/heading' && isOfferHeadline(props.attributes) ? (
					<BlockListBlock {...props} className={[props.className, 'pofsf-headline'].filter(Boolean).join(' ')} />
				) : (
					<BlockListBlock {...props} />
				),
			'withOfferHeadlineClass'
		)
	);
}
