/**
 * Live preview of the template design in the block editor canvas: CSS
 * variables, the template's extra CSS and the chosen Google Fonts. Also
 * outlines the hovered block with its name, as the admin previews do.
 */
import { __ } from '@wordpress/i18n';
import { select } from '@wordpress/data';
import { store as blockEditorStore } from '@wordpress/block-editor';
import { store as blocksStore } from '@wordpress/blocks';

const config = window.pofsfEditor || {};
const STYLE_ID = 'pofsf-live-design';

let latest = null;
let watcher = null;

export function normalizeDesign(raw) {
	const defaults = config.defaults || {};
	const design = { ...defaults, ...(raw && typeof raw === 'object' ? raw : {}) };

	// PHP serializes empty maps as [].
	design.colors = design.colors && !Array.isArray(design.colors) ? { ...design.colors } : {};
	design.fonts = { heading: '', body: '', ...(design.fonts && !Array.isArray(design.fonts) ? design.fonts : {}) };

	return design;
}

function font(key) {
	return (config.fonts || []).find((item) => item.value === key);
}

function tokensCss(design) {
	const inherited = design.use_brand ? config.brandColors || {} : config.defaultColors || {};
	const colors = { ...inherited, ...design.colors };
	const brandFonts = design.use_brand ? config.brandFonts || {} : {};
	const body = font(design.fonts.body)?.stack || brandFonts.body || config.defaultFont;
	const heading = font(design.fonts.heading)?.stack || brandFonts.heading || body;

	const vars = Object.entries(colors)
		.map(([key, value]) => `--pofsf-${key.replace('_', '-')}:${value};`)
		.join('');

	// Template CSS is only previewed; a stray "</style>" cannot close a <style> set via textContent.
	return `:root{${vars}--pofsf-font-heading:${heading};--pofsf-font-body:${body}}\n${design.custom_css || ''}`;
}

function canvasDocument() {
	const iframe = document.querySelector('iframe[name="editor-canvas"]');

	return iframe?.contentDocument?.head ? iframe.contentDocument : document.querySelector('.editor-styles-wrapper') ? document : null;
}

/** The block's name as the List View shows it: its own name, its variation's title, or its type's. */
function blockLabel(clientId) {
	const name = select(blockEditorStore).getBlockName(clientId);
	const attributes = select(blockEditorStore).getBlockAttributes(clientId) || {};
	const type = name ? select(blocksStore).getBlockType(name) : null;

	if (!type) {
		return '';
	}

	if (attributes.metadata?.name) {
		return attributes.metadata.name;
	}

	// Core's "Heading 1–6" variations would otherwise win over the Offer headline's.
	if (attributes.metadata?.bindings?.content?.source === 'pofsf/offer') {
		return __('Offer headline', 'personalized-offers-for-spacefast');
	}

	return select(blocksStore).getActiveBlockVariation(name, attributes)?.title || type.title;
}

const HOVER_CSS =
	'.pofsf-hover{position:fixed;z-index:29;pointer-events:none;display:none;outline:1px solid var(--wp-admin-theme-color,#3858e9);outline-offset:-1px}' +
	'.pofsf-hover.is-shown{display:block}' +
	'.pofsf-hover__label{position:absolute;left:-1px;bottom:100%;padding:1px 6px;border-radius:2px 2px 0 0;background:var(--wp-admin-theme-color,#3858e9);color:#fff;' +
	'font:500 11px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;letter-spacing:normal;text-transform:none;white-space:nowrap}' +
	'.pofsf-hover.is-inside .pofsf-hover__label{bottom:auto;top:0;left:0;border-radius:0 0 2px 0}';

/**
 * A thin outline and a name label on the hovered block of the template
 * (not on the selected one, which has the editor's own outline and toolbar).
 */
function installHover(doc) {
	if (!doc.body || doc.body.pofsfHover) {
		return;
	}

	const style = doc.createElement('style');
	const box = doc.createElement('div');
	const label = doc.createElement('span');
	let current = null;

	style.textContent = HOVER_CSS;
	doc.head.appendChild(style);
	box.className = 'pofsf-hover';
	box.setAttribute('aria-hidden', 'true');
	label.className = 'pofsf-hover__label';
	box.appendChild(label);
	doc.body.appendChild(box);
	doc.body.pofsfHover = true;

	const hide = () => {
		current = null;
		box.classList.remove('is-shown');
	};

	const place = () => {
		const rect = current.getBoundingClientRect();

		if (!current.isConnected || (!rect.width && !rect.height) || current.classList.contains('is-selected')) {
			box.classList.remove('is-shown');
			return;
		}

		Object.assign(box.style, { left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px` });
		box.classList.toggle('is-inside', rect.top < 22);
		box.classList.add('is-shown');
	};

	doc.addEventListener('mouseover', (event) => {
		const block = event.target.closest?.('.is-root-container .block-editor-block-list__block[data-block]');

		if (!block) {
			hide();
			return;
		}

		if (block !== current) {
			current = block;
			label.textContent = blockLabel(block.getAttribute('data-block')) || block.getAttribute('data-title') || '';
		}

		place();
	});
	doc.documentElement.addEventListener('mouseleave', hide);
	// Selecting, typing, scrolling or resizing moves or hides the outline.
	['click', 'keydown'].forEach((type) => doc.addEventListener(type, () => current && window.requestAnimationFrame(() => current && place())));
	doc.addEventListener('scroll', () => current && place(), { capture: true, passive: true });
	doc.defaultView?.addEventListener('resize', hide);
}

function apply() {
	const doc = canvasDocument();

	if (!doc) {
		return;
	}

	installHover(doc);

	if (!latest) {
		return;
	}

	let style = doc.getElementById(STYLE_ID);

	if (!style) {
		style = doc.createElement('style');
		style.id = STYLE_ID;
		doc.head.appendChild(style);
	}

	const css = tokensCss(latest);

	if (style.textContent !== css) {
		style.textContent = css;
	}

	[['heading', latest.fonts.heading], ['body', latest.fonts.body]].forEach(([slot, key]) => {
		const id = `pofsf-live-font-${slot}`;
		const url = font(key)?.url || '';
		let link = doc.getElementById(id);

		if (!url) {
			link?.remove();
			return;
		}

		if (!link) {
			link = doc.createElement('link');
			link.id = id;
			link.rel = 'stylesheet';
			doc.head.appendChild(link);
		}

		if (link.getAttribute('href') !== url) {
			link.setAttribute('href', url);
		}
	});
}

/**
 * Applies the design now, and keeps it applied if the canvas iframe is
 * recreated (e.g. switching device previews).
 */
export function applyDesignToCanvas(design) {
	latest = design;
	apply();

	if (!watcher) {
		watcher = window.setInterval(apply, 1000);
	}
}
