/**
 * "Offer design" panels in the template editor: colors, fonts,
 * copy tone and note guidance, stored in the `_pofsf_design` post meta.
 * Changes are previewed live in the editor canvas.
 */
import {
	BaseControl,
	Button,
	ColorIndicator,
	ColorPicker,
	Dropdown,
	Notice,
	SelectControl,
	TextControl,
	TextareaControl,
	ToggleControl,
} from '@wordpress/components';
import { useEntityProp } from '@wordpress/core-data';
import { useDispatch, useSelect } from '@wordpress/data';
import { PluginDocumentSettingPanel, store as editorStore } from '@wordpress/editor';
import { useEffect } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { applyDesignToCanvas, normalizeDesign } from './canvas';

const config = window.pofsfEditor || {};
const META_KEY = '_pofsf_design';

const COLOR_LABELS = {
	primary: __('Primary (buttons, banners)', 'personalized-offers-for-spacefast'),
	secondary: __('Secondary (prices, hover)', 'personalized-offers-for-spacefast'),
	accent: __('Accent (highlights)', 'personalized-offers-for-spacefast'),
	background: __('Page background', 'personalized-offers-for-spacefast'),
	surface: __('Surface (cards, note)', 'personalized-offers-for-spacefast'),
	border: __('Borders', 'personalized-offers-for-spacefast'),
	text: __('Text', 'personalized-offers-for-spacefast'),
	text_muted: __('Muted text', 'personalized-offers-for-spacefast'),
};

const FONT_GROUPS = [
	['system', __('System fonts (no download)', 'personalized-offers-for-spacefast')],
	['sans-serif', __('Google Fonts: sans-serif', 'personalized-offers-for-spacefast')],
	['serif', __('Google Fonts: serif', 'personalized-offers-for-spacefast')],
	['display', __('Google Fonts: display', 'personalized-offers-for-spacefast')],
	['handwriting', __('Google Fonts: handwriting', 'personalized-offers-for-spacefast')],
	['monospace', __('Google Fonts: monospace', 'personalized-offers-for-spacefast')],
];

function FontSelect({ label, value, onChange, inheritLabel }) {
	const fonts = config.fonts || [];
	const known = fonts.some((font) => font.value === value);

	return (
		<SelectControl __nextHasNoMarginBottom __next40pxDefaultSize label={label} value={known ? value : ''} onChange={onChange}>
			<option value="">{inheritLabel}</option>
			{FONT_GROUPS.map(([category, groupLabel]) => (
				<optgroup key={category} label={groupLabel}>
					{fonts
						.filter((font) => font.category === category)
						.map((font) => (
							<option key={font.value} value={font.value}>
								{font.label}
							</option>
						))}
				</optgroup>
			))}
		</SelectControl>
	);
}

function ColorRow({ label, value, inherited, onChange }) {
	return (
		<Dropdown
			className="pofsf-color-row"
			contentClassName="pofsf-color-row__popover"
			popoverProps={{ placement: 'left-start', offset: 36 }}
			renderToggle={({ isOpen, onToggle }) => (
				<Button className="pofsf-color-row__toggle" onClick={onToggle} aria-expanded={isOpen}>
					<ColorIndicator colorValue={value || inherited} />
					<span>{label}</span>
					{!value && <span className="pofsf-color-row__hint">{__('inherited', 'personalized-offers-for-spacefast')}</span>}
				</Button>
			)}
			renderContent={() => (
				<div className="pofsf-color-row__content">
					<ColorPicker color={value || inherited} onChange={onChange} enableAlpha={false} />
					<Button variant="tertiary" size="small" disabled={!value} onClick={() => onChange('')}>
						{__('Reset to inherited', 'personalized-offers-for-spacefast')}
					</Button>
				</div>
			)}
		/>
	);
}

/**
 * The template's name (its post title), which the canvas does not show
 * (assets/css/editor-canvas.css). Admin only, never on offer pages.
 */
function NamePanel() {
	const title = useSelect((select) => select(editorStore).getEditedPostAttribute('title') || '', []);
	const { editPost } = useDispatch(editorStore);

	return (
		<PluginDocumentSettingPanel name="pofsf-template-name" title={__('Template name', 'personalized-offers-for-spacefast')} className="pofsf-design-panel" initialOpen>
			<TextControl
				__nextHasNoMarginBottom
				__next40pxDefaultSize
				label={__('Name', 'personalized-offers-for-spacefast')}
				hideLabelFromVision
				value={title}
				onChange={(value) => editPost({ title: value })}
				disabled={Boolean(config.builtin)}
				help={
					config.builtin
						? __('Built-in templates can’t be renamed: duplicate this template from the Templates tab to customize it.', 'personalized-offers-for-spacefast')
						: __('Only shown in the admin, never on offer pages.', 'personalized-offers-for-spacefast')
				}
			/>
		</PluginDocumentSettingPanel>
	);
}

export default function DesignPanels() {
	const postType = useSelect((select) => select('core/editor').getCurrentPostType(), []);
	const [meta, setMeta] = useEntityProp('postType', postType, 'meta');
	const design = normalizeDesign(meta?.[META_KEY]);

	useEffect(() => applyDesignToCanvas(design), [JSON.stringify(design)]); // eslint-disable-line react-hooks/exhaustive-deps

	const update = (patch) => setMeta({ ...meta, [META_KEY]: { ...design, ...patch } });
	const setColor = (key, value) => {
		const colors = { ...design.colors };
		if (value) {
			colors[key] = value;
		} else {
			delete colors[key];
		}
		update({ colors });
	};

	const inheritedColors = design.use_brand ? config.brandColors || {} : config.defaultColors || {};

	return (
		<>
			{config.builtin && (
				<Notice status="warning" isDismissible={false}>
					{__('This is a built-in template and cannot be saved. Duplicate it from the Templates tab to customize it.', 'personalized-offers-for-spacefast')}
				</Notice>
			)}

			<NamePanel />

			<PluginDocumentSettingPanel name="pofsf-design-brand" title={__('Offer design: fonts', 'personalized-offers-for-spacefast')} className="pofsf-design-panel" initialOpen>
				<ToggleControl
					__nextHasNoMarginBottom
					label={__('Start from the store brand', 'personalized-offers-for-spacefast')}
					help={__('Use the colors and fonts captured in the plugin settings where this design does not set its own.', 'personalized-offers-for-spacefast')}
					checked={design.use_brand}
					onChange={(useBrand) => update({ use_brand: useBrand })}
				/>
				<FontSelect
					label={__('Heading font', 'personalized-offers-for-spacefast')}
					value={design.fonts.heading}
					inheritLabel={__('Same as body / brand', 'personalized-offers-for-spacefast')}
					onChange={(heading) => update({ fonts: { ...design.fonts, heading } })}
				/>
				<FontSelect
					label={__('Body font', 'personalized-offers-for-spacefast')}
					value={design.fonts.body}
					inheritLabel={design.use_brand ? __('Brand font', 'personalized-offers-for-spacefast') : __('System default', 'personalized-offers-for-spacefast')}
					onChange={(body) => update({ fonts: { ...design.fonts, body } })}
				/>
			</PluginDocumentSettingPanel>

			<PluginDocumentSettingPanel name="pofsf-design-colors" title={__('Offer design: colors', 'personalized-offers-for-spacefast')} className="pofsf-design-panel">
				<BaseControl __nextHasNoMarginBottom help={__('Used by the offer blocks and the Offer group styles. Unset colors are inherited.', 'personalized-offers-for-spacefast')}>
					{(config.colorKeys || []).map((key) => (
						<ColorRow
							key={key}
							label={COLOR_LABELS[key] || key}
							value={design.colors[key] || ''}
							inherited={inheritedColors[key] || '#ffffff'}
							onChange={(value) => setColor(key, value)}
						/>
					))}
				</BaseControl>
			</PluginDocumentSettingPanel>

			<PluginDocumentSettingPanel name="pofsf-design-copy" title={__('Offer design: copy', 'personalized-offers-for-spacefast')} className="pofsf-design-panel">
				<TextControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Copy tone', 'personalized-offers-for-spacefast')}
					help={__('How the AI writes offers that use this template.', 'personalized-offers-for-spacefast')}
					placeholder={__('e.g. warm, upbeat, eco-conscious', 'personalized-offers-for-spacefast')}
					value={design.tone}
					onChange={(tone) => update({ tone })}
				/>
				<TextareaControl
					__nextHasNoMarginBottom
					label={__('Personal note guidance', 'personalized-offers-for-spacefast')}
					help={__('What the personal note to each customer should say. Leave empty for no note.', 'personalized-offers-for-spacefast')}
					value={design.note_guidance}
					onChange={(noteGuidance) => update({ note_guidance: noteGuidance })}
					rows={3}
				/>
				<TextareaControl
					__nextHasNoMarginBottom
					className="pofsf-design-panel__css"
					label={__('Extra CSS', 'personalized-offers-for-spacefast')}
					help={__('E.g. :root { --pofsf-radius: 12px; } sets the corner radius of cards, images and buttons (8px by default).', 'personalized-offers-for-spacefast')}
					value={design.custom_css}
					onChange={(customCss) => update({ custom_css: customCss })}
					rows={5}
				/>
			</PluginDocumentSettingPanel>
		</>
	);
}
