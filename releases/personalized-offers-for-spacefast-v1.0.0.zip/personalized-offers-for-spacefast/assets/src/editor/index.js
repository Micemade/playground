/**
 * Block editor integration for offer templates (pofsf_offer_template):
 * the dynamic offer blocks and the "Offer design" panels.
 */
import { addFilter } from '@wordpress/hooks';
import { registerPlugin } from '@wordpress/plugins';
import { registerOfferBlocks } from './blocks';
import { registerOfferHeadline } from './headline';
import DesignPanels from './design-panel';
import './editor.css';

/*
 * Offer text blocks set their own font sizes, so a Group's font size would
 * only reach some of them; Groups keep colors and spacing. Before the core
 * blocks register (the editor initializes on DOM ready).
 */
addFilter('blocks.registerBlockType', 'pofsf/group-without-font-size', (settings, name) => {
	const typography = settings.supports?.typography;

	if (name !== 'core/group' || !typography) {
		return settings;
	}

	return {
		...settings,
		supports: {
			...settings.supports,
			typography: {
				...typography,
				fontSize: false,
				__experimentalDefaultControls: { ...typography.__experimentalDefaultControls, fontSize: false },
			},
		},
	};
});

registerOfferBlocks();
registerOfferHeadline();

registerPlugin('pofsf-offer-design', { render: DesignPanels, icon: 'art' });
