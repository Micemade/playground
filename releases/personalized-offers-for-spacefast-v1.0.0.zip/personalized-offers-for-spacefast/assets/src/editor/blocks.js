/**
 * Client registration of the dynamic Spacefast offer blocks. Each block
 * previews itself with ServerSideRender, so the editor shows exactly what
 * the published page renders (with sample offer data), including the
 * block's color, typography and spacing settings on the block's own element.
 */
import { registerBlockType, registerBlockVariation } from '@wordpress/blocks';
import { InspectorControls, store as blockEditorStore, useBlockProps } from '@wordpress/block-editor';
import {
	PanelBody,
	RangeControl,
	SelectControl,
	TextControl,
	ToggleControl,
} from '@wordpress/components';
import { useDispatch, useSelect } from '@wordpress/data';
import { useEffect } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import ServerSideRender from '@wordpress/server-side-render';

import branding from '../../../blocks/branding/block.json';
import headline from '../../../blocks/headline/block.json';
import offerText from '../../../blocks/offer-text/block.json';
import products from '../../../blocks/products/block.json';
import offerActionButton from '../../../blocks/offer-action-button/block.json';
import ProductsStyles from './products-styles';
import { legacyHeadline } from './headline';

/** Offer text field types and their labels (OfferCopy::typeLabels()). */
const FIELD_TYPES = window.pofsfEditor?.fieldTypes || {
	overheadline: __('Overheadline', 'personalized-offers-for-spacefast'),
	subheadline: __('Subheadline', 'personalized-offers-for-spacefast'),
	greeting: __('Greeting', 'personalized-offers-for-spacefast'),
	body: __('Body text', 'personalized-offers-for-spacefast'),
	additional: __('Additional text', 'personalized-offers-for-spacefast'),
};

/** Default Offer action button text (OfferPageRenderer::vars() cta_label). */
const ACTION_LABEL = __('Claim your offer', 'personalized-offers-for-spacefast');

/**
 * Grid each product style used before the block had the grid layout
 * support: [columns, gap]. Keep in sync with OfferBlocks::LEGACY_GRID.
 */
const LEGACY_GRID = {
	grid: [3, '16px'],
	list: [1, '16px'],
	tiles: [3, '24px'],
	numbered: [2, '40px'],
	compact: [1, '0px'],
	feature: [1, '24px'],
	story: [1, '2rem'],
	lookbook: [2, '48px'],
};

/** Offer products styles (OfferBlocks::PRODUCT_VARIANTS) and the columns each starts with. */
const PRODUCT_STYLES = [
	{ value: 'story', label: __('Editorial story: image and text, alternating', 'personalized-offers-for-spacefast') },
	{ value: 'feature', label: __('Cover: text set on the image', 'personalized-offers-for-spacefast') },
	{ value: 'lookbook', label: __('Lookbook: staggered captioned images', 'personalized-offers-for-spacefast') },
	{ value: 'numbered', label: __('Index: numbered entries', 'personalized-offers-for-spacefast') },
	{ value: 'catalogue', label: __('Catalogue: product plates with entry lines', 'personalized-offers-for-spacefast') },
	{ value: 'gallery', label: __('Gallery: framed prints with captions', 'personalized-offers-for-spacefast') },
	{ value: 'showcase', label: __('Showcase: one centred product at a time', 'personalized-offers-for-spacefast') },
];

const STYLE_COLUMNS = { story: 1, feature: 2, lookbook: 2, numbered: 2, catalogue: 3, gallery: 3, showcase: 1 };

function gridLayout(columns) {
	return columns > 1
		? { type: 'grid', columnCount: columns, minimumColumnWidth: '12rem' }
		: { type: 'grid', columnCount: 1 };
}

/**
 * Attributes that move a products block saved with the old `columns`
 * setting onto the grid layout, matching OfferBlocks::legacyProductsGrid().
 */
function legacyGridAttributes(attributes) {
	const variant = attributes.variant || 'grid';
	let [columns, gap] = LEGACY_GRID[variant] || LEGACY_GRID.grid;

	if (['grid', 'tiles', 'numbered'].includes(variant) && attributes.columns) {
		columns = Math.max(1, Math.min(variant === 'numbered' ? 2 : 4, attributes.columns));
	}

	const style = attributes.style || {};

	return {
		layout: gridLayout(columns),
		style: { ...style, spacing: { blockGap: gap, ...style.spacing } },
		columns: undefined,
	};
}

const SETTINGS = {
	'pofsf/branding': ({ attributes, setAttributes }) => (
		<>
			<ToggleControl
				__nextHasNoMarginBottom
				label={__('Show logo', 'personalized-offers-for-spacefast')}
				help={__('The site logo, or the site icon when the store has no logo.', 'personalized-offers-for-spacefast')}
				checked={attributes.showLogo}
				onChange={(showLogo) => setAttributes({ showLogo })}
			/>
			{attributes.showLogo && (
				<RangeControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Logo width (px)', 'personalized-offers-for-spacefast')}
					help={__('Leave empty for the automatic size.', 'personalized-offers-for-spacefast')}
					min={16}
					max={600}
					value={attributes.logoWidth || undefined}
					allowReset
					onChange={(logoWidth) => setAttributes({ logoWidth: logoWidth || 0 })}
				/>
			)}
			<ToggleControl
				__nextHasNoMarginBottom
				label={__('Show store title', 'personalized-offers-for-spacefast')}
				help={__('Its font settings are under the block’s Styles → Typography. The title also shows when there is no logo to show.', 'personalized-offers-for-spacefast')}
				checked={attributes.showTitle}
				onChange={(showTitle) => setAttributes({ showTitle })}
			/>
			<ToggleControl
				__nextHasNoMarginBottom
				label={__('Link to the store', 'personalized-offers-for-spacefast')}
				help={__('The logo and title open the store’s home page.', 'personalized-offers-for-spacefast')}
				checked={attributes.isLink}
				onChange={(isLink) => setAttributes({ isLink })}
			/>
		</>
	),
	'pofsf/offer-text': ({ attributes, setAttributes }) => (
		<SelectControl
			__nextHasNoMarginBottom
			label={__('Shows', 'personalized-offers-for-spacefast')}
			value={attributes.field}
			options={Object.entries(FIELD_TYPES).map(([value, label]) => ({ value, label }))}
			onChange={(field) => setAttributes({ field })}
			help={__('The offer’s field of this type, as added under Personalize in the offer form.', 'personalized-offers-for-spacefast')}
		/>
	),
	'pofsf/products': ({ attributes, setAttributes }) => (
		<>
			<SelectControl
				__nextHasNoMarginBottom
				label={__('Style', 'personalized-offers-for-spacefast')}
				value={attributes.variant}
				options={PRODUCT_STYLES}
				help={__('How the picks are presented. Images, colors and type are under the block’s Styles tab; columns and spacing under Layout.', 'personalized-offers-for-spacefast')}
				onChange={(variant) =>
					// Each style has a natural column count; fine-tune it under Layout → Grid.
					setAttributes({ variant, layout: { ...attributes.layout, ...gridLayout(STYLE_COLUMNS[variant] ?? 1) } })
				}
			/>
			<ToggleControl __nextHasNoMarginBottom label={__('Show prices', 'personalized-offers-for-spacefast')} checked={attributes.showPrice} onChange={(showPrice) => setAttributes({ showPrice })} />
			<ToggleControl __nextHasNoMarginBottom label={__('Show each pick’s story', 'personalized-offers-for-spacefast')} checked={attributes.showReason} onChange={(showReason) => setAttributes({ showReason })} />
			<ToggleControl
				__nextHasNoMarginBottom
				label={__('Show cart buttons', 'personalized-offers-for-spacefast')}
				help={__('“Add to cart” or “Select options” on each product. Customers fill a cart on the offer page and complete the purchase at checkout.', 'personalized-offers-for-spacefast')}
				checked={attributes.showCart}
				onChange={(showCart) => setAttributes({ showCart })}
			/>
		</>
	),
	'pofsf/offer-action-button': ({ attributes, setAttributes }) => (
		<>
			<TextControl
				__nextHasNoMarginBottom
				label={__('Button text', 'personalized-offers-for-spacefast')}
				placeholder={ACTION_LABEL}
				help={__('Fallback text for button. Button text is set in the Offer Personalize fields', 'personalized-offers-for-spacefast')}
				value={attributes.label}
				onChange={(label) => setAttributes({ label })}
			/>
			<ToggleControl __nextHasNoMarginBottom label={__('Show arrow', 'personalized-offers-for-spacefast')} checked={attributes.arrow} onChange={(arrow) => setAttributes({ arrow })} />
		</>
	),
};

/**
 * Classes the block supports (colors, typography, block styles) and the
 * Advanced → Additional CSS class add to the editor's block wrapper. The
 * rendered block already carries them on its own element, as on the page,
 * so the wrapper drops them; editor state classes such as has-child-selected stay.
 */
const SUPPORT_CLASS = /^(has-(?!child-selected$|warning$|block-overlay$)|is-style-|wp-elements-)/;

/**
 * The editor's block wrapper without the block's style settings: only the
 * rendered element applies them, so nothing is applied twice (padding,
 * backgrounds) and offer.css rules for the element cannot override them.
 */
function neutralWrapper(blockProps, customClassName) {
	const custom = new Set((customClassName || '').split(/\s+/).filter(Boolean));
	const { style, ...props } = blockProps; // eslint-disable-line no-unused-vars

	return {
		...props,
		className: (blockProps.className || '')
			.split(/\s+/)
			.filter((token) => token && !SUPPORT_CLASS.test(token) && !custom.has(token))
			.join(' '),
	};
}

/**
 * Set when the editor was opened from the Edit offer form: the blocks then
 * show that offer's texts (stored on the server under this key) instead of
 * the sample texts.
 */
const OFFER_COPY_KEY = new URLSearchParams(window.location.search).get('pofsf_copy') || '';

function makeEdit(name) {
	const Settings = SETTINGS[name];

	return function Edit({ clientId, attributes, setAttributes, __unstableLayoutClassNames: layoutClassNames }) {
		const isProducts = name === 'pofsf/products';
		// The products block is itself the grid: the rendered products become its grid items (see editor-canvas.css).
		const blockProps = useBlockProps(
			isProducts
				? { className: ['pofsf-products-editor', `pofsf-products--${attributes.variant}`, layoutClassNames].filter(Boolean).join(' ') }
				: {}
		);
		const postId = useSelect((select) => select('core/editor').getCurrentPostId(), []);
		const { __unstableMarkNextChangeAsNotPersistent: markNotPersistent, replaceBlock } = useDispatch(blockEditorStore);
		const isLegacy = isProducts && attributes.columns !== undefined && !attributes.layout;

		useEffect(() => {
			if (isLegacy) {
				// Opening an older template should not count as an edit.
				markNotPersistent();
				setAttributes(legacyGridAttributes(attributes));
			}
		}, [isLegacy]); // eslint-disable-line react-hooks/exhaustive-deps

		useEffect(() => {
			if (name === 'pofsf/headline') {
				// The former headline block becomes the Offer headline (a Heading variation) with its settings.
				markNotPersistent();
				replaceBlock(clientId, legacyHeadline(attributes));
			}
		}, []); // eslint-disable-line react-hooks/exhaustive-deps

		return (
			<>
				{isProducts && (
					<InspectorControls group="styles">
						<ProductsStyles attributes={attributes} setAttributes={setAttributes} />
					</InspectorControls>
				)}
				{Settings && (
					<InspectorControls>
						<PanelBody title={__('Settings', 'personalized-offers-for-spacefast')}>
							<Settings attributes={attributes} setAttributes={setAttributes} />
						</PanelBody>
					</InspectorControls>
				)}
				{/* The products block's wrapper is its grid and keeps the settings; the
				    other blocks render them on their own element, like the page does. */}
				<div {...(isProducts ? blockProps : neutralWrapper(blockProps, attributes.className))}>
					<ServerSideRender
						block={name}
						attributes={attributes}
						httpMethod="POST"
						skipBlockSupportAttributes={isProducts}
						urlQueryArgs={{ post_id: postId, ...(OFFER_COPY_KEY ? { pofsf_copy: OFFER_COPY_KEY } : {}) }}
					/>
				</div>
			</>
		);
	};
}

export function registerOfferBlocks() {
	[branding, headline, offerText, products, offerActionButton].forEach((metadata) => {
		registerBlockType(metadata, {
			edit: makeEdit(metadata.name),
			save: () => null,
		});
	});

	// One inserter item per field type ("Offer text: Greeting"…); the list view names each block by its type.
	Object.entries(FIELD_TYPES).forEach(([field, label]) => {
		registerBlockVariation(offerText.name, {
			name: field,
			/* translators: %s: offer field type, e.g. "Greeting". */
			title: sprintf(__('Offer text: %s', 'personalized-offers-for-spacefast'), label),
			description: sprintf(
				/* translators: %s: offer field type, e.g. "Greeting". */
				__('The offer’s %s field.', 'personalized-offers-for-spacefast'),
				label
			),
			attributes: { field },
			isActive: ['field'],
			scope: ['inserter', 'transform'],
		});
	});
}
