/**
 * Personalized Offers for Spacefast admin UI.
 *
 * React entry point (built with @wordpress/scripts). Mounts the brand
 * snapshot app and the AI connector app into the placeholders rendered
 * by the WooCommerce settings tab template, and the offers screen (offers,
 * templates, settings and the assistant) into the WooCommerce → WC
 * Personalized Offers page.
 */
import { createRoot } from '@wordpress/element';
import BrandApp from './components/BrandApp';
import AiApp from './components/AiApp';
import OffersApp from './components/OffersApp';

function parseJson(raw, fallback) {
	try {
		return JSON.parse(raw || '');
	} catch (e) {
		return fallback;
	}
}

function mount(id, Component, propsFrom) {
	const element = document.getElementById(id);

	if (!element || element.dataset.mounted) {
		return;
	}

	element.dataset.mounted = '1';
	element.innerHTML = '';
	createRoot(element).render(<Component {...propsFrom(element.dataset)} />);
}

document.addEventListener('DOMContentLoaded', () => {
	mount('pofsf-brand-app', BrandApp, (data) => ({
		versions: parseJson(data.versions, []),
		brandName: data.brandName,
	}));
	mount('pofsf-ai-app', AiApp, (data) => ({
		message: data.message,
		providers: parseJson(data.providers, []),
		supported: data.supported === '1',
	}));
	mount('pofsf-offers-app', OffersApp, (data) => ({ config: parseJson(data.config, {}) }));
});
