/**
 * WooCommerce → Personalized Offers for Spacefast: the offers, customers, segments,
 * templates, Spaces and settings tabs, with the assistant chat in a sidebar that can stay open beside them.
 */
import { useRef, useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { Button, TabPanel } from '@wordpress/components';
import { commentContent } from '@wordpress/icons';
import AssistantOffersNotice from './AssistantOffersNotice';
import ChatApp from './ChatApp';
import CustomersTab from './CustomersTab';
import OffersList from './OffersList';
import SegmentsTab from './SegmentsTab';
import SettingsTab from './SettingsTab';
import SpacesTab from './SpacesTab';
import SpacefastConnect from './SpacefastConnect';
import TemplatesList from './TemplatesList';

const ASSISTANT_KEY = 'pofsf_assistant_open';
const TAB_NAMES = ['offers', 'customers', 'segments', 'templates', 'spaces', 'settings'];

function readAssistantOpen() {
	try {
		return window.localStorage.getItem(ASSISTANT_KEY) === '1';
	} catch (e) {
		return false;
	}
}

export default function OffersApp({ config }) {
	const [spacefast, setSpacefast] = useState(config.spacefast || {});
	// Kept here, not in the tab, so switching tabs does not bring back the page-load values.
	const [settings, setSettings] = useState(config.settings || {});
	const [assistantOpen, setAssistantOpen] = useState(readAssistantOpen);
	// The chat mounts on first open and then stays mounted, so closing the sidebar keeps the conversation and any reply in progress.
	const [assistantStarted, setAssistantStarted] = useState(assistantOpen);
	const toggleRef = useRef(null);
	const tabsRef = useRef(null);
	// For the Offers list: an action on a new offer from the "offer ready" notice ({ action: 'edit' | 'publish', offerId }),
	// or Create offer from the Customers tab ({ action: 'create', customer }) or the Segments tab ({ action: 'create', segment }).
	const [offerRequest, setOfferRequest] = useState(null);
	// Access requests waiting (null: not known yet), for the Spaces tab's title.
	const [requestCount, setRequestCount] = useState(config.accessRequests ?? null);

	/*
	 * Shows the Offers tab, as a click on it would (TabPanel only picks its
	 * first tab itself). Not while another dialog is open, e.g. the template
	 * editor, whose unsaved changes the tab switch would lose, unless `force`.
	 */
	const showOffersTab = (force = false) => {
		const tab = tabsRef.current?.querySelector('[role="tab"][id$="-offers"]');

		if (!tab || tab.getAttribute('aria-selected') === 'true') {
			return;
		}

		if (!force && document.querySelectorAll('.components-modal__frame:not(.pofsf-assistant-offers-notice)').length > 0) {
			return;
		}

		tab.click();
	};

	const toggleAssistant = (open) => {
		setAssistantOpen(open);
		setAssistantStarted((started) => started || open);

		try {
			window.localStorage.setItem(ASSISTANT_KEY, open ? '1' : '0');
		} catch (e) {
			// Not remembered in this browser; the sidebar still toggles now.
		}

		if (!open) {
			toggleRef.current?.focus();
		}
	};

	return (
		<div className={`pofsf-offers-app${assistantOpen ? ' has-assistant' : ''}`}>
			<SpacefastConnect
				status={spacefast}
				dashboardUrl={config.spacefast?.dashboardUrl}
				onChange={setSpacefast}
			/>

			<div className="pofsf-offers-layout">
				<div className="pofsf-offers-main">
					<Button
						ref={toggleRef}
						className="pofsf-assistant-toggle"
						variant={assistantOpen ? 'primary' : 'secondary'}
						icon={commentContent}
						aria-expanded={assistantOpen}
						aria-controls="pofsf-assistant"
						onClick={() => toggleAssistant(!assistantOpen)}
					>
						{__('Assistant', 'personalized-offers-for-spacefast')}
					</Button>

					<div ref={tabsRef}>
					<TabPanel
						className="pofsf-offers-tabs"
						initialTabName={TAB_NAMES.includes(config.initialTab) ? config.initialTab : undefined}
						tabs={[
							{ name: 'offers', title: __('Offers', 'personalized-offers-for-spacefast') },
							{ name: 'customers', title: __('Customers', 'personalized-offers-for-spacefast') },
							{ name: 'segments', title: __('Segments', 'personalized-offers-for-spacefast') },
							{ name: 'templates', title: __('Templates', 'personalized-offers-for-spacefast') },
							{
								name: 'spaces',
								title: requestCount > 0
									? sprintf(
										/* translators: %d: number of access requests waiting. */
										__('Spaces (%d)', 'personalized-offers-for-spacefast'),
										requestCount
									)
									: __('Spaces', 'personalized-offers-for-spacefast'),
							},
							{ name: 'settings', title: __('Settings', 'personalized-offers-for-spacefast') },
						]}
					>
						{(tab) => {
							if (tab.name === 'offers') {
								return (
									<OffersList
										spacefastConnected={Boolean(spacefast.connected)}
										request={offerRequest}
										onRequestDone={() => setOfferRequest(null)}
									/>
								);
							}

							if (tab.name === 'customers') {
								return (
									<CustomersTab
										onCreateOffer={(customer) => {
											showOffersTab(true);
											setOfferRequest({ action: 'create', customer });
										}}
									/>
								);
							}

							if (tab.name === 'segments') {
								return (
									<SegmentsTab
										onCreateOffer={(segment) => {
											showOffersTab(true);
											setOfferRequest({ action: 'create', segment });
										}}
									/>
								);
							}

							if (tab.name === 'spaces') {
								return <SpacesTab spacefastConnected={Boolean(spacefast.connected)} onRequestsCount={setRequestCount} />;
							}

							return tab.name === 'templates' ? (
								<TemplatesList />
							) : (
								<SettingsTab
									config={settings}
									onChange={(changes) => setSettings((current) => ({ ...current, ...changes }))}
									wooSettingsUrl={config.settingsUrl}
								/>
							);
						}}
					</TabPanel>
					</div>
				</div>

				<aside
					id="pofsf-assistant"
					className="pofsf-assistant"
					aria-labelledby="pofsf-assistant-heading"
					hidden={!assistantOpen}
				>
					{assistantStarted && (
						<ChatApp config={config.chat || {}} onClose={() => toggleAssistant(false)} />
					)}
				</aside>
			</div>

			<AssistantOffersNotice
				spacefastConnected={Boolean(spacefast.connected)}
				onReady={() => showOffersTab()}
				onAction={(action, offerId) => {
					showOffersTab(true);
					setOfferRequest({ action, offerId });
				}}
			/>
		</div>
	);
}
