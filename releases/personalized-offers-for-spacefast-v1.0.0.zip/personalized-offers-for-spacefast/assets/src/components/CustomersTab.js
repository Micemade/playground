/**
 * Customers tab: stored customer profiles with their segment and what they
 * like, a profile panel where the manager corrects the preferences offers
 * use, and "Create offer" for a customer (registered or guest).
 */
import { useEffect, useRef, useState } from '@wordpress/element';
import { __, _n, sprintf } from '@wordpress/i18n';
import {
	Button,
	FormTokenField,
	Modal,
	Notice,
	SelectControl,
	Spinner,
	TextControl,
	TextareaControl,
} from '@wordpress/components';
import { ajaxAction, assertSuccess, onAssistantChanges } from '../api';

const PREFIX = 'personalized-offers-for-spacefast/';

export const BAND_LABELS = {
	budget: __('Budget', 'personalized-offers-for-spacefast'),
	mid: __('Mid-range', 'personalized-offers-for-spacefast'),
	premium: __('Premium', 'personalized-offers-for-spacefast'),
};

const SEGMENT_CLASSES = {
	new: 'is-sent',
	loyal: 'is-ready',
	active: 'is-ready',
	at_risk: 'is-pending',
	lapsed: 'is-failed',
};

export function SegmentBadge({ customer }) {
	if (!customer.segmentLabel) {
		return null;
	}

	return <span className={`pofsf-status ${SEGMENT_CLASSES[customer.segment] || ''}`}>{customer.segmentLabel}</span>;
}

/**
 * A token field over named options (categories, attribute values): shows
 * names, keeps their IDs or slugs. With `allowFree`, text that names no
 * option is kept as typed (attribute values the store writes by hand).
 */
export function NamedTokens({ label, options, value, onChange, help, allowFree = false }) {
	const nameOf = (id) => options.find((option) => String(option.value) === String(id))?.label || String(id);
	const idOf = (name) => {
		const text = String(name).trim().toLowerCase();
		const found = options.find((option) => option.label.toLowerCase() === text || String(option.value).toLowerCase() === text);

		return found ? found.value : allowFree && text ? String(name).trim() : undefined;
	};

	return (
		<FormTokenField
			__nextHasNoMarginBottom
			__next40pxDefaultSize
			label={label}
			value={value.map(nameOf)}
			suggestions={options.map((option) => option.label)}
			onChange={(names) => onChange(names.map(idOf).filter((id) => id !== undefined))}
			__experimentalExpandOnFocus
			__experimentalShowHowTo={false}
			help={help}
		/>
	);
}

export function Fact({ label, children }) {
	if (!children || (Array.isArray(children) && children.length === 0)) {
		return null;
	}

	return (
		<div className="pofsf-customer-profile__fact">
			<dt>{label}</dt>
			<dd>{children}</dd>
		</div>
	);
}

function ProfileModal({ customerKey, onClose, onChanged, onCreateOffer }) {
	const [customer, setCustomer] = useState(null);
	const [options, setOptions] = useState(null);
	const [corrections, setCorrections] = useState(null);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);
	const [notice, setNotice] = useState(null);

	const apply = (data) => {
		setCustomer(data);
		setCorrections({ ...data.corrections, attributes: { ...data.corrections.attributes } });
	};

	useEffect(() => {
		ajaxAction('pofsf_customer_get', { key: customerKey, with_options: 1 })
			.then((response) => {
				assertSuccess(response);
				setOptions(response.data.options);
				apply(response.data.customer);
			})
			.catch((err) => setError(err?.message));
	}, [customerKey]);

	const run = async (action, params, message) => {
		setBusy(true);
		setError(null);
		setNotice(null);

		try {
			const response = await ajaxAction(action, { key: customerKey, ...params });
			assertSuccess(response);
			apply(response.data.customer);
			setNotice(message);
			onChanged();
		} catch (err) {
			setError(err?.message);
		} finally {
			setBusy(false);
		}
	};

	const set = (key) => (value) => setCorrections((current) => ({ ...current, [key]: value }));
	const setAttribute = (taxonomy) => (values) =>
		setCorrections((current) => ({ ...current, attributes: { ...current.attributes, [taxonomy]: values } }));

	const categoryOptions = (options?.categories || []).map((category) => ({ value: category.id, label: category.name }));
	const profile = customer?.profile;
	const activity = profile?.activity || {};

	return (
		<Modal
			className="pofsf-customer-profile"
			title={customer ? customer.name : __('Customer profile', 'personalized-offers-for-spacefast')}
			onRequestClose={onClose}
			size="large"
		>
			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}
			{notice && (
				<Notice status="success" isDismissible onRemove={() => setNotice(null)}>
					{notice}
				</Notice>
			)}

			{!customer && !error && <Spinner />}

			{customer && (
				<div className="pofsf-customer-profile__columns">
					<section>
						<p className="pofsf-customer-profile__who">
							{customer.email}
							{customer.guest && <span className="pofsf-status">{__('Guest', 'personalized-offers-for-spacefast')}</span>}
							<SegmentBadge customer={customer} />
						</p>
						<h3>{__('From their orders', 'personalized-offers-for-spacefast')}</h3>
						<dl className="pofsf-customer-profile__facts">
							<Fact label={__('Orders', 'personalized-offers-for-spacefast')}>
								{activity.order_count > 0
									? sprintf(
										/* translators: 1: number of orders, 2: amount spent, 3: date of last order. */
										__('%1$d, %2$s in total, last on %3$s', 'personalized-offers-for-spacefast'),
										activity.order_count,
										customer.spent,
										customer.lastOrder
									)
									: __('None yet', 'personalized-offers-for-spacefast')}
							</Fact>
							<Fact label={__('Buys', 'personalized-offers-for-spacefast')}>{profile.rhythm}</Fact>
							<Fact label={__('Favourite categories', 'personalized-offers-for-spacefast')}>
								{profile.categories.map((category) => (
									<span key={category.id} className="pofsf-customer-profile__chip">
										{category.name}
										{category.pinned && ` (${__('pinned', 'personalized-offers-for-spacefast')})`}
									</span>
								))}
							</Fact>
							<Fact label={__('Brands', 'personalized-offers-for-spacefast')}>{profile.brands.join(', ')}</Fact>
							{Object.entries(profile.attributes).map(([taxonomy, attribute]) => (
								<Fact key={taxonomy} label={attribute.label}>
									{attribute.values.join(', ')}
									{attribute.setBy === 'manager' && <span className="pofsf-muted"> {__('(set by you)', 'personalized-offers-for-spacefast')}</span>}
									{attribute.setBy === 'customer' && <span className="pofsf-muted"> {__('(the customer’s choice)', 'personalized-offers-for-spacefast')}</span>}
								</Fact>
							))}
							<Fact label={__('Typical price per item', 'personalized-offers-for-spacefast')}>
								{profile.priceRange &&
									[
										sprintf(
											/* translators: 1: lower price, 2: higher price. */
											__('%1$s – %2$s', 'personalized-offers-for-spacefast'),
											profile.priceRange.low,
											profile.priceRange.high
										),
										BAND_LABELS[profile.priceRange.band],
									].filter(Boolean).join(', ')}
							</Fact>
							<Fact label={__('Wishlist', 'personalized-offers-for-spacefast')}>
								{profile.wishlist > 0 &&
									sprintf(
										/* translators: %d: number of products. */
										_n('%d product', '%d products', profile.wishlist, 'personalized-offers-for-spacefast'),
										profile.wishlist
									)}
							</Fact>
							<Fact label={__('Searched for', 'personalized-offers-for-spacefast')}>{profile.searches.join(', ')}</Fact>
							<Fact label={__('My preferences', 'personalized-offers-for-spacefast')}>
								{customer.customerInput.consent &&
									sprintf(
										/* translators: %s: date. */
										__('Consent given on %s', 'personalized-offers-for-spacefast'),
										customer.customerInput.consentAt
									)}
							</Fact>
						</dl>
						<p className="pofsf-muted">
							{sprintf(
								/* translators: %s: date and time. */
								__('Updated %s. Profiles update after each paid order and every night.', 'personalized-offers-for-spacefast'),
								profile.builtAt
							)}
						</p>
					</section>

					<section className="pofsf-customer-profile__corrections">
						<h3>{__('Your corrections', 'personalized-offers-for-spacefast')}</h3>
						<p className="pofsf-muted">
							{__('New offers for this customer use these. Existing offers don’t change.', 'personalized-offers-for-spacefast')}
						</p>
						<NamedTokens
							label={__('Favourite categories (first)', 'personalized-offers-for-spacefast')}
							options={categoryOptions}
							value={corrections.categories_pinned}
							onChange={set('categories_pinned')}
						/>
						<NamedTokens
							label={__('Never suggest from', 'personalized-offers-for-spacefast')}
							options={categoryOptions}
							value={corrections.categories_excluded}
							onChange={set('categories_excluded')}
						/>
						{(options?.attributes || []).filter((attribute) => attribute.values.length > 0).map((attribute) => (
							<NamedTokens
								key={attribute.taxonomy}
								label={attribute.label}
								options={attribute.values}
								value={corrections.attributes[attribute.taxonomy] || []}
								onChange={setAttribute(attribute.taxonomy)}
								allowFree
								help={__('Replaces what their orders show.', 'personalized-offers-for-spacefast')}
							/>
						))}
						<TextareaControl
							__nextHasNoMarginBottom
							label={__('Note for the team', 'personalized-offers-for-spacefast')}
							value={corrections.note}
							onChange={set('note')}
							rows={3}
						/>
					</section>
				</div>
			)}

			{customer && (
				<div className="pofsf-modal-actions">
					<Button
						variant="tertiary"
						disabled={busy}
						onClick={() => run('pofsf_customer_refresh', {}, __('Profile updated from their orders.', 'personalized-offers-for-spacefast'))}
					>
						{__('Update from orders', 'personalized-offers-for-spacefast')}
					</Button>
					{customer.corrected && (
						<Button
							variant="tertiary"
							isDestructive
							disabled={busy}
							onClick={() => run('pofsf_customer_correct', { corrections: JSON.stringify({ reset: true }) }, __('Corrections removed.', 'personalized-offers-for-spacefast'))}
						>
							{__('Remove corrections', 'personalized-offers-for-spacefast')}
						</Button>
					)}
					<Button variant="secondary" disabled={busy} onClick={() => onCreateOffer(customer)}>
						{__('Create offer', 'personalized-offers-for-spacefast')}
					</Button>
					<Button
						variant="primary"
						isBusy={busy}
						disabled={busy}
						onClick={() => run('pofsf_customer_correct', { corrections: JSON.stringify(corrections) }, __('Corrections saved.', 'personalized-offers-for-spacefast'))}
					>
						{__('Save corrections', 'personalized-offers-for-spacefast')}
					</Button>
				</div>
			)}
		</Modal>
	);
}

/**
 * @param {Object}   props
 * @param {Function} props.onCreateOffer Opens Create new offer for a customer ({ id, name, email }).
 */
export default function CustomersTab({ onCreateOffer }) {
	const [rows, setRows] = useState([]);
	const [total, setTotal] = useState(0);
	const [pages, setPages] = useState(1);
	const [segments, setSegments] = useState([]);
	const [stored, setStored] = useState(null);
	const [building, setBuilding] = useState(false);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [search, setSearch] = useState('');
	const [query, setQuery] = useState('');
	const [segment, setSegment] = useState('');
	const [kind, setKind] = useState('');
	const [orderby, setOrderby] = useState('last_order_at');
	const [page, setPage] = useState(1);
	const [open, setOpen] = useState(null);
	const latest = useRef(0);

	const load = async () => {
		const request = ++latest.current;
		setLoading(true);

		try {
			const response = await ajaxAction('pofsf_customers_list', { search: query, segment, kind, orderby, page });
			assertSuccess(response);

			if (request !== latest.current) {
				return;
			}

			setRows(response.data.customers);
			setTotal(response.data.total);
			setPages(Math.max(1, response.data.pages));
			setSegments(response.data.segments);
			setStored(response.data.stored);
			setBuilding(response.data.building);
		} catch (err) {
			setError(err?.message);
		} finally {
			if (request === latest.current) {
				setLoading(false);
			}
		}
	};

	useEffect(() => {
		load();
	}, [query, segment, kind, orderby, page]); // eslint-disable-line react-hooks/exhaustive-deps

	// Search as the manager types, after a pause.
	useEffect(() => {
		const timer = setTimeout(() => {
			setQuery(search);
			setPage(1);
		}, 350);

		return () => clearTimeout(timer);
	}, [search]);

	// Profiles being built in the background: show them as they come.
	useEffect(() => {
		if (!building) {
			return;
		}

		const timer = setInterval(load, 5000);

		return () => clearInterval(timer);
	}, [building]); // eslint-disable-line react-hooks/exhaustive-deps

	useEffect(() => onAssistantChanges([`${PREFIX}update-customer-preferences`, `${PREFIX}get-customer-profile`], () => load()), []); // eslint-disable-line react-hooks/exhaustive-deps

	const build = async () => {
		setError(null);

		try {
			assertSuccess(await ajaxAction('pofsf_customers_build'));
			setBuilding(true);
		} catch (err) {
			setError(err?.message);
		}
	};

	const createOffer = (customer) => {
		setOpen(null);
		onCreateOffer({ id: customer.id, name: customer.name, email: customer.email, guest: customer.guest });
	};

	return (
		<div className="pofsf-offers pofsf-customers">
			<div className="pofsf-offers__toolbar">
				<TextControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Search customers', 'personalized-offers-for-spacefast')}
					hideLabelFromVision
					placeholder={__('Search by name or email', 'personalized-offers-for-spacefast')}
					value={search}
					onChange={setSearch}
					type="search"
				/>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Segment', 'personalized-offers-for-spacefast')}
					hideLabelFromVision
					value={segment}
					onChange={(value) => {
						setSegment(value);
						setPage(1);
					}}
					options={[
						{ label: __('All segments', 'personalized-offers-for-spacefast'), value: '' },
						...segments.map((item) => ({ value: item.value, label: `${item.label} (${item.count})` })),
					]}
				/>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Account', 'personalized-offers-for-spacefast')}
					hideLabelFromVision
					value={kind}
					onChange={(value) => {
						setKind(value);
						setPage(1);
					}}
					options={[
						{ label: __('Registered and guests', 'personalized-offers-for-spacefast'), value: '' },
						{ label: __('Registered', 'personalized-offers-for-spacefast'), value: 'registered' },
						{ label: __('Guests', 'personalized-offers-for-spacefast'), value: 'guest' },
					]}
				/>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Sort by', 'personalized-offers-for-spacefast')}
					hideLabelFromVision
					value={orderby}
					onChange={(value) => {
						setOrderby(value);
						setPage(1);
					}}
					options={[
						{ label: __('Latest order', 'personalized-offers-for-spacefast'), value: 'last_order_at' },
						{ label: __('Most spent', 'personalized-offers-for-spacefast'), value: 'total_spent' },
						{ label: __('Most orders', 'personalized-offers-for-spacefast'), value: 'order_count' },
						{ label: __('Name', 'personalized-offers-for-spacefast'), value: 'name' },
					]}
				/>
				<span className="pofsf-muted">
					{sprintf(
						/* translators: %d: number of customers. */
						_n('%d customer', '%d customers', total, 'personalized-offers-for-spacefast'),
						total
					)}
				</span>
				{loading && <Spinner />}
			</div>

			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}

			{building && (
				<Notice status="info" isDismissible={false}>
					{__('Building profiles for everyone who has ordered, in the background. They appear here as they are ready.', 'personalized-offers-for-spacefast')}
				</Notice>
			)}

			{stored === 0 && !building && (
				<Notice status="info" isDismissible={false}>
					<p>
						{__('No customer profiles yet. They are built after each paid order and every night, or build them now for everyone who has ordered.', 'personalized-offers-for-spacefast')}
					</p>
					<Button variant="primary" onClick={build}>
						{__('Build profiles now', 'personalized-offers-for-spacefast')}
					</Button>
				</Notice>
			)}

			<table className="wp-list-table widefat fixed striped pofsf-offers__table pofsf-customers__table">
				<thead>
					<tr>
						<th scope="col">{__('Customer', 'personalized-offers-for-spacefast')}</th>
						<th scope="col" className="column-segment">{__('Segment', 'personalized-offers-for-spacefast')}</th>
						<th scope="col" className="column-orders">{__('Orders', 'personalized-offers-for-spacefast')}</th>
						<th scope="col">{__('Likes', 'personalized-offers-for-spacefast')}</th>
						<th scope="col" className="column-actions">{__('Actions', 'personalized-offers-for-spacefast')}</th>
					</tr>
				</thead>
				<tbody>
					{rows.length === 0 && !loading && (
						<tr>
							<td colSpan={5}>{__('No customers found.', 'personalized-offers-for-spacefast')}</td>
						</tr>
					)}
					{rows.map((customer) => (
						<tr key={customer.key}>
							<td data-label={__('Customer', 'personalized-offers-for-spacefast')}>
								<strong>
									{customer.editUrl ? <a href={customer.editUrl}>{customer.name}</a> : customer.name}
								</strong>
								{customer.guest && <> <span className="pofsf-status">{__('Guest', 'personalized-offers-for-spacefast')}</span></>}
								<br />
								<span className="pofsf-muted">{customer.email}</span>
							</td>
							<td data-label={__('Segment', 'personalized-offers-for-spacefast')}>
								<SegmentBadge customer={customer} />
							</td>
							<td data-label={__('Orders', 'personalized-offers-for-spacefast')}>
								{customer.orders > 0 ? (
									<>
										{customer.orders} · {customer.spent}
										<br />
										<span className="pofsf-muted">{customer.lastOrder}</span>
									</>
								) : (
									<span className="pofsf-muted">{__('None yet', 'personalized-offers-for-spacefast')}</span>
								)}
							</td>
							<td data-label={__('Likes', 'personalized-offers-for-spacefast')}>
								{customer.categories.join(', ')}
								{customer.sizes.length > 0 && (
									<>
										<br />
										<span className="pofsf-muted">
											{sprintf(
												/* translators: %s: sizes, e.g. "M, L". */
												__('Size %s', 'personalized-offers-for-spacefast'),
												customer.sizes.join(', ')
											)}
										</span>
									</>
								)}
								{customer.priceBand && (
									<>
										<br />
										<span className="pofsf-muted">{BAND_LABELS[customer.priceBand]}</span>
									</>
								)}
								{customer.corrected && (
									<>
										<br />
										<span className="pofsf-muted">{__('Corrected by the store', 'personalized-offers-for-spacefast')}</span>
									</>
								)}
							</td>
							<td data-label={__('Actions', 'personalized-offers-for-spacefast')}>
								<div className="pofsf-row-actions">
									<Button variant="secondary" size="small" onClick={() => setOpen(customer.key)}>
										{__('Profile', 'personalized-offers-for-spacefast')}
									</Button>
									<Button variant="secondary" size="small" onClick={() => createOffer(customer)}>
										{__('Create offer', 'personalized-offers-for-spacefast')}
									</Button>
								</div>
							</td>
						</tr>
					))}
				</tbody>
			</table>

			{pages > 1 && (
				<div className="pofsf-offers__pagination">
					<Button variant="secondary" size="small" disabled={page <= 1 || loading} onClick={() => setPage(page - 1)}>
						{__('Previous', 'personalized-offers-for-spacefast')}
					</Button>
					<span>
						{sprintf(
							/* translators: 1: current page, 2: total pages. */
							__('Page %1$d of %2$d', 'personalized-offers-for-spacefast'),
							page,
							pages
						)}
					</span>
					<Button variant="secondary" size="small" disabled={page >= pages || loading} onClick={() => setPage(page + 1)}>
						{__('Next', 'personalized-offers-for-spacefast')}
					</Button>
				</div>
			)}

			{open && (
				<ProfileModal
					customerKey={open}
					onClose={() => setOpen(null)}
					onChanged={() => load()}
					onCreateOffer={createOffer}
				/>
			)}
		</div>
	);
}
