/**
 * Offers assistant chat, shown in the sidebar beside the Offers and
 * Templates tabs. The server keeps the conversation and runs the AI model
 * with the plugin's abilities; this component only sends the next message
 * and renders the transcript.
 */
import { useEffect, useRef, useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { dateI18n, getSettings, humanTimeDiff } from '@wordpress/date';
import { Button, Notice, Spinner, TextareaControl } from '@wordpress/components';
import { backup, close, plus } from '@wordpress/icons';
import { ajaxAction, announceAssistantChanges, assertSuccess } from '../api';

const CHAT_TIMEOUT = 180000;

// Example prompts; three random ones are shown in each new chat.
const SUGGESTIONS = [
	__('Find customers who bought from my best-selling category and create a personal offer for each', 'personalized-offers-for-spacefast'),
	__('Create a thank-you offer for my 5 customers with the most orders', 'personalized-offers-for-spacefast'),
	__('Find my top customers who have no open offers yet and create one for each', 'personalized-offers-for-spacefast'),
	__('Create a public offer page with my 6 best-selling products and publish it to Spacefast', 'personalized-offers-for-spacefast'),
	__('Create a group offer with 4 bestsellers for customers who ordered more than once', 'personalized-offers-for-spacefast'),
	__('Design an offer template that matches my website’s colors and fonts', 'personalized-offers-for-spacefast'),
	__('Design a vibrant template with a thank-you note for loyal customers', 'personalized-offers-for-spacefast'),
	__('Design a minimal, elegant template for a seasonal sale', 'personalized-offers-for-spacefast'),
	__('Which offers are ready to publish to Spacefast?', 'personalized-offers-for-spacefast'),
	__('Publish my latest offer to Spacefast', 'personalized-offers-for-spacefast'),
	__('Show me my 5 most recent customers and how many orders each has placed', 'personalized-offers-for-spacefast'),
	__('Apply my newest template to all unpublished offers', 'personalized-offers-for-spacefast'),
	__('Create a birthday-style offer for my most recent customer with a personal note', 'personalized-offers-for-spacefast'),
	__('Build a public offer page around my most popular product category', 'personalized-offers-for-spacefast'),
	__('Give my latest offer a darker, bolder design without changing its text', 'personalized-offers-for-spacefast'),
];

const SUGGESTION_COUNT = 3;

// A random pick of the example prompts, without repeats.
function pickSuggestions() {
	const pool = [...SUGGESTIONS];

	for (let i = pool.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[pool[i], pool[j]] = [pool[j], pool[i]];
	}

	return pool.slice(0, SUGGESTION_COUNT);
}

const ABILITY_LABELS = {
	'personalized-offers-for-spacefast/find-customers': __('Searched customers', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/create-offers': __('Queued offers', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/create-shared-offer': __('Created offer', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/find-products': __('Searched products', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/publish-offer': __('Published to Spacefast', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/list-offers': __('Checked offers', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/list-templates': __('Checked templates', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/save-template': __('Saved template', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/apply-template': __('Restyled offer', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/restore-template': __('Restored template', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/delete-template': __('Deleted template', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/spacefast-status': __('Checked Spacefast connection', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/list-spaces': __('Listed Spaces', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/delete-space': __('Deleted Space', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/get-settings': __('Read settings', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/update-settings': __('Updated settings', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/brand-status': __('Checked store brand', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/lock-brand': __('Locked store brand', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/list-customer-profiles': __('Listed customer profiles', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/get-customer-profile': __('Read customer profile', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/update-customer-preferences': __('Corrected customer preferences', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/list-segments': __('Looked at customer segments', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/create-segment': __('Saved a customer segment', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/segment-customers': __('Looked at a segment’s customers', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/get-offer': __('Read offer', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/update-offer': __('Updated offer', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/delete-offer': __('Deleted offer', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/send-offer-email': __('Sent offer email', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/share-offer': __('Prepared social posts', 'personalized-offers-for-spacefast'),
	'personalized-offers-for-spacefast/inspect-website-style': __('Read website style', 'personalized-offers-for-spacefast'),
};

const URL_PATTERN = /(https?:\/\/[^\s<>"')]+[^\s<>"').,;:!?])/g;

/**
 * Renders plain text with web addresses as links. Built from React
 * elements, never HTML, so replies cannot inject markup.
 */
function Linkified({ text }) {
	return text.split(URL_PATTERN).map((part, index) =>
		index % 2 === 1 ? (
			<a key={index} href={part} target="_blank" rel="noopener noreferrer">
				{part}
			</a>
		) : (
			part
		)
	);
}

function toolLabel(tool) {
	const label = ABILITY_LABELS[tool.ability] || tool.ability;

	return tool.ok
		? label
		: sprintf(
				/* translators: %s: ability label, e.g. "Queued offers". */
				__('%s (failed)', 'personalized-offers-for-spacefast'),
				label
		  );
}

function ChatTime({ value }) {
	const settings = getSettings();

	return (
		<time
			className="pofsf-muted"
			dateTime={value}
			title={dateI18n(`${settings.formats.date} ${settings.formats.time}`, value)}
		>
			{humanTimeDiff(value)}
		</time>
	);
}

function ChatList({ chats, activeId, disabled, onSelect, onDelete }) {
	return (
		<div className="pofsf-chat__history" aria-labelledby="pofsf-chat-history-heading">
			<h3 id="pofsf-chat-history-heading">{__('Chat history', 'personalized-offers-for-spacefast')}</h3>

			{chats.length === 0 && <p className="pofsf-muted">{__('No chats yet.', 'personalized-offers-for-spacefast')}</p>}

			<ul>
				{chats.map((chat) => (
					<li key={chat.id} className={chat.id === activeId ? 'is-active' : ''}>
						<button
							type="button"
							className="pofsf-chat__history-item"
							onClick={() => onSelect(chat.id)}
							disabled={disabled}
							aria-current={chat.id === activeId ? 'true' : undefined}
						>
							<span className={`pofsf-chat__history-title${chat.titled ? '' : ' is-untitled'}`}>
								{chat.title}
							</span>
							<ChatTime value={chat.updated_at} />
						</button>
						<Button
							icon="trash"
							size="small"
							isDestructive
							label={sprintf(
								/* translators: %s: chat title. */
								__('Delete chat "%s"', 'personalized-offers-for-spacefast'),
								chat.title
							)}
							onClick={() => onDelete(chat)}
							disabled={disabled}
						/>
					</li>
				))}
			</ul>
		</div>
	);
}

export default function ChatApp({ config, onClose }) {
	const available = Boolean(config.available);
	const [chats, setChats] = useState([]);
	const [activeId, setActiveId] = useState('');
	const [messages, setMessages] = useState([]);
	const [draft, setDraft] = useState('');
	const [sending, setSending] = useState(false);
	const [loading, setLoading] = useState(available);
	const [error, setError] = useState(null);
	const [showHistory, setShowHistory] = useState(false);
	const [suggestions, setSuggestions] = useState(pickSuggestions);
	const logRef = useRef(null);
	const requestRef = useRef(0);

	const open = async (chatId) => {
		const request = ++requestRef.current;

		setShowHistory(false);
		setActiveId(chatId);
		// A new pick each time a chat is opened (an empty chat is reused for New chat).
		setSuggestions(pickSuggestions());
		setMessages([]);
		setError(null);

		if (!chatId) {
			setLoading(false);
			return;
		}

		setLoading(true);

		try {
			const response = await ajaxAction('pofsf_chat_history', { chat_id: chatId });
			assertSuccess(response);

			if (request === requestRef.current) {
				setMessages(response.data?.messages || []);
			}
		} catch (err) {
			setError(err?.message);
		} finally {
			if (request === requestRef.current) {
				setLoading(false);
			}
		}
	};

	// Starts a chat on the server so it shows in the history right away.
	const startChat = async () => {
		setError(null);

		try {
			const response = await ajaxAction('pofsf_chat_create');
			assertSuccess(response);
			setChats(response.data.chats);
			open(response.data.chat.id);
		} catch (err) {
			setError(err?.message);
			setLoading(false);
		}
	};

	useEffect(() => {
		if (!available) {
			return;
		}

		ajaxAction('pofsf_chat_list')
			.then((response) => {
				assertSuccess(response);
				const list = response.data?.chats || [];

				if (list.length === 0) {
					startChat();
					return;
				}

				setChats(list);
				open(list[0].id);
			})
			.catch((err) => {
				setError(err?.message);
				setLoading(false);
			});
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [available]);

	useEffect(() => {
		if (logRef.current) {
			logRef.current.scrollTop = logRef.current.scrollHeight;
		}
	}, [messages, sending, showHistory]);

	const send = async (text) => {
		const message = text.trim();

		if (!message || sending) {
			return;
		}

		setError(null);
		setDraft('');
		setSending(true);
		setMessages((current) => [...current, { role: 'user', text: message }]);

		try {
			const response = await ajaxAction(
				'pofsf_chat_send',
				{ message, chat_id: activeId },
				{ timeout: CHAT_TIMEOUT }
			);
			assertSuccess(response, __('The assistant did not respond.', 'personalized-offers-for-spacefast'));
			const chat = response.data.chat;

			setActiveId(chat.id);
			setChats((current) => [chat, ...current.filter((item) => item.id !== chat.id)]);
			setMessages((current) => [
				...current,
				{
					role: 'assistant',
					text: response.data.reply,
					tools: response.data.tools || [],
				},
			]);

			const changed = (response.data.tools || []).filter((tool) => tool.ok).map((tool) => tool.ability);

			if (changed.length > 0) {
				const offerIds = (response.data.tools || []).flatMap((tool) => (tool.ok && tool.offer_ids) || []);
				announceAssistantChanges(changed, { offerIds });
			}
		} catch (err) {
			setError(err?.message || __('The assistant did not respond.', 'personalized-offers-for-spacefast'));
			setDraft(message);
			setMessages((current) => current.slice(0, -1));
		} finally {
			setSending(false);
		}
	};

	const remove = async (chat) => {
		// eslint-disable-next-line no-alert
		if (!window.confirm(sprintf(
			/* translators: %s: chat title. */
			__('Delete the chat "%s"? This cannot be undone.', 'personalized-offers-for-spacefast'),
			chat.title
		))) {
			return;
		}

		setError(null);

		try {
			const response = await ajaxAction('pofsf_chat_delete', { chat_id: chat.id });
			assertSuccess(response);
			setChats(response.data.chats);

			if (chat.id === activeId) {
				if (response.data.chats.length > 0) {
					open(response.data.chats[0].id);
				} else {
					startChat();
				}
			}
		} catch (err) {
			setError(err?.message);
		}
	};

	const onKeyDown = (event) => {
		if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
			event.preventDefault();
			send(draft);
		}
	};

	const header = (
		<div className="pofsf-chat__header">
			<h2 id="pofsf-assistant-heading">{__('Assistant', 'personalized-offers-for-spacefast')}</h2>
			{available && (
				<>
					<Button
						icon={plus}
						size="compact"
						label={__('New chat', 'personalized-offers-for-spacefast')}
						onClick={startChat}
						disabled={sending}
					/>
					<Button
						icon={backup}
						size="compact"
						label={__('Chat history', 'personalized-offers-for-spacefast')}
						isPressed={showHistory}
						aria-expanded={showHistory}
						onClick={() => setShowHistory((current) => !current)}
					/>
				</>
			)}
			<Button icon={close} size="compact" label={__('Close assistant', 'personalized-offers-for-spacefast')} onClick={onClose} />
		</div>
	);

	if (!available) {
		return (
			<div className="pofsf-chat">
				{header}
				<Notice status="warning" isDismissible={false}>
					<p>{config.message || __('No AI provider connected.', 'personalized-offers-for-spacefast')}</p>
					<p>
						<a href={config.connectorsUrl}>
							{__('Connect an AI provider in Settings → Connectors', 'personalized-offers-for-spacefast')}
						</a>
					</p>
				</Notice>
			</div>
		);
	}

	return (
		<div className="pofsf-chat">
			{header}

			{showHistory ? (
				<ChatList
					chats={chats}
					activeId={activeId}
					disabled={sending}
					onSelect={open}
					onDelete={remove}
				/>
			) : (
				<div
					className="pofsf-chat__log"
					ref={logRef}
					role="log"
					aria-live="polite"
					aria-busy={sending || loading}
				>
					{loading && <Spinner />}

					{!loading && messages.length === 0 && (
						<div className="pofsf-chat__empty">
							<p>
								{__(
									'Ask the assistant to find customers, design templates and create personalized Spacefast offers. Try one of these:',
									'personalized-offers-for-spacefast'
								)}
							</p>
							{suggestions.map((suggestion) => (
								<Button key={suggestion} variant="secondary" onClick={() => send(suggestion)}>
									{suggestion}
								</Button>
							))}
						</div>
					)}

					{messages.map((message, index) => (
						<div key={index} className={`pofsf-chat__message is-${message.role}`}>
							{message.tools?.length > 0 && (
								<ul className="pofsf-chat__tools">
									{message.tools.map((tool, toolIndex) => (
										<li key={toolIndex} className={tool.ok ? '' : 'is-failed'}>
											{toolLabel(tool)}
										</li>
									))}
								</ul>
							)}
							<div className="pofsf-chat__bubble">
								<Linkified text={message.text} />
							</div>
						</div>
					))}

					{sending && (
						<div className="pofsf-chat__message is-assistant">
							<div className="pofsf-chat__bubble is-pending">
								<Spinner /> {__('Working…', 'personalized-offers-for-spacefast')}
							</div>
						</div>
					)}
				</div>
			)}

			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}

			<form
				className="pofsf-chat__composer"
				onSubmit={(event) => {
					event.preventDefault();
					send(draft);
				}}
			>
				<TextareaControl
					__nextHasNoMarginBottom
					label={__('Message', 'personalized-offers-for-spacefast')}
					hideLabelFromVision
					placeholder={__('e.g. Create offers for customers who bought jackets', 'personalized-offers-for-spacefast')}
					value={draft}
					onChange={setDraft}
					onKeyDown={onKeyDown}
					rows={3}
					disabled={sending || loading}
				/>
				<Button
					variant="primary"
					type="submit"
					isBusy={sending}
					disabled={sending || loading || !draft.trim()}
				>
					{__('Send', 'personalized-offers-for-spacefast')}
				</Button>
			</form>
		</div>
	);
}
