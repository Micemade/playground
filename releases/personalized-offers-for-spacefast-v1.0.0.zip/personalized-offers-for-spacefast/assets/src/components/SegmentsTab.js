/**
 * Segments tab: customers grouped by rules over their stored profiles —
 * the built-in buying patterns and the store's own segments (favourite
 * categories, sizes and colours, price band, orders, spending) — with what
 * each segment's customers share, and "Create group offer" for a segment.
 */
import { useEffect, useRef, useState } from '@wordpress/element';
import { __, _n, sprintf } from '@wordpress/i18n';
import {
	Button,
	CheckboxControl,
	Modal,
	Notice,
	Spinner,
	TextControl,
	TextareaControl,
	ToggleControl,
} from '@wordpress/components';
import { ajaxAction, assertSuccess, onAssistantChanges } from '../api';
import { BAND_LABELS, Fact, NamedTokens, SegmentBadge } from './CustomersTab';

const PREFIX = 'personalized-offers-for-spacefast/';

const BUYING_LABELS = {
	new: __('New', 'personalized-offers-for-spacefast'),
	loyal: __('Loyal', 'personalized-offers-for-spacefast'),
	active: __('Active', 'personalized-offers-for-spacefast'),
	at_risk: __('At risk', 'personalized-offers-for-spacefast'),
	lapsed: __('Lapsed', 'personalized-offers-for-spacefast'),
	none: __('No orders yet', 'personalized-offers-for-spacefast'),
};

function membersText(members, accounts) {
	return [
		sprintf(
			/* translators: %d: number of customers. */
			_n('%d customer', '%d customers', members, 'personalized-offers-for-spacefast'),
			members
		),
		members > 0 &&
			accounts !== null &&
			sprintf(
				/* translators: %d: number of customers with an account. */
				__('%d with an account', 'personalized-offers-for-spacefast'),
				accounts
			),
	]
		.filter(Boolean)
		.join(' · ');
}

/**
 * Rules as the form edits them: every key present.
 */
function formRules(rules = {}) {
	return {
		buying: rules.buying || [],
		categories: rules.categories || [],
		attributes: { ...(rules.attributes || {}) },
		price_bands: rules.price_bands || [],
		min_orders: rules.min_orders ? String(rules.min_orders) : '',
		min_spent: rules.min_spent ? String(rules.min_spent) : '',
		ordered_within_days: rules.ordered_within_days ? String(rules.ordered_within_days) : '',
		not_ordered_for_days: rules.not_ordered_for_days ? String(rules.not_ordered_for_days) : '',
		accounts_only: Boolean(rules.accounts_only),
	};
}

function toggle(list, value, on) {
	return on ? [...new Set([...list, value])] : list.filter((item) => item !== value);
}

function SegmentFormModal({ segment, options, onClose, onSaved }) {
	const [name, setName] = useState(segment?.name || '');
	const [description, setDescription] = useState(segment?.description || '');
	const [rules, setRules] = useState(() => formRules(segment?.rules));
	const [preview, setPreview] = useState(null);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);
	const editing = Boolean(segment?.id);

	const set = (key) => (value) => setRules((current) => ({ ...current, [key]: value }));
	const rulesJson = JSON.stringify(rules);

	// Who matches, as the rules change.
	useEffect(() => {
		const timer = setTimeout(() => {
			ajaxAction('pofsf_segment_preview', { rules: rulesJson })
				.then((response) => {
					assertSuccess(response);
					setPreview(response.data);
				})
				.catch(() => { });
		}, 400);

		return () => clearTimeout(timer);
	}, [rulesJson]);

	const save = async () => {
		setBusy(true);
		setError(null);

		try {
			const response = await ajaxAction('pofsf_segment_save', {
				id: editing ? segment.id : '',
				segment: JSON.stringify({ name, description, rules }),
			});
			assertSuccess(response, __('The segment could not be saved.', 'personalized-offers-for-spacefast'));
			onSaved(response.data.segment);
		} catch (err) {
			setError(err?.message);
			setBusy(false);
		}
	};

	const categoryOptions = (options?.categories || []).map((category) => ({ value: category.id, label: category.name }));

	return (
		<Modal
			className="pofsf-segment-form"
			title={editing ? __('Edit segment', 'personalized-offers-for-spacefast') : __('New segment', 'personalized-offers-for-spacefast')}
			onRequestClose={onClose}
			size="large"
		>
			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}

			<div className="pofsf-customer-profile__columns">
				<section>
					<TextControl
						__nextHasNoMarginBottom
						__next40pxDefaultSize
						label={__('Name', 'personalized-offers-for-spacefast')}
						value={name}
						onChange={setName}
						maxLength={100}
					/>
					<TextareaControl
						__nextHasNoMarginBottom
						label={__('Description (optional)', 'personalized-offers-for-spacefast')}
						value={description}
						onChange={setDescription}
						rows={2}
					/>

					<h3>{__('What they like', 'personalized-offers-for-spacefast')}</h3>
					<NamedTokens
						label={__('Favourite categories', 'personalized-offers-for-spacefast')}
						options={categoryOptions}
						value={rules.categories}
						onChange={set('categories')}
						help={__('Among their top favourites; subcategories count.', 'personalized-offers-for-spacefast')}
					/>
					{(options?.attributes || []).filter((attribute) => attribute.values.length > 0).map((attribute) => (
						<NamedTokens
							key={attribute.taxonomy}
							label={attribute.label}
							options={attribute.values}
							value={rules.attributes[attribute.taxonomy] || []}
							onChange={(values) => setRules((current) => ({ ...current, attributes: { ...current.attributes, [attribute.taxonomy]: values } }))}
						/>
					))}
					<fieldset className="pofsf-segment-form__checks">
						<legend>{__('Price band', 'personalized-offers-for-spacefast')}</legend>
						{Object.entries(BAND_LABELS).map(([value, label]) => (
							<CheckboxControl
								key={value}
								__nextHasNoMarginBottom
								label={label}
								checked={rules.price_bands.includes(value)}
								onChange={(on) => set('price_bands')(toggle(rules.price_bands, value, on))}
							/>
						))}
					</fieldset>
				</section>

				<section>
					<h3>{__('How they buy', 'personalized-offers-for-spacefast')}</h3>
					<fieldset className="pofsf-segment-form__checks">
						<legend>{__('Buying pattern', 'personalized-offers-for-spacefast')}</legend>
						{Object.entries(BUYING_LABELS).map(([value, label]) => (
							<CheckboxControl
								key={value}
								__nextHasNoMarginBottom
								label={label}
								checked={rules.buying.includes(value)}
								onChange={(on) => set('buying')(toggle(rules.buying, value, on))}
							/>
						))}
					</fieldset>
					<div className="pofsf-segment-form__numbers">
						<TextControl
							__nextHasNoMarginBottom
							__next40pxDefaultSize
							type="number"
							min={1}
							label={__('At least this many orders', 'personalized-offers-for-spacefast')}
							value={rules.min_orders}
							onChange={set('min_orders')}
						/>
						<TextControl
							__nextHasNoMarginBottom
							__next40pxDefaultSize
							type="number"
							min={0}
							step="0.01"
							label={__('Spent at least', 'personalized-offers-for-spacefast')}
							value={rules.min_spent}
							onChange={set('min_spent')}
						/>
						<TextControl
							__nextHasNoMarginBottom
							__next40pxDefaultSize
							type="number"
							min={1}
							label={__('Ordered in the last … days', 'personalized-offers-for-spacefast')}
							value={rules.ordered_within_days}
							onChange={set('ordered_within_days')}
						/>
						<TextControl
							__nextHasNoMarginBottom
							__next40pxDefaultSize
							type="number"
							min={1}
							label={__('No order for … days', 'personalized-offers-for-spacefast')}
							value={rules.not_ordered_for_days}
							onChange={set('not_ordered_for_days')}
						/>
					</div>
					<ToggleControl
						__nextHasNoMarginBottom
						label={__('Only customers with an account', 'personalized-offers-for-spacefast')}
						help={__('Group offers go to customers with an account.', 'personalized-offers-for-spacefast')}
						checked={rules.accounts_only}
						onChange={set('accounts_only')}
					/>

					<div className="pofsf-segment-form__preview" aria-live="polite">
						{preview?.members === null || !preview ? (
							<p className="pofsf-muted">{__('Add a rule to see who matches. Every rule must match; within a rule, any value does.', 'personalized-offers-for-spacefast')}</p>
						) : (
							<>
								<strong>{membersText(preview.members, preview.accounts)}</strong>
								{preview.names.length > 0 && (
									<p className="pofsf-muted">
										{preview.names.join(', ')}
										{preview.accounts > preview.names.length && '…'}
									</p>
								)}
							</>
						)}
					</div>
				</section>
			</div>

			<div className="pofsf-modal-actions">
				<Button variant="tertiary" onClick={onClose} disabled={busy}>
					{__('Cancel', 'personalized-offers-for-spacefast')}
				</Button>
				<Button variant="primary" onClick={save} isBusy={busy} disabled={busy || !name.trim()}>
					{__('Save segment', 'personalized-offers-for-spacefast')}
				</Button>
			</div>
		</Modal>
	);
}

function SegmentModal({ segmentId, onClose, onEdit, onDeleted, onCreateOffer }) {
	const [segment, setSegment] = useState(null);
	const [page, setPage] = useState(1);
	const [loading, setLoading] = useState(true);
	const [busy, setBusy] = useState(false);
	const [confirming, setConfirming] = useState(false);
	const [error, setError] = useState(null);

	useEffect(() => {
		setLoading(true);
		ajaxAction('pofsf_segment_get', { id: segmentId, page })
			.then((response) => {
				assertSuccess(response);
				setSegment(response.data.segment);
			})
			.catch((err) => setError(err?.message))
			.finally(() => setLoading(false));
	}, [segmentId, page]);

	const remove = async () => {
		setBusy(true);
		setError(null);

		try {
			assertSuccess(await ajaxAction('pofsf_segment_delete', { id: segmentId }));
			onDeleted();
		} catch (err) {
			setError(err?.message);
			setBusy(false);
		}
	};

	const shared = segment?.shared;
	const bands = shared ? Object.entries(shared.bands).filter(([, count]) => count > 0) : [];
	const guests = segment ? segment.members - segment.accounts : 0;

	return (
		<Modal
			className="pofsf-customer-profile pofsf-segment"
			title={segment ? segment.name : __('Segment', 'personalized-offers-for-spacefast')}
			onRequestClose={onClose}
			size="large"
		>
			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}

			{!segment && !error && <Spinner />}

			{segment && (
				<>
					<p className="pofsf-customer-profile__who">
						{membersText(segment.members, segment.accounts)}
						{segment.builtIn && <span className="pofsf-status">{__('Built-in', 'personalized-offers-for-spacefast')}</span>}
					</p>
					{segment.description && <p>{segment.description}</p>}
					{segment.ruleText.length > 0 && !segment.builtIn && (
						<ul className="pofsf-segment__rules">
							{segment.ruleText.map((text) => (
								<li key={text}>{text}</li>
							))}
						</ul>
					)}

					<div className="pofsf-customer-profile__columns">
						<section>
							<h3>{__('What they share', 'personalized-offers-for-spacefast')}</h3>
							{segment.members === 0 ? (
								<p className="pofsf-muted">{__('No customers match yet. Members follow the customer profiles, so they join as they buy.', 'personalized-offers-for-spacefast')}</p>
							) : (
								<dl className="pofsf-customer-profile__facts">
									<Fact label={__('Favourite categories', 'personalized-offers-for-spacefast')}>
										{shared.categories.map((category) => (
											<span key={category.id} className="pofsf-customer-profile__chip">
												{category.name} ({category.members})
											</span>
										))}
									</Fact>
									{shared.attributes.map((attribute) => (
										<Fact key={attribute.label} label={attribute.label}>
											{attribute.values.map((value) => `${value.name} (${value.members})`).join(', ')}
										</Fact>
									))}
									<Fact label={__('Price band', 'personalized-offers-for-spacefast')}>
										{bands.map(([band, count]) => `${BAND_LABELS[band]} (${count})`).join(', ')}
									</Fact>
									<Fact label={__('Typical price per item', 'personalized-offers-for-spacefast')}>{shared.typicalPrice}</Fact>
									<Fact label={__('Buying pattern', 'personalized-offers-for-spacefast')}>
										{shared.buying.map((item) => `${item.label} (${item.members})`).join(', ')}
									</Fact>
									<Fact label={__('Spent in total', 'personalized-offers-for-spacefast')}>
										{sprintf(
											/* translators: 1: amount, 2: average number of orders. */
											__('%1$s, %2$s orders each on average', 'personalized-offers-for-spacefast'),
											shared.totalSpent,
											shared.averageOrders
										)}
									</Fact>
								</dl>
							)}
							<p className="pofsf-muted">{__('Numbers in brackets: how many of its customers. Members update as profiles change.', 'personalized-offers-for-spacefast')}</p>
						</section>

						<section>
							<h3>
								{__('Customers', 'personalized-offers-for-spacefast')} {loading && <Spinner />}
							</h3>
							<ul className="pofsf-segment__members">
								{segment.customers.map((customer) => (
									<li key={customer.key}>
										<span>
											<strong>{customer.name}</strong>
											{customer.guest && <> <span className="pofsf-status">{__('Guest', 'personalized-offers-for-spacefast')}</span></>}
											<br />
											<span className="pofsf-muted">
												{customer.orders > 0
													? `${customer.orders} · ${customer.spent} · ${customer.lastOrder}`
													: __('No orders yet', 'personalized-offers-for-spacefast')}
											</span>
										</span>
										<SegmentBadge customer={customer} />
									</li>
								))}
							</ul>
							{segment.pages > 1 && (
								<div className="pofsf-offers__pagination">
									<Button variant="secondary" size="small" disabled={page <= 1 || loading} onClick={() => setPage(page - 1)}>
										{__('Previous', 'personalized-offers-for-spacefast')}
									</Button>
									<span>
										{sprintf(
											/* translators: 1: current page, 2: total pages. */
											__('Page %1$d of %2$d', 'personalized-offers-for-spacefast'),
											page,
											segment.pages
										)}
									</span>
									<Button variant="secondary" size="small" disabled={page >= segment.pages || loading} onClick={() => setPage(page + 1)}>
										{__('Next', 'personalized-offers-for-spacefast')}
									</Button>
								</div>
							)}
						</section>
					</div>

					{guests > 0 && segment.accounts > 0 && (
						<p className="pofsf-muted">
							{sprintf(
								/* translators: %d: number of guest customers. */
								_n(
									'A group offer goes to the customers with an account; %d guest is left out.',
									'A group offer goes to the customers with an account; %d guests are left out.',
									guests,
									'personalized-offers-for-spacefast'
								),
								guests
							)}
						</p>
					)}
					{segment.accounts > segment.recipients.length && (
						<p className="pofsf-muted">
							{sprintf(
								/* translators: %d: most customers in a group offer. */
								__('A group offer can have at most %d customers: those who spent most are in it.', 'personalized-offers-for-spacefast'),
								segment.recipients.length
							)}
						</p>
					)}

					<div className="pofsf-modal-actions">
						{!segment.builtIn && !confirming && (
							<Button variant="tertiary" isDestructive disabled={busy} onClick={() => setConfirming(true)}>
								{__('Delete', 'personalized-offers-for-spacefast')}
							</Button>
						)}
						{confirming && (
							<>
								<span>{__('Delete this segment? Its customers and offers stay.', 'personalized-offers-for-spacefast')}</span>
								<Button variant="tertiary" disabled={busy} onClick={() => setConfirming(false)}>
									{__('Keep', 'personalized-offers-for-spacefast')}
								</Button>
								<Button variant="primary" isDestructive isBusy={busy} disabled={busy} onClick={remove}>
									{__('Delete segment', 'personalized-offers-for-spacefast')}
								</Button>
							</>
						)}
						<Button variant="secondary" disabled={busy} onClick={() => onEdit(segment)}>
							{segment.builtIn ? __('Save a copy to edit', 'personalized-offers-for-spacefast') : __('Edit', 'personalized-offers-for-spacefast')}
						</Button>
						<Button
							variant="primary"
							disabled={busy || segment.recipients.length === 0}
							onClick={() => onCreateOffer(segment)}
						>
							{__('Create group offer', 'personalized-offers-for-spacefast')}
						</Button>
					</div>
					{segment.recipients.length === 0 && segment.members > 0 && (
						<p className="pofsf-muted">{__('None of these customers has an account, so a group offer cannot go to them. Create a personal offer for each from the Customers tab.', 'personalized-offers-for-spacefast')}</p>
					)}
				</>
			)}
		</Modal>
	);
}

function SegmentCard({ segment, onOpen, action = null }) {
	return (
		<li className="pofsf-segment-card">
			<button type="button" className="pofsf-segment-card__main" onClick={onOpen}>
				<strong>{segment.name}</strong>
				<span className="pofsf-muted">{segment.description || segment.ruleText.join(' · ')}</span>
				<span className="pofsf-segment-card__count">{membersText(segment.members, segment.accounts)}</span>
			</button>
			{action}
		</li>
	);
}

/**
 * @param {Object}   props
 * @param {Function} props.onCreateOffer Opens Create new offer for a segment ({ id, name, recipients }).
 */
export default function SegmentsTab({ onCreateOffer }) {
	const [segments, setSegments] = useState([]);
	const [suggestions, setSuggestions] = useState([]);
	const [options, setOptions] = useState(null);
	const [stored, setStored] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [notice, setNotice] = useState(null);
	const [open, setOpen] = useState(null);
	// The segment being edited: {} for a new one, or a segment (a built-in one is saved as a copy).
	const [editing, setEditing] = useState(null);
	const latest = useRef(0);

	const load = async () => {
		const request = ++latest.current;
		setLoading(true);

		try {
			const response = await ajaxAction('pofsf_segments_list', { with_options: options ? 0 : 1 });
			assertSuccess(response);

			if (request !== latest.current) {
				return;
			}

			setSegments(response.data.segments);
			setSuggestions(response.data.suggestions);
			setStored(response.data.stored);

			if (response.data.options) {
				setOptions(response.data.options);
			}
		} catch (err) {
			setError(err?.message);
		} finally {
			if (request === latest.current) {
				setLoading(false);
			}
		}
	};

	useEffect(() => {
		load();
	}, []); // eslint-disable-line react-hooks/exhaustive-deps

	useEffect(() => onAssistantChanges([`${PREFIX}create-segment`, `${PREFIX}update-customer-preferences`], () => load()), []); // eslint-disable-line react-hooks/exhaustive-deps

	const builtIn = segments.filter((segment) => segment.builtIn);
	const own = segments.filter((segment) => !segment.builtIn);

	const edit = (segment) => {
		setOpen(null);
		setEditing(
			segment.builtIn
				? {
					name: sprintf(
						/* translators: %s: segment name. */
						__('%s (copy)', 'personalized-offers-for-spacefast'),
						segment.name
					),
					description: segment.description,
					rules: segment.rules,
				}
				: segment
		);
	};

	return (
		<div className="pofsf-offers pofsf-segments">
			<div className="pofsf-offers__toolbar">
				<p className="pofsf-muted">
					{__('Customers grouped by how they buy and what they like, from their stored profiles. Segments update themselves as profiles change.', 'personalized-offers-for-spacefast')}
				</p>
				{loading && <Spinner />}
				<Button variant="primary" onClick={() => setEditing({})}>
					{__('New segment', 'personalized-offers-for-spacefast')}
				</Button>
			</div>

			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}
			{notice && (
				<Notice status="success" isDismissible onRemove={() => setNotice(null)}>
					{notice}
				</Notice>
			)}
			{stored === 0 && (
				<Notice status="info" isDismissible={false}>
					{__('No customer profiles yet, so segments are empty. Build them in the Customers tab.', 'personalized-offers-for-spacefast')}
				</Notice>
			)}

			<h2 className="pofsf-segments__heading">{__('Buying patterns', 'personalized-offers-for-spacefast')}</h2>
			<ul className="pofsf-segments__grid">
				{builtIn.map((segment) => (
					<SegmentCard key={segment.id} segment={segment} onOpen={() => setOpen(segment.id)} />
				))}
			</ul>

			<h2 className="pofsf-segments__heading">{__('Your segments', 'personalized-offers-for-spacefast')}</h2>
			{own.length === 0 && !loading && (
				<p className="pofsf-muted">{__('None yet. Create one from favourite categories, sizes, colours, price band or spending, or save a suggestion below.', 'personalized-offers-for-spacefast')}</p>
			)}
			<ul className="pofsf-segments__grid">
				{own.map((segment) => (
					<SegmentCard key={segment.id} segment={segment} onOpen={() => setOpen(segment.id)} />
				))}
			</ul>

			{suggestions.length > 0 && (
				<>
					<h2 className="pofsf-segments__heading">{__('Suggested', 'personalized-offers-for-spacefast')}</h2>
					<p className="pofsf-muted">{__('What many of your customers have in common.', 'personalized-offers-for-spacefast')}</p>
					<ul className="pofsf-segments__grid">
						{suggestions.map((suggestion) => (
							<SegmentCard
								key={suggestion.name}
								segment={{ ...suggestion, description: '', ruleText: suggestion.description === suggestion.name ? [] : [suggestion.description], accounts: null }}
								onOpen={() => setEditing({ name: suggestion.name, rules: suggestion.rules })}
								action={
									<Button variant="secondary" size="small" onClick={() => setEditing({ name: suggestion.name, rules: suggestion.rules })}>
										{__('Save as segment', 'personalized-offers-for-spacefast')}
									</Button>
								}
							/>
						))}
					</ul>
				</>
			)}

			{open && (
				<SegmentModal
					segmentId={open}
					onClose={() => setOpen(null)}
					onEdit={edit}
					onDeleted={() => {
						setOpen(null);
						setNotice(__('Segment deleted.', 'personalized-offers-for-spacefast'));
						load();
					}}
					onCreateOffer={(segment) => {
						setOpen(null);
						onCreateOffer({ id: segment.id, name: segment.name, recipients: segment.recipients });
					}}
				/>
			)}

			{editing && (
				<SegmentFormModal
					segment={editing}
					options={options}
					onClose={() => setEditing(null)}
					onSaved={(saved) => {
						setEditing(null);
						setNotice(
							sprintf(
								/* translators: %s: segment name. */
								__('Segment “%s” saved.', 'personalized-offers-for-spacefast'),
								saved.name
							)
						);
						load();
						setOpen(saved.id);
					}}
				/>
			)}
		</div>
	);
}
