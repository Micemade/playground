/**
 * Offers screen → Settings: the same settings as WooCommerce → Settings →
 * Personalized Offers. Both save the pofsf_settings option through
 * Settings::sanitize(), so a change on either screen shows on the other.
 */
import { useEffect, useRef, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import {
	Button,
	Card,
	CardBody,
	CardHeader,
	Notice,
	TextControl,
	ToggleControl,
} from '@wordpress/components';
import { ajaxAction, assertSuccess, onAssistantChanges } from '../api';
import AiApp from './AiApp';
import BrandApp from './BrandApp';

function NumberSetting({ label, help, min, max, value, onChange }) {
	return (
		<TextControl
			__nextHasNoMarginBottom
			__next40pxDefaultSize
			type="number"
			label={label}
			help={help}
			min={min}
			max={max}
			value={String(value)}
			onChange={(next) => onChange(next === '' ? '' : Number(next))}
		/>
	);
}

export default function SettingsTab({ config, onChange, wooSettingsUrl }) {
	const [saved, setSaved] = useState(config.values || {});
	const [values, setValues] = useState(saved);
	const [saving, setSaving] = useState(false);
	const [notice, setNotice] = useState(null);

	const set = (key) => (value) => setValues((current) => ({ ...current, [key]: value }));
	const dirty = JSON.stringify(values) !== JSON.stringify(saved);
	const dirtyRef = useRef(dirty);
	dirtyRef.current = dirty;

	// Settings the assistant changed (update-settings); unsaved edits in the form are kept.
	useEffect(
		() =>
			onAssistantChanges(['personalized-offers-for-spacefast/update-settings'], () =>
				ajaxAction('pofsf_settings_get')
					.then((response) => {
						assertSuccess(response);
						setSaved(response.data.values);
						onChange({ values: response.data.values });

						if (!dirtyRef.current) {
							setValues(response.data.values);
						}
					})
					.catch(() => {})
			),
		[]
	);

	const save = async (event) => {
		event.preventDefault();
		setSaving(true);
		setNotice(null);

		try {
			const response = await ajaxAction('pofsf_settings_save', { settings: JSON.stringify(values) });
			assertSuccess(response, __('The settings could not be saved.', 'personalized-offers-for-spacefast'));
			// The server clamps numbers, so show what it stored.
			setSaved(response.data.values);
			setValues(response.data.values);
			onChange({ values: response.data.values });
			setNotice({ status: 'success', text: response.data.message });
		} catch (err) {
			setNotice({ status: 'error', text: err?.message });
		} finally {
			setSaving(false);
		}
	};

	const toggle = (key, label, help) => (
		<ToggleControl
			__nextHasNoMarginBottom
			label={label}
			help={help}
			checked={Boolean(values[key])}
			onChange={set(key)}
		/>
	);

	return (
		<div className="pofsf-settings-tab">
			<p className="description">
				{__('These are the same settings as in', 'personalized-offers-for-spacefast')}{' '}
				<a href={wooSettingsUrl}>{__('WooCommerce → Settings → Personalized Offers', 'personalized-offers-for-spacefast')}</a>
				{__('; saving here changes them there too.', 'personalized-offers-for-spacefast')}
			</p>

			<section className="pofsf-settings-tab__section">
				<h2>{__('Brand Snapshot', 'personalized-offers-for-spacefast')}</h2>
				<p className="description">
					{__('A locked brand snapshot is active. Generated pages use these tokens only.', 'personalized-offers-for-spacefast')}
				</p>
				<BrandApp
					versions={config.brand?.versions || []}
					brandName={config.brand?.name}
					onChange={(brand) => onChange({ brand })}
				/>
			</section>

			<section className="pofsf-settings-tab__section">
				<h2>{__('AI Connector', 'personalized-offers-for-spacefast')}</h2>
				<AiApp
					message={config.ai?.message}
					providers={config.ai?.providers || []}
					supported={Boolean(config.ai?.supported)}
				/>
			</section>

			<form className="pofsf-settings-tab__section" onSubmit={save}>
				<h2>{__('Offer defaults', 'personalized-offers-for-spacefast')}</h2>
				<Card>
					<CardHeader>
						<h3>{__('Offers', 'personalized-offers-for-spacefast')}</h3>
					</CardHeader>
					<CardBody className="pofsf-settings-tab__fields">
						<NumberSetting
							label={__('Default offer expiry (days)', 'personalized-offers-for-spacefast')}
							min={1}
							max={365}
							value={values.offer_default_expiry}
							onChange={set('offer_default_expiry')}
						/>
						<NumberSetting
							label={__('Max uses per offer', 'personalized-offers-for-spacefast')}
							min={1}
							max={1000000}
							value={values.offer_max_uses}
							onChange={set('offer_max_uses')}
						/>
						{toggle('free_shipping_coupon', __('Free shipping on new offers’ coupons', 'personalized-offers-for-spacefast'), __('The default for “Allow free shipping” in a new offer’s Coupon settings. Each offer can change it.', 'personalized-offers-for-spacefast'))}
					</CardBody>
				</Card>

				<Card>
					<CardHeader>
						<h3>{__('Customer preferences', 'personalized-offers-for-spacefast')}</h3>
					</CardHeader>
					<CardBody className="pofsf-settings-tab__fields">
						{toggle('preferences_page', __('Add a “My preferences” page to My Account', 'personalized-offers-for-spacefast'), __('Customers choose their sizes, colours and favourite categories, with their consent, and new offers for them use these. Mention it in your privacy policy.', 'personalized-offers-for-spacefast'))}
						{toggle('record_searches', __('Let customers allow recording their product searches', 'personalized-offers-for-spacefast'), __('Shown on My preferences. Searches appear in the customer’s profile.', 'personalized-offers-for-spacefast'))}
					</CardBody>
				</Card>

				<Card>
					<CardHeader>
						<h3>{__('Notifications and advanced', 'personalized-offers-for-spacefast')}</h3>
					</CardHeader>
					<CardBody className="pofsf-settings-tab__fields">
						{toggle('email_notifications', __('Email me when offer ZIP is ready', 'personalized-offers-for-spacefast'))}
						{toggle('debug_logging', __('Enable debug logging', 'personalized-offers-for-spacefast'))}
					</CardBody>
				</Card>

				{notice && (
					<Notice status={notice.status} isDismissible onRemove={() => setNotice(null)}>
						{notice.text}
					</Notice>
				)}

				<div className="pofsf-settings-tab__actions">
					<Button variant="primary" type="submit" isBusy={saving} disabled={saving || !dirty}>
						{__('Save settings', 'personalized-offers-for-spacefast')}
					</Button>
					{dirty && !saving && (
						<Button variant="tertiary" onClick={() => setValues(saved)}>
							{__('Discard changes', 'personalized-offers-for-spacefast')}
						</Button>
					)}
				</div>
			</form>
		</div>
	);
}
