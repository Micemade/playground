/**
 * The offers table's "Send email(s)" and "Social share" modals.
 */
import { useCopyToClipboard } from '@wordpress/compose';
import { useEffect, useRef, useState } from '@wordpress/element';
import { __, _n, sprintf } from '@wordpress/i18n';
import {
	Button,
	CheckboxControl,
	ColorIndicator,
	ColorPicker,
	Dropdown,
	ExternalLink,
	Modal,
	Notice,
	SelectControl,
	Spinner,
	TextControl,
	TextareaControl,
} from '@wordpress/components';
import { ajaxAction, assertSuccess } from '../api';

const PREVIEW_DELAY = 400;

/** Tabs in a modal's sidebar, styled as the Edit offer form's tabs. */
function SidebarTabs({ id, tabs, current, onSelect }) {
	const keys = (event) => {
		const index = tabs.findIndex(({ name }) => name === current);
		const moves = { ArrowLeft: index - 1, ArrowRight: index + 1, Home: 0, End: tabs.length - 1 };

		if (!(event.key in moves)) {
			return;
		}

		event.preventDefault();
		const next = tabs[(moves[event.key] + tabs.length) % tabs.length].name;
		onSelect(next);
		event.currentTarget.parentNode.querySelector(`#${id}-tab-${next}`)?.focus();
	};

	return (
		<div className="components-tab-panel__tabs pofsf-offer-form__tabs" role="tablist">
			{tabs.map(({ name, title }) => (
				<button
					key={name}
					type="button"
					role="tab"
					id={`${id}-tab-${name}`}
					aria-controls={`${id}-pane-${name}`}
					aria-selected={current === name}
					tabIndex={current === name ? 0 : -1}
					className={`components-button components-tab-panel__tabs-item${current === name ? ' is-active' : ''}`}
					onClick={() => onSelect(name)}
					onKeyDown={keys}
				>
					{title}
				</button>
			))}
		</div>
	);
}

function Counted({ Control = TextControl, label, value, onChange, max, help, ...props }) {
	return (
		<Control
			__nextHasNoMarginBottom
			{...(Control === TextControl ? { __next40pxDefaultSize: true } : {})}
			label={label}
			value={value}
			onChange={onChange}
			maxLength={max}
			help={
				<>
					{help && <>{help} </>}
					{sprintf(
						/* translators: 1: characters used, 2: character limit. */
						__('%1$d / %2$d characters', 'personalized-offers-for-spacefast'),
						value.length,
						max
					)}
				</>
			}
			{...props}
		/>
	);
}

/** The email as the first recipient gets it, rendered by the server as the design changes. */
function EmailPreview({ offerId, design }) {
	const [html, setHtml] = useState('');
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const request = useRef(0);
	const json = JSON.stringify(design);

	useEffect(() => {
		const id = ++request.current;
		setLoading(true);

		const timer = setTimeout(async () => {
			try {
				const response = await ajaxAction('pofsf_offer_email_preview', { offer_id: offerId, design: json });
				assertSuccess(response, __('The preview could not be loaded.', 'personalized-offers-for-spacefast'));

				if (id === request.current) {
					setHtml(response.data.html);
					setError(null);
				}
			} catch (err) {
				if (id === request.current) {
					setError(err?.message);
				}
			} finally {
				if (id === request.current) {
					setLoading(false);
				}
			}
		}, html ? PREVIEW_DELAY : 0);

		return () => clearTimeout(timer);
	}, [offerId, json]); // eslint-disable-line react-hooks/exhaustive-deps

	return (
		<div className="pofsf-offer-modal__preview">
			{html ? (
				// Links in the email open in a new tab, not inside the preview.
				<iframe title={__('Email preview', 'personalized-offers-for-spacefast')} srcDoc={html.replace('<head>', '<head><base target="_blank">')} sandbox="allow-same-origin allow-popups allow-popups-to-escape-sandbox" />
			) : (
				!error && <Spinner />
			)}
			{loading && html && (
				<span className="pofsf-offer-modal__preview-status">
					<Spinner />
					{__('Updating…', 'personalized-offers-for-spacefast')}
				</span>
			)}
			{error && (
				<Notice className="pofsf-offer-modal__preview-error" status="error" isDismissible={false}>
					{error}
				</Notice>
			)}
		</div>
	);
}

/** The email's texts: subject, title, body, button and footer. */
function EmailContentFields({ design, limits, onChange, onReset }) {
	const set = (key) => (value) => onChange({ ...design, [key]: value });

	return (
		<>
			<Counted label={__('Subject', 'personalized-offers-for-spacefast')} value={design.subject} onChange={set('subject')} max={limits.subject} />
			<Counted
				label={__('Title', 'personalized-offers-for-spacefast')}
				help={__('The heading at the top of the email.', 'personalized-offers-for-spacefast')}
				value={design.title}
				onChange={set('title')}
				max={limits.title}
			/>
			<Counted
				Control={TextareaControl}
				rows={8}
				label={__('Body text', 'personalized-offers-for-spacefast')}
				help={__('A blank line starts a new paragraph.', 'personalized-offers-for-spacefast')}
				value={design.body}
				onChange={set('body')}
				max={limits.body}
			/>
			<Counted
				label={__('Button text', 'personalized-offers-for-spacefast')}
				help={__('The button links to the offer’s Spacefast page.', 'personalized-offers-for-spacefast')}
				value={design.button_text}
				onChange={set('button_text')}
				max={limits.button_text}
			/>
			<Counted
				Control={TextareaControl}
				rows={3}
				label={__('Footer text', 'personalized-offers-for-spacefast')}
				value={design.footer}
				onChange={set('footer')}
				max={limits.footer}
			/>
			<p className="pofsf-muted">
				{__('Placeholders: {first_name}, {customer_name}, {site_title}; in the footer also {site_url}, {store_address} and {store_email}.', 'personalized-offers-for-spacefast')}
			</p>
			<Button variant="link" onClick={onReset}>
				{__('Reset to the offer’s texts', 'personalized-offers-for-spacefast')}
			</Button>
		</>
	);
}

/** A color option: its swatch and value open a color picker. */
function ColorField({ label, help, value, onChange }) {
	return (
		<div className="pofsf-email-color">
			<Dropdown
				popoverProps={{ placement: 'left-start' }}
				renderToggle={({ isOpen, onToggle }) => (
					<Button className="pofsf-email-color__toggle" onClick={onToggle} aria-expanded={isOpen}>
						<ColorIndicator colorValue={value} />
						<span className="pofsf-email-color__label">{label}</span>
						<code>{value}</code>
					</Button>
				)}
				renderContent={() => <ColorPicker color={value} onChange={onChange} enableAlpha={false} />}
			/>
			{help && <p className="pofsf-muted">{help}</p>}
		</div>
	);
}

/** The logo: chosen from the media library, as in WooCommerce's email settings. */
function LogoField({ value, onChange }) {
	const media = window.wp?.media;

	const choose = () => {
		const frame = media({
			title: __('Email logo', 'personalized-offers-for-spacefast'),
			library: { type: 'image' },
			button: { text: __('Use as logo', 'personalized-offers-for-spacefast') },
			multiple: false,
		});

		frame.on('select', () => {
			const image = frame.state().get('selection').first()?.toJSON();

			if (image?.url) {
				onChange(image.url);
			}
		});
		frame.open();
	};

	return (
		<div className="pofsf-logo-field">
			<span className="pofsf-logo-field__label">{__('Logo', 'personalized-offers-for-spacefast')}</span>
			{value ? (
				<img className="pofsf-logo-field__image" src={value} alt="" />
			) : (
				<p className="pofsf-muted">{__('No logo: the store name is shown instead.', 'personalized-offers-for-spacefast')}</p>
			)}
			<div className="pofsf-logo-field__actions">
				{media && (
					<Button variant="secondary" size="compact" onClick={choose}>
						{value ? __('Replace', 'personalized-offers-for-spacefast') : __('Choose logo', 'personalized-offers-for-spacefast')}
					</Button>
				)}
				{value && (
					<Button variant="tertiary" size="compact" isDestructive onClick={() => onChange('')}>
						{__('Remove', 'personalized-offers-for-spacefast')}
					</Button>
				)}
			</div>
		</div>
	);
}

/**
 * WooCommerce's email design options (WooCommerce > Settings > Emails) for
 * this offer's email; they start as the store's.
 */
function EmailStyleFields({ style, data, onChange, onReset }) {
	const set = (key) => (value) => onChange({ ...style, [key]: value });
	const newTemplatesOnly = data.improvements
		? undefined
		: __('Used by WooCommerce’s new email templates, which are off in this store.', 'personalized-offers-for-spacefast');
	const changed = JSON.stringify(style) !== JSON.stringify(data.style_defaults);

	return (
		<>
			<p className="pofsf-muted">
				{__('This offer’s email starts with your store’s email design. Changes here apply to this email only.', 'personalized-offers-for-spacefast')}{' '}
				<ExternalLink href={data.settings_url}>{__('WooCommerce email settings', 'personalized-offers-for-spacefast')}</ExternalLink>
			</p>

			<h3 className="pofsf-email-style__heading">{__('Email template', 'personalized-offers-for-spacefast')}</h3>
			<LogoField value={style.header_image} onChange={set('header_image')} />
			<TextControl
				__nextHasNoMarginBottom
				__next40pxDefaultSize
				type="number"
				min={20}
				max={600}
				label={__('Logo width (px)', 'personalized-offers-for-spacefast')}
				help={newTemplatesOnly}
				value={style.header_image_width}
				onChange={set('header_image_width')}
			/>
			<SelectControl
				__nextHasNoMarginBottom
				__next40pxDefaultSize
				label={__('Header alignment', 'personalized-offers-for-spacefast')}
				help={newTemplatesOnly}
				value={style.header_alignment}
				onChange={set('header_alignment')}
				options={[
					{ value: 'left', label: __('Left', 'personalized-offers-for-spacefast') },
					{ value: 'center', label: __('Center', 'personalized-offers-for-spacefast') },
					{ value: 'right', label: __('Right', 'personalized-offers-for-spacefast') },
				]}
			/>
			<SelectControl
				__nextHasNoMarginBottom
				__next40pxDefaultSize
				label={__('Font family', 'personalized-offers-for-spacefast')}
				help={newTemplatesOnly}
				value={style.font_family}
				onChange={set('font_family')}
				options={data.fonts.map((font) => ({ value: font, label: font }))}
			/>

			<h3 className="pofsf-email-style__heading">{__('Color palette', 'personalized-offers-for-spacefast')}</h3>
			<ColorField
				label={__('Accent', 'personalized-offers-for-spacefast')}
				help={__('Buttons and links.', 'personalized-offers-for-spacefast')}
				value={style.base_color}
				onChange={set('base_color')}
			/>
			<ColorField label={__('Email background', 'personalized-offers-for-spacefast')} value={style.background_color} onChange={set('background_color')} />
			<ColorField label={__('Content background', 'personalized-offers-for-spacefast')} value={style.body_background_color} onChange={set('body_background_color')} />
			<ColorField label={__('Heading & text', 'personalized-offers-for-spacefast')} value={style.text_color} onChange={set('text_color')} />
			<ColorField
				label={__('Secondary text', 'personalized-offers-for-spacefast')}
				help={__('The footer text.', 'personalized-offers-for-spacefast')}
				value={style.footer_text_color}
				onChange={set('footer_text_color')}
			/>

			<Button variant="link" onClick={onReset} disabled={!changed} accessibleWhenDisabled>
				{__('Reset to WooCommerce settings', 'personalized-offers-for-spacefast')}
			</Button>
		</>
	);
}

const RECIPIENT_STATUS = {
	used: __('used up', 'personalized-offers-for-spacefast'),
};

function SendFields({ data, selected, setSelected }) {
	if (data.recipients.length === 0) {
		return <p className="pofsf-muted">{__('This offer has no customer with an email address.', 'personalized-offers-for-spacefast')}</p>;
	}

	if (data.type === 'single') {
		const person = data.recipients[0];

		return (
			<div className="pofsf-email-to">
				<span className="pofsf-email-to__label">{__('To', 'personalized-offers-for-spacefast')}</span>
				<span>
					{person.name !== person.email && <strong>{person.name} </strong>}
					<span className="pofsf-muted">{person.email}</span>
				</span>
			</div>
		);
	}

	const allIds = data.recipients.map((person) => person.id);
	const toggle = (id, on) => setSelected((current) => (on ? [...current, id] : current.filter((item) => item !== id)));

	return (
		<fieldset className="pofsf-email-recipients">
			<legend>
				{sprintf(
					/* translators: 1: customers chosen, 2: customers in the group. */
					__('Customers (%1$d of %2$d)', 'personalized-offers-for-spacefast'),
					selected.length,
					allIds.length
				)}
				<Button variant="link" onClick={() => setSelected(selected.length === allIds.length ? [] : allIds)}>
					{selected.length === allIds.length ? __('Select none', 'personalized-offers-for-spacefast') : __('Select all', 'personalized-offers-for-spacefast')}
				</Button>
			</legend>
			<p className="pofsf-muted">{__('Each customer gets their own personal link.', 'personalized-offers-for-spacefast')}</p>
			{data.recipients.map((person) => (
				<CheckboxControl
					key={person.id}
					__nextHasNoMarginBottom
					checked={selected.includes(person.id)}
					onChange={(on) => toggle(person.id, on)}
					label={
						<>
							{person.name} <span className="pofsf-muted">{person.email}</span>
							{RECIPIENT_STATUS[person.status] && <span className="pofsf-status is-used">{RECIPIENT_STATUS[person.status]}</span>}
						</>
					}
				/>
			))}
		</fieldset>
	);
}

/**
 * "Send email(s)": the offer's email in WooCommerce's email template, sent
 * to the customer or the group's customers. Not for public offers.
 */
export function EmailModal({ offer, onClose, onSent }) {
	const [data, setData] = useState(null);
	const [design, setDesign] = useState(null);
	const [saved, setSaved] = useState(null);
	const [tab, setTab] = useState('settings');
	const [selected, setSelected] = useState([]);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);
	const [notice, setNotice] = useState(null);

	useEffect(() => {
		ajaxAction('pofsf_offer_email_get', { offer_id: offer.id })
			.then((response) => {
				assertSuccess(response, __('The email could not be loaded.', 'personalized-offers-for-spacefast'));
				setData(response.data);
				setDesign(response.data.design);
				setSaved(response.data.design);
				// Customers who used the offer up are not chosen by default.
				setSelected(response.data.recipients.filter((person) => person.status !== 'used').map((person) => person.id));
			})
			.catch((err) => setError(err?.message));
	}, [offer.id]);

	const dirty = design && saved && JSON.stringify(design) !== JSON.stringify(saved);
	const count = data?.type === 'group' ? selected.length : data?.recipients.length || 0;

	const run = async (action, params, done) => {
		setBusy(true);
		setError(null);
		setNotice(null);

		try {
			const response = await ajaxAction(action, { offer_id: offer.id, design: JSON.stringify(design), ...params });
			assertSuccess(response, __('Something went wrong.', 'personalized-offers-for-spacefast'));
			done(response.data);
		} catch (err) {
			setError(err?.message);
		} finally {
			setBusy(false);
		}
	};

	const save = () => run('pofsf_offer_email_save', {}, (result) => {
		setSaved(result.design);
		setDesign(result.design);
		setNotice(__('Email saved.', 'personalized-offers-for-spacefast'));
	});

	const sendTest = () => run('pofsf_offer_email_send', { test: '1' }, () =>
		setNotice(sprintf(
			/* translators: %s: email address. */
			__('Test email sent to %s.', 'personalized-offers-for-spacefast'),
			data.admin_email
		))
	);

	const send = () => run('pofsf_offer_email_send', { recipient_ids: JSON.stringify(selected) }, (result) => {
		setSaved(design);
		onSent(
			sprintf(
				/* translators: 1: emails sent, 2: offer ID. */
				_n('%1$d email sent for offer #%2$d.', '%1$d emails sent for offer #%2$d.', result.sent, 'personalized-offers-for-spacefast'),
				result.sent,
				offer.id
			) + (result.failed.length ? ' ' + sprintf(
				/* translators: %s: email addresses. */
				__('Not sent to: %s', 'personalized-offers-for-spacefast'),
				result.failed.join(', ')
			) : '')
		);
	});

	const published = Boolean(data?.page_url);
	const subjectMissing = design && !design.subject.trim();

	return (
		<Modal
			className="pofsf-offer-modal pofsf-email-modal"
			title={
				offer.type === 'single'
					? sprintf(
						/* translators: 1: offer ID, 2: customer name. */
						__('Email offer #%1$d to %2$s', 'personalized-offers-for-spacefast'),
						offer.id,
						offer.customer.name
					)
					: sprintf(
						/* translators: %d: offer ID. */
						__('Email offer #%d', 'personalized-offers-for-spacefast'),
						offer.id
					)
			}
			onRequestClose={busy ? () => { } : onClose}
			size="fill"
		>
			<div className="pofsf-offer-modal__layout">
				{design ? <EmailPreview offerId={offer.id} design={design} /> : <div className="pofsf-offer-modal__preview">{!error && <Spinner />}</div>}

				<div className="pofsf-offer-modal__sidebar">
					{data && design && (
						<div className="pofsf-offer-form">
							<SidebarTabs
								id="pofsf-email"
								current={tab}
								onSelect={setTab}
								tabs={[
									{ name: 'settings', title: __('Email settings', 'personalized-offers-for-spacefast') },
									{ name: 'design', title: __('Email design', 'personalized-offers-for-spacefast') },
								]}
							/>

							<div className="pofsf-offer-form__pane" role="tabpanel" id="pofsf-email-pane-send" aria-labelledby="pofsf-email-tab-send" hidden={tab !== 'settings'}>
								{!published && (
									<Notice status="warning" isDismissible={false}>
										{__('Publish the offer to Spacefast first: the email’s button links to its page.', 'personalized-offers-for-spacefast')}
									</Notice>
								)}
								<SendFields
									data={data}
									selected={selected}
									setSelected={setSelected}
								/>
								<hr className="pofsf-email-divider" />
								<EmailContentFields
									design={design}
									limits={data.limits}
									onChange={setDesign}
									onReset={() => setDesign({ ...data.defaults, style: design.style })}
								/>
								<hr className="pofsf-email-divider" />
								{published && (
									<p className="pofsf-muted">
										{data.type === 'group'
											? __('The button opens each customer’s personal link to:', 'personalized-offers-for-spacefast')
											: __('The button opens:', 'personalized-offers-for-spacefast')}{' '}
										<ExternalLink href={data.page_url}>{__('the offer page', 'personalized-offers-for-spacefast')}</ExternalLink>
									</p>
								)}
								{offer.spacefast?.outdated && (
									<Notice status="warning" isDismissible={false}>
										{__('The offer has changes that are not published yet. Update its Space first so customers see them.', 'personalized-offers-for-spacefast')}
									</Notice>
								)}
								{data.last_sent && (
									<p className="pofsf-muted">
										{sprintf(
											/* translators: 1: date, 2: number of emails. */
											_n('Last sent %1$s, to %2$d address.', 'Last sent %1$s, to %2$d addresses.', data.last_sent.count, 'personalized-offers-for-spacefast'),
											data.last_sent.at,
											data.last_sent.count
										)}
									</p>
								)}
								<Button variant="secondary" onClick={sendTest} disabled={busy || !published || subjectMissing} accessibleWhenDisabled>
									{sprintf(
										/* translators: %s: email address. */
										__('Send a test to %s', 'personalized-offers-for-spacefast'),
										data.admin_email
									)}
								</Button>
							</div>

							<div className="pofsf-offer-form__pane" role="tabpanel" id="pofsf-email-pane-design" aria-labelledby="pofsf-email-tab-design" hidden={tab !== 'design'}>
								<EmailStyleFields
									style={design.style}
									data={data}
									onChange={(style) => setDesign({ ...design, style })}
									onReset={() => setDesign({ ...design, style: data.style_defaults })}
								/>
							</div>
						</div>
					)}
				</div>
			</div>

			<div className="pofsf-offer-modal__footer">
				{error && (
					<Notice status="error" isDismissible={false}>
						{error}
					</Notice>
				)}
				{notice && !error && (
					<Notice status="success" onRemove={() => setNotice(null)}>
						{notice}
					</Notice>
				)}
				<div className="pofsf-modal-actions">
					<Button variant="tertiary" onClick={onClose} disabled={busy}>
						{__('Close', 'personalized-offers-for-spacefast')}
					</Button>
					<Button variant="secondary" onClick={save} disabled={busy || !dirty} accessibleWhenDisabled>
						{__('Save email', 'personalized-offers-for-spacefast')}
					</Button>
					<Button variant="primary" onClick={send} isBusy={busy} disabled={busy || !data || !published || subjectMissing || count === 0} accessibleWhenDisabled>
						{data?.type === 'single'
							? __('Send email', 'personalized-offers-for-spacefast')
							: sprintf(
								/* translators: %d: number of emails. */
								_n('Send %d email', 'Send %d emails', count, 'personalized-offers-for-spacefast'),
								count
							)}
					</Button>
				</div>
			</div>
		</Modal>
	);
}

/*
 * Social networks. `limit`: characters a post may have; `link`: characters
 * the network counts a link as (X and Mastodon shorten links to 23).
 * `share` builds the network's share address; `textless` networks take
 * only the link (their post text is pasted in by hand).
 */
const NETWORKS = [
	{
		name: 'linkedin',
		label: 'LinkedIn',
		limit: 3000,
		share: ({ text, url }) => `https://www.linkedin.com/feed/?shareActive=true&text=${encodeURIComponent(`${text}\n\n${url}`)}`,
	},
	{
		name: 'x',
		label: 'X',
		limit: 280,
		link: 23,
		share: ({ text, url }) => `https://x.com/intent/post?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`,
	},
	{
		name: 'bluesky',
		label: 'Bluesky',
		limit: 300,
		share: ({ text, url }) => `https://bsky.app/intent/compose?text=${encodeURIComponent(`${text}\n\n${url}`)}`,
	},
	{
		name: 'facebook',
		label: 'Facebook',
		textless: true,
		share: ({ url }) => `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
	},
	{
		name: 'mastodon',
		label: 'Mastodon',
		limit: 500,
		link: 23,
		share: ({ text, url, instance }) => `https://${instance}/share?text=${encodeURIComponent(`${text}\n\n${url}`)}`,
	},
	{
		name: 'threads',
		label: 'Threads',
		limit: 500,
		share: ({ text, url }) => `https://www.threads.net/intent/post?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`,
	},
	{
		name: 'whatsapp',
		label: 'WhatsApp',
		share: ({ text, url }) => `https://wa.me/?text=${encodeURIComponent(`${text}\n\n${url}`)}`,
	},
	{
		name: 'telegram',
		label: 'Telegram',
		share: ({ text, url }) => `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`,
	},
	{
		name: 'reddit',
		label: 'Reddit',
		limit: 300,
		titleOnly: true,
		share: ({ title, url }) => `https://www.reddit.com/submit?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`,
	},
	{
		name: 'pinterest',
		label: 'Pinterest',
		limit: 500,
		// The pin links to the page; its description is the text alone.
		noLink: true,
		needsImage: true,
		share: ({ text, url, image }) => `https://www.pinterest.com/pin/create/button/?url=${encodeURIComponent(url)}&media=${encodeURIComponent(image)}&description=${encodeURIComponent(text)}`,
	},
];

const MASTODON_KEY = 'pofsfMastodonInstance';

function storedInstance() {
	try {
		return window.localStorage.getItem(MASTODON_KEY) || 'mastodon.social';
	} catch (e) {
		return 'mastodon.social';
	}
}

/** Characters the network counts for the post: its text plus the link. */
function postLength(network, text, url) {
	if (network.titleOnly || network.textless) {
		return 0;
	}

	const chars = [...text].length;

	return chars + (url && !network.noLink ? 2 + (network.link || [...url].length) : 0);
}

function domainOf(url) {
	try {
		return new URL(url).hostname.replace(/^www\./, '');
	} catch (e) {
		return '';
	}
}

/** The post as the network shows it: the account, the text and the link card. */
function SocialPost({ network, card, text, url }) {
	const domain = domainOf(url);
	const shownText = network.titleOnly ? card.title : network.textless ? '' : text;

	return (
		<div className={`pofsf-social-post is-${network.name}`}>
			<div className="pofsf-social-post__account">
				<span className="pofsf-social-post__avatar" aria-hidden="true">{(card.site_name || '?').charAt(0).toUpperCase()}</span>
				<span>
					<strong>{card.site_name}</strong>
					<span className="pofsf-muted">{network.label}</span>
				</span>
			</div>
			{shownText && <p className="pofsf-social-post__text">{shownText}</p>}
			<div className="pofsf-social-card">
				{card.image ? (
					<img className="pofsf-social-card__image" src={card.image} alt="" />
				) : (
					<div className="pofsf-social-card__image is-empty">{__('No image', 'personalized-offers-for-spacefast')}</div>
				)}
				<div className="pofsf-social-card__body">
					<span className="pofsf-social-card__domain">{domain}</span>
					<strong className="pofsf-social-card__title">{card.title}</strong>
					{card.description && <span className="pofsf-social-card__description">{card.description}</span>}
				</div>
			</div>
		</div>
	);
}

function CopyButton({ text, label }) {
	const [copied, setCopied] = useState(false);
	const timer = useRef();
	const ref = useCopyToClipboard(text, () => {
		setCopied(true);
		clearTimeout(timer.current);
		timer.current = setTimeout(() => setCopied(false), 2000);
	});

	useEffect(() => () => clearTimeout(timer.current), []);

	return (
		<Button ref={ref} variant="secondary">
			{copied ? __('Copied', 'personalized-offers-for-spacefast') : label}
		</Button>
	);
}

/**
 * "Social share" for a public offer: the post and its link card as each
 * network shows them, and buttons that open the network's share form.
 */
export function ShareModal({ offer, onClose }) {
	const [data, setData] = useState(null);
	const [text, setText] = useState('');
	const [network, setNetwork] = useState(NETWORKS[0].name);
	const [instance, setInstance] = useState(storedInstance);
	const [error, setError] = useState(null);

	useEffect(() => {
		ajaxAction('pofsf_offer_share_get', { offer_id: offer.id })
			.then((response) => {
				assertSuccess(response, __('The share details could not be loaded.', 'personalized-offers-for-spacefast'));
				setData(response.data);
				const { title, description } = response.data.card;
				setText(description ? `${title}\n\n${description}` : title);
			})
			.catch((err) => setError(err?.message));
	}, [offer.id]);

	const current = NETWORKS.find((item) => item.name === network);
	const url = data?.url || '';
	const length = postLength(current, text, url);
	const tooLong = current.limit && length > current.limit;
	const cleanInstance = instance.trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
	const shareUrl = data && current.share({ text, url, title: data.card.title, image: data.card.image, instance: cleanInstance || 'mastodon.social' });
	const blocked = !url || tooLong || (current.needsImage && !data?.card.image);

	const chooseInstance = (value) => {
		setInstance(value);

		try {
			window.localStorage.setItem(MASTODON_KEY, value);
		} catch (e) {
			// Remembering the server is only a convenience.
		}
	};

	const nativeShare = typeof window.navigator.share === 'function'
		? () => window.navigator.share({ title: data.card.title, text, url }).catch(() => { })
		: null;

	return (
		<Modal
			className="pofsf-share-modal"
			title={sprintf(
				/* translators: %d: offer ID. */
				__('Share public offer #%d', 'personalized-offers-for-spacefast'),
				offer.id
			)}
			onRequestClose={onClose}
			size="large"
		>
			{error && (
				<Notice status="error" isDismissible={false}>
					{error}
				</Notice>
			)}
			{!data && !error && <Spinner />}

			{data && (
				<>
					{!url && (
						<Notice status="warning" isDismissible={false}>
							{__('Publish the offer to Spacefast first: the post links to its page.', 'personalized-offers-for-spacefast')}
						</Notice>
					)}

					<div className="pofsf-share">
						<div className="pofsf-share__compose">
							<TextareaControl
								__nextHasNoMarginBottom
								label={__('Post text', 'personalized-offers-for-spacefast')}
								help={__('The link to the offer page is added after the text.', 'personalized-offers-for-spacefast')}
								rows={6}
								value={text}
								onChange={setText}
							/>
							{url && (
								<p className="pofsf-share__link">
									<ExternalLink href={url}>{url}</ExternalLink>
								</p>
							)}

							<div className="pofsf-share__networks" role="radiogroup" aria-label={__('Social network', 'personalized-offers-for-spacefast')}>
								{NETWORKS.map((item) => (
									<Button
										key={item.name}
										role="radio"
										aria-checked={item.name === network}
										variant={item.name === network ? 'primary' : 'secondary'}
										size="compact"
										onClick={() => setNetwork(item.name)}
									>
										{item.label}
									</Button>
								))}
							</div>

							{current.name === 'mastodon' && (
								<TextControl
									__nextHasNoMarginBottom
									__next40pxDefaultSize
									label={__('Your Mastodon server', 'personalized-offers-for-spacefast')}
									value={instance}
									onChange={chooseInstance}
									placeholder="mastodon.social"
								/>
							)}

							<p className={tooLong ? 'pofsf-share__count is-over' : 'pofsf-share__count'}>
								{current.textless
									? sprintf(
										/* translators: %s: social network. */
										__('%s takes only the link: copy the text and paste it into the post.', 'personalized-offers-for-spacefast'),
										current.label
									)
									: current.titleOnly
										? sprintf(
											/* translators: %s: social network. */
											__('%s posts the link with the offer headline as its title.', 'personalized-offers-for-spacefast'),
											current.label
										)
										: !current.limit
											? null
											: current.noLink
												? sprintf(
													/* translators: 1: characters used, 2: character limit, 3: social network. */
													__('%1$d / %2$d characters on %3$s.', 'personalized-offers-for-spacefast'),
													length,
													current.limit,
													current.label
												)
												: sprintf(
													/* translators: 1: characters used, 2: character limit, 3: social network. */
													__('%1$d / %2$d characters on %3$s, with the link.', 'personalized-offers-for-spacefast'),
													length,
													current.limit,
													current.label
												)}
								{current.needsImage && !data.card.image && ' ' + __('Pinterest needs an image: add a product with an image to the offer.', 'personalized-offers-for-spacefast')}
							</p>

							<div className="pofsf-modal-actions pofsf-share__actions">
								<CopyButton text={url ? `${text}\n\n${url}` : text} label={__('Copy text and link', 'personalized-offers-for-spacefast')} />
								{nativeShare && url && (
									<Button variant="secondary" onClick={nativeShare}>
										{__('Share…', 'personalized-offers-for-spacefast')}
									</Button>
								)}
								<Button
									variant="primary"
									href={blocked ? undefined : shareUrl}
									target="_blank"
									rel="noopener noreferrer"
									disabled={blocked}
									accessibleWhenDisabled
								>
									{sprintf(
										/* translators: %s: social network. */
										__('Share on %s', 'personalized-offers-for-spacefast'),
										current.label
									)}
								</Button>
							</div>
						</div>

						<div className="pofsf-share__preview">
							<span className="pofsf-share__preview-label">{__('Preview', 'personalized-offers-for-spacefast')}</span>
							<SocialPost network={current} card={data.card} text={text} url={url || 'https://spacefast.app'} />
							<p className="pofsf-muted">
								{__('Networks build the link card from the published page. If an older Space shows no card, use Update Space.', 'personalized-offers-for-spacefast')}
							</p>
						</div>
					</div>
				</>
			)}
		</Modal>
	);
}
