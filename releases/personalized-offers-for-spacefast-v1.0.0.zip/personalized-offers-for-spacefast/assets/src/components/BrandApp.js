/**
 * Brand snapshot panel: capture the store brand, list locked versions,
 * and activate a previous version. State refreshes in place from the
 * server after every mutation — no page reload.
 */
import { useEffect, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button, Card, CardBody, CardHeader, Notice, Spinner } from '@wordpress/components';
import { ajaxAction, assertSuccess, onAssistantChanges } from '../api';

/**
 * $wpdb returns every column as a string, so is_active arrives as "0"/"1".
 * The string "0" is truthy in JS — normalize to real booleans/numbers or
 * the per-row action buttons never render.
 */
function normalizeVersions(rows) {
	if (!Array.isArray(rows)) {
		return [];
	}

	return rows.map((row) => ({
		version: Number(row.version) || 0,
		isActive:
			row.is_active === true ||
			row.is_active === 1 ||
			row.is_active === '1',
		createdAt: row.created_at || row.createdAt || '',
	}));
}

function formatDate(iso) {
	if (!iso) {
		return '';
	}
	const date = new Date(String(iso).replace(' ', 'T') + 'Z');
	return Number.isNaN(date.getTime()) ? iso : date.toLocaleDateString();
}

export default function BrandApp({ versions: initialVersions, brandName: initialBrandName, onChange }) {
	const [versions, setVersions] = useState(() => normalizeVersions(initialVersions));
	const [brandName, setBrandName] = useState(initialBrandName || '');
	const [busy, setBusy] = useState(null);
	const [notice, setNotice] = useState(null);

	const refreshVersions = async () => {
		const response = await ajaxAction('pofsf_brand_versions');
		assertSuccess(response, __('Could not refresh brand versions.', 'personalized-offers-for-spacefast'));
		setVersions(normalizeVersions(response.data.versions));
		setBrandName(response.data.brand_name || '');
		onChange?.({ versions: response.data.versions, name: response.data.brand_name || '' });
	};

	// The assistant can lock the brand too (lock-brand).
	useEffect(() => onAssistantChanges(['personalized-offers-for-spacefast/lock-brand'], () => refreshVersions().catch(() => {})), []);

	const onCapture = async () => {
		setBusy('capture');
		setNotice(null);

		try {
			// The server captures the brand and stores it as a new version.
			const locked = await ajaxAction('pofsf_lock_brand');
			assertSuccess(locked, __('Could not lock the brand snapshot.', 'personalized-offers-for-spacefast'));

			await refreshVersions();

			setNotice({
				status: 'success',
				message:
					locked.data?.message ||
					__('Brand snapshot locked successfully.', 'personalized-offers-for-spacefast'),
			});
		} catch (error) {
			setNotice({
				status: 'error',
				message: error?.message || __('Brand capture failed.', 'personalized-offers-for-spacefast'),
			});
		} finally {
			setBusy(null);
		}
	};

	const onDelete = async (version) => {
		if (
			!window.confirm(
				__('Delete this brand version? This cannot be undone.', 'personalized-offers-for-spacefast')
			)
		) {
			return;
		}

		setBusy(`delete-${version}`);
		setNotice(null);

		try {
			const response = await ajaxAction('pofsf_delete_brand_version', {
				version: String(version),
			});
			assertSuccess(response, __('Could not delete brand version.', 'personalized-offers-for-spacefast'));

			await refreshVersions();

			setNotice({
				status: 'success',
				message:
					response.data?.message ||
					__('Brand version deleted.', 'personalized-offers-for-spacefast'),
			});
		} catch (error) {
			setNotice({
				status: 'error',
				message:
					error?.message || __('Could not delete brand version.', 'personalized-offers-for-spacefast'),
			});
		} finally {
			setBusy(null);
		}
	};

	const onActivate = async (version) => {
		if (!window.confirm(__('Activate this brand version?', 'personalized-offers-for-spacefast'))) {
			return;
		}

		setBusy(`activate-${version}`);
		setNotice(null);

		try {
			const response = await ajaxAction('pofsf_activate_brand_version', {
				version: String(version),
			});
			assertSuccess(response, __('Could not activate brand version.', 'personalized-offers-for-spacefast'));

			await refreshVersions();

			setNotice({
				status: 'success',
				message:
					response.data?.message ||
					__('Brand version activated.', 'personalized-offers-for-spacefast'),
			});
		} catch (error) {
			setNotice({
				status: 'error',
				message:
					error?.message || __('Could not activate brand version.', 'personalized-offers-for-spacefast'),
			});
		} finally {
			setBusy(null);
		}
	};

	return (
		<Card>
			<CardHeader>
				<strong>
					{brandName
						? brandName
						: __('No brand snapshot yet', 'personalized-offers-for-spacefast')}
				</strong>
			</CardHeader>
			<CardBody>
				{notice && (
					<Notice status={notice.status} isDismissible onRemove={() => setNotice(null)}>
						{notice.message}
					</Notice>
				)}

				{versions.length > 0 && (
					<table className="widefat striped">
						<thead>
							<tr>
								<th>{__('Version', 'personalized-offers-for-spacefast')}</th>
								<th>{__('Active', 'personalized-offers-for-spacefast')}</th>
								<th>{__('Captured', 'personalized-offers-for-spacefast')}</th>
								<th>{__('Actions', 'personalized-offers-for-spacefast')}</th>
							</tr>
						</thead>
						<tbody>
							{versions.map((row) => (
								<tr key={row.version}>
									<td>v{row.version}</td>
									<td>{row.isActive ? '●' : ''}</td>
									<td>{formatDate(row.createdAt)}</td>
									<td>
										{!row.isActive && (
											<span style={{ display: 'inline-flex', gap: '0.5rem' }}>
												<Button
													variant="secondary"
													size="small"
													isBusy={busy === `activate-${row.version}`}
													disabled={busy !== null}
													onClick={() => onActivate(row.version)}
												>
													{__('Activate', 'personalized-offers-for-spacefast')}
												</Button>
												<Button
													variant="secondary"
													size="small"
													isDestructive
													isBusy={busy === `delete-${row.version}`}
													disabled={busy !== null}
													onClick={() => onDelete(row.version)}
												>
													{__('Delete', 'personalized-offers-for-spacefast')}
												</Button>
											</span>
										)}
									</td>
								</tr>
							))}
						</tbody>
					</table>
				)}

				<p style={{ marginTop: '1rem' }}>
					<Button
						variant="primary"
						isBusy={busy === 'capture'}
						disabled={busy !== null}
						onClick={onCapture}
					>
						{busy === 'capture' ? (
							<>
								<Spinner /> {__('Capturing…', 'personalized-offers-for-spacefast')}
							</>
						) : (
							__('Capture & lock brand', 'personalized-offers-for-spacefast')
						)}
					</Button>
				</p>
				<p className="description">
					{__(
						'Captures logo, colors and fonts from Global Styles and Email branding into a locked, versioned snapshot.',
						'personalized-offers-for-spacefast'
					)}
				</p>
			</CardBody>
		</Card>
	);
}
