/**
 * After the assistant creates offers: waits until they are built (offers
 * from create-offers build in the background), refreshes the Offers list
 * and pops up "Your new offer is ready for review and publishing".
 *
 * The server keeps the offers still waiting for this notice (see
 * ChatAgent::NEW_OFFERS_META), so it also appears after a reload or when
 * the chat reply never arrived. Mounted beside the tabs, so it works
 * whichever tab is open.
 */
import { useEffect, useRef, useState } from '@wordpress/element';
import { __, _n, sprintf } from '@wordpress/i18n';
import { Button, Modal, Spinner } from '@wordpress/components';
import { ajaxAction, announceAssistantChanges, assertSuccess, onAssistantChanges } from '../api';

const CREATE_ABILITIES = ['personalized-offers-for-spacefast/create-offers', 'personalized-offers-for-spacefast/create-shared-offer'];
const BUILDING = ['pending', 'building'];
const POLL_MS = 5000;
const MAX_POLLS = 120; // Ten minutes; then the offers still building are reported as not ready yet.

/**
 * @param {Object}   props
 * @param {boolean}  props.spacefastConnected
 * @param {Function} props.onReady  The new offers are ready (show the Offers tab).
 * @param {Function} props.onAction (action, offerId): 'edit' opens Edit offer, 'publish' the Publish to Spacefast dialog.
 */
export default function AssistantOffersNotice({ spacefastConnected, onReady, onAction }) {
	// Polling while true; the offers to watch come from the server and the chat reply.
	const [active, setActive] = useState(true);
	const [result, setResult] = useState(null);
	// Offers still building, for the "Building offer" popup.
	const [building, setBuilding] = useState(0);
	const extra = useRef([]);
	const polls = useRef(0);

	useEffect(
		() => onAssistantChanges(CREATE_ABILITIES, (detail) => {
			extra.current = [...new Set([...extra.current, ...(detail?.offerIds || []).map(Number).filter(Boolean)])];
			polls.current = 0;
			setActive(true);
		}),
		[]
	);

	useEffect(() => {
		if (!active) {
			return undefined;
		}

		let cancelled = false;
		let timer;

		const check = async () => {
			polls.current += 1;

			try {
				const response = await ajaxAction('pofsf_offers_status', { offer_ids: JSON.stringify(extra.current) });
				assertSuccess(response);

				if (cancelled) {
					return;
				}

				const statuses = response.data.statuses || {};
				const watching = [...new Set([...(response.data.pending || []).map(Number), ...extra.current])].filter(
					(id) => statuses[id] !== undefined
				);

				if (watching.length === 0) {
					extra.current = [];
					setBuilding(0);
					setActive(false);
					return;
				}

				const stillBuilding = watching.filter((id) => BUILDING.includes(statuses[id]));

				if (stillBuilding.length > 0 && polls.current < MAX_POLLS) {
					setBuilding(stillBuilding.length);
					timer = setTimeout(check, POLL_MS);
					return;
				}

				setBuilding(0);

				const failed = watching.filter((id) => statuses[id] === 'failed').length;
				const done = watching.filter((id) => !BUILDING.includes(statuses[id]));

				const readyIds = done.filter((id) => statuses[id] !== 'failed');

				extra.current = [];
				setActive(false);
				// Newest first; the actions apply to the only (or newest) ready offer.
				setResult({ ready: readyIds.length, failed, building: stillBuilding.length, offerId: Math.max(0, ...readyIds) });

				if (readyIds.length > 0) {
					onReady();
				}

				// The Offers list shows the built offers; the notice will not show these again.
				announceAssistantChanges(['personalized-offers-for-spacefast/create-offers']);
				ajaxAction('pofsf_offers_notice_seen', { offer_ids: JSON.stringify(done) }).catch(() => {});
			} catch (err) {
				if (!cancelled) {
					timer = setTimeout(check, POLL_MS);
				}
			}
		};

		check();

		return () => {
			cancelled = true;
			clearTimeout(timer);
		};
	}, [active]);

	if (!result) {
		return building > 0 ? (
			<div className="pofsf-building-offer" role="status" aria-live="polite">
				<Spinner />
				<div>
					<strong>
						{building === 1
							? __('Building offer', 'personalized-offers-for-spacefast')
							: sprintf(
									/* translators: %d: number of offers. */
									__('Building %d offers', 'personalized-offers-for-spacefast'),
									building
							  )}
					</strong>
					<span>{__('You can keep working; you will be told when it is ready.', 'personalized-offers-for-spacefast')}</span>
				</div>
			</div>
		) : null;
	}

	const close = () => setResult(null);

	return (
		<Modal
			title={
				result.ready > 0
					? _n('New offer ready', 'New offers ready', result.ready, 'personalized-offers-for-spacefast')
					: result.failed > 0
					? __('Offer not built', 'personalized-offers-for-spacefast')
					: __('Offers still building', 'personalized-offers-for-spacefast')
			}
			onRequestClose={close}
			size="small"
			className="pofsf-assistant-offers-notice"
		>
			{result.ready > 0 && (
				<p>
					{result.ready === 1
						? __('Your new offer is ready for review and publishing.', 'personalized-offers-for-spacefast')
						: sprintf(
								/* translators: %d: number of offers. */
								__('Your %d new offers are ready for review and publishing.', 'personalized-offers-for-spacefast'),
								result.ready
						  )}
				</p>
			)}
			{result.failed > 0 && (
				<p className="pofsf-muted">
					{sprintf(
						/* translators: %d: number of offers. */
						_n('%d offer could not be built; see its error in the Offers list.', '%d offers could not be built; see their errors in the Offers list.', result.failed, 'personalized-offers-for-spacefast'),
						result.failed
					)}
				</p>
			)}
			{result.building > 0 && (
				<p className="pofsf-muted">
					{sprintf(
						/* translators: %d: number of offers. */
						_n('%d offer is still being built.', '%d offers are still being built.', result.building, 'personalized-offers-for-spacefast'),
						result.building
					)}
				</p>
			)}
			<div className="pofsf-assistant-offers-notice__actions">
				
				{result.ready === 1 && (
					<>
						<Button
							variant="secondary"
							onClick={() => {
								close();
								onAction('edit', result.offerId);
							}}
						>
							{__('Review & edit offer', 'personalized-offers-for-spacefast')}
						</Button>
						<Button
							variant="primary"
							disabled={!spacefastConnected}
							accessibleWhenDisabled
							label={spacefastConnected ? undefined : __('Connect Spacefast first', 'personalized-offers-for-spacefast')}
							showTooltip={!spacefastConnected}
							onClick={() => {
								close();
								onAction('publish', result.offerId);
							}}
						>
							{__('Publish to Spacefast', 'personalized-offers-for-spacefast')}
						</Button>
					</>
				)}
			</div>
		</Modal>
	);
}
