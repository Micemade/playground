/**
 * Offer templates: list, preview, set default, duplicate, delete.
 * Templates are edited in the WordPress block editor, opened in a
 * full-screen modal. The assistant can also create them (save-template).
 */
import { useEffect, useRef, useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import {
	Button,
	Card,
	CardBody,
	CardFooter,
	CardHeader,
	CardMedia,
	Dropdown,
	DropdownMenu,
	MenuGroup,
	MenuItem,
	Modal,
	Notice,
	RangeControl,
	SelectControl,
	Spinner,
	TextControl,
} from '@wordpress/components';
import { arrowLeft, chevronLeft, chevronRight, copy, moreVertical, pencil, starEmpty, starFilled } from '@wordpress/icons';
import { SCRIPTED_PREVIEW_SANDBOX, ajaxAction, assertSuccess, onAssistantChanges } from '../api';
import { TemplateEditorFrame, confirmLeaveTemplate, isTemplateDirty, saveTemplate } from './TemplateEditor';

const COLOR_KEYS = ['primary', 'secondary', 'accent', 'background', 'surface', 'border', 'text', 'text_muted'];

export function Swatches({ colors }) {
	const values = COLOR_KEYS.map((key) => colors?.[key]).filter(Boolean);

	if (values.length === 0) {
		return <span className="pofsf-muted">{__('Brand colors', 'personalized-offers-for-spacefast')}</span>;
	}

	return (
		<span className="pofsf-swatches" aria-hidden="true">
			{values.map((color, index) => (
				<span key={index} className="pofsf-swatch" style={{ background: color }} />
			))}
		</span>
	);
}

/** The thumbnail renders the page at this width, scaled down to the card. */
const THUMB_WIDTH = 1280;
const THUMB_RATIO = 3 / 4;

const COLUMNS_KEY = 'pofsf_template_columns';
// The track starts at 0 (values below 1 snap back to 1), so the highlighted ticks match the column count.
const COLUMN_MARKS = [1, 2, 3, 4, 5, 6].map((value) => ({ value }));
const DEFAULT_COLUMNS = 4;

function storedColumns() {
	try {
		const value = Number(window.localStorage.getItem(COLUMNS_KEY));

		return value >= 1 && value <= 6 ? value : DEFAULT_COLUMNS;
	} catch (e) {
		return DEFAULT_COLUMNS;
	}
}

/**
 * A live, scaled-down preview of the template's page with sample content.
 * The iframe is inert; the button over it opens the full preview, or does
 * what onOpen does with `openLabel` (and `pressed` for a toggle).
 */
export function TemplateThumbnail({ template, onOpen, openLabel, pressed }) {
	const ref = useRef(null);
	const [scale, setScale] = useState(0);
	const [loaded, setLoaded] = useState(false);
	// previewUrl changes when the template is saved, so the thumbnail reloads.
	const src = template.previewUrl;

	useEffect(() => {
		const element = ref.current;

		if (!element) {
			return undefined;
		}

		const update = () => setScale(element.clientWidth / THUMB_WIDTH);
		const observer = new window.ResizeObserver(update);

		update();
		observer.observe(element);

		return () => observer.disconnect();
	}, []);

	useEffect(() => setLoaded(false), [src]);

	return (
		<div className="pofsf-template-thumb" ref={ref}>
			{!loaded && <Spinner />}
			{scale > 0 && (
				<iframe
					src={src}
					title={sprintf(
						/* translators: %s: template name. */
						__('Thumbnail of %s', 'personalized-offers-for-spacefast'),
						template.name
					)}
					tabIndex={-1}
					aria-hidden="true"
					// Inert: no scripts. Same origin only so the page can load its images and styles (and Playground can serve it).
					sandbox="allow-same-origin"
					loading="lazy"
					onLoad={() => setLoaded(true)}
					style={{
						width: THUMB_WIDTH,
						height: THUMB_WIDTH * THUMB_RATIO,
						transform: `scale(${scale})`,
						opacity: loaded ? 1 : 0,
					}}
				/>
			)}
			<button
				type="button"
				className="pofsf-template-thumb__open"
				onClick={() => onOpen(template)}
				aria-pressed={pressed}
				aria-label={openLabel || sprintf(
					/* translators: %s: template name. */
					__('Preview %s', 'personalized-offers-for-spacefast'),
					template.name
				)}
			/>
		</div>
	);
}

const PREVIEW_WIDTHS = {
	desktop: '100%',
	mobile: '390px',
};

/**
 * Full preview of one template, with arrows to step through the others.
 * "Edit" (or "Duplicate & edit" for a built-in) opens the block editor in
 * the same modal; "Back to preview" asks about unsaved edits first.
 */
function PreviewModal({ templates, initialId, onTemplates, onClose }) {
	const [device, setDevice] = useState('desktop');
	const [currentId, setCurrentId] = useState(initialId);
	const [editing, setEditing] = useState(false);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);
	const [version, setVersion] = useState(0);
	const [asking, setAsking] = useState(false);
	const frameRef = useRef(null);

	const index = Math.max(0, templates.findIndex((item) => item.id === currentId));
	const template = templates[index];
	const step = (delta) => setCurrentId(templates[(index + delta + templates.length) % templates.length].id);

	useEffect(() => {
		if (editing || templates.length < 2) {
			return undefined;
		}

		const onKey = (event) => {
			const tag = event.target?.tagName;

			if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') {
				return;
			}

			if (event.key === 'ArrowLeft') {
				step(-1);
			} else if (event.key === 'ArrowRight') {
				step(1);
			}
		};

		window.addEventListener('keydown', onKey);

		return () => window.removeEventListener('keydown', onKey);
	});

	if (!template) {
		return null;
	}

	const startEditing = async () => {
		setError(null);

		if (!template.builtin) {
			setEditing(true);
			return;
		}

		setBusy(true);

		try {
			const response = await ajaxAction('pofsf_template_create', { source_id: template.id });
			assertSuccess(response);
			onTemplates(response.data.templates);
			setCurrentId(response.data.template_id);
			setEditing(true);
		} catch (err) {
			setError(err?.message);
		} finally {
			setBusy(false);
		}
	};

	const refresh = async () => {
		const response = await ajaxAction('pofsf_templates_list');
		assertSuccess(response);
		onTemplates(response.data.templates);
	};

	// Back to the preview, reloaded: the template may have been saved in the editor itself.
	const leaveEditor = async () => {
		try {
			await refresh();
		} catch (err) {
			// The list reloads when the modal closes.
		}

		setAsking(false);
		setEditing(false);
		setVersion((count) => count + 1);
	};

	const backToPreview = () => {
		setError(null);

		if (isTemplateDirty(frameRef)) {
			setAsking(true);
		} else {
			leaveEditor();
		}
	};

	const saveAndBack = async () => {
		setBusy(true);

		try {
			await saveTemplate(frameRef);
		} catch (err) {
			setError(err?.message);
			setAsking(false);
			setBusy(false);
			return;
		}

		await leaveEditor();
		setBusy(false);
	};

	const close = () => {
		if (busy) {
			return;
		}

		if (!editing || confirmLeaveTemplate(frameRef)) {
			onClose();
		}
	};

	const previewSrc = version ? `${template.previewUrl}${template.previewUrl.includes('?') ? '&' : '?'}v=${version}` : template.previewUrl;

	return (
		<Modal
			title={
				<span className="pofsf-preview-modal__title">
					{editing
						? sprintf(
							/* translators: %s: template name. */
							__('Edit template: %s', 'personalized-offers-for-spacefast'),
							template.name
						)
						: sprintf(
							/* translators: %s: template name. */
							__('Preview: %s', 'personalized-offers-for-spacefast'),
							template.name
						)}
					{!editing && template.isDefault && <span className="pofsf-status is-ready">{__('Default', 'personalized-offers-for-spacefast')}</span>}
					{!editing && template.builtin && <span className="pofsf-status">{__('Built-in', 'personalized-offers-for-spacefast')}</span>}
				</span>
			}
			onRequestClose={close}
			shouldCloseOnClickOutside={!editing}
			size="fill"
			className={editing ? 'pofsf-preview-modal is-editing' : 'pofsf-preview-modal'}
			headerActions={
				editing ? (
					<div className="pofsf-preview-modal__actions">
						<Button size="compact" variant="secondary" icon={arrowLeft} onClick={backToPreview} disabled={busy} accessibleWhenDisabled>
							{__('Back to Preview', 'personalized-offers-for-spacefast')}
						</Button>
					</div>
				) : (
				<div className="pofsf-preview-modal__actions">
					<Button
						size="small"
						variant="primary"
						icon={template.builtin ? copy : pencil}
						onClick={startEditing}
						isBusy={busy}
						disabled={busy}
						accessibleWhenDisabled
					>
						{template.builtin ? __('Duplicate & Edit', 'personalized-offers-for-spacefast') : __('Edit', 'personalized-offers-for-spacefast')}
					</Button>
					<Button
						size="small"
						variant={device === 'desktop' ? 'primary' : 'tertiary'}
						icon="desktop"
						onClick={() => setDevice('desktop')}
						aria-pressed={device === 'desktop'}
					>
						{__('Desktop', 'personalized-offers-for-spacefast')}
					</Button>
					<Button
						size="small"
						variant={device === 'mobile' ? 'primary' : 'tertiary'}
						icon="smartphone"
						onClick={() => setDevice('mobile')}
						aria-pressed={device === 'mobile'}
					>
						{__('Mobile', 'personalized-offers-for-spacefast')}
					</Button>
					<Button size="small" variant="tertiary" icon="external" href={template.previewUrl} target="_blank">
						{__('Open in new tab', 'personalized-offers-for-spacefast')}
					</Button>
				</div>
				)
			}
		>
			{asking && (
				<Modal
					title={__('Unsaved changes', 'personalized-offers-for-spacefast')}
					size="small"
					onRequestClose={busy ? () => {} : () => setAsking(false)}
					className="pofsf-unsaved-dialog"
				>
					<p>{__('There are unsaved edits to this template. Do you want to save the changes, or just go back to preview?', 'personalized-offers-for-spacefast')}</p>
					<div className="pofsf-unsaved-dialog__actions">
						<Button variant="tertiary" isDestructive onClick={leaveEditor} disabled={busy} accessibleWhenDisabled>
							{__('Back', 'personalized-offers-for-spacefast')}
						</Button>
						<Button variant="primary" onClick={saveAndBack} isBusy={busy} disabled={busy} accessibleWhenDisabled>
							{__('Save & go back', 'personalized-offers-for-spacefast')}
						</Button>
					</div>
				</Modal>
			)}
			{error && (
				<Notice status="error" onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}
			{editing ? (
				<TemplateEditorFrame key={template.id} template={template} frameRef={frameRef} />
			) : (
				<div className="pofsf-preview-modal__stage">
					<iframe
						key={`${template.id}-${version}`}
						title={__('Template preview', 'personalized-offers-for-spacefast')}
						src={previewSrc}
						style={{ width: PREVIEW_WIDTHS[device] }}
						// The page's cart script runs; no same-origin access to the admin (see SCRIPTED_PREVIEW_SANDBOX).
						sandbox={SCRIPTED_PREVIEW_SANDBOX}
					/>
					{templates.length > 1 && (
						<>
							<Button
								className="pofsf-preview-modal__nav is-prev"
								icon={chevronLeft}
								label={sprintf(
									/* translators: %s: template name. */
									__('Previous template: %s', 'personalized-offers-for-spacefast'),
									templates[(index - 1 + templates.length) % templates.length].name
								)}
								showTooltip
								onClick={() => step(-1)}
							/>
							<Button
								className="pofsf-preview-modal__nav is-next"
								icon={chevronRight}
								label={sprintf(
									/* translators: %s: template name. */
									__('Next template: %s', 'personalized-offers-for-spacefast'),
									templates[(index + 1) % templates.length].name
								)}
								showTooltip
								onClick={() => step(1)}
							/>
						</>
					)}
				</div>
			)}
		</Modal>
	);
}

function PreviewMenu({ template, onModal }) {
	return (
		<Dropdown
			popoverProps={{ placement: 'bottom-start' }}
			renderToggle={({ isOpen, onToggle }) => (
				<Button
					variant="secondary"
					size="small"
					icon="arrow-down-alt2"
					iconPosition="right"
					onClick={onToggle}
					aria-expanded={isOpen}
					aria-haspopup="menu"
				>
					{__('Preview', 'personalized-offers-for-spacefast')}
				</Button>
			)}
			renderContent={({ onClose }) => (
				<MenuGroup>
					<MenuItem
						icon="visibility"
						onClick={() => {
							onClose();
							onModal(template);
						}}
					>
						{__('Preview here', 'personalized-offers-for-spacefast')}
					</MenuItem>
					<MenuItem
						icon="external"
						href={template.previewUrl}
						target="_blank"
						rel="noopener noreferrer"
						onClick={onClose}
					>
						{__('Open in new tab', 'personalized-offers-for-spacefast')}
					</MenuItem>
				</MenuGroup>
			)}
		/>
	);
}

/**
 * The block editor for one template, in a full-screen modal. Closing asks
 * for confirmation when the editor has unsaved changes.
 */
function EditorModal({ template, onClose }) {
	const frameRef = useRef(null);

	const close = () => {
		if (confirmLeaveTemplate(frameRef)) {
			onClose();
		}
	};

	return (
		<Modal
			title={__('Edit template', 'personalized-offers-for-spacefast')}
			onRequestClose={close}
			isFullScreen
			shouldCloseOnClickOutside={false}
			className="pofsf-editor-modal"
			headerActions={
				<Button size="small" variant="tertiary" icon="external" href={template.previewUrl} target="_blank">
					{__('Preview saved version', 'personalized-offers-for-spacefast')}
				</Button>
			}
		>
			<TemplateEditorFrame template={template} frameRef={frameRef} />
		</Modal>
	);
}

/**
 * Name a new template and pick the template it starts from.
 */
function NewTemplateModal({ templates, onClose, onCreated }) {
	const [name, setName] = useState('');
	const [sourceId, setSourceId] = useState(String(templates[0]?.id || ''));
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);
	const source = templates.find((template) => String(template.id) === sourceId);

	const create = async () => {
		setBusy(true);
		setError(null);

		try {
			const response = await ajaxAction('pofsf_template_create', { source_id: sourceId, name });
			assertSuccess(response);
			onCreated(response.data);
		} catch (err) {
			setError(err?.message);
			setBusy(false);
		}
	};

	return (
		<Modal title={__('New template', 'personalized-offers-for-spacefast')} onRequestClose={busy ? () => {} : onClose} size="medium">
			<div className="pofsf-template-form">
				<TextControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Name', 'personalized-offers-for-spacefast')}
					placeholder={source ? sprintf(
						/* translators: %s: template name. */
						__('%s (copy)', 'personalized-offers-for-spacefast'),
						source.name
					) : ''}
					value={name}
					onChange={setName}
				/>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Start from', 'personalized-offers-for-spacefast')}
					help={source?.description}
					value={sourceId}
					onChange={setSourceId}
					options={templates.map((template) => ({
						value: String(template.id),
						label: template.builtin
							? sprintf(
									/* translators: %s: template name. */
									__('%s (built-in)', 'personalized-offers-for-spacefast'),
									template.name
							  )
							: template.name,
					}))}
				/>
				<p className="description">
					{__('The new template opens in the block editor, where you can rearrange the layout and set colors and fonts under Offer design.', 'personalized-offers-for-spacefast')}
				</p>
			</div>

			{error && (
				<Notice status="error" isDismissible={false}>
					{error}
				</Notice>
			)}

			<div className="pofsf-modal-actions">
				<Button variant="tertiary" onClick={onClose} disabled={busy}>
					{__('Cancel', 'personalized-offers-for-spacefast')}
				</Button>
				<Button variant="primary" onClick={create} isBusy={busy} disabled={busy || !sourceId}>
					{__('Create and edit', 'personalized-offers-for-spacefast')}
				</Button>
			</div>
		</Modal>
	);
}

export default function TemplatesList() {
	const [templates, setTemplates] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [editing, setEditing] = useState(null);
	const [creating, setCreating] = useState(false);
	const [previewing, setPreviewing] = useState(null);
	const [columns, setColumns] = useState(storedColumns);

	const changeColumns = (value) => {
		// The track starts at 0 for the tick highlighting; 0 means 1 column.
		const next = Number.isFinite(Number(value)) && value !== undefined ? Math.max(1, Math.min(6, Number(value))) : DEFAULT_COLUMNS;
		setColumns(next);

		try {
			window.localStorage.setItem(COLUMNS_KEY, String(next));
		} catch (e) {
			// Not remembered in this browser; the setting still applies now.
		}
	};

	const load = () =>
		ajaxAction('pofsf_templates_list')
			.then((response) => {
				assertSuccess(response);
				setTemplates(response.data.templates);
			})
			.catch((err) => setError(err?.message))
			.finally(() => setLoading(false));

	useEffect(() => {
		load();

		return onAssistantChanges(['personalized-offers-for-spacefast/save-template', 'personalized-offers-for-spacefast/restore-template', 'personalized-offers-for-spacefast/delete-template'], load);
	}, []);

	const run = async (action, template) => {
		setError(null);

		try {
			const response = await ajaxAction(action, { template_id: template.id });
			assertSuccess(response);
			setTemplates(response.data.templates);
		} catch (err) {
			setError(err?.message);
		}
	};

	const duplicate = async (template) => {
		setError(null);

		try {
			const response = await ajaxAction('pofsf_template_create', { source_id: template.id });
			assertSuccess(response);
			openCreated(response.data);
		} catch (err) {
			setError(err?.message);
		}
	};

	const openCreated = (data) => {
		setTemplates(data.templates);
		setCreating(false);
		setEditing(data.templates.find((template) => template.id === data.template_id) || null);
	};

	const remove = (template) => {
		// eslint-disable-next-line no-alert
		if (window.confirm(sprintf(
			/* translators: %s: template name. */
			__('Delete the template "%s"? Offers that used it keep their design.', 'personalized-offers-for-spacefast'),
			template.name
		))) {
			run('pofsf_template_delete', template);
		}
	};

	return (
		<div className="pofsf-templates">
			<div className="pofsf-offers__toolbar">
				<p className="description">
					{__(
						'Templates set the layout and look of offer pages and are edited in the block editor. Saving a template updates every offer that uses it; published offers are marked for an update on Spacefast. You can also ask the assistant to design one.',
						'personalized-offers-for-spacefast'
					)}
				</p>

				<div className="actions">

					<Button variant="primary" __next40pxDefaultSize onClick={() => setCreating(true)} disabled={loading}>
						{__('New template', 'personalized-offers-for-spacefast')}
					</Button>

					<div className="pofsf-templates__cards-in-row">
						<RangeControl
							__nextHasNoMarginBottom
							__next40pxDefaultSize
							min={0}
							max={6}
							step={1}
							value={columns}
							onChange={changeColumns}
							withInputField={false}
							marks={COLUMN_MARKS}
							renderTooltipContent={(value) => Math.max(1, value)}
						/>
					</div>
				</div>
			</div>

			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}

			{loading && <Spinner />}

			<div className="pofsf-templates__grid" data-columns={columns} style={{ '--pofsf-template-columns': columns }}>
				{templates.map((template) => (
					<Card key={template.id} size="small" className="pofsf-template-card">
						<CardMedia>
							<TemplateThumbnail template={template} onOpen={setPreviewing} />
						</CardMedia>
						<CardHeader className="pofsf-template-card__header">
							<h3>
								{template.name}{' '}
								{template.isDefault && <span className="pofsf-status is-ready">{__('Default', 'personalized-offers-for-spacefast')}</span>}{' '}
								{template.builtin && <span className="pofsf-status">{__('Built-in', 'personalized-offers-for-spacefast')}</span>}
							</h3>
							<DropdownMenu
								icon={moreVertical}
								label={sprintf(
									/* translators: %s: name of the item the menu acts on, e.g. a template name or an offer text type such as "Body text". */
									__('Actions for %s', 'personalized-offers-for-spacefast'),
									template.name
								)}
								toggleProps={{ size: 'small' }}
								popoverProps={{ placement: 'bottom-end' }}
								controls={[
									...(template.builtin
										? []
										: [
												{
													title: __('Edit in block editor', 'personalized-offers-for-spacefast'),
													icon: pencil,
													onClick: () => setEditing(template),
												},
										  ]),
									{
										title: template.builtin
											? __('Duplicate & customize', 'personalized-offers-for-spacefast')
											: __('Duplicate', 'personalized-offers-for-spacefast'),
										icon: copy,
										onClick: () => duplicate(template),
									},
									template.isDefault
										? {
												title: __('Unset default', 'personalized-offers-for-spacefast'),
												icon: starEmpty,
												onClick: () => run('pofsf_template_default', { id: 0 }),
										  }
										: {
												title: __('Make default', 'personalized-offers-for-spacefast'),
												icon: starFilled,
												onClick: () => run('pofsf_template_default', template),
										  },
								]}
							/>
						</CardHeader>
						<CardBody>
							{template.description && <p className="pofsf-muted">{template.description}</p>}
							<Swatches colors={template.design.colors} />
							{(template.fonts.heading || template.fonts.body) && (
								<p className="pofsf-muted">
									{sprintf(
										/* translators: 1: heading font name, 2: body font name. */
										__('Fonts: %1$s / %2$s', 'personalized-offers-for-spacefast'),
										template.fonts.heading || __('brand', 'personalized-offers-for-spacefast'),
										template.fonts.body || __('brand', 'personalized-offers-for-spacefast')
									)}
								</p>
							)}
						</CardBody>
						<CardFooter className="pofsf-row-actions">
							<PreviewMenu template={template} onModal={setPreviewing} />
							{!template.builtin && (
								<Button variant="secondary" size="small" onClick={() => setEditing(template)}>
									{__('Edit', 'personalized-offers-for-spacefast')}
								</Button>
							)}
							{!template.builtin && (
								<Button variant="tertiary" size="small" isDestructive onClick={() => remove(template)}>
									{__('Delete', 'personalized-offers-for-spacefast')}
								</Button>
							)}
						</CardFooter>
					</Card>
				))}
			</div>

			{previewing && (
				<PreviewModal
					templates={templates}
					initialId={previewing.id}
					onTemplates={setTemplates}
					onClose={() => {
						setPreviewing(null);
						load();
					}}
				/>
			)}

			{creating && <NewTemplateModal templates={templates} onClose={() => setCreating(false)} onCreated={openCreated} />}

			{editing && (
				<EditorModal
					template={editing}
					onClose={() => {
						setEditing(null);
						load();
					}}
				/>
			)}
		</div>
	);
}
