/**
 * AI connector status panel with a recheck action.
 * Replaces the former jQuery handler (.pofsf-check-ai).
 */
import { useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button, Card, CardBody, Notice, Spinner } from '@wordpress/components';
import { ajaxAction, assertSuccess } from '../api';

export default function AiApp({ message: initialMessage, providers: initialProviders, supported }) {
	const [message, setMessage] = useState(initialMessage || '');
	const [providers, setProviders] = useState(() => (Array.isArray(initialProviders) ? initialProviders : []));
	const [checking, setChecking] = useState(false);
	const [error, setError] = useState(null);

	const onRecheck = async () => {
		setChecking(true);
		setError(null);

		try {
			const response = await ajaxAction('pofsf_check_ai_connector');
			assertSuccess(response, __('Status check failed.', 'personalized-offers-for-spacefast'));
			const status = response.data || {};
			setMessage(status.message || '');
			setProviders(Array.isArray(status.providers) ? status.providers : []);
		} catch (err) {
			setError(err?.message || __('Status check failed.', 'personalized-offers-for-spacefast'));
		} finally {
			setChecking(false);
		}
	};

	return (
		<Card>
			<CardBody>
				{error && (
					<Notice status="error" isDismissible onRemove={() => setError(null)}>
						{error}
					</Notice>
				)}

				<p>
					<strong>{message}</strong>
				</p>

				{supported && providers.length > 0 && (
					<ul>
						{providers.map((provider) => (
							<li key={provider.id}>
								{provider.name}:{' '}
								{provider.connected
									? __('Connected', 'personalized-offers-for-spacefast')
									: __('Not connected', 'personalized-offers-for-spacefast')}
							</li>
						))}
					</ul>
				)}

				{!supported && (
					<p className="description">
						{__(
							'WordPress AI Client not available. Requires WordPress 7.0+ with Connectors.',
							'personalized-offers-for-spacefast'
						)}
					</p>
				)}

				<p>
					<Button
						variant="secondary"
						size="small"
						isBusy={checking}
						disabled={checking}
						onClick={onRecheck}
					>
						{checking ? (
							<>
								<Spinner /> {__('Checking…', 'personalized-offers-for-spacefast')}
							</>
						) : (
							__('Recheck status', 'personalized-offers-for-spacefast')
						)}
					</Button>
				</p>
			</CardBody>
		</Card>
	);
}
