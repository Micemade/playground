/**
 * Spacefast account connection: paste a team API key, or disconnect.
 */
import { useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import {
	Button,
	Card,
	CardBody,
	ExternalLink,
	Notice,
	TextControl,
} from '@wordpress/components';
import { ajaxAction, assertSuccess } from '../api';

export default function SpacefastConnect({ status, dashboardUrl, onChange }) {
	const [apiKey, setApiKey] = useState('');
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);

	const run = async (action, params = {}) => {
		setBusy(true);
		setError(null);

		try {
			const response = await ajaxAction(action, params);
			assertSuccess(response);
			setApiKey('');
			onChange(response.data.spacefast);
		} catch (err) {
			setError(err?.message);
		} finally {
			setBusy(false);
		}
	};

	if (status.connected) {
		return (
			<Card className="pofsf-spacefast-card" size="small">
				<CardBody className="pofsf-spacefast-card__body">
					<span className="pofsf-spacefast-card__status is-connected" />
					<span>
						{sprintf(
							/* translators: 1: Spacefast team name, 2: last characters of the API key. */
							__('Spacefast: connected to %1$s (key %2$s)', 'personalized-offers-for-spacefast'),
							status.team_name || status.team_id,
							status.key_hint
						)}
					</span>
					{!status.from_constant && (
						<Button
							variant="tertiary"
							isDestructive
							isBusy={busy}
							disabled={busy}
							onClick={() => run('pofsf_spacefast_disconnect')}
						>
							{__('Disconnect', 'personalized-offers-for-spacefast')}
						</Button>
					)}
				</CardBody>
				{error && (
					<Notice status="error" isDismissible onRemove={() => setError(null)}>
						{error}
					</Notice>
				)}
			</Card>
		);
	}

	return (
		<Card className="pofsf-spacefast-card" size="small">
			<CardBody>
				<form
					className="pofsf-spacefast-card__form"
					onSubmit={(event) => {
						event.preventDefault();
						run('pofsf_spacefast_connect', { api_key: apiKey });
					}}
				>
					<TextControl
						__nextHasNoMarginBottom
						__next40pxDefaultSize
						type="password"
						autoComplete="off"
						label={__('Spacefast API key', 'personalized-offers-for-spacefast')}
						help={
							<>
								{__(
									'Connect your Spacefast team to publish offers as Spaces. Create a team API key in your',
									'personalized-offers-for-spacefast'
								)}{' '}
								<ExternalLink href={dashboardUrl}>
									{__('Spacefast dashboard', 'personalized-offers-for-spacefast')}
								</ExternalLink>
								.
							</>
						}
						value={apiKey}
						onChange={setApiKey}
					/>
					<Button
						__next40pxDefaultSize
						variant="primary"
						type="submit"
						isBusy={busy}
						disabled={busy || !apiKey.trim()}
					>
						{__('Connect', 'personalized-offers-for-spacefast')}
					</Button>
				</form>
				{error && (
					<Notice status="error" isDismissible onRemove={() => setError(null)}>
						{error}
					</Notice>
				)}
			</CardBody>
		</Card>
	);
}
