/**
 * Spacefast account connection: paste a team API key, or disconnect. A
 * signed-in connection shows the account, and Reconnect once Spacefast no
 * longer accepts the sign-in.
 */
import { useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import {
	Button,
	Card,
	CardBody,
	ExternalLink,
	Notice,
	TextControl,
} from '@wordpress/components';
import { ajaxAction, assertSuccess } from '../api';

export default function SpacefastConnect({ status, dashboardUrl, onChange, hideHelp = false, signInUrl = '' }) {
	const [apiKey, setApiKey] = useState('');
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);

	const run = async (action, params = {}) => {
		setBusy(true);
		setError(null);

		try {
			const response = await ajaxAction(action, params);
			assertSuccess(response);
			setApiKey('');
			onChange(response.data.spacefast);
		} catch (err) {
			setError(err?.message);
		} finally {
			setBusy(false);
		}
	};

	if (status.connected) {
		return (
			<Card className="pofsf-spacefast-card" size="small">
				<CardBody className="pofsf-spacefast-card__body">
					<span className={`pofsf-spacefast-card__status${status.reconnect ? '' : ' is-connected'}`} />
					<span>
						{status.auth === 'oauth'
							? sprintf(
								/* translators: 1: Spacefast team name, 2: email address of the Spacefast account. */
								__('Spacefast: connected to %1$s (signed in as %2$s)', 'personalized-offers-for-spacefast'),
								status.team_name || status.team_id,
								status.account_email
							)
							: sprintf(
								/* translators: 1: Spacefast team name, 2: last characters of the API key. */
								__('Spacefast: connected to %1$s (key %2$s)', 'personalized-offers-for-spacefast'),
								status.team_name || status.team_id,
								status.key_hint
							)}
					</span>
					{!status.from_constant && (
						<Button
							variant="tertiary"
							isDestructive
							isBusy={busy}
							disabled={busy}
							onClick={() => run('pofsf_spacefast_disconnect')}
						>
							{__('Disconnect', 'personalized-offers-for-spacefast')}
						</Button>
					)}
				</CardBody>
				{status.reconnect && (
					<Notice status="warning" isDismissible={false} className="pofsf-spacefast-card__reconnect">
						{__('Spacefast no longer accepts this site’s sign-in (it expired or was revoked), so offers can’t be published.', 'personalized-offers-for-spacefast')}{' '}
						{signInUrl && (
							<Button variant="primary" href={signInUrl}>
								{__('Reconnect', 'personalized-offers-for-spacefast')}
							</Button>
						)}
					</Notice>
				)}
				{error && (
					<Notice status="error" isDismissible onRemove={() => setError(null)}>
						{error}
					</Notice>
				)}
			</Card>
		);
	}

	return (
		<Card className="pofsf-spacefast-card" size="small">
			<CardBody>
				<form
					className="pofsf-spacefast-card__form"
					onSubmit={(event) => {
						event.preventDefault();
						run('pofsf_spacefast_connect', { api_key: apiKey });
					}}
				>
					<TextControl
						__nextHasNoMarginBottom
						__next40pxDefaultSize
						type="password"
						autoComplete="off"
						label={__('Spacefast API key', 'personalized-offers-for-spacefast')}
						help={
							hideHelp ? undefined : <>
								{__(
									'Connect your Spacefast team to publish offers as Spaces. Create a team API key in your',
									'personalized-offers-for-spacefast'
								)}{' '}
								<ExternalLink href={dashboardUrl}>
									{__('Spacefast dashboard', 'personalized-offers-for-spacefast')}
								</ExternalLink>
								.
							</>
						}
						value={apiKey}
						onChange={setApiKey}
					/>
					<Button
						__next40pxDefaultSize
						variant="primary"
						type="submit"
						isBusy={busy}
						disabled={busy || !apiKey.trim()}
					>
						{__('Connect', 'personalized-offers-for-spacefast')}
					</Button>
					{signInUrl && (
						<Button __next40pxDefaultSize variant="secondary" href={signInUrl}>
							{__('Or sign in with Spacefast', 'personalized-offers-for-spacefast')}
						</Button>
					)}
				</form>
				{error && (
					<Notice status="error" isDismissible onRemove={() => setError(null)}>
						{error}
					</Notice>
				)}
			</CardBody>
		</Card>
	);
}
