/**
 * Offers table: publish to a Spacefast Space, email the offer, share a
 * public one on social networks; preview, download the ZIP or delete.
 */
import { useCopyToClipboard } from '@wordpress/compose';
import { useCallback, useEffect, useRef, useState } from '@wordpress/element';
import { __, _n, sprintf } from '@wordpress/i18n';
import {
	Button,
	CheckboxControl,
	DropdownMenu,
	ExternalLink,
	MenuGroup,
	MenuItem,
	Modal,
	Notice,
	RadioControl,
	SelectControl,
	Spinner,
	Tooltip,
} from '@wordpress/components';
import { ajaxAction, assertSuccess, onAssistantChanges } from '../api';
import { moreVertical, pencil } from '@wordpress/icons';
import { CreateOfferModal, EditOfferModal, TemplateModal } from './OfferModals';
import { EmailModal, ShareModal } from './OfferSharing';

const PUBLISH_TIMEOUT = 150000;
// Spacefast's analytics can take 20 s or more.
const STATS_TIMEOUT = 60000;
const AUTO_REFRESH_MS = 10000;

const TYPE_LABELS = {
	single: __('One customer', 'personalized-offers-for-spacefast'),
	group: __('Group', 'personalized-offers-for-spacefast'),
	public: __('Public', 'personalized-offers-for-spacefast'),
};

const STATUS_LABELS = {
	pending: __('Pending', 'personalized-offers-for-spacefast'),
	building: __('Building', 'personalized-offers-for-spacefast'),
	ready: __('Ready', 'personalized-offers-for-spacefast'),
	sent: __('Sent', 'personalized-offers-for-spacefast'),
	used: __('Used', 'personalized-offers-for-spacefast'),
	expired: __('Expired', 'personalized-offers-for-spacefast'),
	revoked: __('Revoked', 'personalized-offers-for-spacefast'),
	failed: __('Failed', 'personalized-offers-for-spacefast'),
};

/**
 * navigator.clipboard only exists on HTTPS (and localhost) pages, so it
 * silently does nothing on an admin served over plain HTTP; this hook
 * falls back to the selection-based copy there.
 */
function CopyLinkButton({ url }) {
	const [copied, setCopied] = useState(false);
	const timer = useRef();
	const ref = useCopyToClipboard(url, () => {
		setCopied(true);
		clearTimeout(timer.current);
		timer.current = setTimeout(() => setCopied(false), 2000);
	});

	useEffect(() => () => clearTimeout(timer.current), []);

	return (
		<Button
			ref={ref}
			variant="link"
			label={__('Copy the link to send to the customer', 'personalized-offers-for-spacefast')}
			showTooltip
		>
			{copied ? __('Copied', 'personalized-offers-for-spacefast') : __('Copy', 'personalized-offers-for-spacefast')}
		</Button>
	);
}

/** The link to share for a published Space: the public page, or the private access link. */
function shareUrlOf(space) {
	return space?.access === 'public' ? space?.liveUrl : space?.accessUrl || space?.liveUrl;
}

/** Success notice for a publish: the message, then the Space's link to open or copy. */
function PublishedMessage({ text, offer }) {
	const url = shareUrlOf(offer?.spacefast);

	return (
		<span className="pofsf-published-message">
			{text}{' '}
			{url && (
				<>
					<ExternalLink href={url}>
						{offer.spacefast.access === 'public'
							? __('Open the public page', 'personalized-offers-for-spacefast')
							: __('Open the preview link', 'personalized-offers-for-spacefast')}
					</ExternalLink>{' '}
					<CopyLinkButton url={url} />
				</>
			)}
		</span>
	);
}

/**
 * Why an offer can't be emailed or shared yet: the page must be on
 * Spacefast and up to date, so the link goes to what the offer shows now.
 */
function shareBlockedReason(offer) {
	const space = offer.spacefast;

	if (!space?.spaceId || space.status === 'publishing') {
		return space?.status === 'publishing'
			? __('The offer is still publishing to Spacefast. Wait until its page is live.', 'personalized-offers-for-spacefast')
			: __('Publish the offer to Spacefast first: the link goes to its page.', 'personalized-offers-for-spacefast');
	}

	if (!shareUrlOf(space)) {
		return __('The offer’s Spacefast page has no link yet. Check its status.', 'personalized-offers-for-spacefast');
	}

	if (space.outdated) {
		return space.updating
			? __('The Space is being updated with your latest changes. Wait until it finishes.', 'personalized-offers-for-spacefast')
			: __('The offer has changes not published yet. Update the Space first.', 'personalized-offers-for-spacefast');
	}

	return '';
}

/** "Send email(s)" or "Social share": disabled, with the reason on hover or focus, until the page is up to date. */
function ShareActionButton({ offer, onClick, children }) {
	const reason = offer.exportable ? shareBlockedReason(offer) : '';
	const button = (
		<Button
			variant="secondary"
			size="small"
			onClick={onClick}
			disabled={!offer.exportable || '' !== reason}
			accessibleWhenDisabled={'' !== reason}
		>
			{children}
		</Button>
	);

	return reason ? <Tooltip text={reason}>{button}</Tooltip> : button;
}

/** Page views (last 30 days) and, for a group, how many customers opened their link. */
function SpaceStats({ stats }) {
	const hasViews = typeof stats?.views === 'number';

	if (!stats || (!hasViews && !stats.recipients)) {
		return null;
	}

	return (
		<Tooltip
			text={__(
				'Views of the offer page in the last 30 days (the longest Spacefast keeps), your own visits included. A customer counts as having opened their personal link if they ever did.',
				'personalized-offers-for-spacefast'
			)}
		>
			<span className="pofsf-muted pofsf-space-stats" tabIndex={0}>
				{hasViews && sprintf(
					/* translators: 1: page views, e.g. "3 views", 2: visitors, e.g. "1 visitor". */
					__('%1$s · %2$s', 'personalized-offers-for-spacefast'),
					sprintf(
						/* translators: %d: page views in the last 30 days. */
						_n('%d view', '%d views', stats.views, 'personalized-offers-for-spacefast'),
						stats.views
					),
					sprintf(
						/* translators: %d: visitors in the last 30 days. */
						_n('%d visitor', '%d visitors', stats.visitors, 'personalized-offers-for-spacefast'),
						stats.visitors
					)
				)}
				{stats.recipients > 0 && (
					<>
						{hasViews && <br />}
						{sprintf(
							/* translators: 1: customers who opened their link, 2: customers in the group. */
							_n('%1$d of %2$d customer opened', '%1$d of %2$d customers opened', stats.recipients, 'personalized-offers-for-spacefast'),
							stats.opened,
							stats.recipients
						)}
					</>
				)}
			</span>
		</Tooltip>
	);
}

function SpaceCell({ offer, stats, onCheck, checking }) {
	const space = offer.spacefast;

	if (!space) {
		return <span className="pofsf-muted">—</span>;
	}

	if (space.status === 'publishing') {
		return (
			<Button variant="link" onClick={onCheck} isBusy={checking} disabled={checking}>
				{__('Publishing… check status', 'personalized-offers-for-spacefast')}
			</Button>
		);
	}

	if (space.closed && !space.accessError) {
		return (
			<Tooltip text={__('The offer expired or was withdrawn, so its page no longer opens. Extending it opens the page again.', 'personalized-offers-for-spacefast')}>
				<span className="pofsf-muted" tabIndex={0}>
					{__('Closed on Spacefast', 'personalized-offers-for-spacefast')}
				</span>
			</Tooltip>
		);
	}

	const shareUrl = shareUrlOf(space);

	return (
		<div className="pofsf-space-cell">
			{space.outdated && (
				<span className="pofsf-status is-pending">
					{space.updating
						? __('Updating page…', 'personalized-offers-for-spacefast')
						: __('Changes not published', 'personalized-offers-for-spacefast')}
				</span>
			)}
			<ExternalLink href={shareUrl}>
				{space.access === 'public'
					? __('Public page', 'personalized-offers-for-spacefast')
					: __('Preview link', 'personalized-offers-for-spacefast')}
			</ExternalLink>
			<SpaceStats stats={stats} />
			{space.accessError && (
				<Tooltip text={space.accessError}>
					<span className="pofsf-status is-failed" tabIndex={0}>
						{__('Access not updated on Spacefast', 'personalized-offers-for-spacefast')}
					</span>
				</Tooltip>
			)}
			{space.accessExpiresAt && space.access !== 'public' && (
				<span className="pofsf-muted">
					{sprintf(
						/* translators: %s: date the private link expires. */
						__('Link expires %s', 'personalized-offers-for-spacefast'),
						space.accessExpiresAt
					)}
				</span>
			)}
		</div>
	);
}

function PublishModal({ offer, onClose, onPublished }) {
	const updating = Boolean(offer.spacefast?.spaceId);
	// A public offer is meant to be found; a personal one stays behind a share link.
	const [access, setAccess] = useState(offer.type === 'public' ? 'public' : 'private');
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);

	const publish = async () => {
		setBusy(true);
		setError(null);

		try {
			const response = await ajaxAction(
				'pofsf_offer_publish',
				{ offer_id: offer.id, access },
				{ timeout: PUBLISH_TIMEOUT }
			);
			assertSuccess(response, __('Publishing failed.', 'personalized-offers-for-spacefast'));
			onPublished(response.data.offer);
		} catch (err) {
			setError(err?.message);
			setBusy(false);
		}
	};

	return (
		<Modal
			title={
				updating
					? __('Update the offer Space', 'personalized-offers-for-spacefast')
					: __('Publish offer to Spacefast', 'personalized-offers-for-spacefast')
			}
			onRequestClose={busy ? () => {} : onClose}
			size="medium"
		>
			<p>
				{updating
					? __(
							'The current offer page will be published as a new version of its existing Space. Links you already shared keep working.',
							'personalized-offers-for-spacefast'
					  )
					: offer.type === 'public'
						? __('A new Spacefast Space will be created with the public offer page.', 'personalized-offers-for-spacefast')
						: offer.type === 'group'
							? __('A new Spacefast Space will be created with the group offer page. Then send each customer their personal link, from Edit offer.', 'personalized-offers-for-spacefast')
					: sprintf(
							/* translators: %s: customer name. */
							__('A new Spacefast Space will be created with the offer page for %s.', 'personalized-offers-for-spacefast'),
							offer.customer.name
					  )}
			</p>

			{!updating && (
				<RadioControl
					label={__('Who can open it', 'personalized-offers-for-spacefast')}
					selected={access}
					onChange={setAccess}
					options={[
						{
							label:
								offer.type === 'public'
									? __('Private link — only people you send the link to', 'personalized-offers-for-spacefast')
									: __('Private link (recommended) — only people you send the link to', 'personalized-offers-for-spacefast'),
							value: 'private',
						},
						{
							label: __('Public — anyone with the Space address', 'personalized-offers-for-spacefast'),
							value: 'public',
						},
					]}
				/>
			)}

			{error && (
				<Notice status="error" isDismissible={false}>
					{error}
				</Notice>
			)}

			<div className="pofsf-modal-actions">
				<Button variant="tertiary" onClick={onClose} disabled={busy}>
					{__('Cancel', 'personalized-offers-for-spacefast')}
				</Button>
				<Button variant="primary" onClick={publish} isBusy={busy} disabled={busy}>
					{busy
						? __('Publishing…', 'personalized-offers-for-spacefast')
						: updating
						? __('Publish update', 'personalized-offers-for-spacefast')
						: __('Create Space', 'personalized-offers-for-spacefast')}
				</Button>
			</div>
		</Modal>
	);
}

function DeleteModal({ offer, spacefastConnected, onClose, onDeleted }) {
	const published = Boolean(offer.spacefast?.spaceId);
	const [deleteSpace, setDeleteSpace] = useState(published && spacefastConnected);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);

	const remove = async () => {
		setBusy(true);
		setError(null);

		try {
			const response = await ajaxAction('pofsf_offer_delete', {
				offer_id: offer.id,
				delete_space: deleteSpace ? '1' : '',
			});
			assertSuccess(response, __('The offer could not be deleted.', 'personalized-offers-for-spacefast'));
			onDeleted(offer);
		} catch (err) {
			setError(err?.message);
			setBusy(false);
		}
	};

	return (
		<Modal
			title={sprintf(
				/* translators: %d: offer ID. */
				__('Delete offer #%d?', 'personalized-offers-for-spacefast'),
				offer.id
			)}
			onRequestClose={busy ? () => {} : onClose}
			size="medium"
		>
			<p>
				{offer.type === 'public'
					? __('The public offer and its free-shipping coupon will be deleted. Its checkout link will stop working for everyone. This cannot be undone.', 'personalized-offers-for-spacefast')
					: offer.type === 'group'
						? __('The group offer and its free-shipping coupon will be deleted. Every customer’s personal link will stop working. This cannot be undone.', 'personalized-offers-for-spacefast')
						: sprintf(
							/* translators: %s: customer name. */
							__('The offer for %s and its free-shipping coupon will be deleted. Its checkout link will stop working. This cannot be undone.', 'personalized-offers-for-spacefast'),
							offer.customer.name
						)}
			</p>

			{published && (
				<CheckboxControl
					__nextHasNoMarginBottom
					label={__('Also delete its Spacefast Space, so the shared page stops working', 'personalized-offers-for-spacefast')}
					help={
						spacefastConnected
							? undefined
							: __('Connect Spacefast to delete the Space, or remove it in the Spacefast dashboard.', 'personalized-offers-for-spacefast')
					}
					checked={deleteSpace}
					disabled={!spacefastConnected}
					onChange={setDeleteSpace}
				/>
			)}

			{error && (
				<Notice status="error" isDismissible={false}>
					{error}
				</Notice>
			)}

			<div className="pofsf-modal-actions">
				<Button variant="tertiary" onClick={onClose} disabled={busy}>
					{__('Cancel', 'personalized-offers-for-spacefast')}
				</Button>
				<Button variant="primary" isDestructive onClick={remove} isBusy={busy} disabled={busy}>
					{__('Delete offer', 'personalized-offers-for-spacefast')}
				</Button>
			</div>
		</Modal>
	);
}

/**
 * @param {Object}   props
 * @param {boolean}  props.spacefastConnected
 * @param {?Object}  props.request       From the "offer ready" notice: open the Edit offer or Publish dialog of { action: 'edit' | 'publish', offerId }; from the Customers tab: { action: 'create', customer }; from the Segments tab: { action: 'create', segment }.
 * @param {Function} props.onRequestDone Called once the request was handled.
 */
export default function OffersList({ spacefastConnected, request = null, onRequestDone = () => { } }) {
	const [offers, setOffers] = useState([]);
	const [total, setTotal] = useState(0);
	const [page, setPage] = useState(1);
	const [pageSize, setPageSize] = useState(20);
	const [status, setStatus] = useState('');
	const [type, setType] = useState('');
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [notice, setNotice] = useState(null);
	const [publishing, setPublishing] = useState(null);
	const [deleting, setDeleting] = useState(null);
	const [emailing, setEmailing] = useState(null);
	const [sharing, setSharing] = useState(null);
	const [editing, setEditing] = useState(null);
	const [creating, setCreating] = useState(false);
	const [choosingTemplate, setChoosingTemplate] = useState(null);
	const [templates, setTemplates] = useState([]);

	const loadTemplates = () =>
		ajaxAction('pofsf_templates_list')
			.then((response) => {
				assertSuccess(response);
				setTemplates(response.data.templates);
			})
			.catch(() => setTemplates([]));

	useEffect(() => {
		loadTemplates();

		return onAssistantChanges(['personalized-offers-for-spacefast/save-template', 'personalized-offers-for-spacefast/restore-template', 'personalized-offers-for-spacefast/delete-template'], loadTemplates);
	}, []);
	const [checking, setChecking] = useState(null);
	// View counts by offer ID, loaded after the list (Spacefast may be slow).
	const [stats, setStats] = useState({});

	const load = useCallback(async ({ quiet = false } = {}) => {
		if (!quiet) {
			setLoading(true);
		}
		setError(null);

		try {
			const response = await ajaxAction('pofsf_offers_list', { page, status, type });
			assertSuccess(response);
			setOffers(response.data.offers);
			setTotal(response.data.total);
			setPageSize(response.data.pageSize);
		} catch (err) {
			setError(err?.message);
		} finally {
			setLoading(false);
		}
	}, [page, status, type]);

	useEffect(() => {
		load();
	}, [load]);

	const statsIds = offers
		.filter((o) => o.spacefast?.spaceId && o.spacefast.status !== 'publishing' && !o.spacefast.closed)
		.map((o) => o.id)
		.join(',');

	useEffect(() => {
		if (!statsIds) {
			return;
		}

		let current = true;
		const ids = statsIds.split(',').map(Number);
		const fetchStats = (id, cached) =>
			ajaxAction('pofsf_offer_stats', { offer_id: id, cached: cached ? 1 : 0 }, { timeout: STATS_TIMEOUT })
				.then((response) => {
					assertSuccess(response);

					if (current) {
						setStats((before) => ({ ...before, [id]: response.data.stats }));
					}

					return response.data.stats;
				})
				.catch(() => null);

		// First what is quick (link opens, cached views); then views still
		// missing, one offer per request and three at a time, as Spacefast's
		// analytics can take 20 s or more.
		Promise.all(ids.map((id) => fetchStats(id, true))).then((quick) => {
			const queue = ids.filter((id, i) => quick[i] && typeof quick[i].views !== 'number');
			const next = () => {
				const id = queue.shift();

				return current && undefined !== id ? fetchStats(id, false).then(next) : Promise.resolve();
			};

			next();
			next();
			next();
		});

		return () => {
			current = false;
		};
	}, [statsIds]);

	useEffect(
		() => onAssistantChanges(
			[
				'personalized-offers-for-spacefast/create-offers',
				'personalized-offers-for-spacefast/create-shared-offer',
				'personalized-offers-for-spacefast/publish-offer',
				'personalized-offers-for-spacefast/apply-template',
				'personalized-offers-for-spacefast/restore-template',
				'personalized-offers-for-spacefast/update-offer',
				'personalized-offers-for-spacefast/delete-offer',
				'personalized-offers-for-spacefast/delete-space',
				'personalized-offers-for-spacefast/send-offer-email',
			],
			() => load({ quiet: true })
		),
		[load]
	);

	const requestReloaded = useRef(null);

	// The notice's request, once the offer is in the list (newest first, so on the first page without filters).
	useEffect(() => {
		if (!request) {
			return;
		}

		// Create offer from the Customers tab: the form, for that customer.
		if (request.action === 'create') {
			setCreating(request.segment ? { segment: request.segment } : request.customer || true);
			onRequestDone();
			return;
		}

		if (loading) {
			return;
		}

		const offer = offers.find((item) => item.id === Number(request.offerId));

		if (offer) {
			if (request.action === 'publish') {
				setPublishing(offer);
			} else {
				setEditing(offer);
			}

			onRequestDone();
		} else if (page !== 1 || status || type) {
			setPage(1);
			setStatus('');
			setType('');
		} else if (requestReloaded.current !== request) {
			// The list may predate the offer (a quiet refresh still running): look once more.
			requestReloaded.current = request;
			load();
		} else {
			setError(sprintf(
				/* translators: %d: offer ID. */
				__('Offer #%d is not in the list any more.', 'personalized-offers-for-spacefast'),
				Number(request.offerId)
			));
			onRequestDone();
		}
	}, [request, offers, loading]); // eslint-disable-line react-hooks/exhaustive-deps

	// Offers build in the background; keep the list current until they settle.
	// Builds, and Spaces being published again after their template changed.
	const inProgress = offers.some((offer) => ['pending', 'building'].includes(offer.status) || offer.spacefast?.updating);

	useEffect(() => {
		if (!inProgress) {
			return undefined;
		}

		const timer = setInterval(() => load({ quiet: true }), AUTO_REFRESH_MS);

		return () => clearInterval(timer);
	}, [inProgress, load]);

	const replace = (updated) => {
		if (updated) {
			setOffers((current) => current.map((o) => (o.id === updated.id ? updated : o)));
		}
	};

	const checkStatus = async (offer) => {
		setChecking(offer.id);

		try {
			const response = await ajaxAction('pofsf_offer_publish_status', { offer_id: offer.id });
			assertSuccess(response);
			replace(response.data.offer);

			// The publish that was still finishing is done: show its link.
			if (offer.spacefast?.status === 'publishing' && response.data.offer?.spacefast?.status !== 'publishing' && shareUrlOf(response.data.offer?.spacefast)) {
				setNotice(
					<PublishedMessage
						offer={response.data.offer}
						text={sprintf(
							/* translators: %d: offer ID. */
							__('Offer #%d is published on Spacefast.', 'personalized-offers-for-spacefast'),
							offer.id
						)}
					/>
				);
			}
		} catch (err) {
			setError(err?.message);
		} finally {
			setChecking(null);
		}
	};

	// A template saved from the offer form also updated the offers using it (names, Space status).
	const templatesChanged = (list) => {
		setTemplates(list);
		load({ quiet: true });
	};

	const pages = Math.max(1, Math.ceil(total / pageSize));

	return (
		<div className="pofsf-offers">
			<div className="pofsf-offers__toolbar">
				<Button variant="primary" icon="plus" onClick={() => setCreating(true)} __next40pxDefaultSize>
					{__('Create new offer', 'personalized-offers-for-spacefast')}
				</Button>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Status', 'personalized-offers-for-spacefast')}
					hideLabelFromVision
					value={status}
					onChange={(value) => {
						setStatus(value);
						setPage(1);
					}}
					options={[
						{ label: __('All statuses', 'personalized-offers-for-spacefast'), value: '' },
						...Object.entries(STATUS_LABELS).map(([value, label]) => ({ value, label })),
					]}
				/>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Type', 'personalized-offers-for-spacefast')}
					hideLabelFromVision
					value={type}
					onChange={(value) => {
						setType(value);
						setPage(1);
					}}
					options={[
						{ label: __('All types', 'personalized-offers-for-spacefast'), value: '' },
						...Object.entries(TYPE_LABELS).map(([value, label]) => ({ value, label })),
					]}
				/>
				<span className="pofsf-muted">
					{sprintf(
						/* translators: %d: number of offers. */
						_n('%d offer', '%d offers', total, 'personalized-offers-for-spacefast'),
						total
					)}
				</span>
				<Button variant="secondary" onClick={() => load()} disabled={loading} __next40pxDefaultSize>
					{__('Refresh', 'personalized-offers-for-spacefast')}
				</Button>
			</div>

			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}
			{notice && (
				<Notice
					status="success"
					isDismissible
					onRemove={() => setNotice(null)}
					// A notice with links (PublishedMessage) is read out by its text: Notice would otherwise
					// render it to a string, which runs its Copy button's hooks outside React (error #311).
					spokenMessage={typeof notice === 'string' ? notice : notice?.props?.text}
				>
					{notice}
				</Notice>
			)}

			<table className="wp-list-table widefat fixed striped pofsf-offers__table">
				<thead>
					<tr>
						<th scope="col" className="column-id">{__('ID', 'personalized-offers-for-spacefast')}</th>
						<th scope="col">{__('Offer title', 'personalized-offers-for-spacefast')}</th>
						<th scope="col">{__('Customer', 'personalized-offers-for-spacefast')}</th>
						<th scope="col" className="column-template">{__('Template', 'personalized-offers-for-spacefast')}</th>
						<th scope="col" className="column-status">{__('Status', 'personalized-offers-for-spacefast')}</th>
						<th scope="col">{__('Dates', 'personalized-offers-for-spacefast')}</th>
						<th scope="col" className="column-spacefast">{__('Spacefast', 'personalized-offers-for-spacefast')}</th>
						<th scope="col" className="column-actions">{__('Actions', 'personalized-offers-for-spacefast')}</th>
					</tr>
				</thead>
				<tbody>
					{loading && (
						<tr>
							<td colSpan="8">
								<Spinner />
							</td>
						</tr>
					)}

					{!loading && offers.length === 0 && (
						<tr>
							<td colSpan="8">
								{__(
									'No offers yet. Ask the assistant to create one, or use the "Spacefast Offer" action on the Users screen.',
									'personalized-offers-for-spacefast'
								)}
							</td>
						</tr>
					)}

					{!loading &&
						offers.map((offer) => (
							<tr key={offer.id}>

								<td className="column-id" data-label={__('ID', 'personalized-offers-for-spacefast')}>
									#{offer.id}
								</td>

								<td className="column-title" data-label={__('Offer title', 'personalized-offers-for-spacefast')}>
									{<span className="pofsf-offer-title">{offer.headline}</span> || <span className="pofsf-muted">—</span>}
									{offer.picks > 0 && (
										<>
											<br />
											<span className="pofsf-muted">
												{sprintf(
													/* translators: %d: number of products in the offer. */
													_n('%d product', '%d products', offer.picks, 'personalized-offers-for-spacefast'),
													offer.picks
												)}
											</span>
										</>
									)}
									{offer.editable && (
										<div>
											<Button
												icon={pencil}
												variant="primary"
												size="small"
												onClick={() => setEditing(offer)}
											>
												{__('Edit offer', 'personalized-offers-for-spacefast')}
											</Button>
										</div>
									)}
								</td>

								<td data-label={__('Customer', 'personalized-offers-for-spacefast')}>
									{offer.type === 'public' ? (
										<>
											<strong>{TYPE_LABELS.public}</strong>
											<br />
											<span className="pofsf-muted">{__('Anyone with the link', 'personalized-offers-for-spacefast')}</span>
										</>
									) : offer.type === 'group' ? (
										<>
											<strong>{offer.segment ? `${TYPE_LABELS.group}: ${offer.segment}` : TYPE_LABELS.group}</strong>
											<br />
											<span className="pofsf-muted">
												{sprintf(
													/* translators: 1: customers in the group, 2: customers who used up the offer. */
													_n('%1$d customer, %2$d used up', '%1$d customers, %2$d used up', offer.recipients?.total || 0, 'personalized-offers-for-spacefast'),
													offer.recipients?.total || 0,
													offer.recipients?.used || 0
												)}
											</span>
										</>
									) : (
										<>
											{offer.customer.editUrl ? <a href={offer.customer.editUrl}>{offer.customer.name}</a> : offer.customer.name}
											<br />
											<span className="pofsf-muted">{offer.customer.email}</span>
										</>
									)}
								</td>


								<td className="column-template" data-label={__('Template', 'personalized-offers-for-spacefast')}>
									{offer.template || <span className="pofsf-muted">{__('Store brand', 'personalized-offers-for-spacefast')}</span>}
									{offer.status !== 'building' && (
										<div>
											<Button variant="link" onClick={() => setChoosingTemplate(offer)}>
												{__('Change', 'personalized-offers-for-spacefast')}
											</Button>
										</div>
									)}
								</td>
								<td className="column-status" data-label={__('Status', 'personalized-offers-for-spacefast')}>
									<span className={`pofsf-status is-${offer.status}`}>
										{STATUS_LABELS[offer.status] || offer.status}
									</span>
									{['pending', 'building'].includes(offer.status) && <Spinner />}
									{offer.error && <p className="pofsf-offer-error">{offer.error}</p>}
								</td>
								<td data-label={__('Dates', 'personalized-offers-for-spacefast')}>
									{offer.createdAt}
									{offer.expiresAt && (
										<>
											<br />
											<span className="pofsf-muted">
												{sprintf(
													/* translators: %s: offer expiry date. */
													__('Expires %s', 'personalized-offers-for-spacefast'),
													offer.expiresAt
												)}
											</span>
										</>
									)}
								</td>
								<td className="column-spacefast" data-label={__('Spacefast', 'personalized-offers-for-spacefast')}>
									<SpaceCell
										offer={offer}
										stats={stats[offer.id]}
										checking={checking === offer.id}
										onCheck={() => checkStatus(offer)}
									/>
								</td>
								<td className="column-actions" data-label={__('Actions', 'personalized-offers-for-spacefast')}>
									<div className="pofsf-row-actions">
										<Button
											variant="primary"
											size="small"
											onClick={() => setPublishing(offer)}
											disabled={!offer.exportable || !spacefastConnected}
											label={
												spacefastConnected
													? undefined
													: __('Connect Spacefast above first', 'personalized-offers-for-spacefast')
											}
											showTooltip={!spacefastConnected}
										>
											{offer.spacefast
												? __('Update Space', 'personalized-offers-for-spacefast')
												: __('Publish to Spacefast', 'personalized-offers-for-spacefast')}
										</Button>
										{/* A public offer is shared with its link, not emailed. */}
										{offer.type !== 'public' && (
											<ShareActionButton offer={offer} onClick={() => setEmailing(offer)}>
												{offer.type === 'single'
													? __('Send email', 'personalized-offers-for-spacefast')
													: __('Send emails', 'personalized-offers-for-spacefast')}
											</ShareActionButton>
										)}
										{offer.type === 'public' && (
											<ShareActionButton offer={offer} onClick={() => setSharing(offer)}>
												{__('Social share', 'personalized-offers-for-spacefast')}
											</ShareActionButton>
										)}
										<DropdownMenu
											icon={moreVertical}
											label={sprintf(
												/* translators: %d: offer ID. */
												__('More actions for offer #%d', 'personalized-offers-for-spacefast'),
												offer.id
											)}
											text={__('More actions', 'personalized-offers-for-spacefast')}
											toggleProps={{
												size: 'small',
												iconPosition: 'right',
												iconSize: 14,
												variant: 'secondary',
											}}
											popoverProps={{ placement: 'bottom-end' }}
										>
											{({ onClose }) => (
												<>
													<MenuGroup>
														<MenuItem
															href={offer.exportable ? offer.previewUrl : undefined}
															target="_blank"
															disabled={!offer.exportable}
															onClick={onClose}
														>
															{__('View', 'personalized-offers-for-spacefast')}
														</MenuItem>
														<MenuItem
															href={offer.exportable ? offer.downloadUrl : undefined}
															disabled={!offer.exportable}
															onClick={onClose}
														>
															{__('Download ZIP', 'personalized-offers-for-spacefast')}
														</MenuItem>
													</MenuGroup>
													<MenuGroup>
														<MenuItem
															isDestructive
															disabled={offer.status === 'building'}
															info={
																offer.status === 'building'
																	? __('Wait until the offer has finished building', 'personalized-offers-for-spacefast')
																	: undefined
															}
															onClick={() => {
																onClose();
																setDeleting(offer);
															}}
														>
															{__('Delete', 'personalized-offers-for-spacefast')}
														</MenuItem>
													</MenuGroup>
												</>
											)}
										</DropdownMenu>
									</div>
								</td>
							</tr>
						))}
				</tbody>
			</table>

			{pages > 1 && (
				<div className="pofsf-offers__pagination">
					<Button variant="secondary" size="small" disabled={page <= 1 || loading} onClick={() => setPage(page - 1)}>
						{__('Previous', 'personalized-offers-for-spacefast')}
					</Button>
					<span>
						{sprintf(
							/* translators: 1: current page, 2: total pages. */
							__('Page %1$d of %2$d', 'personalized-offers-for-spacefast'),
							page,
							pages
						)}
					</span>
					<Button variant="secondary" size="small" disabled={page >= pages || loading} onClick={() => setPage(page + 1)}>
						{__('Next', 'personalized-offers-for-spacefast')}
					</Button>
				</div>
			)}

			{editing && (
				<EditOfferModal
					offer={editing}
					templates={templates}
					onTemplatesChanged={templatesChanged}
					onClose={() => setEditing(null)}
					onUpdated={replace}
					onSaved={(updated) => {
						replace(updated);
						setEditing(null);
						setNotice(
							sprintf(
								/* translators: %d: offer ID. */
								__('Offer #%d saved.', 'personalized-offers-for-spacefast'),
								updated.id
							)
						);
					}}
				/>
			)}

			{creating && (
				<CreateOfferModal
					initialCustomer={creating === true || creating.segment ? null : creating}
					initialSegment={creating.segment || null}
					templates={templates}
					onTemplatesChanged={templatesChanged}
					onClose={() => setCreating(false)}
					onSaved={(created) => {
						setCreating(false);
						setNotice(
							created.type === 'public'
								? sprintf(
									/* translators: %d: offer ID. */
									__('Public offer #%d created. Preview it, then download it or publish it to Spacefast and share the link.', 'personalized-offers-for-spacefast'),
									created.id
								)
								: created.type === 'group'
									? sprintf(
										/* translators: 1: offer ID, 2: customers in the group. */
										__('Group offer #%1$d for %2$d customers created. Publish it to Spacefast, then send each customer their personal link from Edit offer.', 'personalized-offers-for-spacefast'),
										created.id,
										created.recipients?.total || 0
									)
									: sprintf(
										/* translators: 1: offer ID, 2: customer name. */
										__('Offer #%1$d for %2$s created. Preview it, then download it or publish it to Spacefast.', 'personalized-offers-for-spacefast'),
										created.id,
										created.customer.name
									)
						);
						setStatus('');
						setType('');

						if (page === 1) {
							load({ quiet: true });
						} else {
							setPage(1);
						}
					}}
				/>
			)}

			{choosingTemplate && (
				<TemplateModal
					offer={choosingTemplate}
					templates={templates}
					onTemplatesChanged={templatesChanged}
					onClose={() => setChoosingTemplate(null)}
					onSaved={(updated) => {
						replace(updated);
						setChoosingTemplate(null);
						setNotice(
							sprintf(
								/* translators: 1: offer ID, 2: template name. */
								__('Offer #%1$d now uses %2$s.', 'personalized-offers-for-spacefast'),
								updated.id,
								updated.template || __('the store brand look', 'personalized-offers-for-spacefast')
							)
						);
					}}
				/>
			)}

			{deleting && (
				<DeleteModal
					offer={deleting}
					spacefastConnected={spacefastConnected}
					onClose={() => setDeleting(null)}
					onDeleted={(removed) => {
						setDeleting(null);
						setNotice(
							sprintf(
								/* translators: %d: offer ID. */
								__('Offer #%d deleted.', 'personalized-offers-for-spacefast'),
								removed.id
							)
						);
						if (offers.length === 1 && page > 1) {
							setPage(page - 1);
						} else {
							load({ quiet: true });
						}
					}}
				/>
			)}

			{emailing && (
				<EmailModal
					offer={emailing}
					onClose={() => setEmailing(null)}
					onSent={(message) => {
						setEmailing(null);
						setNotice(message);
						load({ quiet: true });
					}}
				/>
			)}

			{sharing && <ShareModal offer={sharing} onClose={() => setSharing(null)} />}

			{publishing && (
				<PublishModal
					offer={publishing}
					onClose={() => setPublishing(null)}
					onPublished={(updated) => {
						const wasPublished = Boolean(publishing.spacefast?.spaceId);

						replace(updated);
						setPublishing(null);

						if (updated?.spacefast?.status === 'publishing') {
							setNotice(__('Spacefast is still finishing the publish. Use "check status" in a moment.', 'personalized-offers-for-spacefast'));
							return;
						}

						setNotice(
							<PublishedMessage
								offer={updated}
								text={
									wasPublished
										? sprintf(
											/* translators: %d: offer ID. */
											__('Space of offer #%d updated.', 'personalized-offers-for-spacefast'),
											updated.id
										)
										: updated?.type === 'public'
											? __('Offer published to Spacefast. Copy the link and share it.', 'personalized-offers-for-spacefast')
											: updated?.type === 'group'
												? __('Offer published to Spacefast. Send each customer their personal link from Edit offer.', 'personalized-offers-for-spacefast')
												: __('Offer published to Spacefast. Copy the link and send it to the customer.', 'personalized-offers-for-spacefast')
								}
							/>
						);
					}}
				/>
			)}
		</div>
	);
}
