/**
 * Spaces tab: Spacefast as a whole. The connection and the plan's usage,
 * live updates (a webhook), the team's Spaces next to the offers —
 * leftovers to delete or give to an offer, offers whose Space is gone —
 * requests to open private offers, and an offer's own domain.
 */
import { useEffect, useState } from '@wordpress/element';
import { __, _n, sprintf } from '@wordpress/i18n';
import {
	Button,
	ExternalLink,
	Modal,
	Notice,
	SelectControl,
	Spinner,
	TextControl,
} from '@wordpress/components';
import { ajaxAction, assertSuccess, onAssistantChanges } from '../api';

const PREFIX = 'personalized-offers-for-spacefast/';

const KIND_LABELS = {
	offer: __('Offer', 'personalized-offers-for-spacefast'),
	leftover: __('Leftover', 'personalized-offers-for-spacefast'),
	other: __('Not from this store', 'personalized-offers-for-spacefast'),
};

const DOMAIN_STATUS = {
	active: __('Active', 'personalized-offers-for-spacefast'),
	not_required: __('Active', 'personalized-offers-for-spacefast'),
	verified: __('Active', 'personalized-offers-for-spacefast'),
	pending: __('Waiting for DNS', 'personalized-offers-for-spacefast'),
	failed: __('DNS check failed', 'personalized-offers-for-spacefast'),
};

export function formatBytes(bytes) {
	if (!bytes) {
		return '0 MB';
	}

	if (bytes >= 1e9) {
		return `${(bytes / 1e9).toFixed(bytes >= 1e10 ? 0 : 1)} GB`;
	}

	return `${Math.max(0.1, bytes / 1e6).toFixed(bytes >= 1e7 ? 0 : 1)} MB`;
}

function formatDate(iso) {
	if (!iso) {
		return '';
	}

	const date = new Date(iso);

	return Number.isNaN(date.getTime()) ? '' : date.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}

function offerLabel(offer) {
	if (!offer) {
		return '';
	}

	return offer.headline
		? sprintf(
			/* translators: 1: offer ID, 2: offer headline. */
			__('Offer #%1$d: %2$s', 'personalized-offers-for-spacefast'),
			offer.id,
			offer.headline
		)
		: sprintf(
			/* translators: %d: offer ID. */
			__('Offer #%d', 'personalized-offers-for-spacefast'),
			offer.id
		);
}

/**
 * One limit of the plan: what is used of it, with a bar when it has a limit.
 */
function Meter({ label, used, limit, format = (value) => String(value) }) {
	const share = limit ? Math.min(1, used / limit) : 0;
	const tone = share >= 1 ? ' is-full' : share >= 0.8 ? ' is-high' : '';

	return (
		<div className={`pofsf-meter${tone}`}>
			<div className="pofsf-meter__label">
				<span>{label}</span>
				<strong>
					{limit
						? sprintf(
							/* translators: 1: amount used, 2: plan limit. */
							__('%1$s of %2$s', 'personalized-offers-for-spacefast'),
							format(used),
							format(limit)
						)
						: sprintf(
							/* translators: %s: amount used. */
							__('%s (no limit)', 'personalized-offers-for-spacefast'),
							format(used)
						)}
				</strong>
			</div>
			{limit > 0 && (
				<div className="pofsf-meter__bar" aria-hidden="true">
					<span style={{ width: `${Math.round(share * 100)}%` }} />
				</div>
			)}
		</div>
	);
}

function LiveUpdates({ webhook, onChange }) {
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);

	const toggle = async (enable) => {
		setBusy(true);
		setError(null);

		try {
			const response = await ajaxAction('pofsf_spacefast_webhook', { enable: enable ? '1' : '' });
			assertSuccess(response, __('Live updates could not be changed.', 'personalized-offers-for-spacefast'));
			onChange(response.data.webhook);
		} catch (err) {
			setError(err?.message);
		} finally {
			setBusy(false);
		}
	};

	return (
		<div className="pofsf-spaces__live">
			<h3>{__('Live updates', 'personalized-offers-for-spacefast')}</h3>
			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}
			{webhook.enabled ? (
				<>
					<p>
						<span className="pofsf-status is-ready">{__('On', 'personalized-offers-for-spacefast')}</span>{' '}
						{webhook.received > 0
							? sprintf(
								/* translators: 1: number of events, 2: date and time. */
								_n('%1$d event received, the last on %2$s.', '%1$d events received, the last on %2$s.', webhook.received, 'personalized-offers-for-spacefast'),
								webhook.received,
								formatDate(webhook.last_at)
							)
							: __('No events received yet.', 'personalized-offers-for-spacefast')}
					</p>
					{['failing', 'disabled'].includes(webhook.remote) && (
						<Notice status="warning" isDismissible={false}>
							{webhook.remote === 'disabled'
								? __('Spacefast stopped sending events after this site failed to answer many times. Turn live updates off and on again once the site is reachable.', 'personalized-offers-for-spacefast')
								: __('Spacefast could not deliver recent events to this site. It keeps retrying.', 'personalized-offers-for-spacefast')}
						</Notice>
					)}
					<p className="pofsf-muted">
						{__('Spacefast tells this site when a publish finishes or fails, when a Space is deleted there, when a domain goes live, and when someone asks to open a private offer (the store’s admin email is told).', 'personalized-offers-for-spacefast')}
					</p>
					<Button variant="secondary" isBusy={busy} disabled={busy} onClick={() => toggle(false)}>
						{__('Turn off', 'personalized-offers-for-spacefast')}
					</Button>
					{webhook.recent?.length > 0 && (
						<details className="pofsf-spaces__events">
							<summary>{__('Recent events', 'personalized-offers-for-spacefast')}</summary>
							<ul>
								{webhook.recent.map((event, index) => (
									<li key={index}>
										<code>{event.code}</code> {event.message}
										{event.offer_id > 0 && ` (#${event.offer_id})`}
										<span className="pofsf-muted"> {formatDate(event.at)}</span>
									</li>
								))}
							</ul>
						</details>
					)}
				</>
			) : webhook.reachable ? (
				<>
					<p>
						<span className="pofsf-status">{__('Off', 'personalized-offers-for-spacefast')}</span>{' '}
						{__('The plugin checks Spacefast itself when offers are opened. With live updates, Spacefast tells this site at once when a publish finishes or fails, when a Space is deleted there, when a domain goes live, and when someone asks to open a private offer (the store’s admin email is told).', 'personalized-offers-for-spacefast')}
					</p>
					<Button variant="secondary" isBusy={busy} disabled={busy} onClick={() => toggle(true)}>
						{__('Turn on', 'personalized-offers-for-spacefast')}
					</Button>
				</>
			) : (
				<p>
					<span className="pofsf-status">{__('Not available', 'personalized-offers-for-spacefast')}</span>{' '}
					{webhook.reason}{' '}
					{__('Publishing works the same: the plugin checks Spacefast itself.', 'personalized-offers-for-spacefast')}
				</p>
			)}
		</div>
	);
}

function AccountCard({ data, onWebhookChange }) {
	const { health, plan } = data;

	return (
		<div className="pofsf-spaces__account">
			<div>
				<h3>{__('Connection', 'personalized-offers-for-spacefast')}</h3>
				<p>
					<span className={`pofsf-spacefast-card__status${health.ok ? ' is-connected' : ''}`} />{' '}
					{health.ok
						? sprintf(
							/* translators: 1: Spacefast team name, 2: milliseconds. */
							__('%1$s: Spacefast answered in %2$d ms.', 'personalized-offers-for-spacefast'),
							data.team,
							health.ms
						)
						: health.error}
				</p>

				<h3>
					{plan
						? sprintf(
							/* translators: %s: Spacefast plan name. */
							__('Plan: %s', 'personalized-offers-for-spacefast'),
							plan.name
						)
						: __('Plan', 'personalized-offers-for-spacefast')}
				</h3>
				{plan ? (
					<div className="pofsf-spaces__meters">
						<Meter label={__('Live Spaces', 'personalized-offers-for-spacefast')} used={plan.usage.live_spaces} limit={plan.limits.live_spaces} />
						<Meter label={__('Storage', 'personalized-offers-for-spacefast')} used={plan.usage.storage_bytes} limit={plan.limits.storage_bytes} format={formatBytes} />
						<Meter label={__('Publishes today', 'personalized-offers-for-spacefast')} used={plan.usage.publishes_today} limit={plan.limits.publishes_daily} />
						<Meter label={__('Custom domains', 'personalized-offers-for-spacefast')} used={plan.usage.custom_domains} limit={plan.limits.custom_domains} />
					</div>
				) : (
					<p className="pofsf-muted">{data.usageError}</p>
				)}
				{plan?.warnings?.map((warning) => (
					<Notice key={warning} status="warning" isDismissible={false}>
						{warning}
					</Notice>
				))}
				{plan && plan.limits.live_spaces > 0 && plan.usage.live_spaces >= plan.limits.live_spaces && (
					<Notice status="warning" isDismissible={false}>
						{__('Every live Space of the plan is used: publishing a new offer will fail. Delete leftovers or unpublish expired offers, or upgrade the plan in Spacefast.', 'personalized-offers-for-spacefast')}
					</Notice>
				)}
			</div>
			<LiveUpdates webhook={data.webhook} onChange={onWebhookChange} />
		</div>
	);
}

function LinkModal({ space, offers, onClose, onDone }) {
	const [offerId, setOfferId] = useState(offers[0] ? String(offers[0].id) : '');
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);

	const link = async () => {
		setBusy(true);
		setError(null);

		try {
			// Publishing to the Space can take a while.
			const response = await ajaxAction('pofsf_space_link', { space_id: space.id, offer_id: offerId }, { timeout: 120000 });
			assertSuccess(response, __('The Space could not be linked.', 'personalized-offers-for-spacefast'));
			onDone();
		} catch (err) {
			setError(err?.message);
			setBusy(false);
		}
	};

	return (
		<Modal title={__('Link Space to an offer', 'personalized-offers-for-spacefast')} onRequestClose={onClose}>
			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}
			{offers.length === 0 ? (
				<p>{__('Every built offer already has a Space. Delete this one instead, or build an offer first.', 'personalized-offers-for-spacefast')}</p>
			) : (
				<>
					<p>
						{sprintf(
							/* translators: %s: Space title. */
							__('“%s” becomes the offer’s Space and the offer is published to it, instead of using a new Space of the plan.', 'personalized-offers-for-spacefast'),
							space.title
						)}
					</p>
					<SelectControl
						__nextHasNoMarginBottom
						__next40pxDefaultSize
						label={__('Offer', 'personalized-offers-for-spacefast')}
						value={offerId}
						options={offers.map((offer) => ({ value: String(offer.id), label: offerLabel(offer) }))}
						onChange={setOfferId}
					/>
					<p className="pofsf-muted">
						{__('Links made for the Space before stop working, so nobody reaches the offer through them. Its address stays the same.', 'personalized-offers-for-spacefast')}
					</p>
				</>
			)}
			<div className="pofsf-modal-actions">
				<Button variant="tertiary" onClick={onClose} disabled={busy}>
					{__('Cancel', 'personalized-offers-for-spacefast')}
				</Button>
				{offers.length > 0 && (
					<Button variant="primary" isBusy={busy} disabled={busy || !offerId} onClick={link}>
						{__('Link and publish', 'personalized-offers-for-spacefast')}
					</Button>
				)}
			</div>
		</Modal>
	);
}

function DeleteModal({ space, onClose, onDone }) {
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);

	const remove = async () => {
		setBusy(true);
		setError(null);

		try {
			const response = await ajaxAction('pofsf_space_delete', { space_id: space.id });
			assertSuccess(response, __('The Space could not be deleted.', 'personalized-offers-for-spacefast'));
			onDone();
		} catch (err) {
			setError(err?.message);
			setBusy(false);
		}
	};

	return (
		<Modal title={__('Delete Space?', 'personalized-offers-for-spacefast')} onRequestClose={onClose} size="medium">
			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}
			<p>
				{sprintf(
					/* translators: %s: Space title. */
					__('“%s” belongs to no offer of this store. Deleting it takes it offline for good and frees a live Space of the plan.', 'personalized-offers-for-spacefast'),
					space.title
				)}
			</p>
			<p className="pofsf-muted">
				{__('Another site connected to the same Spacefast team, such as a staging copy with the same store name, may use it. Delete it only if it is not theirs.', 'personalized-offers-for-spacefast')}
			</p>
			<div className="pofsf-modal-actions">
				<Button variant="tertiary" onClick={onClose} disabled={busy}>
					{__('Cancel', 'personalized-offers-for-spacefast')}
				</Button>
				<Button variant="primary" isDestructive isBusy={busy} disabled={busy} onClick={remove}>
					{__('Delete Space', 'personalized-offers-for-spacefast')}
				</Button>
			</div>
		</Modal>
	);
}

function DomainsModal({ space, onClose, onChanged }) {
	const [domains, setDomains] = useState(null);
	const [hostname, setHostname] = useState('');
	const [busy, setBusy] = useState('');
	const [error, setError] = useState(null);
	const offerId = space.offer.id;

	const run = async (action, params, key) => {
		setBusy(key);
		setError(null);

		try {
			const response = await ajaxAction(action, { offer_id: offerId, ...params });
			assertSuccess(response, __('Spacefast did not accept the change.', 'personalized-offers-for-spacefast'));
			setDomains(response.data.domains);

			if (action !== 'pofsf_space_domains') {
				onChanged();
			}

			return true;
		} catch (err) {
			setError(err?.message);

			return false;
		} finally {
			setBusy('');
		}
	};

	useEffect(() => {
		run('pofsf_space_domains', {}, 'load');
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [offerId]);

	const custom = (domains || []).filter((domain) => !domain.managed);

	return (
		<Modal
			className="pofsf-domains"
			title={sprintf(
				/* translators: %s: offer label, e.g. "Offer #12: Spring picks". */
				__('Address of %s', 'personalized-offers-for-spacefast'),
				offerLabel(space.offer)
			)}
			onRequestClose={onClose}
			size="large"
		>
			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}
			{domains === null ? (
				<Spinner />
			) : (
				<>
					<ul className="pofsf-domains__list">
						{domains.map((domain) => (
							<li key={domain.id}>
								<div className="pofsf-domains__name">
									<strong>{domain.name}</strong>
									<span className={`pofsf-status${['active', 'verified', 'not_required'].includes(domain.status) ? ' is-ready' : domain.status === 'failed' ? ' is-failed' : ' is-pending'}`}>
										{DOMAIN_STATUS[domain.status] || domain.status}
									</span>
									{domain.primary && <span className="pofsf-status is-sent">{__('Main address', 'personalized-offers-for-spacefast')}</span>}
									{!domain.managed && (
										<span className="pofsf-domains__actions">
											{domain.status !== 'verified' && (
												<Button variant="secondary" size="compact" isBusy={busy === `verify-${domain.id}`} disabled={Boolean(busy)} onClick={() => run('pofsf_space_domain_verify', { domain_id: domain.id }, `verify-${domain.id}`)}>
													{__('Check DNS now', 'personalized-offers-for-spacefast')}
												</Button>
											)}
											<Button variant="tertiary" size="compact" isDestructive isBusy={busy === `remove-${domain.id}`} disabled={Boolean(busy)} onClick={() => run('pofsf_space_domain_remove', { domain_id: domain.id }, `remove-${domain.id}`)}>
												{__('Remove', 'personalized-offers-for-spacefast')}
											</Button>
										</span>
									)}
								</div>
								{domain.managed && <p className="pofsf-muted">{__('The Space’s own address on Spacefast. It always works.', 'personalized-offers-for-spacefast')}</p>}
								{!domain.managed && domain.records.length > 0 && domain.status !== 'verified' && (
									<>
										<p>{__('Add these records at your domain’s DNS provider. Spacefast checks them by itself, and adds the certificate for HTTPS once they are found.', 'personalized-offers-for-spacefast')}</p>
										<table className="widefat striped pofsf-domains__records">
											<thead>
												<tr>
													<th>{__('Type', 'personalized-offers-for-spacefast')}</th>
													<th>{__('Name', 'personalized-offers-for-spacefast')}</th>
													<th>{__('Value', 'personalized-offers-for-spacefast')}</th>
												</tr>
											</thead>
											<tbody>
												{domain.records.map((record, index) => (
													<tr key={index}>
														<td>{record.type}</td>
														<td><code>{record.name || '@'}</code></td>
														<td><code className="pofsf-domains__value">{record.value}</code></td>
													</tr>
												))}
											</tbody>
										</table>
									</>
								)}
								{domain.problems.map((problem) => (
									<Notice key={problem} status="warning" isDismissible={false}>
										{problem}
									</Notice>
								))}
							</li>
						))}
					</ul>

					{custom.length === 0 && (
						<form
							className="pofsf-domains__add"
							onSubmit={async (event) => {
								event.preventDefault();

								if (await run('pofsf_space_domain_add', { hostname }, 'add')) {
									setHostname('');
								}
							}}
						>
							<TextControl
								__nextHasNoMarginBottom
								__next40pxDefaultSize
								label={__('Your own domain', 'personalized-offers-for-spacefast')}
								help={__('A subdomain of your shop’s domain, such as offers.yourshop.com. It becomes the offer’s main address; links already sent keep working.', 'personalized-offers-for-spacefast')}
								value={hostname}
								onChange={setHostname}
								placeholder="offers.yourshop.com"
							/>
							<Button variant="primary" type="submit" isBusy={busy === 'add'} disabled={Boolean(busy) || !hostname.trim()}>
								{__('Add domain', 'personalized-offers-for-spacefast')}
							</Button>
						</form>
					)}
				</>
			)}
			<div className="pofsf-modal-actions">
				<Button variant="secondary" onClick={onClose}>
					{__('Close', 'personalized-offers-for-spacefast')}
				</Button>
			</div>
		</Modal>
	);
}

const MATCH_LABELS = {
	customer: __('This offer’s customer', 'personalized-offers-for-spacefast'),
	recipient: __('A customer of this offer', 'personalized-offers-for-spacefast'),
	removed: __('Removed from this offer', 'personalized-offers-for-spacefast'),
	other: __('Not a customer of this offer', 'personalized-offers-for-spacefast'),
};

/**
 * Requests to open a private offer, from people who confirmed their email
 * on its page. Someone who isn't the offer's customer is let in only
 * after a confirmation: a single offer is written for one person.
 */
function AccessRequests({ requests, onChange }) {
	const [busy, setBusy] = useState('');
	const [error, setError] = useState(null);
	const [done, setDone] = useState(null);
	const [confirming, setConfirming] = useState(null);

	const decide = async (item, decision) => {
		setBusy(item.id + decision);
		setError(null);
		setDone(null);

		try {
			const response = await ajaxAction('pofsf_access_request_decide', { offer_id: item.offer?.id || 0, request_id: item.id, decision });

			if (response?.data?.requests) {
				onChange(response.data.requests);
			}

			assertSuccess(response, __('The request could not be answered.', 'personalized-offers-for-spacefast'));
			setDone(
				decision === 'approve'
					? sprintf(
						/* translators: %s: email address. */
						__('%s can now open the offer. Spacefast emailed them.', 'personalized-offers-for-spacefast'),
						response.data.email
					)
					: sprintf(
						/* translators: %s: email address. */
						__('Declined the request from %s.', 'personalized-offers-for-spacefast'),
						response.data.email
					)
			);
		} catch (err) {
			setError(err?.message);
		} finally {
			setBusy('');
			setConfirming(null);
		}
	};

	const approve = (item) => (['customer', 'recipient'].includes(item.match) ? decide(item, 'approve') : setConfirming(item));

	if (requests.items.length === 0 && !requests.error && !done && !error) {
		return null;
	}

	return (
		<div className="pofsf-spaces__requests">
			<h3>
				{sprintf(
					/* translators: %d: number of requests. */
					__('Access requests (%d)', 'personalized-offers-for-spacefast'),
					requests.items.length
				)}
			</h3>
			<p className="pofsf-muted">
				{__('People who couldn’t open a private offer asked for access on its page. Approve to let them open it until the offer expires or is revoked.', 'personalized-offers-for-spacefast')}
			</p>
			{requests.error && (
				<Notice status="warning" isDismissible={false}>
					{requests.error}
				</Notice>
			)}
			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}
			{done && (
				<Notice status="success" isDismissible onRemove={() => setDone(null)}>
					{done}
				</Notice>
			)}
			{requests.items.length > 0 && (
				<ul className="pofsf-spaces__request-list">
					{requests.items.map((item) => (
						<li key={item.id}>
							<div className="pofsf-spaces__request-who">
								<strong>{item.name || item.email}</strong>
								{item.name && <span className="pofsf-muted"> {item.email}</span>}{' '}
								<span className={`pofsf-status${['customer', 'recipient'].includes(item.match) ? ' is-ready' : ' is-pending'}`}>
									{MATCH_LABELS[item.match] || MATCH_LABELS.other}
								</span>
								<div className="pofsf-muted">
									{offerLabel(item.offer)}
									{item.match === 'other' && item.account && ` · ${sprintf(
										/* translators: %s: customer name. */
										__('store account: %s', 'personalized-offers-for-spacefast'),
										item.account
									)}`}
									{` · ${formatDate(item.createdAt)}`}
								</div>
								{item.message && <blockquote className="pofsf-spaces__request-note">{item.message}</blockquote>}
							</div>
							<div className="pofsf-spaces__request-actions">
								<Button
									variant="primary"
									size="compact"
									isBusy={busy === item.id + 'approve'}
									disabled={Boolean(busy) || item.match === 'removed'}
									onClick={() => approve(item)}
								>
									{__('Approve', 'personalized-offers-for-spacefast')}
								</Button>
								<Button
									variant="tertiary"
									size="compact"
									isBusy={busy === item.id + 'deny'}
									disabled={Boolean(busy)}
									onClick={() => decide(item, 'deny')}
								>
									{__('Decline', 'personalized-offers-for-spacefast')}
								</Button>
							</div>
						</li>
					))}
				</ul>
			)}

			{confirming && (
				<Modal title={__('Let someone else in?', 'personalized-offers-for-spacefast')} onRequestClose={() => setConfirming(null)} size="medium">
					<p>
						{sprintf(
							/* translators: 1: email address, 2: offer label. */
							__('%1$s is not a customer of %2$s. Approving lets them open its page, with its prices and coupon.', 'personalized-offers-for-spacefast'),
							confirming.email,
							offerLabel(confirming.offer)
						)}
					</p>
					{confirming.offer?.type === 'single' && (
						<p className="pofsf-muted">
							{__('This offer was written for one customer, so it may show their name and what they bought.', 'personalized-offers-for-spacefast')}
						</p>
					)}
					<div className="pofsf-modal-actions">
						<Button variant="tertiary" onClick={() => setConfirming(null)} disabled={Boolean(busy)}>
							{__('Cancel', 'personalized-offers-for-spacefast')}
						</Button>
						<Button variant="primary" isBusy={Boolean(busy)} disabled={Boolean(busy)} onClick={() => decide(confirming, 'approve')}>
							{__('Approve anyway', 'personalized-offers-for-spacefast')}
						</Button>
					</div>
				</Modal>
			)}
		</div>
	);
}

function MissingNotice({ missing, onForgotten }) {
	const [busy, setBusy] = useState(0);
	const [error, setError] = useState(null);

	const forget = async (offerId) => {
		setBusy(offerId);
		setError(null);

		try {
			const response = await ajaxAction('pofsf_space_forget', { offer_id: offerId });
			assertSuccess(response);
			onForgotten();
		} catch (err) {
			setError(err?.message);
		} finally {
			setBusy(0);
		}
	};

	return (
		<Notice status="warning" isDismissible={false} className="pofsf-spaces__missing">
			<p>
				{_n(
					'This offer’s Space is no longer in Spacefast (deleted there?), so its links don’t work. Mark it unpublished, then publish it again for a new Space and new links.',
					'These offers’ Spaces are no longer in Spacefast (deleted there?), so their links don’t work. Mark them unpublished, then publish them again for new Spaces and new links.',
					missing.length,
					'personalized-offers-for-spacefast'
				)}
			</p>
			{error && <p className="pofsf-spaces__error">{error}</p>}
			<ul>
				{missing.map((item) => (
					<li key={item.offerId}>
						{offerLabel(item.offer || { id: item.offerId })}{' '}
						<Button variant="link" isBusy={busy === item.offerId} disabled={Boolean(busy)} onClick={() => forget(item.offerId)}>
							{__('Mark unpublished', 'personalized-offers-for-spacefast')}
						</Button>
					</li>
				))}
			</ul>
		</Notice>
	);
}

export default function SpacesTab({ spacefastConnected, onRequestsCount = () => {} }) {
	const [data, setData] = useState(null);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);
	const [filter, setFilter] = useState('all');
	const [dialog, setDialog] = useState(null);

	const load = async (fresh = false) => {
		setLoading(true);
		setError(null);

		try {
			const response = await ajaxAction('pofsf_spaces_overview', { fresh: fresh ? '1' : '' });
			assertSuccess(response, __('Spacefast could not be reached.', 'personalized-offers-for-spacefast'));
			setData(response.data);
			onRequestsCount(response.data.requests?.items?.length ?? null);
		} catch (err) {
			setError(err?.message);
		} finally {
			setLoading(false);
		}
	};

	useEffect(() => {
		if (spacefastConnected) {
			load();
		}
	}, [spacefastConnected]);

	useEffect(
		() =>
			onAssistantChanges(
				[`${PREFIX}delete-space`, `${PREFIX}publish-offer`, `${PREFIX}delete-offer`],
				() => load(true)
			),
		[]
	);

	if (!spacefastConnected) {
		return (
			<Notice status="info" isDismissible={false}>
				{__('Connect a Spacefast account above to see its Spaces and plan.', 'personalized-offers-for-spacefast')}
			</Notice>
		);
	}

	if (!data) {
		return error ? (
			<Notice status="error" isDismissible={false}>
				{error}
			</Notice>
		) : (
			<Spinner />
		);
	}

	const spaces = data.spaces.filter((space) => filter === 'all' || space.kind === filter);
	const counts = data.spaces.reduce((all, space) => ({ ...all, [space.kind]: (all[space.kind] || 0) + 1 }), {});
	const done = () => {
		setDialog(null);
		load(true);
	};

	return (
		<div className="pofsf-spaces">
			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}

			<AccountCard data={data} onWebhookChange={(webhook) => setData((current) => ({ ...current, webhook }))} />

			{data.requests && (
				<AccessRequests
					requests={data.requests}
					onChange={(requests) => {
						setData((current) => ({ ...current, requests }));
						onRequestsCount(requests.items.length);
					}}
				/>
			)}

			{data.missing.length > 0 && <MissingNotice missing={data.missing} onForgotten={() => load(true)} />}

			<div className="pofsf-offers__toolbar">
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Show', 'personalized-offers-for-spacefast')}
					hideLabelFromVision
					value={filter}
					options={[
						{ value: 'all', label: sprintf(/* translators: %d: number of Spaces. */ __('All Spaces (%d)', 'personalized-offers-for-spacefast'), data.spaces.length) },
						{ value: 'offer', label: sprintf(/* translators: %d: number of Spaces. */ __('Offers (%d)', 'personalized-offers-for-spacefast'), counts.offer || 0) },
						{ value: 'leftover', label: sprintf(/* translators: %d: number of Spaces. */ __('Leftovers (%d)', 'personalized-offers-for-spacefast'), counts.leftover || 0) },
						{ value: 'other', label: sprintf(/* translators: %d: number of Spaces. */ __('Not from this store (%d)', 'personalized-offers-for-spacefast'), counts.other || 0) },
					]}
					onChange={setFilter}
				/>
				<p className="pofsf-muted">
					{__('Leftovers are titled like this store’s offer Spaces but belong to no offer: delete them, or give one to an offer that has no Space.', 'personalized-offers-for-spacefast')}
				</p>
				<Button variant="secondary" isBusy={loading} disabled={loading} onClick={() => load(true)}>
					{__('Refresh', 'personalized-offers-for-spacefast')}
				</Button>
			</div>

			{data.spacesError && (
				<Notice status="error" isDismissible={false}>
					{data.spacesError}
				</Notice>
			)}

			<table className="wp-list-table widefat fixed striped pofsf-offers__table pofsf-spaces__table">
				<thead>
					<tr>
						<th className="column-primary">{__('Space', 'personalized-offers-for-spacefast')}</th>
						<th className="column-kind">{__('Belongs to', 'personalized-offers-for-spacefast')}</th>
						<th className="column-storage">{__('Storage', 'personalized-offers-for-spacefast')}</th>
						<th className="column-updated">{__('Updated', 'personalized-offers-for-spacefast')}</th>
						<th className="column-actions">{__('Actions', 'personalized-offers-for-spacefast')}</th>
					</tr>
				</thead>
				<tbody>
					{spaces.length === 0 ? (
						<tr>
							<td colSpan={5}>{__('No Spaces here.', 'personalized-offers-for-spacefast')}</td>
						</tr>
					) : (
						spaces.map((space) => (
							<tr key={space.id}>
								<td className="column-primary">
									<strong>{space.title || space.id}</strong>
									{space.liveUrl && (
										<div className="pofsf-muted">
											<ExternalLink href={space.liveUrl}>{space.liveUrl.replace(/^https:\/\/|\/$/g, '')}</ExternalLink>
										</div>
									)}
								</td>
								<td className="column-kind">
									{space.offer ? (
										<>
											{offerLabel(space.offer)}{' '}
											<span className={`pofsf-status is-${space.offer.status}`}>{space.offer.status}</span>
										</>
									) : (
										<span className={`pofsf-status${space.kind === 'leftover' ? ' is-pending' : ''}`}>{KIND_LABELS[space.kind]}</span>
									)}
								</td>
								<td className="column-storage">{formatBytes(space.storage)}</td>
								<td className="column-updated">{formatDate(space.updatedAt || space.createdAt)}</td>
								<td className="column-actions">
									{space.kind === 'offer' && (
										<Button variant="secondary" size="compact" onClick={() => setDialog({ type: 'domains', space })}>
											{__('Address', 'personalized-offers-for-spacefast')}
										</Button>
									)}
									{space.kind === 'leftover' && (
										<>
											<Button variant="secondary" size="compact" onClick={() => setDialog({ type: 'link', space })}>
												{__('Link to offer', 'personalized-offers-for-spacefast')}
											</Button>{' '}
											<Button variant="tertiary" size="compact" isDestructive onClick={() => setDialog({ type: 'delete', space })}>
												{__('Delete', 'personalized-offers-for-spacefast')}
											</Button>
										</>
									)}
								</td>
							</tr>
						))
					)}
				</tbody>
			</table>

			{dialog?.type === 'link' && <LinkModal space={dialog.space} offers={data.linkable} onClose={() => setDialog(null)} onDone={done} />}
			{dialog?.type === 'delete' && <DeleteModal space={dialog.space} onClose={() => setDialog(null)} onDone={done} />}
			{dialog?.type === 'domains' && <DomainsModal space={dialog.space} onClose={() => setDialog(null)} onChanged={() => load(true)} />}
		</div>
	);
}
