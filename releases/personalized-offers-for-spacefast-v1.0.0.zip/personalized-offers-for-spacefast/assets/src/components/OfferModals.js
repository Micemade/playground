/**
 * Offer modals: choose a template; and edit an offer or create a new one
 * by hand, with a live preview of the offer page.
 */
import { useCopyToClipboard } from '@wordpress/compose';
import { useEffect, useRef, useState } from '@wordpress/element';
import { __, _n, sprintf } from '@wordpress/i18n';
import {
	Button,
	Card,
	CardBody,
	CardHeader,
	CardMedia,
	CheckboxControl,
	ComboboxControl,
	Dropdown,
	DropdownMenu,
	ExternalLink,
	Modal,
	Notice,
	RadioControl,
	SearchControl,
	SelectControl,
	Spinner,
	TextControl,
	TextareaControl,
	ToggleControl,
	Tooltip,
} from '@wordpress/components';
import apiFetch from '@wordpress/api-fetch';
import { addQueryArgs } from '@wordpress/url';
import { arrowLeft, caution, check, chevronDown, chevronUp, copy, moreVertical, pencil, plus, trash } from '@wordpress/icons';
import { SCRIPTED_PREVIEW_SANDBOX, ajaxAction, assertSuccess } from '../api';
import { TemplateEditorFrame, confirmLeaveTemplate } from './TemplateEditor';
import { Swatches, TemplateThumbnail } from './TemplatesList';

async function saveChanges(offerId, changes) {
	const response = await ajaxAction('pofsf_offer_update', {
		offer_id: offerId,
		changes: JSON.stringify(changes),
	});
	assertSuccess(response, __('The offer could not be saved.', 'personalized-offers-for-spacefast'));

	return response.data.offer;
}

/**
 * Whether the offer's template (saved ID) was deleted: the offer keeps its
 * copy, which can be saved as a template again (useTemplateRestore()).
 */
function templateDeleted(templateId, templates) {
	return String(templateId || 0) !== '0' && templates.length > 0 && !templates.some((template) => String(template.id) === String(templateId));
}

/**
 * Restores the offer's deleted template from its copy (pofsf_template_restore);
 * onRestored(newId, templates) gets the new template ID and list.
 */
function useTemplateRestore(offerId, onRestored) {
	const [restoring, setRestoring] = useState(false);
	const [restored, setRestored] = useState(false);
	const [restoreError, setRestoreError] = useState(null);

	const restore = async () => {
		setRestoring(true);
		setRestoreError(null);

		try {
			const response = await ajaxAction('pofsf_template_restore', { offer_id: offerId });
			assertSuccess(response, __('The template could not be restored.', 'personalized-offers-for-spacefast'));
			setRestored(true);
			onRestored(String(response.data.template_id), response.data.templates);
		} catch (err) {
			setRestoreError(err?.message);
		} finally {
			setRestoring(false);
		}
	};

	return { restore, restoring, restored, restoreError };
}

/**
 * The deleted-template message and Restore template button (Template modal
 * notice, Edit offer header dropdown).
 */
function DeletedTemplateMessage({ name, restoring, disabled, onRestore }) {
	return (
		<>
			<p>
				{sprintf(
					/* translators: %s: template name. */
					__('The template "%s" previously assigned to this offer was deleted. This offer keeps its design, but no longer follows a template. Restore it to edit it again and to use it for other offers.', 'personalized-offers-for-spacefast'),
					name || __('(no name)', 'personalized-offers-for-spacefast')
				)}
			</p>
			<Button variant="secondary" onClick={onRestore} isBusy={restoring} disabled={restoring || disabled} accessibleWhenDisabled __next40pxDefaultSize>
				{__('Restore template', 'personalized-offers-for-spacefast')}
			</Button>
		</>
	);
}

/**
 * The Edit offer header dropdown's content. Takes focus once the template is
 * restored: the Restore button goes away, and the dropdown closes when focus
 * leaves it.
 */
function TemplateAlertContent({ restored, children }) {
	const ref = useRef(null);

	useEffect(() => {
		if (restored) {
			ref.current?.focus();
		}
	}, [restored]);

	return (
		<div ref={ref} tabIndex={-1} className="pofsf-offer-modal__template-alert-content">
			{children}
		</div>
	);
}

const RESTORED_MESSAGE = () => __('Template restored. It is on the Templates tab, and the offers that used it follow it again.', 'personalized-offers-for-spacefast');

/**
 * Template choices for a select; a deleted template the offer still uses
 * (deleted = { id, name }) is listed so the select shows it.
 */
function templateOptions(templates, deleted = null) {
	return [
		{ value: '0', label: __('Store brand look (no template)', 'personalized-offers-for-spacefast') },
		...(deleted
			? [
				{
					value: String(deleted.id),
					label: sprintf(
						/* translators: %s: template name. */
						__('%s (deleted)', 'personalized-offers-for-spacefast'),
						deleted.name || __('(no name)', 'personalized-offers-for-spacefast')
					),
				},
			]
			: []),
		...templates.map((template) => ({
			value: String(template.id),
			label: template.isDefault
				? sprintf(
						/* translators: %s: template name. */
						__('%s (default)', 'personalized-offers-for-spacefast'),
						template.name
				  )
				: template.name,
		})),
	];
}

function PublishedNote({ offer }) {
	if (!offer.spacefast?.spaceId) {
		return null;
	}

	return (
		<Notice status="info" isDismissible={false}>
			{__('This offer is published on Spacefast. After saving, use "Update Space" to publish the changes.', 'personalized-offers-for-spacefast')}
		</Notice>
	);
}

/**
 * Cancel and the save button; with `onSaveOnly`, also a button that saves
 * and keeps the dialog open (`saveOnlyLabel`, disabled without changes).
 */
function ModalActions({ busy, onClose, onSave, disabled, label, onSaveOnly, saveOnlyLabel, saveOnlyDisabled }) {
	return (
		<div className="pofsf-modal-actions">
			<Button variant="tertiary" onClick={onClose} disabled={busy}>
				{__('Cancel', 'personalized-offers-for-spacefast')}
			</Button>
			{onSaveOnly && (
				<Button variant="secondary" onClick={onSaveOnly} isBusy={busy} disabled={busy || disabled || saveOnlyDisabled} accessibleWhenDisabled>
					{saveOnlyLabel}
				</Button>
			)}
			<Button variant="primary" onClick={onSave} isBusy={busy} disabled={busy || disabled}>
				{label || __('Save', 'personalized-offers-for-spacefast')}
			</Button>
		</div>
	);
}

/** One choice in the template picker: thumbnail, name with badges, colors and fonts. */
function TemplateChoice({ template, selected, onSelect }) {
	const label = template
		? template.name
		: __('Store brand look', 'personalized-offers-for-spacefast');
	const select = () => onSelect(template ? String(template.id) : '0');

	return (
		<Card size="small" className={selected ? 'pofsf-template-card pofsf-template-choice is-selected' : 'pofsf-template-card pofsf-template-choice'}>
			<CardMedia>
				{template ? (
					<TemplateThumbnail template={template} onOpen={select} openLabel={sprintf(
						/* translators: %s: template name. */
						__('Use %s', 'personalized-offers-for-spacefast'),
						label
					)} pressed={selected} />
				) : (
					<div className="pofsf-template-thumb pofsf-template-choice__brand">
						<span>{__('No template', 'personalized-offers-for-spacefast')}</span>
						<button
							type="button"
							className="pofsf-template-thumb__open"
							onClick={select}
							aria-pressed={selected}
							aria-label={__('Use the store brand look', 'personalized-offers-for-spacefast')}
						/>
					</div>
				)}
			</CardMedia>
			<CardHeader className="pofsf-template-card__header">
				<h3>
					{label}{' '}
					{template?.isDefault && <span className="pofsf-status is-ready">{__('Default', 'personalized-offers-for-spacefast')}</span>}{' '}
					{template?.builtin && <span className="pofsf-status">{__('Built-in', 'personalized-offers-for-spacefast')}</span>}
				</h3>
				{selected && <span className="pofsf-template-choice__check" aria-hidden="true">✓</span>}
			</CardHeader>
			<CardBody>
				{template ? (
					<>
						<Swatches colors={template.design.colors} />
						{(template.fonts?.heading || template.fonts?.body) && (
							<p className="pofsf-muted">
								{sprintf(
									/* translators: 1: heading font name, 2: body font name. */
									__('Fonts: %1$s / %2$s', 'personalized-offers-for-spacefast'),
									template.fonts.heading || __('brand', 'personalized-offers-for-spacefast'),
									template.fonts.body || __('brand', 'personalized-offers-for-spacefast')
								)}
							</p>
						)}
						<ExternalLink href={template.previewUrl}>{__('Preview', 'personalized-offers-for-spacefast')}</ExternalLink>
					</>
				) : (
					<p className="pofsf-muted">{__('Colors, fonts and logo from the Brand tab.', 'personalized-offers-for-spacefast')}</p>
				)}
			</CardBody>
		</Card>
	);
}

export function TemplateModal({ offer, templates, onClose, onSaved, onTemplatesChanged }) {
	const [currentId, setCurrentId] = useState(String(offer.templateId || 0));
	const [templateId, setTemplateId] = useState(currentId);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);
	const deleted = templateDeleted(currentId, templates);
	const { restore, restoring, restored, restoreError } = useTemplateRestore(offer.id, (restoredId, list) => {
		setCurrentId(restoredId);
		setTemplateId(restoredId);
		onTemplatesChanged?.(list);
	});

	const save = async () => {
		setBusy(true);
		setError(null);

		try {
			onSaved(await saveChanges(offer.id, { template_id: Number(templateId) }));
		} catch (err) {
			setError(err?.message);
			setBusy(false);
		}
	};

	return (
		<Modal
			title={sprintf(
				/* translators: 1: offer ID, 2: offer title. */
				__('Template for offer #%1$d: "%2$s"', 'personalized-offers-for-spacefast'),
				offer.id,
				offer.headline || __('(no title)', 'personalized-offers-for-spacefast')
			)}
			onRequestClose={busy ? () => {} : onClose}
			size="large"
			className="pofsf-template-picker"
		>
			<p>
				{__('Changes the look of the offer page. The offer text stays the same.', 'personalized-offers-for-spacefast')}
			</p>

			{deleted && (
				<Notice status="warning" isDismissible={false} className="pofsf-template-picker__notice pofsf-template-picker__deleted">
					<DeletedTemplateMessage name={offer.template} restoring={restoring} disabled={busy} onRestore={restore} />
				</Notice>
			)}

			{restored && (
				<Notice status="success" isDismissible={false} className="pofsf-template-picker__notice">
					{RESTORED_MESSAGE()}
				</Notice>
			)}

			{restoreError && (
				<Notice status="error" isDismissible={false} className="pofsf-template-picker__notice">
					{restoreError}
				</Notice>
			)}

			<div className="pofsf-templates__grid pofsf-template-picker__grid" role="group" aria-label={__('Templates', 'personalized-offers-for-spacefast')}>
				<TemplateChoice template={null} selected={templateId === '0'} onSelect={setTemplateId} />
				{templates.map((template) => (
					<TemplateChoice
						key={template.id}
						template={template}
						selected={templateId === String(template.id)}
						onSelect={setTemplateId}
					/>
				))}
			</div>

			{templates.length === 0 && (
				<p className="pofsf-muted">
					{__('No templates yet. Create one on the Templates tab or ask the assistant.', 'personalized-offers-for-spacefast')}
				</p>
			)}

			<PublishedNote offer={offer} />

			{error && (
				<Notice status="error" isDismissible={false}>
					{error}
				</Notice>
			)}

			<ModalActions
				busy={busy}
				onClose={onClose}
				onSave={save}
				disabled={restoring || templateId === currentId}
				label={__('Apply template', 'personalized-offers-for-spacefast')}
			/>
		</Modal>
	);
}

function CountedText({ Control, label, value, onChange, max, ...props }) {
	return (
		<Control
			__nextHasNoMarginBottom
			label={label}
			value={value}
			onChange={onChange}
			maxLength={max}
			help={sprintf(
				/* translators: 1: characters used, 2: character limit. */
				__('%1$d / %2$d characters', 'personalized-offers-for-spacefast'),
				value.length,
				max
			)}
			{...props}
		/>
	);
}

const PRODUCTS_PER_PAGE = 30;

/** Plain text from the Store API's HTML strings (names and prices are HTML). */
function textOf(html) {
	return new window.DOMParser().parseFromString(html || '', 'text/html').body.textContent.trim();
}

function fromStoreApi(item) {
	return {
		product_id: item.id,
		name: textOf(item.name),
		price: textOf(item.price_html),
		image: item.images?.[0]?.thumbnail || '',
		in_stock: Boolean(item.is_in_stock),
		variable: item.type === 'variable',
		// The checkout hand-off cannot add grouped or external products to a cart.
		pickable: Boolean(item.is_purchasable) && !['grouped', 'external'].includes(item.type),
	};
}

/** Product categories as select options, children indented under parents. */
function useStoreCategories() {
	const [options, setOptions] = useState([]);

	useEffect(() => {
		apiFetch({ path: '/wc/store/v1/products/categories' })
			.then((categories) => {
				const children = (parent) =>
					categories
						.filter((category) => category.parent === parent)
						.sort((a, b) => a.name.localeCompare(b.name));
				const walk = (parent, depth) =>
					children(parent).flatMap((category) => [
						{ value: String(category.id), label: `${'— '.repeat(depth)}${textOf(category.name)} (${category.count})` },
						...walk(category.id, depth + 1),
					]);

				setOptions(walk(0, 0));
			})
			.catch(() => setOptions([]));
	}, []);

	return options;
}

/**
 * Products from the WC Store API: the search and category when given,
 * otherwise the customer's suggested products (or the newest products).
 */
function useStoreProducts(search, category, suggested) {
	const [state, setState] = useState({ items: [], total: 0, loading: true, error: null });
	const requestRef = useRef(0);
	const suggestions = search || category ? [] : suggested.slice(0, PRODUCTS_PER_PAGE);
	const suggestionKey = suggestions.join(',');

	useEffect(() => {
		const request = ++requestRef.current;
		const query = { per_page: PRODUCTS_PER_PAGE };

		if (search) {
			query.search = search;
		}

		if (category) {
			query.category = category;
		}

		if (suggestionKey) {
			query.include = suggestionKey;
		}

		setState((current) => ({ ...current, loading: true, error: null }));

		const timer = setTimeout(async () => {
			try {
				const response = await apiFetch({ path: addQueryArgs('/wc/store/v1/products', query), parse: false });
				const items = (await response.json()).map(fromStoreApi);

				if (suggestionKey) {
					const order = suggestionKey.split(',').map(Number);
					items.sort((a, b) => order.indexOf(a.product_id) - order.indexOf(b.product_id));
				}

				if (request === requestRef.current) {
					setState({ items, total: Number(response.headers.get('X-WP-Total')) || items.length, loading: false, error: null });
				}
			} catch (err) {
				if (request === requestRef.current) {
					setState({ items: [], total: 0, loading: false, error: err?.message || __('Products could not be loaded.', 'personalized-offers-for-spacefast') });
				}
			}
		}, search ? 300 : 0);

		return () => clearTimeout(timer);
	}, [search, category, suggestionKey]);

	return { ...state, suggesting: suggestionKey !== '' };
}

/**
 * The variation a variable pick adds to the cart. "Any available" leaves
 * the choice to checkout (the default variation, or the first in stock).
 */
function VariationSelect({ pick, onChange }) {
	if (pick.variations === null) {
		return (
			<p className="pofsf-muted">
				<Spinner /> {__('Loading variations…', 'personalized-offers-for-spacefast')}
			</p>
		);
	}

	if (!pick.variations?.length) {
		return null;
	}

	const chosen = pick.variations.find((variation) => variation.id === pick.variation_id);

	return (
		<SelectControl
			__nextHasNoMarginBottom
			__next40pxDefaultSize
			label={__('Variation', 'personalized-offers-for-spacefast')}
			help={
				chosen && !chosen.in_stock
					? __('Out of stock: checkout will add an available variation instead.', 'personalized-offers-for-spacefast')
					: __('What the customer gets at checkout.', 'personalized-offers-for-spacefast')
			}
			value={String(pick.variation_id || 0)}
			onChange={(value) => onChange(Number(value))}
			options={[
				{ value: '0', label: __('Any available (chosen at checkout)', 'personalized-offers-for-spacefast') },
				...pick.variations.map((variation) => ({
					value: String(variation.id),
					label: variation.in_stock
						? variation.label
						: sprintf(
							/* translators: %s: variation, e.g. "Color: White, Size: M". */
							__('%s (out of stock)', 'personalized-offers-for-spacefast'),
							variation.label
						),
				})),
			]}
		/>
	);
}

function ProductImage({ src }) {
	return src ? <img src={src} alt="" width="40" height="40" /> : <span className="pofsf-offer-form__noimg" />;
}

function ProductLabel({ product }) {
	return (
		<>
			{product.name} <span className="pofsf-muted">{product.price}</span>
			{!product.in_stock && <span className="pofsf-status is-failed">{__('Out of stock', 'personalized-offers-for-spacefast')}</span>}
		</>
	);
}

/**
 * Product picks: the picked products with their title, story and reason
 * fields, then a catalog search (WC Store API) with a category filter.
 * Without a search, the products suggested for the customer are listed.
 */
function ProductPicker({ picks, suggested, limits, onChange, suggestedLabel }) {
	const [search, setSearch] = useState('');
	const [category, setCategory] = useState('');
	const categories = useStoreCategories();
	const results = useStoreProducts(search.trim(), category, suggested);
	const pickedIds = picks.map((pick) => pick.product_id);
	const full = picks.length >= limits.max_picks;
	// Picks whose title, story and reason fields are shown.
	const [open, setOpen] = useState(() => new Set());
	const toggleDetails = (productId) =>
		setOpen((current) => {
			const next = new Set(current);
			next.has(productId) ? next.delete(productId) : next.add(productId);
			return next;
		});

	const update = (productId, patch) => onChange((current) => current.map((pick) => (pick.product_id === productId ? { ...pick, ...patch } : pick)));

	const toggle = (product, picked) => {
		if (!picked) {
			onChange((current) => current.filter((pick) => pick.product_id !== product.product_id));
			return;
		}

		onChange((current) => [
			...current,
			{
				product_id: product.product_id,
				name: product.name,
				price: product.price,
				image: product.image,
				in_stock: product.in_stock,
				variation_id: 0,
				// null while a variable product's variations load.
				variations: product.variable ? null : [],
				title: '',
				story: '',
				reason: '',
			},
		]);

		if (product.variable) {
			ajaxAction('pofsf_product_variations', { product_id: product.product_id })
				.then((response) => {
					assertSuccess(response);
					update(product.product_id, { variations: response.data.variations, variation_id: response.data.preferred });
				})
				.catch(() => update(product.product_id, { variations: [] }));
		}
	};

	let status;

	if (results.loading) {
		status = <Spinner />;
	} else if (results.error) {
		status = results.error;
	} else if (results.items.length === 0) {
		status = __('No products match.', 'personalized-offers-for-spacefast');
	} else if (results.suggesting) {
		status = suggestedLabel || __('Suggested for this customer. Search to find any product.', 'personalized-offers-for-spacefast');
	} else {
		status = sprintf(
			/* translators: 1: products shown, 2: products found. */
			__('Showing %1$d of %2$d products.', 'personalized-offers-for-spacefast'),
			results.items.length,
			results.total
		);
	}

	return (
		<>
			<p className="pofsf-muted">
				{__('Each pick shows its title and story (the reason when the story is empty); write them under Details.', 'personalized-offers-for-spacefast')}
			</p>

			{picks.length > 0 && (
				<ul className="pofsf-offer-form__products">
					{picks.map((pick) => {
						const detailsOpen = open.has(pick.product_id);
						const detailsId = `pofsf-pick-details-${pick.product_id}`;
						const written = [pick.title, pick.story, pick.reason].filter((text) => (text || '').trim() !== '').length;

						return (
							<li key={pick.product_id} className="is-picked">
								<div className="pofsf-offer-form__product">
									<ProductImage src={pick.image} />
									<CheckboxControl __nextHasNoMarginBottom label={<ProductLabel product={pick} />} checked onChange={() => toggle(pick, false)} />
									<Button
										className="pofsf-offer-form__details-toggle"
										variant="tertiary"
										size="small"
										icon={detailsOpen ? chevronUp : chevronDown}
										iconPosition="right"
										aria-expanded={detailsOpen}
										aria-controls={detailsId}
										onClick={() => toggleDetails(pick.product_id)}
									>
										{written > 0
											? sprintf(
												/* translators: %d: number of filled-in texts (title, story, reason). */
												__('Details (%d)', 'personalized-offers-for-spacefast'),
												written
											)
											: __('Details', 'personalized-offers-for-spacefast')}
									</Button>
								</div>
								<VariationSelect pick={pick} onChange={(variationId) => update(pick.product_id, { variation_id: variationId })} />
								<div className="pofsf-offer-form__story" id={detailsId} hidden={!detailsOpen}>
									<TextControl
										__nextHasNoMarginBottom
										label={__('Title', 'personalized-offers-for-spacefast')}
										placeholder={__('An editorial line, not the product name', 'personalized-offers-for-spacefast')}
										value={pick.title}
										maxLength={limits.title}
										onChange={(title) => update(pick.product_id, { title })}
									/>
									<TextareaControl
										__nextHasNoMarginBottom
										label={__('Story', 'personalized-offers-for-spacefast')}
										rows={3}
										placeholder={__('How it fits the customer’s life and style', 'personalized-offers-for-spacefast')}
										value={pick.story}
										maxLength={limits.story}
										onChange={(story) => update(pick.product_id, { story })}
									/>
									<TextControl
										__nextHasNoMarginBottom
										label={__('Reason', 'personalized-offers-for-spacefast')}
										placeholder={__('Why this product suits the customer', 'personalized-offers-for-spacefast')}
										value={pick.reason}
										maxLength={limits.reason}
										onChange={(reason) => update(pick.product_id, { reason })}
									/>
								</div>
							</li>
						);
					})}
				</ul>
			)}

			<div className="pofsf-offer-form__filters">
				<SearchControl
					__nextHasNoMarginBottom
					label={__('Search products', 'personalized-offers-for-spacefast')}
					placeholder={__('Search all products', 'personalized-offers-for-spacefast')}
					value={search}
					onChange={setSearch}
				/>
				<SelectControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					label={__('Category', 'personalized-offers-for-spacefast')}
					hideLabelFromVision
					value={category}
					onChange={setCategory}
					options={[{ value: '', label: __('All categories', 'personalized-offers-for-spacefast') }, ...categories]}
				/>
				<p className="pofsf-muted pofsf-offer-form__results-status" role="status">
					{status}
				</p>
			</div>

			<ul className="pofsf-offer-form__products is-results" aria-busy={results.loading}>
				{results.items.map((product) => {
					const picked = pickedIds.includes(product.product_id);

					return (
						<li key={product.product_id} className={picked ? 'is-picked' : ''}>
							<div className="pofsf-offer-form__product">
								<ProductImage src={product.image} />
								<CheckboxControl
									__nextHasNoMarginBottom
									label={<ProductLabel product={product} />}
									help={!product.pickable ? __('Cannot be bought through an offer.', 'personalized-offers-for-spacefast') : undefined}
									checked={picked}
									disabled={!picked && (full || !product.pickable)}
									onChange={(value) => toggle(product, value)}
								/>
							</div>
						</li>
					);
				})}
			</ul>
		</>
	);
}

const PREVIEW_DELAY = 600;
const MAX_USES = 65535;

/** Field types an offer's texts can have (OfferCopy::typeLabels()); the server sends them with the form. */
const FIELD_TYPES = {
	overheadline: __('Overheadline', 'personalized-offers-for-spacefast'),
	subheadline: __('Subheadline', 'personalized-offers-for-spacefast'),
	greeting: __('Greeting', 'personalized-offers-for-spacefast'),
	body: __('Body text', 'personalized-offers-for-spacefast'),
	additional: __('Additional text', 'personalized-offers-for-spacefast'),
};

/** Field types written on one line; the others get a text area. */
const SHORT_FIELDS = ['overheadline', 'subheadline', 'greeting'];

let lastFieldKey = 0;

/** Fields as the form keeps them: each with a key, so React tracks it while fields move. */
function withKeys(fields) {
	return (fields || []).map((field) => ({ ...field, key: ++lastFieldKey }));
}

/** Fields as the server reads them. */
function fieldsOf(fields) {
	return (fields || []).map(({ type, text }) => ({ type, text }));
}

/**
 * The offer's texts: the fixed headline, then the fields the manager adds,
 * each of a type that decides where the template shows it (the template's
 * Offer text blocks show the fields of their type).
 */
function CopyFields({ form, set, limits }) {
	const types = form.field_types || FIELD_TYPES;
	const fields = form.fields;
	// Each type once: the menus offer the types the offer has no field of yet.
	const unused = Object.keys(types).filter((type) => !fields.some((field) => field.type === type));
	const setFields = (next) => set('fields', next);
	const update = (key, patch) => setFields(fields.map((field) => (field.key === key ? { ...field, ...patch } : field)));

	return (
		<>
			<CountedText Control={TextControl} __next40pxDefaultSize label={__('Headline', 'personalized-offers-for-spacefast')} value={form.headline} onChange={(value) => set('headline', value)} max={limits.headline} />
			{fields.map((field) => {
				const label = types[field.type] || field.type;
				const short = SHORT_FIELDS.includes(field.type);

				return (
					<div className="pofsf-copy-field" key={field.key}>
						<div className="pofsf-copy-field__head">
							<span className="pofsf-copy-field__label">{label}</span>
							<DropdownMenu
								icon={moreVertical}
								label={sprintf(
									/* translators: %s: name of the item the menu acts on, e.g. a template name or an offer text type such as "Body text". */
									__('Actions for %s', 'personalized-offers-for-spacefast'),
									label
								)}
								toggleProps={{ size: 'small' }}
								popoverProps={{ placement: 'bottom-end' }}
								controls={[
									unused.map((type) => ({
										title: sprintf(
											/* translators: %s: field type, e.g. "Body text". */
											__('Change to %s', 'personalized-offers-for-spacefast'),
											types[type]
										),
										onClick: () => update(field.key, { type, text: field.text.slice(0, limits[type]) }),
									})),
									[
										{
											title: __('Remove field', 'personalized-offers-for-spacefast'),
											icon: trash,
											onClick: () => setFields(fields.filter((item) => item.key !== field.key)),
										},
									],
								].filter((group) => group.length > 0)}
							/>
						</div>
						<CountedText
							Control={short ? TextControl : TextareaControl}
							{...(short ? { __next40pxDefaultSize: true } : { rows: 3 })}
							label={label}
							hideLabelFromVision
							value={field.text}
							onChange={(text) => update(field.key, { text })}
							max={limits[field.type]}
						/>
					</div>
				);
			})}
			{unused.length > 0 && (
				<DropdownMenu
					icon={plus}
					label={__('Add field', 'personalized-offers-for-spacefast')}
					text={__('Add field', 'personalized-offers-for-spacefast')}
					toggleProps={{ variant: 'secondary', size: 'compact', showTooltip: false, className: 'pofsf-copy-fields__add' }}
					popoverProps={{ placement: 'bottom-start' }}
					controls={unused.map((type) => ({
						title: types[type],
						onClick: () => setFields([...fields, { type, text: '', key: ++lastFieldKey }]),
					}))}
				/>
			)}
			<p className="description">
				{__('The template shows each field where it has an Offer text block of that type. Empty fields are left out.', 'personalized-offers-for-spacefast')}
			</p>
			<div className="pofsf-copy-field pofsf-copy-field--button">
				<CountedText
					Control={TextControl}
					__next40pxDefaultSize
					label={__('Offer action button text', 'personalized-offers-for-spacefast')}
					value={form.button_text || ''}
					onChange={(value) => set('button_text', value)}
					max={limits.button_text || 40}
				/>
				<p className="description">
					{__('Leave empty to use the button text set in the template’s Offer action button block.', 'personalized-offers-for-spacefast')}
				</p>
			</div>
		</>
	);
}

/** The usage limit as the server stores it: 0 when the limit is off. */
function maxUsesOf(form) {
	return form.usage_limit ? Number(form.max_uses) || 0 : 0;
}

/**
 * "Enable offer usage limit", and the limit itself while it is on. Opening
 * the offer's checkout link counts as a use; admin previews do not.
 */
function UsageLimitFields({ form, set }) {
	return (
		<>
			<ToggleControl
				__nextHasNoMarginBottom
				label={__('Enable offer usage limit', 'personalized-offers-for-spacefast')}
				help={
					form.usage_limit
						? {
							public: __('Orders from all customers together count toward the limit; then the offer becomes Used. Previews in the admin do not count.', 'personalized-offers-for-spacefast'),
							group: __('Each customer in the group can place this many orders from the offer. When nobody can any more, the offer becomes Used. Previews in the admin do not count.', 'personalized-offers-for-spacefast'),
						}[form.type] || __('Each order placed from the offer counts as a use; then the offer becomes Used. Previews in the admin do not count.', 'personalized-offers-for-spacefast')
						: __('The offer can be used any number of times until it expires.', 'personalized-offers-for-spacefast')
				}
				checked={form.usage_limit}
				onChange={(value) => set('usage_limit', value)}
			/>
			{form.usage_limit && (
				<TextControl
					__nextHasNoMarginBottom
					__next40pxDefaultSize
					type="number"
					min={1}
					max={MAX_USES}
					label={
						{
							public: __('Max orders in total', 'personalized-offers-for-spacefast'),
							group: __('Max uses per customer', 'personalized-offers-for-spacefast'),
						}[form.type] || __('Max uses per offer', 'personalized-offers-for-spacefast')
					}
					help={
						form.used_count > 0
							? sprintf(
								/* translators: %d: times the offer was used. */
								_n('Used %d time so far.', 'Used %d times so far.', form.used_count, 'personalized-offers-for-spacefast'),
								form.used_count
							)
							: undefined
					}
					value={String(form.max_uses)}
					onChange={(value) => set('max_uses', value === '' ? '' : Number(value))}
				/>
			)}
		</>
	);
}

const DISCOUNT_TYPES = [
	{ value: 'percent', label: __('Percentage discount', 'personalized-offers-for-spacefast') },
	{ value: 'fixed_cart', label: __('Fixed cart discount', 'personalized-offers-for-spacefast') },
	{ value: 'fixed_product', label: __('Fixed product discount', 'personalized-offers-for-spacefast') },
];

/** A code like the ones the server generates; the server checks it is unused when saving. */
function generateCouponCode() {
	const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
	const bytes = window.crypto.getRandomValues(new Uint8Array(8));

	return 'pofsf_offer_' + Array.from(bytes, (byte) => chars[byte % chars.length]).join('');
}

/** Why the coupon settings cannot be saved yet; '' when they can. */
function couponProblem(coupon) {
	if (!coupon) {
		return '';
	}

	if (!String(coupon.code || '').trim()) {
		return __('Coupon: enter a coupon code.', 'personalized-offers-for-spacefast');
	}

	const amount = Number(String(coupon.amount ?? '').replace(',', '.') || 0);

	if (!Number.isFinite(amount) || amount < 0 || (coupon.discount_type === 'percent' && amount > 100)) {
		return coupon.discount_type === 'percent'
			? __('Coupon: the percentage discount must be between 0 and 100.', 'personalized-offers-for-spacefast')
			: __('Coupon: the discount amount must be 0 or more.', 'personalized-offers-for-spacefast');
	}

	return '';
}

/**
 * The offer's WooCommerce coupon: its code, discount and free shipping,
 * and the offer's usage limit, which the coupon follows. The offer link
 * applies the coupon at checkout, so customers never type the code.
 */
function CouponFields({ form, set }) {
	const coupon = form.coupon;
	const setCoupon = (patch) => set('coupon', { ...coupon, ...patch });
	const percent = coupon.discount_type === 'percent';

	return (
		<>
			{form.coupon_missing && (
				<Notice status="warning" isDismissible={false}>
					{__('This offer has no coupon yet. Saving the offer creates one with these settings.', 'personalized-offers-for-spacefast')}
				</Notice>
			)}
			<TextControl
				__nextHasNoMarginBottom
				__next40pxDefaultSize
				label={__('Coupon code', 'personalized-offers-for-spacefast')}
				help={__('The offer link applies it at checkout, so customers don’t need to type it. It must not be used by another coupon.', 'personalized-offers-for-spacefast')}
				value={coupon.code}
				maxLength={50}
				onChange={(code) => setCoupon({ code: code.replace(/\s+/g, '') })}
			/>
			<Button variant="link" className="pofsf-coupon__generate" onClick={() => setCoupon({ code: generateCouponCode() })}>
				{__('Generate a new code', 'personalized-offers-for-spacefast')}
			</Button>
			<SelectControl
				__nextHasNoMarginBottom
				__next40pxDefaultSize
				label={__('Discount type', 'personalized-offers-for-spacefast')}
				help={
					coupon.discount_type === 'fixed_cart'
						? __('A fixed amount off the whole cart.', 'personalized-offers-for-spacefast')
						: __('Applies to the offer’s products only.', 'personalized-offers-for-spacefast')
				}
				value={coupon.discount_type}
				options={DISCOUNT_TYPES}
				onChange={(discountType) => setCoupon({ discount_type: discountType })}
			/>
			<TextControl
				__nextHasNoMarginBottom
				__next40pxDefaultSize
				type="number"
				min={0}
				max={percent ? 100 : undefined}
				step="any"
				label={percent ? __('Discount (%)', 'personalized-offers-for-spacefast') : __('Discount amount', 'personalized-offers-for-spacefast')}
				help={
					coupon.discount_type === 'fixed_product'
						? __('Taken off each of the offer’s products in the cart, per item. 0 for no discount.', 'personalized-offers-for-spacefast')
						: __('0 for no discount.', 'personalized-offers-for-spacefast')
				}
				value={String(coupon.amount ?? '')}
				onChange={(amount) => setCoupon({ amount })}
			/>
			<ToggleControl
				__nextHasNoMarginBottom
				label={__('Allow free shipping', 'personalized-offers-for-spacefast')}
				help={__('Needs a Free shipping method in WooCommerce → Settings → Shipping that requires “A valid free shipping coupon”.', 'personalized-offers-for-spacefast')}
				checked={Boolean(coupon.free_shipping)}
				onChange={(freeShipping) => setCoupon({ free_shipping: freeShipping })}
			/>
			<UsageLimitFields form={form} set={set} />
		</>
	);
}

function picksOf(picks) {
	return picks.map(({ product_id: id, variation_id: variationId, title, story, reason }) => ({ product_id: id, variation_id: variationId || 0, title, story, reason }));
}

/** The form as the server reads it: type, copy, expiry, template and picks. */
function offerInput(form) {
	const input = {
		type: form.type,
		expires_on: form.expires_on,
		template_id: Number(form.template_id),
		max_uses: maxUsesOf(form),
		picks: picksOf(form.picks),
	};

	input.headline = form.headline;
	input.button_text = form.button_text || '';
	input.fields = fieldsOf(form.fields);

	return input;
}

/**
 * The offer page for the form's current state, re-rendered on the server a
 * moment after each change. offerId 0 previews a new offer.
 */
function OfferPreview({ offerId, input }) {
	const [html, setHtml] = useState('');
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const requestRef = useRef(0);
	const key = JSON.stringify(input);

	useEffect(() => {
		const request = ++requestRef.current;
		setLoading(true);

		const timer = setTimeout(async () => {
			try {
				const response = await ajaxAction('pofsf_offer_draft_preview', { offer_id: offerId, offer: key });
				assertSuccess(response, __('The preview could not be rendered.', 'personalized-offers-for-spacefast'));

				if (request === requestRef.current) {
					setHtml(response.data.html);
					setError(null);
				}
			} catch (err) {
				if (request === requestRef.current) {
					setError(err?.message);
				}
			} finally {
				if (request === requestRef.current) {
					setLoading(false);
				}
			}
		}, html ? PREVIEW_DELAY : 0);

		return () => clearTimeout(timer);
	}, [offerId, key]); // eslint-disable-line react-hooks/exhaustive-deps

	return (
		<div className="pofsf-offer-modal__preview" aria-busy={loading}>
			{html && (
				<iframe
					title={__('Offer preview', 'personalized-offers-for-spacefast')}
					srcDoc={html}
					// Scripts for the page's cart (offer-cart.js); no same-origin access to the admin (see SCRIPTED_PREVIEW_SANDBOX).
					// Links and the checkout form open in a new tab (<base target="_blank">).
					sandbox={SCRIPTED_PREVIEW_SANDBOX}
				/>
			)}
			{loading && (
				<span className="pofsf-offer-modal__preview-status">
					<Spinner /> {__('Updating preview…', 'personalized-offers-for-spacefast')}
				</span>
			)}
			{error && (
				<Notice status="error" isDismissible={false} className="pofsf-offer-modal__preview-error">
					{error}
				</Notice>
			)}
		</div>
	);
}

function CopyRecipientLink({ link }) {
	const [copied, setCopied] = useState(false);
	const timer = useRef();
	const ref = useCopyToClipboard(link, () => {
		setCopied(true);
		clearTimeout(timer.current);
		timer.current = setTimeout(() => setCopied(false), 2000);
	});

	useEffect(() => () => clearTimeout(timer.current), []);

	return (
		<Button ref={ref} variant="link" label={__('Copy this customer’s personal link to the offer page', 'personalized-offers-for-spacefast')} showTooltip>
			{copied ? __('Copied', 'personalized-offers-for-spacefast') : __('Copy link', 'personalized-offers-for-spacefast')}
		</Button>
	);
}

/**
 * A group offer's customers: search to add, remove from the list. When
 * editing, each shows their uses and their personal link to the published
 * page (customers added since saving get one when the offer is saved).
 */
function RecipientsField({ recipients, max, editing, pageUrl, onChange, disabled }) {
	const [options, setOptions] = useState([]);
	const [search, setSearch] = useState('');
	const found = useRef(new Map());

	useEffect(() => {
		const timer = setTimeout(() => {
			ajaxAction('pofsf_customers_search', { search })
				.then((response) => {
					assertSuccess(response);
					response.data.customers.forEach((item) => found.current.set(String(item.id), item));
					setOptions(response.data.customers.map((item) => ({ value: String(item.id), label: `${item.name} (${item.email})` })));
				})
				.catch(() => setOptions([]));
		}, search ? 300 : 0);

		return () => clearTimeout(timer);
	}, [search]);

	const chosen = new Set(recipients.map((item) => String(item.id)));
	const full = recipients.length >= max;

	const add = (value) => {
		const customer = value && found.current.get(value);

		if (customer && !chosen.has(value) && !full) {
			onChange([...recipients, { id: customer.id, name: customer.name, email: customer.email }]);
		}
	};

	return (
		<div className="pofsf-recipients">
			<ComboboxControl
				__nextHasNoMarginBottom
				__next40pxDefaultSize
				label={sprintf(
					/* translators: 1: customers in the group, 2: most allowed. */
					__('Customers (%1$d/%2$d)', 'personalized-offers-for-spacefast'),
					recipients.length,
					max
				)}
				help={
					full
						? __('The group is full.', 'personalized-offers-for-spacefast')
						: __('Search by name or email, then choose a customer to add them. Each gets a personal link to the same offer page.', 'personalized-offers-for-spacefast')
				}
				value={null}
				options={options.filter((option) => !chosen.has(option.value))}
				onFilterValueChange={setSearch}
				onChange={add}
				disabled={disabled || full}
			/>
			{editing && !pageUrl && recipients.length > 0 && (
				<p className="pofsf-muted">{__('Publish the offer to Spacefast to get each customer’s personal link.', 'personalized-offers-for-spacefast')}</p>
			)}
			{recipients.length > 0 && (
				<ul className="pofsf-recipients__list">
					{recipients.map((item) => (
						<li key={item.id}>
							<span className="pofsf-recipients__who">
								<strong>{item.name}</strong>
								<span className="pofsf-muted">{item.email}</span>
								{item.status === 'used' && <span className="pofsf-muted">{__('Used up', 'personalized-offers-for-spacefast')}</span>}
								{item.used_count > 0 && item.status !== 'used' && (
									<span className="pofsf-muted">
										{sprintf(
											/* translators: %d: orders placed by this customer. */
											_n('%d order', '%d orders', item.used_count, 'personalized-offers-for-spacefast'),
											item.used_count
										)}
									</span>
								)}
								{item.opens !== undefined && (
									<span className="pofsf-muted">
										{item.opens > 0
											? sprintf(
												/* translators: %d: times the customer opened their personal link. */
												_n('Opened link %d time', 'Opened link %d times', item.opens, 'personalized-offers-for-spacefast'),
												item.opens
											)
											: __('Link not opened yet', 'personalized-offers-for-spacefast')}
									</span>
								)}
							</span>
							<span className="pofsf-recipients__actions">
								{item.link && <CopyRecipientLink link={item.link} />}
								{editing && !item.link && pageUrl && <span className="pofsf-muted">{__('Link after saving', 'personalized-offers-for-spacefast')}</span>}
								<Button
									size="small"
									icon="no-alt"
									label={sprintf(
										/* translators: %s: customer name. */
										__('Remove %s from the group', 'personalized-offers-for-spacefast'),
										item.name
									)}
									onClick={() => onChange(recipients.filter((other) => other.id !== item.id))}
									disabled={disabled}
								/>
							</span>
						</li>
					))}
				</ul>
			)}
		</div>
	);
}

/**
 * Searches customer accounts as the admin types. The chosen customer's
 * shortlist is loaded by the form.
 */
/** A customer's identity in the form: their account, or a guest's email. */
export function customerKey(customer) {
	if (!customer) {
		return '';
	}

	return customer.id > 0 ? String(customer.id) : `guest:${String(customer.email).toLowerCase()}`;
}

function customerLabel(customer) {
	const label = `${customer.name} (${customer.email})`;

	/* translators: %s: a customer's name and email. */
	return customer.id > 0 ? label : sprintf(__('%s, guest', 'personalized-offers-for-spacefast'), label);
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function CustomerPicker({ customer, onChange, disabled }) {
	const [found, setFound] = useState([]);
	const [search, setSearch] = useState('');

	useEffect(() => {
		const timer = setTimeout(() => {
			ajaxAction('pofsf_customers_search', { search, guests: 1 })
				.then((response) => {
					assertSuccess(response);
					setFound(response.data.customers);
				})
				.catch(() => setFound([]));
		}, search ? 300 : 0);

		return () => clearTimeout(timer);
	}, [search]);

	// An email nobody has used yet can still get an offer, as a guest.
	const typed = search.trim();
	const customers = EMAIL_PATTERN.test(typed) && !found.some((item) => item.email.toLowerCase() === typed.toLowerCase())
		? [...found, { id: 0, name: typed, email: typed, guest: true }]
		: found;
	// Keep the chosen customer selectable while the results show others.
	const all = customer && !customers.some((item) => customerKey(item) === customerKey(customer)) ? [customer, ...customers] : customers;

	return (
		<ComboboxControl
			__nextHasNoMarginBottom
			__next40pxDefaultSize
			label={__('Customer', 'personalized-offers-for-spacefast')}
			help={__('Search by name or email; guests (customers without an account) too, or type a new email. Products matched to this customer are suggested under Products.', 'personalized-offers-for-spacefast')}
			value={customer ? customerKey(customer) : null}
			options={all.map((item) => ({ value: customerKey(item), label: customerLabel(item) }))}
			onFilterValueChange={setSearch}
			onChange={(value) => onChange(all.find((item) => customerKey(item) === value) || null)}
			disabled={disabled}
		/>
	);
}

/** The request parameters that name a customer. */
function customerParams(customer) {
	return customer?.id > 0 ? { customer_id: customer.id } : { customer_id: 0, customer_email: customer?.email || '' };
}

/**
 * Offers follow their template when it is saved. Says when an offer's copy
 * is still older than the saved template (rare), and when the preview shows
 * the latest version.
 */
function TemplateVersionNote({ name, outdated, refreshed, onRefresh }) {
	if (refreshed) {
		return (
			<Notice status="info" isDismissible={false}>
				{sprintf(
					/* translators: %s: template name. */
					__('The preview shows the latest saved version of "%s".', 'personalized-offers-for-spacefast'),
					name
				)}
			</Notice>
		);
	}

	if (!outdated) {
		return null;
	}

	return (
		<Notice
			status="warning"
			isDismissible={false}
			actions={[{ label: __('Use the latest version', 'personalized-offers-for-spacefast'), onClick: onRefresh, variant: 'secondary' }]}
		>
			{sprintf(
				/* translators: %s: template name. */
				__('This offer still shows an older version of "%s". Use the latest version, then save the offer.', 'personalized-offers-for-spacefast'),
				name
			)}
		</Notice>
	);
}

/**
 * What changing a saved offer's type does to the links already shared.
 */
function TypeChangeNote({ from, to }) {
	if (from === to) {
		return null;
	}

	let message = __('The offer keeps its link. Publish it again after saving so the page matches.', 'personalized-offers-for-spacefast');

	if (from === 'group') {
		message = __('The customers\' personal links stop working at checkout. The offer gets one link again: publish it after saving and share that link.', 'personalized-offers-for-spacefast');
	} else if (to === 'group') {
		message = __('The offer\'s current link stops working at checkout. After saving, publish the offer again and send each customer their personal link from Edit offer.', 'personalized-offers-for-spacefast');
	}

	return (
		<Notice status="warning" isDismissible={false}>
			{message}
		</Notice>
	);
}

/**
 * Edit offer and Create new offer: the live offer page in the main area,
 * the fields in collapsible sidebar sections. offer is null when creating.
 * The offer's template can be edited in the block editor, shown in place
 * of the form; built-in templates are duplicated first.
 */
function OfferFormModal({ offer, templates: initialTemplates, onClose, onSaved, onUpdated, onTemplatesChanged, initialCustomer = null, initialSegment = null }) {
	const creating = !offer;
	// Updated here when a template is duplicated or edited from this form.
	const [ownTemplates, setOwnTemplates] = useState(null);
	const templates = ownTemplates || initialTemplates;
	const defaultTemplate = templates.find((template) => template.isDefault);
	const [form, setForm] = useState(() =>
		creating
			? {
				headline: '',
				button_text: '',
				fields: [],
				type: 'single',
				recipients: [],
				expires_on: '',
				template_id: String(defaultTemplate?.id || 0),
				usage_limit: true,
				max_uses: '',
				used_count: 0,
				picks: [],
				suggested: [],
				limits: null,
				coupon: null,
				customer: null,
				// The segment a new group offer is for ({ id, name }), from the Segments tab.
				segment: null,
			}
			: null
	);
	const [original, setOriginal] = useState(null);
	const [loadingCustomer, setLoadingCustomer] = useState(false);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(null);
	const [savedNotice, setSavedNotice] = useState(false);
	const [editingTemplate, setEditingTemplate] = useState(null);
	const [templateBusy, setTemplateBusy] = useState(false);
	// Bumped when the offer's template was saved in the editor: the preview,
	// and on save the offer, take the template's new version.
	const [templateRefresh, setTemplateRefresh] = useState(0);
	const [tab, setTab] = useState('basic');
	const templateFrame = useRef(null);

	// The saved offer as the form edits it; also after "Save offer", so later changes compare with what is saved.
	const loadOffer = async () => {
		const response = await ajaxAction('pofsf_offer_get', { offer_id: offer.id });
		assertSuccess(response);
		const data = { ...response.data.offer, template_id: String(response.data.offer.template_id || 0), fields: withKeys(response.data.offer.fields) };
		setForm(data);
		setOriginal(data);
	};

	useEffect(() => {
		if (creating) {
			return;
		}

		loadOffer().catch((err) => setError(err?.message));
	}, [creating, offer?.id]); // eslint-disable-line react-hooks/exhaustive-deps

	// A new customer brings their own shortlist; copy already written stays.
	const chooseCustomer = async (chosen) => {
		setError(null);

		if (!chosen) {
			setForm((current) => ({ ...current, customer: null, suggested: [] }));
			return;
		}

		setLoadingCustomer(true);

		try {
			const response = await ajaxAction('pofsf_offer_new', customerParams(chosen));
			assertSuccess(response);
			const blank = response.data.offer;

			setForm((current) => ({
				...current,
				customer: blank.customer,
				suggested: blank.suggested,
				limits: blank.limits,
				expires_on: current.expires_on || blank.expires_on,
				max_uses: current.max_uses === '' ? blank.max_uses : current.max_uses,
				coupon: current.coupon || blank.coupon,
			}));
		} catch (err) {
			setError(err?.message);
			setForm((current) => ({ ...current, customer: null, suggested: [] }));
		} finally {
			setLoadingCustomer(false);
		}
	};

	// Opened for a customer (Customers tab): start with them. For a segment
	// (Segments tab): a group of its customers with an account; the
	// suggestions follow below.
	useEffect(() => {
		if (creating && initialCustomer) {
			chooseCustomer(initialCustomer);
		}

		if (creating && initialSegment) {
			setForm((current) => ({
				...current,
				type: 'group',
				recipients: initialSegment.recipients || [],
				segment: { id: initialSegment.id, name: initialSegment.name },
			}));
		}
	}, []); // eslint-disable-line react-hooks/exhaustive-deps

	// Group and public offers have no single customer.
	const chooseType = async (type) => {
		setError(null);

		// Back to the saved type: its customer, group and suggestions return.
		if (!creating && type === original.type) {
			setForm((current) => ({
				...current,
				type,
				customer: original.customer,
				recipients: original.recipients,
				suggested: original.suggested,
			}));
			return;
		}

		setForm((current) => ({
			...current,
			type,
			customer: null,
			suggested: [],
			segment: type === 'group' ? current.segment : null,
			// A saved offer's copy stays editable while a customer is chosen.
			limits: creating ? null : current.limits,
		}));

		if (type === 'single') {
			return;
		}

		setLoadingCustomer(true);

		try {
			const response = await ajaxAction('pofsf_offer_new', { type, customer_ids: JSON.stringify(form.recipients.map((item) => item.id)) });
			assertSuccess(response);
			const blank = response.data.offer;

			setForm((current) =>
				current.type === type
					? {
						...current,
						suggested: blank.suggested,
						limits: blank.limits,
						expires_on: current.expires_on || blank.expires_on,
						max_uses: current.max_uses === '' ? blank.max_uses : current.max_uses,
						coupon: current.coupon || blank.coupon,
					}
					: current
			);
		} catch (err) {
			setError(err?.message);
		} finally {
			setLoadingCustomer(false);
		}
	};

	// A new group's suggestions follow its customers: what they have in common.
	// For a segment: what its customers share, whoever is in the group.
	const segmentId = form?.type === 'group' ? form.segment?.id || '' : '';
	const recipientKey = form?.type === 'group' && (creating || original?.type !== 'group') ? form.recipients.map((item) => item.id).join(',') : '';
	const suggestionKey = segmentId ? `segment:${segmentId}` : recipientKey;

	useEffect(() => {
		if (!suggestionKey) {
			return undefined;
		}

		const timer = setTimeout(() => {
			ajaxAction('pofsf_offer_new', { type: 'group', segment: segmentId, customer_ids: JSON.stringify(segmentId ? [] : recipientKey.split(',').map(Number)) })
				.then((response) => {
					assertSuccess(response);
					const blank = response.data.offer;
					setForm((current) =>
						current.type === 'group'
							? {
								...current,
								suggested: blank.suggested,
								limits: current.limits || blank.limits,
								expires_on: current.expires_on || blank.expires_on,
								max_uses: current.max_uses === '' ? blank.max_uses : current.max_uses,
								coupon: current.coupon || blank.coupon,
							}
							: current
					);
				})
				.catch(() => { });
		}, segmentId ? 0 : 600);

		return () => clearTimeout(timer);
	}, [suggestionKey]); // eslint-disable-line react-hooks/exhaustive-deps

	const set = (key, value) => setForm((current) => ({ ...current, [key]: value }));
	const pickedCount = form ? form.picks.length : 0;
	const limits = form?.limits;
	const isPublic = form?.type === 'public';
	const isGroup = form?.type === 'group';
	const offerTabs = [
		{ name: 'basic', title: __('Basic', 'personalized-offers-for-spacefast') },
		{ name: 'coupon', title: __('Coupon', 'personalized-offers-for-spacefast') },
		{ name: 'personalize', title: __('Personalize', 'personalized-offers-for-spacefast') },
		{
			name: 'products',
			title: limits
				? sprintf(
						/* translators: 1: products picked, 2: maximum. */
						__('Products (%1$d/%2$d)', 'personalized-offers-for-spacefast'),
						pickedCount,
						limits.max_picks
					)
				: __('Products', 'personalized-offers-for-spacefast'),
		},
	];

	/** Arrow keys, Home and End move between the form's tabs. */
	const tabKeys = (event) => {
		const index = offerTabs.findIndex(({ name }) => name === tab);
		const moves = { ArrowLeft: index - 1, ArrowRight: index + 1, Home: 0, End: offerTabs.length - 1 };

		if (!(event.key in moves)) {
			return;
		}

		event.preventDefault();
		const next = offerTabs[(moves[event.key] + offerTabs.length) % offerTabs.length].name;
		setTab(next);
		event.currentTarget.parentNode.querySelector(`#pofsf-offer-tab-${next}`)?.focus();
	};
	const recipientIds = (list) => (list || []).map((item) => item.id).sort((a, b) => a - b);

	// Why the offer cannot be saved yet; the field may be in a closed section.
	let problem = '';

	if (form && form.type === 'single' && !form.customer) {
		problem = __('Basic options: choose a customer.', 'personalized-offers-for-spacefast');
	} else if (form && isGroup && form.recipients.length === 0) {
		problem = __('Basic options: add at least one customer to the group.', 'personalized-offers-for-spacefast');
	} else if (form && form.usage_limit && !(maxUsesOf(form) >= 1 && maxUsesOf(form) <= MAX_USES)) {
		problem = sprintf(
			/* translators: %d: highest allowed number of uses. */
			__('Basic options: max uses per offer must be between 1 and %d.', 'personalized-offers-for-spacefast'),
			MAX_USES
		);
	} else if (form && couponProblem(form.coupon)) {
		problem = couponProblem(form.coupon);
	} else if (form && !form.headline.trim()) {
		problem = __('Personalize: the headline cannot be empty.', 'personalized-offers-for-spacefast');
	} else if (form && pickedCount === 0) {
		problem = __('Products: pick at least one product.', 'personalized-offers-for-spacefast');
	}

	const changes = () => {
		const out = {};

		if (form.type !== original.type) {
			out.type = form.type;
		}

		if (form.type === 'single' && customerKey(form.customer) !== customerKey(original.customer)) {
			Object.assign(out, customerParams(form.customer));
		}

		['headline', 'button_text', 'expires_on'].forEach((key) => {
			if ((form[key] || '') !== (original[key] || '')) {
				out[key] = form[key];
			}
		});

		if (JSON.stringify(fieldsOf(form.fields)) !== JSON.stringify(fieldsOf(original.fields))) {
			out.fields = fieldsOf(form.fields);
		}

		if (maxUsesOf(form) !== maxUsesOf(original)) {
			out.max_uses = maxUsesOf(form);
		}

		// An offer without a coupon gets one on any save.
		if (form.coupon && (original.coupon_missing || JSON.stringify(form.coupon) !== JSON.stringify(original.coupon))) {
			out.coupon = form.coupon;
		}

		// The same template again when it was edited, so the offer takes its new version.
		if (form.template_id !== original.template_id || templateRefresh > 0) {
			out.template_id = Number(form.template_id);
		}

		if (JSON.stringify(picksOf(form.picks)) !== JSON.stringify(picksOf(original.picks))) {
			out.picks = picksOf(form.picks);
		}

		if (isGroup && (form.type !== original.type || JSON.stringify(recipientIds(form.recipients)) !== JSON.stringify(recipientIds(original.recipients)))) {
			out.recipients = recipientIds(form.recipients);
		}

		return out;
	};

	/**
	 * Saves; closes the dialog unless `stay` (the "Save offer" button of an
	 * existing offer), which keeps editing the saved version.
	 */
	const save = async (stay = false) => {
		setBusy(true);
		setError(null);
		setSavedNotice(false);

		try {
			if (creating) {
				const response = await ajaxAction('pofsf_offer_create', {
					type: form.type,
					...(form.type === 'single' ? customerParams(form.customer) : { customer_id: 0 }),
					// Recipients stay out of offerInput(), so changing them does not re-render the preview.
					// Coupon settings stay out of offerInput() too: they do not change the page.
					offer: JSON.stringify({
						...offerInput(form),
						...(isGroup ? { recipients: recipientIds(form.recipients), segment: form.segment?.id || '' } : {}),
						...(form.coupon ? { coupon: form.coupon } : {}),
					}),
				});
				assertSuccess(response, __('The offer could not be created.', 'personalized-offers-for-spacefast'));
				onSaved(response.data.offer);
				return;
			}

			const diff = changes();

			if (Object.keys(diff).length === 0) {
				if (stay) {
					setBusy(false);
				} else {
					onClose();
				}
				return;
			}

			const updated = await saveChanges(offer.id, diff);

			if (!stay) {
				onSaved(updated);
				return;
			}

			onUpdated?.(updated);
			setTemplateRefresh(0);

			try {
				await loadOffer();
			} catch (err) {
				// Saved; the form keeps what was typed.
				setOriginal(form);
			}

			setSavedNotice(true);
			setBusy(false);
		} catch (err) {
			setError(err?.message);
			setBusy(false);
		}
	};

	const updateTemplates = (list) => {
		setOwnTemplates(list);
		onTemplatesChanged?.(list);
	};

	// The saved offer's template was deleted (the offer keeps its copy of it).
	const deletedTemplate = !creating && original && templateDeleted(original.template_id, templates)
		? { id: original.template_id, name: offer.template }
		: null;
	const { restore, restoring, restored, restoreError } = useTemplateRestore(offer?.id, (restoredId, list) => {
		updateTemplates(list);
		// The restored template is the offer's saved template; a template chosen meanwhile stays chosen.
		setOriginal((current) => ({ ...current, template_id: restoredId }));
		setForm((current) => (current.template_id === original.template_id ? { ...current, template_id: restoredId } : current));
	});

	const selectedTemplate = form ? templates.find((template) => String(template.id) === form.template_id) : null;

	/**
	 * The template as the editor opens it: its blocks show this form's texts
	 * and products (also unsaved ones), and the samples where they are empty.
	 */
	const withOfferCopy = async (template) => {
		try {
			const response = await ajaxAction('pofsf_template_editor_copy', {
				copy: JSON.stringify({ headline: form.headline, button_text: form.button_text || '', fields: fieldsOf(form.fields), picks: picksOf(form.picks) }),
			});
			assertSuccess(response);

			return { ...template, editUrl: addQueryArgs(template.editUrl, { pofsf_copy: response.data.key }) };
		} catch (err) {
			// The editor still opens, with the sample texts.
			return template;
		}
	};

	// Opens the chosen custom template in the block editor (built-in ones are read-only).
	const editTemplate = async () => {
		if (!selectedTemplate || selectedTemplate.builtin) {
			return;
		}

		setTemplateBusy(true);
		setError(null);
		setEditingTemplate(await withOfferCopy(selectedTemplate));
		setTemplateBusy(false);
	};

	// Copies the chosen template, switches this offer to the copy and opens it in the block editor.
	const duplicateTemplate = async () => {
		if (!selectedTemplate) {
			return;
		}

		setTemplateBusy(true);
		setError(null);

		try {
			const response = await ajaxAction('pofsf_template_create', { source_id: selectedTemplate.id });
			assertSuccess(response);
			updateTemplates(response.data.templates);
			set('template_id', String(response.data.template_id));
			setEditingTemplate(
				await withOfferCopy(
					response.data.templates.find((template) => template.id === response.data.template_id) || {
						id: response.data.template_id,
						name: '',
						editUrl: response.data.editUrl,
					}
				)
			);
		} catch (err) {
			setError(err?.message);
		} finally {
			setTemplateBusy(false);
		}
	};

	const backToOffer = async () => {
		if (!confirmLeaveTemplate(templateFrame)) {
			return;
		}

		const edited = editingTemplate;
		setEditingTemplate(null);

		try {
			const response = await ajaxAction('pofsf_templates_list');
			assertSuccess(response);
			updateTemplates(response.data.templates);
			const fresh = response.data.templates.find((template) => template.id === edited.id);

			// Saved in the editor, or the offer's copy was already older than the template.
			if (!fresh || fresh.updatedAt !== edited.updatedAt || (original?.template_outdated && String(edited.id) === original.template_id)) {
				setTemplateRefresh((count) => count + 1);
			}
		} catch (err) {
			// Unknown whether it was saved: take the template as it is now.
			setTemplateRefresh((count) => count + 1);
		}
	};

	const close = () => {
		if (!editingTemplate || confirmLeaveTemplate(templateFrame)) {
			onClose();
		}
	};

	const needsCustomer = creating && !limits && (
		<p className="pofsf-muted">
			{loadingCustomer ? <Spinner /> : __('Choose a customer under Basic options first.', 'personalized-offers-for-spacefast')}
		</p>
	);

	return (
		<Modal
			className={editingTemplate ? 'pofsf-offer-modal is-editing-template' : 'pofsf-offer-modal'}
			title={
				editingTemplate
					? sprintf(
						/* translators: %s: template name. */
						__('Edit template: %s', 'personalized-offers-for-spacefast'),
						editingTemplate.name
					)
					: creating
						? __('Create new offer', 'personalized-offers-for-spacefast')
						: offer.type === 'public'
							? sprintf(
								/* translators: %d: offer ID. */
								__('Edit public offer #%d', 'personalized-offers-for-spacefast'),
								offer.id
							)
							: offer.type === 'group'
								? sprintf(
									/* translators: %d: offer ID. */
									__('Edit group offer #%d', 'personalized-offers-for-spacefast'),
									offer.id
								)
								: sprintf(
									/* translators: 1: offer ID, 2: customer name. */
									__('Edit offer #%1$d for %2$s', 'personalized-offers-for-spacefast'),
									offer.id,
									offer.customer.name
								)
			}
			onRequestClose={busy ? () => { } : close}
			shouldCloseOnClickOutside={!editingTemplate}
			size="fill"
			headerActions={
				editingTemplate ? (
					<Button size="compact" variant="secondary" icon={arrowLeft} onClick={backToOffer}>
						{__('Back to offer edit', 'personalized-offers-for-spacefast')}
					</Button>
				) : (
					form && (
						<div className="pofsf-offer-modal__template-bar">

								{(deletedTemplate || restored || restoreError) && (
									<Dropdown
										className="pofsf-offer-modal__template-alert"
										popoverProps={{ placement: 'bottom-end' }}
										defaultOpen={false}
										renderToggle={({ isOpen, onToggle }) => (
											<Button
												size="compact"
												icon={deletedTemplate || restoreError ? caution : check}
												className={deletedTemplate || restoreError ? 'is-warning' : 'is-success'}
												label={deletedTemplate
													? __('The template was deleted', 'personalized-offers-for-spacefast')
													: __('Template restored', 'personalized-offers-for-spacefast')}
												showTooltip
												onClick={onToggle}
												aria-expanded={isOpen}
											/>
										)}
										renderContent={() => (
											<TemplateAlertContent restored={restored && !deletedTemplate}>
												{deletedTemplate && (
													<DeletedTemplateMessage name={deletedTemplate.name} restoring={restoring} disabled={busy || templateBusy} onRestore={restore} />
												)}
												{restored && !deletedTemplate && <p>{RESTORED_MESSAGE()}</p>}
												{restoreError && (
													<Notice status="error" isDismissible={false}>
														{restoreError}
													</Notice>
												)}
											</TemplateAlertContent>
										)}
									/>
								)}

								<SelectControl
								__nextHasNoMarginBottom
									size="compact"
									label={__('Template', 'personalized-offers-for-spacefast')}
									labelPosition="side"
									value={form.template_id}
									onChange={(value) => set('template_id', value)}
									options={templateOptions(templates, deletedTemplate)}
									disabled={busy || templateBusy}
								/>

							{selectedTemplate && (
								<>
									<Tooltip
										text={
											selectedTemplate.builtin
												? __('Built-in templates can’t be changed. Use Duplicate & edit template to customize it.', 'personalized-offers-for-spacefast')
												: __('Opens the template in the block editor. Saving the template updates this offer and every other offer that uses it.', 'personalized-offers-for-spacefast')
										}
									>
										<Button
											variant="secondary"
											size="compact"
											icon={pencil}
											onClick={editTemplate}
											isBusy={templateBusy}
											disabled={busy || templateBusy || selectedTemplate.builtin}
											accessibleWhenDisabled
										>
											{__('Edit template', 'personalized-offers-for-spacefast')}
										</Button>
									</Tooltip>
									<Tooltip text={__('A new template for this offer. Will be possible to use in future offers', 'personalized-offers-for-spacefast')}>
										<Button
											variant="secondary"
											size="compact"
											icon={copy}
											onClick={duplicateTemplate}
											isBusy={templateBusy}
											disabled={busy || templateBusy}
											accessibleWhenDisabled
										>
											{__('Duplicate & edit template', 'personalized-offers-for-spacefast')}
										</Button>
									</Tooltip>
								</>
							)}
						</div>
					)
				)
			}
		>
			{editingTemplate && <TemplateEditorFrame template={editingTemplate} frameRef={templateFrame} />}

			{/* Hidden, not removed, while the template editor is open, so the form keeps its state. */}
			<div className="pofsf-offer-modal__layout" hidden={Boolean(editingTemplate)}>
				{form ? (
					<OfferPreview offerId={creating ? 0 : offer.id} input={{ ...offerInput(form), refresh_template: templateRefresh }} />
				) : (
					<div className="pofsf-offer-modal__preview">{!error && <Spinner />}</div>
				)}

				<div className="pofsf-offer-modal__sidebar">
					{form && (
						<div className="pofsf-offer-form">
							<div className="components-tab-panel__tabs pofsf-offer-form__tabs" role="tablist">
								{offerTabs.map(({ name, title }) => (
									<button
										key={name}
										type="button"
										role="tab"
										id={`pofsf-offer-tab-${name}`}
										aria-controls={`pofsf-offer-pane-${name}`}
										aria-selected={tab === name}
										tabIndex={tab === name ? 0 : -1}
										className={`components-button components-tab-panel__tabs-item${tab === name ? ' is-active' : ''}`}
										onClick={() => setTab(name)}
										onKeyDown={tabKeys}
									>
										{title}
									</button>
								))}
							</div>

							<div className="pofsf-offer-form__pane" role="tabpanel" id="pofsf-offer-pane-basic" aria-labelledby="pofsf-offer-tab-basic" hidden={tab !== 'basic'}>
								<RadioControl
									label={__('Offer type', 'personalized-offers-for-spacefast')}
									selected={form.type}
									onChange={chooseType}
									disabled={busy}
									options={[
										{
											label: __('One customer — personalized from their order history', 'personalized-offers-for-spacefast'),
											value: 'single',
										},
										{
											label: __('Group — the same offer for chosen customers, each with a personal link', 'personalized-offers-for-spacefast'),
											value: 'group',
										},
										{
											label: __('Public — one link anyone can use, nothing personal', 'personalized-offers-for-spacefast'),
											value: 'public',
										},
									]}
								/>
								{!creating && original && <TypeChangeNote from={original.type} to={form.type} />}
								{form.type === 'single' && (
									<CustomerPicker customer={form.customer} onChange={chooseCustomer} disabled={busy || loadingCustomer} />
								)}
								{isGroup && creating && form.segment && (
									<Notice status="info" isDismissible={false} className="pofsf-offer-form__segment">
										{sprintf(
											/* translators: %s: segment name. */
											__('For the segment “%s”: its customers with an account, and products picked from what they share. Change either below.', 'personalized-offers-for-spacefast'),
											form.segment.name
										)}
									</Notice>
								)}
								{isGroup && (
									<RecipientsField
										recipients={form.recipients}
										max={form.max_recipients || 100}
										editing={!creating}
										pageUrl={form.page_url || ''}
										onChange={(value) => set('recipients', value)}
										disabled={busy}
									/>
								)}
								<TextControl
									__nextHasNoMarginBottom
									__next40pxDefaultSize
									type="date"
									label={__('Expires on', 'personalized-offers-for-spacefast')}
									help={__('The offer and its coupon stop working at the end of this day.', 'personalized-offers-for-spacefast')}
									value={form.expires_on}
									onChange={(value) => set('expires_on', value)}
								/>
								{!creating && <PublishedNote offer={offer} />}
							</div>

							<div className="pofsf-offer-form__pane" role="tabpanel" id="pofsf-offer-pane-coupon" aria-labelledby="pofsf-offer-tab-coupon" hidden={tab !== 'coupon'}>
								{form.coupon ? <CouponFields form={form} set={set} /> : needsCustomer}
							</div>

							<div className="pofsf-offer-form__pane" role="tabpanel" id="pofsf-offer-pane-personalize" aria-labelledby="pofsf-offer-tab-personalize" hidden={tab !== 'personalize'}>
								{!creating && selectedTemplate && form.template_id === original?.template_id && (
									<TemplateVersionNote
										name={selectedTemplate.name}
										outdated={Boolean(original.template_outdated)}
										refreshed={templateRefresh > 0}
										onRefresh={() => setTemplateRefresh((count) => count + 1)}
									/>
								)}
								{limits ? (
									<CopyFields form={form} set={set} limits={limits} />
								) : (
									needsCustomer
								)}
							</div>

							<div className="pofsf-offer-form__pane" role="tabpanel" id="pofsf-offer-pane-products" aria-labelledby="pofsf-offer-tab-products" hidden={tab !== 'products'}>
								{limits ? (
									<ProductPicker picks={form.picks} suggested={form.suggested} limits={limits} suggestedLabel={
										isPublic
											? __('Your bestsellers. Search to find any product.', 'personalized-offers-for-spacefast')
											: isGroup
												? __('Popular with these customers, then your bestsellers. Search to find any product.', 'personalized-offers-for-spacefast')
												: undefined
									} onChange={(next) => setForm((current) => ({ ...current, picks: typeof next === 'function' ? next(current.picks) : next }))} />
								) : (
									needsCustomer
								)}
							</div>
						</div>
					)}
				</div>
			</div>

			<div className="pofsf-offer-modal__footer" hidden={Boolean(editingTemplate)}>
				{form && problem && (
					<p className="pofsf-offer-form__problem" role="status">
						{problem}
					</p>
				)}

				{error && (
					<Notice status="error" isDismissible={false}>
						{error}
					</Notice>
				)}

				{savedNotice && !error && (
					<Notice status="success" onRemove={() => setSavedNotice(false)}>
						{__('Offer saved.', 'personalized-offers-for-spacefast')}
					</Notice>
				)}

				<ModalActions
					busy={busy}
					onClose={onClose}
					onSave={() => save(false)}
					disabled={!form || problem !== '' || loadingCustomer}
					label={creating ? __('Create offer', 'personalized-offers-for-spacefast') : __('Save offer and close', 'personalized-offers-for-spacefast')}
					onSaveOnly={creating ? undefined : () => save(true)}
					saveOnlyLabel={__('Save offer', 'personalized-offers-for-spacefast')}
					saveOnlyDisabled={!form || !original || Object.keys(changes()).length === 0}
				/>
			</div>
		</Modal>
	);
}

export function EditOfferModal(props) {
	return <OfferFormModal {...props} />;
}

export function CreateOfferModal(props) {
	return <OfferFormModal {...props} offer={null} />;
}
