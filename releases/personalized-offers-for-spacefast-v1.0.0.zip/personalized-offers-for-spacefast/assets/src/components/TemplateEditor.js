/**
 * The block editor for one offer template, in an iframe. Shared by the
 * Templates tab (its own full-screen modal) and the Edit offer modal
 * (shown in place of the offer form).
 */
import { useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Spinner } from '@wordpress/components';

/**
 * Whether the editor in frameRef has unsaved changes.
 */
export function isTemplateDirty(frameRef) {
	try {
		return Boolean(frameRef.current?.contentWindow?.wp?.data?.select('core/editor')?.isEditedPostDirty());
	} catch (e) {
		return false;
	}
}

/**
 * True when the editor may be left: no unsaved changes, or the user
 * confirms losing them.
 */
export function confirmLeaveTemplate(frameRef) {
	// eslint-disable-next-line no-alert
	return !isTemplateDirty(frameRef) || window.confirm(__('This template has unsaved changes. Leave the editor anyway?', 'personalized-offers-for-spacefast'));
}

/**
 * Saves the template open in frameRef's block editor. Resolves when the
 * save succeeded (or there was nothing to save), rejects otherwise.
 */
export async function saveTemplate(frameRef) {
	const data = frameRef.current?.contentWindow?.wp?.data;

	if (!data?.select('core/editor')) {
		throw new Error(__('The editor is still loading. Try again in a moment.', 'personalized-offers-for-spacefast'));
	}

	if (!data.select('core/editor').isEditedPostDirty()) {
		return;
	}

	await data.dispatch('core/editor').savePost();

	if (!data.select('core/editor').didPostSaveRequestSucceed()) {
		throw new Error(__('The template could not be saved. Check the editor for details.', 'personalized-offers-for-spacefast'));
	}
}

export function TemplateEditorFrame({ template, frameRef }) {
	const [loading, setLoading] = useState(true);

	return (
		<div className="pofsf-template-editor">
			{loading && (
				<div className="pofsf-template-editor__loading">
					<Spinner />
				</div>
			)}
			<iframe
				ref={frameRef}
				title={__('Template editor', 'personalized-offers-for-spacefast')}
				src={template.editUrl}
				onLoad={() => setLoading(false)}
			/>
		</div>
	);
}
