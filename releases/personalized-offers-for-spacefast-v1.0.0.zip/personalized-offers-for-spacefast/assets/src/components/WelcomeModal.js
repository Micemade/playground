/**
 * First-run welcome: what the plugin does, capture the brand, connect
 * Spacefast (sign in, paste a key, or skip), then a first offer. Opens by
 * itself once per user after a fresh install (Admin\Welcome), from the Setup
 * guide button, and on return from the Spacefast sign-in.
 */
import { useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { Button, ExternalLink, Modal, Notice, RadioControl } from '@wordpress/components';
import { Icon, check } from '@wordpress/icons';
import { ajaxAction, assertSuccess } from '../api';
import SpacefastConnect from './SpacefastConnect';

const STEPS = ['welcome', 'brand', 'spacefast', 'done'];

/*
 * After the sign-in round trip the modal opens on the step it came back
 * to: Done when connected, the Spacefast step for a team choice or an error.
 */
function firstStep(oauth) {
	if (oauth?.step === 'connected') {
		return STEPS.indexOf('done');
	}

	return ['team', 'error'].includes(oauth?.step) ? STEPS.indexOf('spacefast') : 0;
}

function BrandPreview({ brand }) {
	return (
		<div className="pofsf-welcome__brand">
			{brand.logo && <img src={brand.logo} alt="" className="pofsf-welcome__brand-logo" />}
			<div>
				<strong>{brand.name || __('Your store', 'personalized-offers-for-spacefast')}</strong>
				{brand.colors.length > 0 && (
					<div className="pofsf-welcome__swatches" aria-hidden="true">
						{brand.colors.map((color) => (
							<span key={color} className="pofsf-welcome__swatch" style={{ background: color }} title={color} />
						))}
					</div>
				)}
			</div>
		</div>
	);
}

function Done({ done, children }) {
	return (
		<li className={done ? 'is-done' : ''}>
			{done ? (
				<Icon icon={check} size={20} className="pofsf-welcome__check" />
			) : (
				<span className="pofsf-welcome__check pofsf-welcome__todo" aria-hidden="true">–</span>
			)}
			{children}
		</li>
	);
}

function KeySteps({ spacefast, dashboardUrl, onSpacefastChange }) {
	return (
		<>
			<ol className="pofsf-welcome__how">
				<li>
					{__('No account yet?', 'personalized-offers-for-spacefast')}{' '}
					<ExternalLink href={dashboardUrl}>
						{__('Create a free Spacefast account', 'personalized-offers-for-spacefast')}
					</ExternalLink>
				</li>
				<li>{__('In the Spacefast dashboard, create a team API key.', 'personalized-offers-for-spacefast')}</li>
				<li>{__('Paste it here and click Connect.', 'personalized-offers-for-spacefast')}</li>
			</ol>
			<SpacefastConnect status={spacefast} dashboardUrl={dashboardUrl} onChange={onSpacefastChange} hideHelp />
		</>
	);
}

/**
 * For an account with several teams: Spacefast's approval page doesn't
 * ask which one, so the modal does. Cancel discards the sign-in.
 */
function TeamPicker({ teams, onPicked, onError }) {
	const [team, setTeam] = useState(teams[0]?.id || '');
	const [busy, setBusy] = useState(false);

	const pick = async (teamId) => {
		setBusy(true);
		onError(null);

		try {
			const response = await ajaxAction('pofsf_spacefast_pick_team', { team_id: teamId });
			assertSuccess(response);
			onPicked(response.data.spacefast, teamId !== '');
		} catch (err) {
			onError(err?.message);
			onPicked(null, false);
		} finally {
			setBusy(false);
		}
	};

	return (
		<div className="pofsf-welcome__teams">
			<RadioControl
				label={__('Your Spacefast account has several teams. Which one should publish this store’s offers?', 'personalized-offers-for-spacefast')}
				selected={team}
				options={teams.map((item) => ({ label: item.name || item.slug || item.id, value: item.id }))}
				onChange={setTeam}
			/>
			<div className="pofsf-welcome__teams-actions">
				<Button variant="primary" isBusy={busy} disabled={busy || !team} onClick={() => pick(team)}>
					{__('Connect this team', 'personalized-offers-for-spacefast')}
				</Button>
				<Button variant="tertiary" disabled={busy} onClick={() => pick('')}>
					{__('Cancel', 'personalized-offers-for-spacefast')}
				</Button>
			</div>
		</div>
	);
}

export default function WelcomeModal({ initialBrand, spacefast, dashboardUrl, oauth, onSpacefastChange, onCreateOffer, onClose }) {
	const [step, setStep] = useState(() => firstStep(oauth));
	const [brand, setBrand] = useState(initialBrand || null);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState(oauth?.step === 'error' ? oauth.error : null);
	const [teams, setTeams] = useState(oauth?.step === 'team' ? oauth.teams || [] : []);
	const [useKey, setUseKey] = useState(false);
	const name = STEPS[step];
	const canSignIn = Boolean(oauth?.available);
	const connected = Boolean(spacefast.connected && !spacefast.reconnect);

	const close = () => {
		// Remembered for this user, so the modal doesn't open by itself again.
		ajaxAction('pofsf_welcome_done').catch(() => {});
		onClose();
	};

	const capture = async () => {
		setBusy(true);
		setError(null);

		try {
			const response = await ajaxAction('pofsf_lock_brand');
			assertSuccess(response, __('Brand capture failed.', 'personalized-offers-for-spacefast'));
			setBrand(response.data.brand || null);
		} catch (err) {
			setError(err?.message);
		} finally {
			setBusy(false);
		}
	};

	const next = () => {
		setError(null);
		setStep((current) => Math.min(current + 1, STEPS.length - 1));
	};

	const back = () => {
		setError(null);
		setStep((current) => Math.max(current - 1, 0));
	};

	const signIn = (
		<div className="pofsf-welcome__signin">
			<Button variant="primary" href={oauth?.startUrl} __next40pxDefaultSize>
				{spacefast.reconnect
					? __('Reconnect with Spacefast', 'personalized-offers-for-spacefast')
					: __('Continue with Spacefast', 'personalized-offers-for-spacefast')}
			</Button>
			<p className="pofsf-muted">
				{__('Sign in, or create a free account. It takes a minute, and you come back here.', 'personalized-offers-for-spacefast')}
			</p>
			<p>
				<Button variant="link" onClick={() => setUseKey(true)}>
					{__('Use an API key instead', 'personalized-offers-for-spacefast')}
				</Button>{' '}
				<span className="pofsf-muted">{__('(needed for live updates)', 'personalized-offers-for-spacefast')}</span>
			</p>
		</div>
	);

	return (
		<Modal
			className="pofsf-welcome"
			title={__('Welcome to Personalized Offers', 'personalized-offers-for-spacefast')}
			onRequestClose={close}
			size="medium"
		>
			<p className="pofsf-welcome__progress">
				{sprintf(
					/* translators: 1: current step number, 2: number of steps. */
					__('Step %1$d of %2$d', 'personalized-offers-for-spacefast'),
					step + 1,
					STEPS.length
				)}
			</p>

			{error && (
				<Notice status="error" isDismissible onRemove={() => setError(null)}>
					{error}
				</Notice>
			)}

			{name === 'welcome' && (
				<div className="pofsf-welcome__step">
					<h2>{__('A personal offer page for every customer', 'personalized-offers-for-spacefast')}</h2>
					<ul className="pofsf-welcome__points">
						<li>{__('Your store learns what each customer likes from their orders and wishlist.', 'personalized-offers-for-spacefast')}</li>
						<li>{__('The plugin picks products they haven’t bought yet and writes an on-brand offer page.', 'personalized-offers-for-spacefast')}</li>
						<li>{__('Each page is published privately on Spacefast. One click brings the customer back with a filled cart and the discount applied.', 'personalized-offers-for-spacefast')}</li>
					</ul>
					<p>{__('Setup takes about two minutes: capture your brand and connect Spacefast.', 'personalized-offers-for-spacefast')}</p>
				</div>
			)}

			{name === 'brand' && (
				<div className="pofsf-welcome__step">
					<h2>{__('Your brand', 'personalized-offers-for-spacefast')}</h2>
					<p>
						{__('Offer pages use your logo, colours and fonts. Capture them from your site in one click. Each capture is kept as a version, so a later redesign never changes offers you’ve already sent.', 'personalized-offers-for-spacefast')}
					</p>
					{brand && <BrandPreview brand={brand} />}
					<Button variant={brand ? 'secondary' : 'primary'} isBusy={busy} disabled={busy} onClick={capture}>
						{brand
							? __('Capture again', 'personalized-offers-for-spacefast')
							: __('Capture my brand', 'personalized-offers-for-spacefast')}
					</Button>
				</div>
			)}

			{name === 'spacefast' && (
				<div className="pofsf-welcome__step">
					<h2>{__('Publish with Spacefast', 'personalized-offers-for-spacefast')}</h2>
					<p>
						{__('Spacefast hosts each offer as its own small website, private by default, so offer pages never load your store’s server. You can start on its free plan.', 'personalized-offers-for-spacefast')}
					</p>

					{teams.length > 0 && (
						<TeamPicker
							teams={teams}
							onError={setError}
							onPicked={(status, picked) => {
								setTeams([]);

								if (status) {
									onSpacefastChange(status);
								}

								if (picked) {
									next();
								}
							}}
						/>
					)}

					{teams.length === 0 && connected && (
						<>
							<p className="pofsf-welcome__connected">
								<Icon icon={check} size={20} />
								{spacefast.auth === 'oauth'
									? sprintf(
										/* translators: 1: Spacefast team name, 2: email address of the Spacefast account. */
										__('Connected to %1$s, signed in as %2$s.', 'personalized-offers-for-spacefast'),
										spacefast.team_name || spacefast.team_id,
										spacefast.account_email
									)
									: sprintf(
										/* translators: %s: Spacefast team name. */
										__('Connected to %s with an API key.', 'personalized-offers-for-spacefast'),
										spacefast.team_name || spacefast.team_id
									)}
							</p>
							{spacefast.auth !== 'oauth' && canSignIn && !spacefast.from_constant && (
								<p className="pofsf-muted">
									<Button variant="link" href={oauth.startUrl}>
										{__('Switch to signing in with Spacefast', 'personalized-offers-for-spacefast')}
									</Button>{' '}
									{__('(this turns live updates off: they need an API key)', 'personalized-offers-for-spacefast')}
								</p>
							)}
						</>
					)}

					{teams.length === 0 && !connected && (
						<>
							{spacefast.reconnect && (
								<Notice status="warning" isDismissible={false}>
									{__('Your Spacefast sign-in expired or was revoked. Sign in again to keep publishing.', 'personalized-offers-for-spacefast')}
								</Notice>
							)}
							{canSignIn && !useKey ? (
								signIn
							) : (
								<>
									{!canSignIn && oauth?.needsHttps && (
										<p className="pofsf-muted">
											{__('Signing in with Spacefast needs a site address that starts with https://. Use an API key instead.', 'personalized-offers-for-spacefast')}
										</p>
									)}
									<KeySteps spacefast={spacefast} dashboardUrl={dashboardUrl} onSpacefastChange={onSpacefastChange} />
									{canSignIn && (
										<p>
											<Button variant="link" onClick={() => setUseKey(false)}>
												{__('Sign in with Spacefast instead', 'personalized-offers-for-spacefast')}
											</Button>
										</p>
									)}
								</>
							)}
							<p className="pofsf-muted">
								{__('Not now? Skip this step: you can still preview offers and download them as ZIP files, and connect later from the top of this page.', 'personalized-offers-for-spacefast')}
							</p>
						</>
					)}
				</div>
			)}

			{name === 'done' && (
				<div className="pofsf-welcome__step">
					<h2>{__('You’re ready', 'personalized-offers-for-spacefast')}</h2>
					<ul className="pofsf-welcome__summary">
						<Done done={Boolean(brand)}>
							{brand
								? __('Brand captured', 'personalized-offers-for-spacefast')
								: __('Brand not captured yet: you can do it later in the Settings tab.', 'personalized-offers-for-spacefast')}
						</Done>
						<Done done={connected}>
							{connected
								? sprintf(
									/* translators: %s: Spacefast team name. */
									__('Spacefast connected: %s', 'personalized-offers-for-spacefast'),
									spacefast.team_name || spacefast.team_id
								)
								: __('Spacefast not connected: offers can be previewed and downloaded as ZIP files.', 'personalized-offers-for-spacefast')}
						</Done>
					</ul>
					<p>
						{__('Start with your most loyal customer: open their profile in the Customers tab and click Create offer.', 'personalized-offers-for-spacefast')}
					</p>
				</div>
			)}

			<div className="pofsf-welcome__footer">
				{step > 0 && step < STEPS.length - 1 && (
					<Button variant="tertiary" onClick={back}>
						{__('Back', 'personalized-offers-for-spacefast')}
					</Button>
				)}
				<span className="pofsf-welcome__spacer" />
				{name === 'welcome' && (
					<Button variant="primary" onClick={next}>
						{__('Get started', 'personalized-offers-for-spacefast')}
					</Button>
				)}
				{name === 'brand' && (
					<Button variant={brand ? 'primary' : 'tertiary'} onClick={next} disabled={busy}>
						{brand ? __('Next', 'personalized-offers-for-spacefast') : __('Skip', 'personalized-offers-for-spacefast')}
					</Button>
				)}
				{name === 'spacefast' && teams.length === 0 && (
					<Button variant={connected ? 'primary' : 'tertiary'} onClick={next}>
						{connected
							? __('Next', 'personalized-offers-for-spacefast')
							: __('Skip for now', 'personalized-offers-for-spacefast')}
					</Button>
				)}
				{name === 'done' && (
					<>
						<Button variant="tertiary" onClick={close}>
							{__('Close', 'personalized-offers-for-spacefast')}
						</Button>
						<Button
							variant="primary"
							onClick={() => {
								close();
								onCreateOffer();
							}}
						>
							{__('Go to Customers', 'personalized-offers-for-spacefast')}
						</Button>
					</>
				)}
			</div>
		</Modal>
	);
}
