/**
 * admin-ajax client built on @wordpress/api-fetch.
 *
 * apiFetch only forces a JSON Content-Type when the `data` option is used.
 * Passing a URLSearchParams `body` lets fetch set
 * `application/x-www-form-urlencoded` itself, so PHP populates $_POST
 * and check_ajax_referer() finds the nonce in the request body.
 */
import apiFetch from '@wordpress/api-fetch';
import { __ } from '@wordpress/i18n';

const DEFAULT_TIMEOUT = 60000;

export function ajaxAction(action, params = {}, { timeout = DEFAULT_TIMEOUT } = {}) {
	const config = window.pofsfAdmin || {};

	const body = new URLSearchParams({
		action,
		nonce: config.nonce || '',
		...params,
	});

	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), timeout);

	return apiFetch({
		url: config.ajaxUrl,
		method: 'POST',
		body,
		signal: controller.signal,
	})
		.catch((error) => {
			if (error && error.name === 'AbortError') {
				throw new Error(
					__('The request timed out. Please try again.', 'personalized-offers-for-spacefast')
				);
			}
			throw error;
		})
		.finally(() => clearTimeout(timer));
}

/**
 * apiFetch resolves HTTP 200 responses even when they carry a
 * wp_send_json_error() envelope ({success: false}). Fail loudly so
 * callers never mistake an error envelope for data.
 */
export function assertSuccess(response, fallbackMessage) {
	if (response && response.success === true) {
		return response;
	}

	const message =
		response?.data?.message ||
		fallbackMessage ||
		__('Unexpected server response.', 'personalized-offers-for-spacefast');

	throw new Error(String(message));
}

const ASSISTANT_CHANGED = 'pofsf:assistant-changed';

/**
 * The assistant sidebar stays open beside the Offers and Templates tabs,
 * so lists listen for what it changed and reload themselves.
 */
export function announceAssistantChanges(abilities, details = {}) {
	window.dispatchEvent(new CustomEvent(ASSISTANT_CHANGED, { detail: { ...details, abilities } }));
}

/**
 * Calls `callback` (with the event details, e.g. `offerIds`) when the
 * assistant ran one of `abilities`; returns the unsubscribe function.
 */
export function onAssistantChanges(abilities, callback) {
	const listener = (event) => {
		if (event.detail.abilities.some((ability) => abilities.includes(ability))) {
			callback(event.detail);
		}
	};

	window.addEventListener(ASSISTANT_CHANGED, listener);

	return () => window.removeEventListener(ASSISTANT_CHANGED, listener);
}

/**
 * The sandbox of an iframe that shows a rendered page with its scripts
 * (offer and template previews): no same-origin access to the admin,
 * unless the site allows it with the `pofsf_preview_same_origin` filter.
 * WordPress Playground needs it: a page without its origin is not served
 * by Playground's service worker.
 */
export const SCRIPTED_PREVIEW_SANDBOX = `allow-scripts allow-popups allow-popups-to-escape-sandbox allow-forms${window.pofsfAdmin?.previewSameOrigin ? ' allow-same-origin' : ''}`;
